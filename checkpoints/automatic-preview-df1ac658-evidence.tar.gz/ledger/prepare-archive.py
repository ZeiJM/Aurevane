import hashlib,json,pathlib,subprocess,tarfile
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-16-automatic-preview'
receipt=json.loads((w/'final-check.json').read_text());audit=json.loads((w/'package-log-audit.json').read_text());assert receipt['exit_code']==0 and audit['vitest']==8939 and audit['node']==7
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
bundle=w/'automatic-preview.bundle'
subprocess.run(['git','bundle','create',str(bundle),'4eb8780087d7d83bf9167fb0f6b61c2c10532443..HEAD'],check=True)
evidence=w/'automatic-preview-evidence.tar.gz'
with tarfile.open(evidence,'w:gz') as t:
 for p in sorted(w.iterdir()):
  if p.is_file() and p.suffix in ['.md','.py','.json','.log'] and p.name not in ['backup-payload.json','remote-restoration-proof.json']:
   t.add(p,arcname='ledger/'+p.name)
 for p in sorted(root.parent.glob('automatic-*.log')):
  t.add(p,arcname='witnesses/'+p.name)
 for p in [*root.glob('apps/*/.turbo/turbo-*.log'),*root.glob('packages/*/.turbo/turbo-*.log')]:
  t.add(p,arcname='packages/'+str(p.relative_to(root)))
 t.add(root/'docs/verification/2026-10-16-automatic-event-preview.md',arcname='report.md')
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
meta={'sourceHead':head,'sourceTree':tree,'testedSource':receipt['sourceHead'],'prerequisite':'4eb8780087d7d83bf9167fb0f6b61c2c10532443','prerequisiteArchive':'e506de6d7b038452e8d1b67b87215d5da4f480d5','branch':'agent/event-preview-20261016','tests':{'vitest':8939,'node':7,'focused':345,'new':29},'fullCheck':receipt,'review':{'critical':0,'important':1,'fixed':1,'minor':2,'fixWaves':1,'rereviews':0},'bundle':info(bundle),'evidence':info(evidence),'main':'29506e293e81abef1b0b8a46099618ab3ae3f0ae','deploymentLock':'b8a4e0e3c57b95a8da49c05d1fe5f60ba2181b5f','remaining':'Historical/native/browser/balance/hosted/Atlas/human/release remain open; two new display/copy Minors and fourteen inherited Minors deferred. No deployment.'}
(w/'backup-payload.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
