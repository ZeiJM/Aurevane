import hashlib,json,pathlib,re
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-16-automatic-preview'
receipt=json.loads((w/'final-check.json').read_text());assert receipt['exit_code']==0
rows=[]
for p in sorted([*root.glob('apps/*/.turbo/turbo-test.log'),*root.glob('packages/*/.turbo/turbo-test.log')]):
 raw=p.read_bytes();s=re.sub(r'\x1b\[[0-9;]*m','',raw.decode())
 m=re.search(r'Tests\s+(\d+) passed',s);assert m,p
 node=re.search(r'ℹ tests (\d+)',s)
 rows.append({'path':str(p.relative_to(root)),'vitest':int(m[1]),'node':int(node[1]) if node else 0,'sha256':hashlib.sha256(raw).hexdigest(),'tail':s.splitlines()[-10:]})
assert sum(r['vitest'] for r in rows)==8939
assert sum(r['node'] for r in rows)==7
builds=[]
for name in ['web','worker']:
 p=root/f'apps/{name}/.turbo/turbo-build.log';s=p.read_text()
 assert ('server-rendered on demand' in s) if name=='web' else ('tsc -p tsconfig.build.json' in s)
 builds.append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tail':s.splitlines()[-10:]})
result={'receipt':receipt,'tests':rows,'vitest':8939,'node':7,'builds':builds}
(w/'package-log-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'vitest':8939,'node':7,'packages':len(rows),'builds':len(builds),'exit_code':receipt['exit_code']}))
