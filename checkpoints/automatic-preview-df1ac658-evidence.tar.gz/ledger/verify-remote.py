import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-16-automatic-preview';meta=json.loads((w/'backup-payload.json').read_text());archive=sys.argv[1]
ref='refs/remotes/origin/agent/overhaul-source-backup-20261016'
subprocess.run(['git','fetch','--no-write-fetch-head','origin',f'refs/heads/agent/overhaul-source-backup-20261016:{ref}'],check=True)
assert subprocess.check_output(['git','rev-parse',ref],text=True).strip()==archive
prefix='checkpoints/automatic-preview-'+meta['sourceHead'][:8]
for key,suffix in [('bundle','.bundle'),('evidence','-evidence.tar.gz')]:
 raw=subprocess.check_output(['git','show',f'{archive}:{prefix}{suffix}'])
 assert len(raw)==meta[key]['bytes'] and hashlib.sha256(raw).hexdigest()==meta[key]['sha256']
 assert subprocess.check_output(['git','rev-parse',f'{archive}:{prefix}{suffix}'],text=True).strip()==meta[key]['blobSha']
 if key=='bundle':(w/'downloaded.bundle').write_bytes(raw)
remote_meta=subprocess.check_output(['git','show',f'{archive}:{prefix}.json'])
assert remote_meta==(w/'backup-payload.json').read_bytes()
restore=root.parent/'automatic-restoration-check';restore.mkdir(exist_ok=True)
subprocess.run(['git','init',str(restore)],check=True,capture_output=True)
common=pathlib.Path(subprocess.check_output(['git','rev-parse','--git-common-dir'],text=True).strip()).resolve()
(restore/'.git/objects/info/alternates').write_text(str(common/'objects')+'\n')
(restore/'.git/shallow').write_text(meta['prerequisite']+'\n')
subprocess.run(['git','-C',str(restore),'update-ref','refs/heads/prerequisite',meta['prerequisite']],check=True)
r=subprocess.run(['git','-C',str(restore),'bundle','verify',str(w/'downloaded.bundle')],check=True,capture_output=True,text=True);(w/'bundle-verify.log').write_text(r.stdout+r.stderr)
subprocess.run(['git','-C',str(restore),'fetch',str(w/'downloaded.bundle'),'HEAD'],check=True,capture_output=True)
assert subprocess.check_output(['git','-C',str(restore),'rev-parse','FETCH_HEAD'],text=True).strip()==meta['sourceHead']
assert subprocess.check_output(['git','-C',str(restore),'rev-parse','FETCH_HEAD^{tree}'],text=True).strip()==meta['sourceTree']
proof={'archive':archive,'sourceHead':meta['sourceHead'],'sourceTree':meta['sourceTree'],'prerequisite':meta['prerequisite'],'remoteByteHashesMatch':True,'restoredTipAndTreeMatch':True,'scope':'Incremental bundle restored against retained prerequisite objects via local alternates, with prerequisite shallow boundary. Not an independent cold restoration of all earlier archives.'}
(w/'remote-restoration-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
