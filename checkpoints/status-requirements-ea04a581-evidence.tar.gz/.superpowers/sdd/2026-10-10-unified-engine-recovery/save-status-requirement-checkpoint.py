import subprocess, pathlib, hashlib, json, tarfile, base64, sys

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'status-requirements-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = (workspace / 'status-requirements-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
assert 'passed (' in log and 'ERROR' not in log
prerequisite = '883b63a7e2b16a7d77f44655b395d050208a38d2'
bundle = workspace / ('status-requirements-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + prerequisite], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'status-requirements-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('status-requirements-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T0*.log')):
        if file.name >= '20261016T065200':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-status-requirement-review.md', 'task15-status-requirement-review.diff', 'task15-status-requirement-preflight.md', 'task15-activation-preflight.md', 'status-requirements-tested-source.txt', 'status-requirements-bundle-verify.log', 'save-status-requirement-checkpoint.py']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

manifest = root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'prerequisite': prerequisite, 'previousArchiveCommit': '353b842d32cdbf4d6818e2a17c902cf6b404c029', 'previousArchiveTree': 'ac35ef152887f84f7e2312390848024dd4efb16d', 'manifestSha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': 'Bounded executable24authorable statuses plus actual LoweredGuard/system and Displaced/history,8Requirement kinds; three reproduced runtime fixes, exact manifest unchanged. Task15/16 OPEN: activation inventory/cycles/all294individual outcomes/realAI-Level100/nativebrowser/readers/Owneredits-hostedCAS/Atlas. No hosted write, activation, merge or deployment. See committed verification report for exact review findings and full gate counts.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
