import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'live-strength-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'live-strength-tested-source.txt').read_text().strip();reviewed=(w/'live-strength-reviewed-source.txt').read_text().strip();base='505b00cc253fdeeff966edffd152b7b19750cb84'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==4 and all(p.startswith('apps/web/') or p=='docs/verification/2026-10-16-live-effect-strength-readers.md' for p in paths),paths
assert reviewed=='2fdb2f36d9e2dc97dfce177075f91c1c7e056223' and len(tested)==40
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8574,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'live-strength-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged'] and observed['rawSha256']==sha(w/'live-strength-reader-observation.json')
bundle=w/('live-strength-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'live-strength-bundle-verify.log').write_text(v.stdout)
evidence=w/('live-strength-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-live-strength-reader-brief.md', 'live-strength-combined-review-package.md', 'task15-live-strength-combined-review.md', 'live-strength-review-outcome.md', 'live-strength-review-rulings.md', 'live-strength-implementation-notes.md', 'live-strength-tested-source.txt', 'live-strength-reviewed-source.txt', 'live-strength-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-live-strength-checkpoint.py', 'live-strength-readers-diagnostic.test.tsx', 'vitest-live-strength-reader.config.ts', 'live-strength-reader-observation.json', 'live-strength-reader-analysis.json', 'analyze-live-strength-readers.py', 'live-strength-fullcheck-audit.json', 'live-strength-turbo-logs.tar.gz', 'live-amount-reader-observation.json', 'ranged-ai-analysis.json', 'finalize-live-strength-report.py', 'audit-live-strength-fullcheck.py', 'task15-live-strength-next-notes.md', 'live-strength-test-count.txt', 'live-strength-checkpoint-summary.txt']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T184400':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'cf6de8a1258daea1dae03a7ea09e0ff480cbf41f','previousArchiveTree':'707835f421d9d16950212e721a32c8d6b3dee9c5','fullCheckReceipt':gate,'tests':{'vitest':8574,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/'live-strength-checkpoint-summary.txt').read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
