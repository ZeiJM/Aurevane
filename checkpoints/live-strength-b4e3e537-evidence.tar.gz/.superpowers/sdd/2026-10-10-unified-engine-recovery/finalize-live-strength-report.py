from pathlib import Path
import json,re,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=Path(gate['log']).read_text()
expected=int((w/'live-strength-test-count.txt').read_text());counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
source=(w/'live-strength-tested-source.txt').read_text().strip();reviewed=(w/'live-strength-reviewed-source.txt').read_text().strip();assert reviewed=='2fdb2f36d9e2dc97dfce177075f91c1c7e056223'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source and not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
observed=json.loads((w/'live-strength-reader-analysis.json').read_text());assert observed['source']==source and observed['records']==294 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged']
review=(w/'live-strength-review-outcome.md').read_text();rulings=(w/'live-strength-review-rulings.md').read_text();new=expected-8544
report=f'''# Captured combined damage multipliers — verified development checkpoint

The shared live-effect reader now shows the combined damage multiplier for Damage Up, Suppress, Reckless and Fortified. Reckless and Fortified show incoming and outgoing values separately. Values use the existing gold/orange summary rows and equivalent accessible descriptions. Current encounters retain each recorded application/default magnitude; historical encounters apply their recorded row once. Pending values explicitly say on activation. These are multipliers from this effect; other damage modifiers and combat rules still apply, so the reader does not claim final HP damage.

Damage Up follows native integer flooring after each application. Reckless and Fortified follow native exact-ratio composition with the final basis-point rounding. A three-application1.99% case yields106.07% for Damage Up and106.08% for Reckless, matching their different operators. Suppress uses its strongest recorded percentage once, including a genuine0% outgoing multiplier at full suppression. Default then20% Damage Up shows132% under current application stacking and120% under historical whole-row rules. Two default Reckless applications show196% outgoing/156.25% incoming; two default Fortified applications show64% outgoing/49% incoming.

Unsafe or unsupported exact totals are unavailable without crashing the reader. Integer formatting preserves hundredths without floating-point percentage drift. Current minimum authored/persisted potency is100basispoints; native safe-total overflow occurs before the defensive16,384-step Damage Up rendering limit. Exact-ratio arithmetic uses the native65,536-bit capacity ceiling and bounded exponentiation. Native execution and validation are unchanged.

Condition-dependent damage, Healing Down/recovery rates, other non-damage strength and whole-action readiness remain separate work. The reader does not invent missing attacker/recipient/source/facing context. Existing per-application descriptions, lifetime, unknown-version behavior and Covert privacy remain shared. No projection, persistence, schema, native operator, command, control, AI, manifest, CSS, artwork or geometry file changes.

## Verification and review

- BASE505b00cc253fdeeff966edffd152b7b19750cb84 → initial reviewed `{reviewed}` → final tested `{source}`. Three initial web source/test files; **{new} new cases overall**. The report is a docs-only descendant of tested production source.
- TDD184715734384 failed before tests because combat-suppress is not a package subpath export; the test now imports that native source directly without changing exports.184732890331 had19 valid missing-row failures, two invalid multiple-application Suppress fixtures and six guards passing. Corrected184815374988 had21 valid missing-row failures and six guards passing; initial implementation184841655477 passed27cases.
- A zero assertion was strengthened to inspect the actual summary row rather than matching0% inside100% dictionary prose. Added an actual native100-damage attack after120% Damage Up and60% Suppress, which deals72HP, plus large-count/capacity cases. Temporarily removing only the new reader integration produced184922453937:23 valid missing-row failures, two invalid potency1 fixtures and five passing guards. Authored and persisted potency minimum is100basispoints, so the fixtures were corrected.185012292738 then reproduced both corrected large cases as missing-row RED. The earlier ruling about discarding a valid low-potency total was explicitly withdrawn; such potency is invalid.
- Restored185026002871 had29 cases pass and one test-only row-order assertion fail; focused185035335286 had939 pass/one same assertion fail. Fortified's native definition orders incoming before outgoing; the test now checks both directions without an invented ordering requirement. No production ordering change was made. Final initial focused **940tests/85files GREEN185101256902**; web types185035334144 and zero-warning lint185035334221 GREEN. Core58/2 GREEN185101777557; the third requested conditional-modifiers filename does not exist and is not counted. Actual native conditional suites **722tests/3files GREEN185155843703**.
- Final exact-source full check: **{expected:,}Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds GREEN. Receipt `{Path(gate['log']).stem}`, {gate['started_utc']} → {gate['completed_utc']}. Package counts: {', '.join(a+' '+b for a,b in counts)}. Complete root build tail and package-log hash audit preserved.
- All294 named Skill reports and HTML strings remain exactly unchanged against the preceding amount-reader checkpoint:294records,297groups,604effects; observation SHA256 `{observed['rawSha256']}`. Manifest and six AI/native source hashes unchanged. No fresh289-case gameplay-matrix claim for this presentation-only change.

{review}

Tests use real native casts, conditional kernels, actual public spectator projection and the real shared report/SSR body, with only the server-only import marker mocked. They check current/legacy captured defaults and mixed strengths, native rounding, pending labels, zero, unsafe totals, source input immutability, conditions/unknown versions, Covert, and an actual direct-damage outcome. SSR and source parity are not mounted DOM, native browser, assistive-technology or physical geometry acceptance. Both desktop/mobile PvE/PvP/spectators inherit the existing shared reader path; their native acceptance remains open.

## Remaining release work

The modular foundation already live, proposed rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance remain pre-release requirements. Further strength categories, conditional/readiness context, historical Chronicle, public Manual references, full roster cycles, natural pacing/twelve-round balance, current Owner edits, hosted authority/CAS, Atlas motion and human acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is made here. High remains sufficient for routine integration. The provisional16–30activehours/roughly2–4fullworkingdays is an uncertain working estimate, not a calendar launch promise or mechanically reduced count.

## Deferred Minors

Thirteen inherited items remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status input immutability witness; legacy duplicate component keys. Any new reviewed Minor is listed in the review outcome above.

## Initial implementation decisions

1. Scope multipliers to this effect, preserving conditional/full-damage context for separate work. Reason: isolated public rows lack actual attacker/recipient/other modifiers. Cost if wrong: a per-effect reader cannot replace the full damage forecast.
2. Preserve native per-application flooring for Damage Up and exact-ratio arithmetic for always modifiers. Reason: these operators differ. Cost if wrong: kernel comparisons and native final-damage tests remain necessary.
3. Historical rows apply once; Suppress never multiplies by stacks. Reason: captured native policies govern strength. Cost if wrong: visible counts do not independently establish multiplier count.
4. Defensive rendering limits show unavailable rather than freeze or pretend zero. The initial low-potency computable-total concern was withdrawn after inspecting both validation boundaries. Cost if wrong: malformed/unsupported arithmetic remains unavailable rather than receiving invented values.

## Every parent set-aside ruling

{rulings}
'''
(root/'docs/verification/2026-10-16-live-effect-strength-readers.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Final combined damage strength checkpoint\n'+report+'\n')
print('Wrote guarded final strength report and ledger.')
