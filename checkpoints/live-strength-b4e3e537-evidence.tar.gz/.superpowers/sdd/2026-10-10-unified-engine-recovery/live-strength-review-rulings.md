1. Final: Ruling: Final actor/recipient HP forecast — Retain per-effect multipliers because other modifiers and combat state are absent. Cost if wrong: These rows do not establish final HP.

2. Final: Ruling: Conditional opponent/source/facing/HP damage — Leave unchanged conditions for their own context-aware integration. Cost if wrong: Conditional combined magnitude remains open.

3. Final: Ruling: Legacy global damage-budget presentation — Do not attribute a global clamp to one effect; isolated supported legacy values stay within it. Cost if wrong: Per-effect rows are not the complete legacy damage budget.

4. Final: Ruling: Other non-damage strength — Keep separate from the four selected damage effects. Cost if wrong: Other category readers remain incomplete.

5. Final: Ruling: Controlled and other readiness — Keep action-state ownership and separate integration. Cost if wrong: Readiness acceptance remains open.

6. Final: Ruling: Noncompact EffectModifiers trigger summaries — Retain existing individual deltas; this cohort changes popup/report strength. Cost if wrong: Trigger summaries are not fully audited or combined.

7. Final: Ruling: Manual/authored-content reader acceptance — Leave separate public Manual/content gate. Cost if wrong: No full content-reader acceptance.

8. Final: Ruling: Historical Chronicle/modal redesign — Keep unchanged historical fallback for later work. Cost if wrong: Historical readers remain unfinished.

9. Final: Ruling: Existing ordinary incoming-damage summary arithmetic — Keep unchanged helper; new arithmetic is limited to its applicable native operators. Cost if wrong: This cohort does not reverify all ordinary summary rounding.

10. Final: Ruling: Mounted mouse — Leave native acceptance open; no browser execution. Cost if wrong: Mouse interaction remains unverified.

11. Final: Ruling: Mounted touch — Leave native acceptance open; no browser execution. Cost if wrong: Touch interaction remains unverified.

12. Final: Ruling: Mounted keyboard/focus — Source parity is insufficient for physical acceptance. Cost if wrong: Keyboard/focus acceptance remains open.

13. Final: Ruling: Assistive technology — Keep shared accessible strings without claiming actual AT execution. Cost if wrong: AT output remains unverified.

14. Final: Ruling: Long reports/small screens/200%zoom — Keep existing layout and physical acceptance gate. Cost if wrong: Added content may expose clipping/overflow.

15. Final: Ruling: Button/popup CSS geometry — No geometry changed; no physical evidence to close gate. Cost if wrong: Physical sizing remains unverified.

16. Final: Ruling: Inspection backdrop dismissal — Keep existing outside-click ownership. Cost if wrong: Outside inspection still closes the whole inspection.

17. Final: Ruling: Whole persisted/pending/summon malformed-data validation — Keep parser authority; relevant constraints traced, not whole parser. Cost if wrong: Broader parser audit remains open.

18. Final: Ruling: Expiry/revocation/character authority/CAS/direct RPC — Keep separate Task8/16 gate; authority unchanged. Cost if wrong: Hosted security acceptance remains required.

19. Final: Ruling: No input/duplicate payment/extra turns/interrupted Move origins — Native execution unchanged; keep gameplay gate. Cost if wrong: Fresh gameplay acceptance remains required.

20. Final: Ruling: Publication/build/claim/recovery/settlement concurrency — Transactions and workers unchanged. Cost if wrong: Hosted concurrency acceptance remains required.

21. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated witness. Cost if wrong: Witness still starts at origin.

22. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; unrelated capture test. Cost if wrong: Exact version coverage remains incomplete.

23. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Identity witness remains weaker.

24. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

25. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission unchanged. Cost if wrong: Duplicate prefix wording remains.

26. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; no relevant execution change. Cost if wrong: Negative witness remains preparation-only.

27. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; unrelated event test. Cost if wrong: Events lack independent HP reconciliation.

28. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact history value/label coverage incomplete.

29. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; unrelated wording. Cost if wrong: Grammar defect remains.

30. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; Burn unchanged. Cost if wrong: Burn boundary wording remains imprecise.

31. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry remains unverified.

32. Final: Ruling: Cross-status input-immutability witness — Keep inherited Minor deferred; different cohort. Cost if wrong: That direct-input witness remains weaker.

33. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: no new status rows or demonstrated mounted failure. Cost if wrong: Expiry/replacement may still misassociate popup state.

34. Final: Ruling: Whole-roster balance/full cycles — Keep separate natural/full-cycle/balance gate. Cost if wrong: Roster balance remains unaccepted.

35. Final: Ruling: Full Task15/16 — Bounded readers cannot close original combat integration. Cost if wrong: Task15/16 remain unfinished.

36. Final: Ruling: Owner-hosted acceptance — No hosted execution establishes acceptance. Cost if wrong: Hosted gate remains open.

37. Final: Ruling: Atlas acceptance — Unchanged and outside this reader check. Cost if wrong: Atlas motion/acceptance remains open.

38. Final: Ruling: Human gameplay acceptance — Source review/tests cannot establish human acceptance. Cost if wrong: Human gate remains open.

39. Final: Ruling: Merge/deployment/activation/release readiness — Review supplies no operational authorization; preserve no-release boundary. Cost if wrong: Combat update remains unreleased.
