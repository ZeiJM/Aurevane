import { readFileSync, writeFileSync } from 'node:fs'
import { expect, it } from 'vitest'
import { captureCombatAbilitySource } from '@aurevane/game-core/combat/combat-behavior-capture'
import { materializeCombatAbilityAction } from '@aurevane/game-core/combat/combat-behavior-runtime'
import { parseAbilityDefinition } from '@aurevane/game-core/combat/combat-definition'
import { executeCombatAction, endCombatTurn } from '@aurevane/game-core/combat/actions'
import { selectCurrentFinalFacing } from '@aurevane/game-core/combat/board'
import { defaultCombatEffectTimingPolicy } from '@aurevane/game-core/combat/combat-effect-timing'
import { PV1F_COMBAT_CONTENT } from '@aurevane/game-core/combat/pv1f-action-economy'
import { percentageDotEncounter } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-percentage-dots.test-utils'
const w='/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery'
it('observes exact actual elemental materialized packet clocks, without claiming full learned-build admission',()=>{
 const rows=JSON.parse(readFileSync('/workspace/scratch/680b26e4eb86/aurevane/docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json','utf8')).records
 const observations=[]
 for(const id of ['resonance.chronist-frostweaver.linked-sequence','resonance.chronist-stormsinger.linked-sequence']){
  const row=rows.find((r:{id:string})=>r.id===id)
  const definition=parseAbilityDefinition(row.after.ability)
  const source=captureCombatAbilitySource({schemaVersion:1,sourceInstanceId:'reader.'+id,ownerCombatantId:'actor',abilityId:id,contentVersion:row.after.contentVersion,sourceKind:'resonance',tags:['resonance'],definition})
  const action=materializeCombatAbilityAction(source,definition.behaviors[0]!)
  const initial={...percentageDotEncounter(),elementalDamagePolicyVersion:2 as const,effectTimingPolicy:defaultCombatEffectTimingPolicy()}
  let transition=executeCombatAction(initial,action,{kind:'unit',combatantId:'enemy'},PV1F_COMBAT_CONTENT)
  let state=transition.state
  const observationsForRecord=[]
  const sample=()=>observationsForRecord.push({round:state.tactical.battle.round,actor:state.tactical.battle.currentTurn?.combatantId,pending:state.pendingEffects?.map(p=>({round:p.activationRound,type:p.effect.type,origin:p.effectOrigin,timingMode:p.timingMode})),statuses:state.statusState.find(s=>s.combatantId==='enemy')?.statuses,events:transition.events.filter(e=>e.event==='status_applied'||e.event==='damage_applied')})
  sample()
  for(let i=0;i<24;i++){
   transition=endCombatTurn({...state,tactical:selectCurrentFinalFacing(state.tactical,'west').state},PV1F_COMBAT_CONTENT)
   state=transition.state;sample()
  }
  expect(observationsForRecord.some(o=>o.statuses?.some(s=>s.statusId===(id.includes('frostweaver')?'frozen':'conductive')))).toBe(true)
  observations.push({id,sourceVersion:source.contentVersion,modes:action.effectTimingModes,observations:observationsForRecord})
 }
 writeFileSync(w+'/elemental-wrapper-clock-observation.json',JSON.stringify({source:'98916aa36631868418c078cab968a764cc7fc5a1',scope:'Exact materialized packet/captured timing in a core scenario; not full learned-build/Requirements/payment/AI acceptance',records:observations},null,2)+'\n')
})
