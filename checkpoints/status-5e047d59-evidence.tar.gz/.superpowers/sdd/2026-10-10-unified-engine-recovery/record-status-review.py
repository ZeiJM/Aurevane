from pathlib import Path
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery')
rows=[
('Stale-browser revocation','Retain stale-session authority gate; no authority execution here','A revoked browser may remain unverified'),
('Alternate selected-character binding','Formatting does not establish character binding','Wrong-character authority may remain unverified'),
('Direct RPC expiry/CAS','Keep protected RPC gate; no call made','A direct-call concurrency defect may remain'),
('Malformed nested definitions','Use existing parser authority; valid fixtures do not replace rejection evidence','Malformed definitions may remain unverified'),
('Malformed captured data','No new capture-validation evidence','Invalid captures may remain unverified'),
('Malformed pending data','Clock witnesses do not establish malformed-packet rejection','Invalid pending packets may remain unverified'),
('Malformed summon data','No summon change or validation exercise','Malformed summons may remain unverified'),
('Recursive private-accuracy confidentiality','Shared public readers are narrower than transport-wide inspection','Another boundary could expose private data'),
('Every immutable historical consumer','Preserved selected fallbacks do not accept every historical consumer','Another historical reader may remain wrong'),
('No-input/timeout execution','Retain scheduler acceptance; no scheduler change','A timeout defect may remain'),
('Free priming bounds','Instructions are preserved without execution evidence','A prime allowance defect may remain'),
('Repeated-event bounds','No repeated-event or reaction-budget exercise','An event loop may remain unverified'),
('Duplicate payment','Native packet witnesses intentionally bypass full admission/payment','A payment defect may remain'),
('Extra-turn prevention','No turn-economy change or dedicated acceptance','An extra-turn path may remain unverified'),
('Interrupted Move/reached-origin attacks','No movement execution change or native proof','An attack origin defect may remain'),
('Concurrent publication','No hosted race/rollback exercise','Publication races may remain'),
('Concurrent build writes','No build-write race exercise','Concurrent build incoherence may remain'),
('Concurrent claim/idempotency','No claim race exercise','Duplicate claims may remain unverified'),
('Concurrent recovery','Sequential clock witnesses do not prove concurrency','Recovery races may remain'),
('Concurrent settlement','No late-worker or settlement race exercise','Duplicate settlement may remain unverified'),
('Hosted locks/retry/no-contest','Retain actual database gate; no hosted operation','Database-only integrity defects may remain'),
('Long-name layout','Static rendering does not establish native geometry','Long names may overflow'),
('Missing metadata across every reader','Selected policy fixtures are narrower than all historical metadata','Another fallback may remain misleading'),
('Native keyboard/focus','SSR does not execute focus or dismissal','Keyboard readers may remain inaccessible'),
('Touch/mobile','No native device interaction','Touch controls may remain inaccessible'),
('Zoom/contrast/overflow','No actual200% browser layout/contrast evidence','Zoom or contrast may remain inadequate'),
('Native Targeting','Retain original combat integration gate','A targeting path may remain unfinished'),
('Native Move','Retain original movement acceptance','A movement gesture may remain unfinished'),
('Editable five Basics','Shared readers do not accept every native edited Basic','An edited Basic may remain misrepresented'),
('Controlled prime/release/cancel','Instructions remain; full native interaction stays open','A release/cancel interaction may remain wrong'),
('Rewind anchors/history','No Rewind source change or full interaction exercise','An anchor/history path may remain unverified'),
('Every editor/preview/popup','Shared consumers are narrower than all mounted surfaces','Another consumer may remain stale'),
('Airborne secondary facts','Retain exact old explanation until all important values are structured','Shortening early could hide immunity or elevation'),
('Blindside secondary facts','Retain exact old explanation until captured multipliers/activation are structured','Shortening early could hide facing or trigger rules'),
('Haste secondary facts','Retain exact old explanation until movement floor is structured','Shortening early could hide minimum AP'),
('Drenched secondary facts','Retain exact old explanation until Initiative/cap facts are structured','Shortening early could hide Initiative rules'),
('Burn backlash','Separate secondary-fact cohort required','Backlash magnitude or allowance may remain poorly presented'),
('Poison movement refresh','Separate secondary-fact cohort required','Movement refresh could remain poorly presented'),
('Ground presentation','No Ground change in this status delta','Ground delivery prose may remain repetitive'),
('All294 prose quality','All294 static observation supplements but does not replace semantic audit','Other wording may remain repetitive or incomplete'),
('Orange references/links','Existing fact classes are reused; full appearance/interaction audit remains','Other references may remain inconsistent'),
('Active lifetime through expiry','New witnesses assert recorded two-round counter, not actual expiry; retain expiry evidence gate','An expiry defect may remain unverified'),
('Learned-build/canonical Requirements','Packet witnesses intentionally do not accept full build or preconditions','A legal admission/setup path may remain ineffective'),
('Manifest shorthand/full legal cycles','Existing double-stage queue is not a new balance choice; retain meaningful-cycle review','Timing shorthand or cycle value may remain wrong'),
('AI quality/289 replay','Planner/fixture/authority unchanged; do not duplicate289for a reader-only delta','Broader strategic quality remains open'),
('Natural pacing','No balance experiment','Sustain stalls may remain'),
('Twelve-round balance','Keep full pacing benchmark gate','Broader pacing may remain outside target'),
('Current Owner edits','Require fresh release-time Owner data','Stale publication could overwrite newer work'),
('Atlas','Retain existing bound and acceptance gate','Motion acceptance remains unresolved'),
('Human gameplay','Retain actual Owner gameplay acceptance','Feel or usability may remain unmet'),
('Frozen full-project result','Accept only actual completed frozen output below','Unchecked regressions could be accepted'),
('Publication/activation/migration/merge/deployment','Do none here; retain original release prerequisites','Premature release could bypass unfinished work'),
('Broader Master panels','Follow combat package per approved ordering','Unrelated Master work remains unfinished until that stage'),
]
assert len(rows)==53
text='\n## Combined review and individual rulings\n\nOne fresh gpt-6-astra High combined review98916aa3..3fc8b7a8 finds0Critical/0Important/1newMinor. Parent agrees with the Minor grade: supported one-duration elemental payloads display “1 affected turns” or “1 full rounds”; value and clock stay truthful. Defer count-aware grammar until relevant authorized follow-up. No fix wave or rereview. Total nine deferred Minors, with the prior eight individually preserved in preceding reports.\n\n'
text+='\n\n'.join(f'Final: Ruling: {name} — {why} — Cost if wrong: {cost}.' for name,why,cost in rows)
text+='\n\nFinal: minor (deferred): One-duration elemental labels use plural turn/round grammar; values and clock remain correct.\n'
(w/'status-review-rulings.md').write_text(text)
(w/'task15-standard-status-review.md').write_text('One fresh read-only gpt-6-astra High combinedreview98916aa3..3fc8b7a8:0C0I1Minor, one-durationpluralgrammar atcanonical-status-explanation.ts56. Parentdefer,total9prior8unchanged. No fixwave/norereview. Nativeunits/direction/coupledmagnitudes,HealingDownscope,explicitwrapperoverdefaults,Controlledaffectedturnrelease,conditionalpositiveHP/survival,oldpolicyfallback/authoredalignment coherent. ActualrecordtestsR3/R5assertremainingroundcount2,notexpiry/fulllearnedbuild/Requirements/payment/AI.53declinesindividuallyparentruledinstatus-review-rulings.md/report/progress. Fullrootparentgatepending atreview. No suites/services/mutations/delegation.\n')
p=Path('docs/verification/2026-10-16-canonical-status-reader-prose.md');s=p.read_text().replace('with two full round boundaries of active lifetime, then check','with a recorded remaining lifetime counter of two full rounds, then check').replace('A fresh exact-source all294 static observation is required to compare the affected and untouched explanations.','Exact frozen-source all294 static observation `144820895639` confirms297groups/604effects,154changed explanations from the prior checkpoint,324changed/280unchanged from the original, and all17protected explanations exactly unchanged. Digit-bearing candidates521→199 and non-direct-Damage candidates350→28 are observations, not28proven violations. Raw SHA256 `aa06f7dfe4136e9d278c7e9134f15c71e31060a35eba96a679ee00aafb4ea2e4`.')
p.write_text(s+text)
with (w/'progress.md').open('a') as f:f.write(text+'\nStandardstatusreview0C0I1newMinor/defer,total9. No fixwave/norereview. Exactall294SSR144820895639 rawaa06f7dfe4136e9d278c7e9134f15c71e31060a35eba96a679ee00aafb4ea2e4:154new/324originalchanged280unchanged/17protectedwordsunchanged.53individualdeclinerulingsretained. Finalfullrootpending; noacceptanceclaimuntilactualoutput.\n')
