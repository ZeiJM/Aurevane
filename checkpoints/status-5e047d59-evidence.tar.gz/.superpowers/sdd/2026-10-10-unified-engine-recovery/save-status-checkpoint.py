import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'status-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'status-tested-source.txt').read_text().strip();base='98916aa36631868418c078cab968a764cc7fc5a1'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==5 and all(p.startswith('apps/web/src/components/character/') or p=='docs/verification/2026-10-16-canonical-status-reader-prose.md' for p in paths),paths
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()];gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8325
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'status-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['changedFromRecovery']==154 and observed['changedFromOriginal']==324 and observed['rawSha256']==sha(w/'status-reader-observation.json')
bundle=w/('status-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'status-bundle-verify.log').write_text(v.stdout)
evidence=w/('status-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-standard-status-reader-brief.md', 'task15-standard-status-review.md', 'status-review-rulings.md', 'record-status-review.py', 'status-tested-source.txt', 'status-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-status-checkpoint.py', 'status-readers-diagnostic.test.tsx', 'vitest-status-reader.config.ts', 'status-reader-observation.json', 'status-reader-analysis.json', 'remaining-status-reader-inventory.json', 'elemental-wrapper-reader-candidates.json', 'elemental-wrapper-clock-observation.test.ts', 'vitest-elemental-wrapper-clock.config.ts', 'elemental-wrapper-clock-observation.json', 'task15-secondary-status-next-brief.md']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T144300':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'prerequisite':base,'previousArchiveCommit':'ed98d7dd4cab81e3b73ed023c69eb581963c1fc7','previousArchiveTree':'d924fd7168876ea9738e5230b29393aef11d099b','fullCheckReceipt':gate,'tests':{'vitest':8325,'node':7},'bundle':info(bundle),'evidence':info(evidence),'acceptance':'Canonical16statusIDs154effects plainprose+structuredStacks/nativeunits/direction and exact elemental wrapper clocks.0C0I1newMinor grammardeferred,total9.30newtests750covering;frozen8325Vitest+7Node verified.294record297group604effect SSR:154new/324originalchanged280unchanged,17protectedexactoldwords. ActualmaterializedpacketR3/R5+remaining2rounds is not learnedbuild/admission/payment/fullcycle/expiry acceptance. Non-directDamage numeric candidates350to28, not28provenviolations. Manifest/AI/executor/prices/defaultfixture unchanged; no duplicate289. Originalcombat/readers/secondaryfacts/prose/native/fullbalance/Ownerhosted/Atlas/human/releaseOPEN. No publication/activation/migration/merge/deploy.'}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
