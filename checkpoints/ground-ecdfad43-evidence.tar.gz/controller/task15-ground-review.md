# Task15 canonical Ground milestone review

Reviewed the original uncommitted milestone over HEAD `1876210d89d80e6b02de4065d2fc9233041ecb3f`, using `task15-ground-review.diff`, plus the explicitly included untracked `combat-canonical-ground-areas.test.ts`. This is one combined spec/quality review of all 11 files and their relevant native, authoring, preview, capture and projection callers. The inherited commit range and full Task15/16 release acceptance are outside this review.

Binding requirements: coverage manifest `groundExtension`, COMBAT persistent Ground/Airborne contracts, applicable AGENTS and engineering/concurrent workflow, and the final progress.md rulings. The implementation appropriately reuses native Ground lifetime/entry claims, adds stable IDs without rewriting schema1 history, rejects selected Pierce, preserves origins/visibility, and uses the safe public area projection.

## Important findings

1. **Captured conditional entry eligibility is not honored by every native consumer.** New integration: `packages/game-core/src/combat/actions-legacy.ts:6982–6987`; actual settlement defect: `actions-legacy.ts:4558–4565`; resistance defect: `combat-status-resistance.ts:59–86`.

   Reproduction A: canonical Ground action has unconditional Damage20 and percentage Poison gated on affected Marked. Cast on an empty tile while nobody is Marked. Its area correctly captures `entryEffectEligibleRecipientIds: [null, []]`. After the enemy enters, Damage20 lands and Poison nevertheless applies with `capturedDamage:20` and the conditional effect's origin. The special `groundPercentageEffects` settlement loop checks damage, life and resistance but never the per-ordinal eligibility mask. Burn/Bleed share this loop. This violates the selected extension's captured conditional recipient authority. Check eligibility before applying each Ground DoT.

   Reproduction B: same setup with conditional Slow instead of Poison, valid bridge4/statBalancePolicy1 and 1500 resistance. Slow correctly does not apply, but entry advances RNG draws0→1 and emits `combat_status_resistance_resolved` with `eligibleEffectOrdinals:[1]`. `forecastCombatStatusResistance` does not filter per-ordinal recipient eligibility. An ineligible application must not draw resistance or produce its receipt; this also remains relevant to conditional DoTs after fixing settlement.

   Both are confirmed through narrow real canonical cast→turn→movement scripts executed in memory. No passing suite was rerun. Root has independently fixed/tested the first consequence while this original-snapshot review continued; that fix was not re-reviewed here.

2. **Ordinary editor edits can strand hidden, invalid Ground metadata.** `apps/web/src/components/master/combat-content/skill-ground-editor.tsx:164–174,182–183` and the existing Remove callback now integrated with it at `ability-definition-editor.tsx:253–257`.

   Start with a valid Ground group: affected Damage `hit`, actor Healing `heal`, and `groundArea.entryEffectIds:['hit']`. Remove `hit` through the normal editor callback. The callback retains the old `groundArea`; the adapter resolves its ID to−1, and native `SkillGroundEditor` returns null because no supported unit entry effect remains (`skill-ground-editor.tsx:49–50`). Parser now reports invalid-ground-area, and the Persistent ground checkbox has disappeared, so the intended remaining nonpersistent actor-heal draft cannot be saved without undoing/recreating an effect. Changing targeting away from Ground or mode away from action similarly hides retained Ground state. Reconcile Ground references when effects/target/mode change, or keep an accessible removal control for existing metadata.

   Confirmed with a narrow actual `AbilityDefinitionEditor` render of the normal Remove callback's resulting value: before validation errors `[]`; afterwards invalid-ground-area; `aria-label="Persistent ground effect"` absent. No browser/publication acceptance is claimed.

## Minor

- `apps/web/src/components/character/ability-detail-presentation.ts:278–280` describes every selected subset with the same generic “applies its unit effects” sentence. A valid group with cast Damage+Slow and only Damage selected for entry gives no reader indication that Slow is cast-only. Consider naming the repeated subset, or marking repeat delivery on the relevant structured effect rows. This is an ambiguity for the general supported schema/editor, not a defect in the three selected designs, which select all applicable nonactor unit effects.

## Declined judgments and limits

- No request for a new delayed entry queue: the recorded ruling explicitly retains native immediate entry settlement. Metadata capture itself does not justify changing native clocks.
- No demand to implement repeating Pierce; selected Pierce is deliberately rejected and the selected three plans do not require it.
- No whole-roster balance, complete Task15/16 surface, protected browser, publication, hosted mutation or release acceptance finding; those gates remain expressly open.
- No new issue found in stable-ID mapping after Move/Summon filtering, finite parser validation, metadata alignment/value validation, captured source removal, the public area's safe projection, or the three exact selected plan compilation paths.
- Static inspection covers the entire supplied milestone and relevant callers. Narrow reproductions supplement the controller-reported focused/full quality receipts; this reviewer did not rerun broad suites. `git diff --check` was clean before fixes began.

Assessment of original snapshot: **Needs fixes** (two Important findings; no Critical). Root's subsequent fixes and final verification determine the amended milestone's acceptance.
