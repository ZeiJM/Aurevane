import subprocess, pathlib, hashlib, json, tarfile, base64, sys

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'ai-manual-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = (workspace / 'ai-manual-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
assert '4097 passed (4097)' in log and '3431 passed (3431)' in log
prerequisite = 'dda3d5f8caa9978d576d73ac283df8a1ca85d2f3'
bundle = workspace / ('ai-manual-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + prerequisite], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'ai-manual-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('ai-manual-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T0*.log')):
        if file.name >= '20261016T091000':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-ai-manual-review.md', 'task15-ai-manual-review.diff', 'task15-ai-cycle-preflight.md', 'task15-legal-cycle-preflight.md', 'ai-manual-tested-source.txt', 'ai-manual-bundle-verify.log', 'save-ai-manual-checkpoint.py']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

manifest = root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'tests': {'vitest': 7774, 'node': 7}, 'prerequisite': prerequisite, 'previousArchiveCommit': 'dd8cc89bd1afb647ab48edf4322e92e182cd5dae', 'previousArchiveTree': 'f82ef2dc66e45ca86bc8149f5f27e57338a4e1b6', 'manifestSha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': 'Bounded actualAI Manual bundle selection/propagation,14core+2service new tests. Shared canonical/native/Controlled atomic executor and actual service CAS preserved. Review0Critical/0Important/1Minor deferred,prior3 carried. Manifest unchanged. Task15/16 OPEN: every294record/legal-equippedcycles/realAI-Level100balance/nativebrowser/readers/Owneredits-hostedCAS/Ground/Atlas. No hosted write, activation, merge or deployment. See committed verification report for exact review findings and full gate counts.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
