import { appendFileSync } from 'node:fs'
import { it,vi } from 'vitest'
import { createLegalRosterDuel,legalRosterCycleKits } from './roster-legal-duel.test-utils'
vi.mock('server-only',()=>({}))
it('records real seeded four-participant first actor',async()=>{
const kit=legalRosterCycleKits.find(k=>k.primary==='farstrider'&&!k.secondary)!
for(const seed of [1,2,3,4,5,6,7,8]){
const d=await createLegalRosterDuel({kit,additionalKits:[kit,kit],level:100,context:'pvp',seed,board:{width:7,height:3,positions:[{x:1,y:1},{x:2,y:1},{x:1,y:0},{x:1,y:2}],facings:['east','west','south','north']}})
appendFileSync('/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/ranged-ai-start-orders.jsonl',JSON.stringify({seed,actor:d.state.tactical.battle.currentTurn!.combatantId})+'\n')
}
})
