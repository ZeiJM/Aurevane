import { appendFileSync, readFileSync } from 'node:fs'
import { expect, it, vi } from 'vitest'
import { createLegalRosterDuel, legalRosterCycleKits, playLegalRosterDuel } from './roster-legal-duel.test-utils'
vi.mock('server-only', () => ({}))
const base = legalRosterCycleKits.find((k) => k.primary === 'dawnshield' && !k.secondary)!
const alternative = {...base, name: 'dawnshield:earned-judgment-kit', ids: ['dawnshield.radiant-strike','dawnshield.sacred-guard','dawnshield.judgment','dawnshield.aegis']}
const scenarios = ([1,100] as const).flatMap((level) => (['pve','pvp'] as const).flatMap((context) => [base,alternative].map((kit) => ({name:`${kit.name}:${level}:${context}`,kit,level,context}))))
it.each(scenarios)('$name is observed to real completion or40rounds, without repricing or forced outcomes', async ({kit,level,context}) => {
  const d = await createLegalRosterDuel({kit,level,context,seed:1,board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]}})
  const before = JSON.stringify(d.state)
  const result = playLegalRosterDuel(d,{maximumRounds:40})
  expect(JSON.stringify(d.state)).toBe(before)
  expect(result.errors).toEqual([])
  expect(result.state.tactical.battle.lifecycle==='completed'||result.state.tactical.battle.round>40).toBe(true)
  if(kit===base&&level===100&&context==='pvp') {
    const old = readFileSync('/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/ranged-ai-final-pacing.jsonl','utf8').trim().split('\n').map((s)=>JSON.parse(s)).find((r)=>r.kit===base.name)
    expect(result.commands).toEqual(old.commands)
    expect(result.state.tactical.battle.round).toBe(old.round)
    expect(result.state.tactical.battle.lifecycle).toBe(old.lifecycle)
  }
  appendFileSync('/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/defense-payoff-natural.jsonl',JSON.stringify({kit:kit.name,level,context,seed:1,maximumRounds:40,round:result.state.tactical.battle.round,lifecycle:result.state.tactical.battle.lifecycle,sourceVersions:d.participants.map((p)=>({actorId:p.actorId,sources:p.sources.map((s)=>({sourceInstanceId:s.sourceInstanceId,abilityId:s.abilityId,contentVersion:s.contentVersion,sourceKind:s.sourceKind}))})),commands:result.commands,final:result.state.tactical.battle.combatants.map((u)=>({id:u.id,hp:u.hp,maxHp:u.maxHp,mp:u.mp,maxMp:u.maxMp}))})+'\n')
},180_000)
