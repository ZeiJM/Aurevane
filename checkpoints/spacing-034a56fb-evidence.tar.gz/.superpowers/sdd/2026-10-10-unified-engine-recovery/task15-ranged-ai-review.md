# Fresh combined review — ranged_ai_spacing_review

Reviewer gpt-6-astra High, fork none; read-only review of d817d6f2..2931dfa7. Parent-owned full gates pending at dispatch. No reviewer suite runs, mutation or subdelegation. Final reviewer response follows.

### Strengths

The change fits the approved bounded direction: four neighboring tiles, existing command quotes, no future RNG draws, and commitment of only the walk followed by a fresh decision. Shared movement authority handles occupancy, Root, Movement, terrain and Jump; captured sources and held Controlled attachments remain authoritative.

The permanent tests establish both a beneficial three-target Volley and the correctly rejected single-target Aimed Shot retreat across Levels 1/100 and PvE/PvP. The default fixture compatibility guard remains intact.

I verified the review diff against the requested commit range, all recorded source/evidence hashes, and the retained baseline module byte-for-byte against `d817d6f2`. The five paired performance samples reproduce the reported medians/counts; all five pacing replays match their prior commands, final resources, rounds and lifecycles.

### Issues

#### Critical

None found.

#### Important

1. **Rich captured flat Move is projected as pure AP expenditure and geometry.**

   **Evidence:** `packages/game-core/src/combat/recruit-ai-build.ts:296–339`. The flat Move quote supplies only `quote.cost` to the projection; `moveCurrentCombatant` and `spendPv1fActionEconomy` then construct the presumed follow-up state. MP/HP payments, conditional movement and additional effects are absent. These are supported flat Move authoring features: `packages/game-core/src/combat/combat-basic-actions.ts:231–260` explicitly distinguishes them from restricted native per-terrain walking.

   **Effect:** The AI can spend AP and MP repositioning for a shot that was affordable only in the incomplete projection. Replanning prevents an illegal release, but cannot recover the wasted move or resources.

   **Concrete regression shape:** Adapt the held Longshot + Keen Focus case at `recruit-ai-ranged-spacing.test.ts:227–281` to captured flat Move costing **15 AP + 15 MP**. The actor starts with 20 MP; the exact held release costs 6 MP. Current projection retains 20 MP and sees a legal release, whereas actual walking leaves 5 MP and cannot release that bundle.

   **Bounded fix:** Conservatively exclude flat Move from this optional spacing projection unless the selected captured behavior is pure, unconditional AP-paid walking with no unmodelled effects or clocks. Preserve the existing pure flat 15 AP positive case. Do not introduce a new effects simulation engine.

2. **The strict efficiency comparison omits already-quoted alternatives.**

   **Evidence:** `recruit-ai-build.ts:243–260` considers candidate ratios only when `apCost` is truthy. `nativeBasicModifierCandidates` at `491–527` obtains an exact shared quote but returns neither `apCost` nor `effectUtility`. The fallback quotes `baseline.intent`, which is the ordinary baseline decision, not the selected native Basic attachment bundle. The historical native Skill winner guard at line 203 does not cover these Basic candidates.

   The same truthiness check also drops positive-value canonical candidates costing **zero AP**, which the definition schema permits (`combat-definition.ts:262–267`).

   **Effect:** A walk can win the adjusted raw-utility comparison while having worse value/AP than an available native Basic+modifier, or than a free immediate attack. This defeats the deliberate safeguard against paying for inferior spacing.

   **Concrete regression shapes:**
   - Historical native Basic plus an eligible attachment remains immediately legal and has better value/AP than the proposed walk+shot, while the shot has enough additional raw utility to pass the walking penalty. Illustrative values: plain Basic `20/30`, attached Basic `40/35`, ranged opportunity `50/(20+45)`. The present gate compares against `20/30` and can accept the retreat despite `40/35`.
   - An immediately legal, positive-value canonical attack costs zero AP; a higher raw-value paid ranged opportunity exists. The free alternative must not disappear from the strict efficiency comparison.

   **Bounded fix:** Carry exact shared-quote AP cost and effect utility for native Basic modifier candidates and other immediate candidates covered by this comparison. Treat positive-value zero-AP alternatives explicitly. Preserve the historical native winner guard and existing ranking.

#### Minor

No new Minor finding. The six previously deferred Minors remain deferred individually below.

### Requirements, correctness and evidence assessment

The implementation is substantially aligned with the bounded brief, but the two Important findings prevent its claims of actual combined affordability and comparison against current quoted alternatives from being fully true.

Controlled priming itself remains free and uses existing authority; held bundles are retained exactly. Ordinary native movement preserves facing and spends Movement through the same board function used by execution. The Ground and Poison exclusions conservatively avoid the hazards they recognize. No new outcome or future-RNG predictor was found.

The latency evidence is credible within its stated limits: the multi-enemy sample adds approximately **300 ms** and the adjacent single-enemy sample approximately **53 ms**. Quote budgets bound the added ranged evaluations, not total planner runtime or all discovery work. These measurements do not establish a hosted latency threshold.

I performed read-only source/evidence inspection only. I did not run suites or mutate files. The frozen full-root and explicit 289-case results were pending when this review was dispatched; earlier green receipts do not establish those final gates, and fixes require verification on their resulting source.

### Recommendations

Resolve both Important findings in the authorized single RED→GREEN wave, retain the pure flat Move and native historical behavior guards, then complete the parent-owned frozen checks and exact recovery checkpoint. Keep the report’s explicit limits on pacing, performance and release acceptance.

### Declined to judge

- **Complete roster cycle coverage:** This milestone exercises selected ranged opportunities; every class, Essence and pair cycle remains a broader Task15 obligation.
- **Whole-turn optimality and kiting doctrine:** The approved extension makes one bounded movement decision; it does not optimize an entire turn.
- **Later unexamined lanes and attachment bundles:** Deterministic prefix coverage is an explicit bounded tradeoff; missed opportunities remain possible.
- **Line-of-sight or facing-only repositioning with no distance gap:** The current trigger intentionally excludes this wider search.
- **Full reactive movement and interruption forecasting:** Ground/Poison guards and actual replanning are narrower than evaluating every automatic or ongoing consequence; no comprehensive forecast claim is accepted.
- **Hosted p95, latency SLO and all-roster worst-case cost:** Five local warm samples cannot establish these.
- **Natural sustain pacing:** Three retained mirrors remain active at the 40-round horizon; this correction does not close that issue.
- **Twelve-round balance acceptance:** The observed matches and unchanged long sustain cases do not meet or establish that benchmark.
- **Repricing, resource thresholds or combat formula changes:** None are implemented or authorized by this bounded review.
- **Native browser interaction and accessibility:** Source inspection and local engine tests do not establish these.
- **Complete editor-to-reader acceptance:** The single new reason label is not an audit of all editor, preview, popup and public descriptions.
- **Current hosted Owner-edit reconciliation:** Captured local source correctness does not establish reconciliation with hosted edits.
- **Hosted PvE/PvP admission and multiplayer authority:** The four-team local authority fixtures are not hosted standard-session admission evidence.
- **Migration, publication, activation, merge and deployment:** Outside this checkpoint; no release authorization inferred.
- **Final full-root gate:** Parent-owned and pending at dispatch; must be assessed on the final fixed source.
- **Final explicit 289-case audit:** Parent-owned and pending at dispatch; the narrower ranged tests are not a substitute.
- **Exact recovery backup:** Parent-owned checkpoint work remains to be verified after fixes and final gates.
- **Prior Minor—Rewind origin fixture:** Intentionally deferred; not reopened by this change.
- **Prior Minor—Supporting Shot version:** Intentionally deferred; not reopened by this change.
- **Prior Minor—Ongoing pair literal ID:** Intentionally deferred; not reopened by this change.
- **Prior Minor—Repeated bounded route/target discovery:** Intentionally deferred; measured overhead does not resolve it.
- **Prior Minor—Admission fixture double-prefix provenance:** Intentionally deferred; added participants do not establish corrected provenance.
- **Prior Minor—Ranged negative preparation versus direct commit:** Intentionally deferred; not reopened incidentally.

### Assessment

**Ready for the bounded local checkpoint: With fixes.**

There are **0 Critical, 2 Important and 0 new Minor findings**. The shared-authority design and retained evidence are sound foundations, but rich flat Move projection and incomplete alternative comparison must be corrected before accepting this checkpoint; Task15/16 and release acceptance remain open.
