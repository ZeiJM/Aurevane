import { it, expect, vi } from 'vitest'
import { writeFileSync } from 'node:fs'
import { prepareCombatAbilityCommand } from '@aurevane/game-core/combat/combat-ability-command'
import { combatAbilityCommandContext } from '@aurevane/game-core/combat/combat-behavior-runtime'
import { createLegalRosterDuel, legalRosterCycleKits } from './roster-legal-duel.test-utils'
import { chooseBuildAwareRecruitAiDecision, executeBuildAwareRecruitAiAction, projectedCombatEffectUtility } from '@aurevane/game-core/combat/recruit-ai-build'
import { evaluatePv1fAction, evaluatePv1fMovement, executePv1fMovement, PV1F_BASIC_ATTACK_ID, PV1F_COMBAT_CONTENT, readPv1fActionEconomy } from '@aurevane/game-core/combat/pv1f-action-economy'
vi.mock('server-only', () => ({}))
it('observes exact real prices and actual decisions for the changed Wildwarden-primary pair', async () => {
  const kit = legalRosterCycleKits.find((k) => k.name === 'resonance.farstrider-wildwarden.linked-sequence:primary:wildwarden')!
  const d = await createLegalRosterDuel({kit, level: 100, context: 'pvp', seed: 12345})
  const actorId = d.state.tactical.battle.currentTurn!.combatantId
  const enemyId = d.participants.find((p) => p.actorId !== actorId)!.actorId
  const before = JSON.stringify(d.state)
  const basic = evaluatePv1fAction(d.state, PV1F_BASIC_ATTACK_ID, {kind: 'unit', combatantId: enemyId})
  const first = chooseBuildAwareRecruitAiDecision({state: d.state, tieBreakSeed: 12345})
  expect(first.intent.kind).toBe('move')
  if (first.intent.kind !== 'move') throw Error('No changed initial spacing')
  const move = evaluatePv1fMovement(d.state, first.intent.path)
  const moved = executePv1fMovement(d.state, first.intent.path)
  const second = chooseBuildAwareRecruitAiDecision({state: moved.state, tieBreakSeed: 12345})
  expect(second.intent.kind).toBe('action')
  if (second.intent.kind !== 'action') throw Error('No ranged followup')
  const source = moved.state.capturedAbilitySources!.find((s) => s.ownerCombatantId === actorId && s.abilityId === second.intent.actionId)!
  const quote = prepareCombatAbilityCommand({state: moved.state, actorId, root: {kind: 'canonical', source, behaviorId: second.intent.behaviorId}, selection: second.intent.target, manualModifiers: second.intent.manualModifiers, content: PV1F_COMBAT_CONTENT, context: combatAbilityCommandContext(moved.state, source)})
  const shot = executeBuildAwareRecruitAiAction(moved.state, second.intent.actionId, second.intent.target, {}, second.intent)
  const third = chooseBuildAwareRecruitAiDecision({state: shot.state, tieBreakSeed: 12345})
  expect(JSON.stringify(d.state)).toBe(before)
  writeFileSync('/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/ranged-ai-changed-kit.json', JSON.stringify({kit: kit.name, first, second, third, basic: {cost: basic.cost, utility: projectedCombatEffectUtility(basic.evaluation, basic.prepared, basic.action.effects)}, moveCost: move.economyCost, shot: {cost: quote.costs.filter((c) => c.resource === 'ap').reduce((n,c) => n+c.amount,0), utility: projectedCombatEffectUtility(quote.evaluation, moved.state, quote.action.effects), apAfter: readPv1fActionEconomy(shot.state)?.current}}, null, 2))
})
