import { appendFileSync } from 'node:fs'
import { it,expect,vi } from 'vitest'
import * as command from '@aurevane/game-core/combat/combat-ability-command'
import { chooseBuildAwareRecruitAiDecision as current } from '@aurevane/game-core/combat/recruit-ai-build'
import { chooseBuildAwareRecruitAiDecision as baseline } from '../../../../../packages/game-core/src/combat/recruit-ai-build-baseline.test-utils'
import { createLegalRosterDuel,legalRosterCycleKits } from './roster-legal-duel.test-utils'
vi.mock('server-only',()=>({}))
it('pairs original/current planning time and counts original shared command quotes',async()=>{
 const kit=legalRosterCycleKits.find(k=>k.primary==='farstrider'&&!k.secondary)!
 const spy=vi.spyOn(command,'prepareCombatAbilityCommand')
 for(const scenario of ['multi','close','range']as const){
  const duel=await createLegalRosterDuel({kit,level:100,context:'pvp',seed:1,...(scenario==='multi'?{additionalKits:[kit,kit],board:{width:7,height:3,positions:[{x:2,y:1},{x:1,y:1},{x:1,y:0},{x:1,y:2}],facings:['west','east','south','north']as const}}:scenario==='range'?{board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]}}:{})})
  const input={state:duel.state,tieBreakSeed:7};const before=JSON.stringify(duel.state)
  baseline(input);current(input)
  const samples=[]
  for(let run=0;run<5;run++){
   spy.mockClear();let start=performance.now();const old=baseline(input);const oldMs=performance.now()-start,oldQuotes=spy.mock.calls.length
   spy.mockClear();start=performance.now();const next=current(input);const newMs=performance.now()-start,newQuotes=spy.mock.calls.length
   expect(oldQuotes).toBeGreaterThan(0);expect(newQuotes-oldQuotes).toBeLessThanOrEqual(scenario==='close'?5:29)
   expect(JSON.stringify(duel.state)).toBe(before)
   samples.push({run,oldMs,newMs,oldQuotes,newQuotes,old,next})
  }
  appendFileSync('/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/ranged-ai-performance-limited.jsonl',JSON.stringify({scenario,samples})+'\n')
 }
 spy.mockRestore()
},120_000)
