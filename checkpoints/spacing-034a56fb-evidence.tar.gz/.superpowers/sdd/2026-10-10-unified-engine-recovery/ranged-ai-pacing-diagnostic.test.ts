import { appendFileSync } from 'node:fs'
import { describe,expect,it,vi } from 'vitest'
import { createLegalRosterDuel,legalRosterCycleKits,playLegalRosterDuel } from './roster-legal-duel.test-utils'
vi.mock('server-only',()=>({}))
const kits=legalRosterCycleKits.filter(k=>!k.secondary&&['vanguard','bastion','farstrider','wildwarden','dawnshield'].includes(k.primary))
describe('post-spacing actual natural pacing, no balance acceptance',()=>{
 it.each(kits)('$name',async kit=>{
  const d=await createLegalRosterDuel({kit,level:100,context:'pvp',seed:1,board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]}})
  const result=playLegalRosterDuel(d,{maximumRounds:40})
  expect(result.errors).toEqual([])
  expect(result.state.tactical.battle.lifecycle==='completed'||result.state.tactical.battle.round>40).toBe(true)
  appendFileSync('/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/ranged-ai-pacing.jsonl',JSON.stringify({kit:kit.name,level:100,context:'pvp',seed:1,maximumRounds:40,round:result.state.tactical.battle.round,lifecycle:result.state.tactical.battle.lifecycle,commands:result.commands,final:result.state.tactical.battle.combatants.map(u=>({id:u.id,hp:u.hp,maxHp:u.maxHp,mp:u.mp,maxMp:u.maxMp}))})+'\n')
 },180_000)
})
