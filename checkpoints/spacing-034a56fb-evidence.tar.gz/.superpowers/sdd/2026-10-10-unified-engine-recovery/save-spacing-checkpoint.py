import subprocess, pathlib, hashlib, json, tarfile, base64, sys, re

root = pathlib.Path.cwd()
w = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = w / 'spacing-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def info(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': sha(p),
            'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
            'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

assert not git('status', '--porcelain'), 'requires clean final source'
head = git('rev-parse', 'HEAD')
tested = (w / 'ranged-ai-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(s) for s in (w / 'verification.jsonl').read_text().splitlines()]
gate = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
assert gate['exit_code'] == 0
log = pathlib.Path(gate['log']).read_text()
counts = re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed', log)
assert len(counts) == 7 and sum(int(n) for _, n in counts) == 8230, counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
matrix_receipt = next(r for r in reversed(receipts) if r['argv'] == [
    'pnpm', '--filter', '@aurevane/web', 'exec', 'vitest', 'run',
    'src/server/battle/roster-legal-duel-matrix.test.ts'])
assert matrix_receipt['exit_code'] == 0
assert '289 passed' in pathlib.Path(matrix_receipt['log']).read_text()
analysis = json.loads((w / 'ranged-ai-analysis.json').read_text())
for name, digest in analysis['sourceHashes'].items():
    assert sha(root / name) == digest, name
for name, digest in analysis['evidenceHashes'].items():
    assert sha(w / name) == digest, name
matrix = json.loads((w / 'ranged-ai-matrix-analysis.json').read_text())
assert matrix['cases'] == 289 and matrix['testedSource'] == tested
assert matrix['matrixSha256'] == sha(w / 'ranged-ai-final-matrix.jsonl')
assert (w / 'task15-ranged-ai-review.md').stat().st_size > 500
prerequisite = 'd817d6f22afcc6dc357257a2fb315f0104abd3c7'
bundle = w / ('spacing-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + prerequisite], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(w / 'spacing-bundle-verify.log').write_text(verified.stdout)
evidence = w / ('spacing-' + head[:8] + '-evidence.tar.gz')
names = ['progress.md', 'task-15-brief.md', 'task15-ranged-ai-brief.md',
         'verification.jsonl', 'run.py', 'task15-ranged-ai-review.md',
         'task15-ranged-ai-review.diff', 'ranged-ai-tested-source.txt',
         'spacing-bundle-verify.log', 'save-spacing-checkpoint.py',
         'audit-ranged-ai-matrix.py', 'task15-ranged-ai-final.diff', 'task15-defense-cycle-next-brief.md', 'roster-legal-defense-payoff-cycles.draft.ts', 'defense-payoff-natural.jsonl', 'defense-payoff-natural-analysis.json', 'defense-payoff-natural-diagnostic.test.ts', 'pure-pacing-natural.jsonl',
         'recruit-ai-build-baseline.test-utils.ts']
names += [p.name for p in w.glob('ranged-ai-*') if p.is_file()]
with tarfile.open(evidence, 'w:gz') as archive:
    for p in sorted((w / 'evidence').glob('20261016T*.log')):
        if p.name >= '20261016T120000':
            archive.add(p, arcname=str(p.relative_to(root)))
    for name in sorted(set(names)):
        p = w / name
        assert p.is_file(), name
        archive.add(p, arcname=str(p.relative_to(root)))
manifest = root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
assert sha(manifest) == 'b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
meta = {
    'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
    'testedSource': tested, 'fullCheckReceipt': gate, 'fullMatrixReceipt': matrix_receipt,
    'tests': {'vitest': 8230, 'node': 7}, 'matrix': matrix,
    'prerequisite': prerequisite,
    'previousArchiveCommit': '15cd5ca9c505cfeb62043e1122437f82aa26e58f',
    'previousArchiveTree': '5dcbe1d56c78cca92fcb8e0c9abb60c83f230836',
    'manifestSha256': sha(manifest), 'bundle': info(bundle), 'evidence': info(evidence),
    'acceptance': 'Bounded paid native one-tile ranged spacing: 12 real learned-build cases, '
        '21 isolated kernel guards, frozen fullroot and explicit289 actual legal-kit replay audit. '
        'Five pre-final diagnostic natural mirrors exactly unchanged, three sustain cases still active after40; '
        'local warm performance medians only, ~300–360ms measured additional multi-foe planning at diagnostic source. '
        'No pricing/formula/definition/hostedwrite/activation/merge/deploy; '
        'Task15/16 allcycles/setupAI/balance/nativeUI/Owneredits/hostedCAS/human/release OPEN. '
        'See report for combined review and individual parent rulings.'
}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
