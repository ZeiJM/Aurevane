import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'live-recovery-rate-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'live-recovery-rate-tested-source.txt').read_text().strip();reviewed=(w/'live-recovery-rate-reviewed-source.txt').read_text().strip();base='b4e3e537d01817b78e75ecb6810500009e8a3120'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==6 and all(p.startswith('apps/web/') or p=='docs/verification/2026-10-16-live-effect-recovery-rate-readers.md' for p in paths),paths
assert reviewed=='df53d50ba49ea70094fceb7945927018d9a031fb' and len(tested)==40
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8608,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'live-recovery-rate-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged'] and observed['rawSha256']==sha(w/'live-recovery-rate-reader-observation.json')
bundle=w/('live-recovery-rate-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'live-recovery-rate-bundle-verify.log').write_text(v.stdout)
evidence=w/('live-recovery-rate-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-live-recovery-rate-reader-brief.md', 'live-recovery-rate-combined-review-package.md', 'task15-live-recovery-rate-combined-review.md', 'live-recovery-rate-review-outcome.md', 'live-recovery-rate-review-rulings.md', 'live-recovery-rate-implementation-notes.md', 'live-recovery-rate-tested-source.txt', 'live-recovery-rate-reviewed-source.txt', 'live-recovery-rate-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-live-recovery-rate-checkpoint.py', 'live-recovery-rate-readers-diagnostic.test.tsx', 'vitest-live-recovery-rate-reader.config.ts', 'live-recovery-rate-reader-observation.json', 'live-recovery-rate-reader-analysis.json', 'analyze-live-recovery-rate-readers.py', 'live-recovery-rate-fullcheck-audit.json', 'live-recovery-rate-initial-fullcheck-audit.json', 'live-recovery-rate-initial-turbo-logs.tar.gz', 'live-recovery-rate-turbo-logs.tar.gz', 'live-strength-reader-observation.json', 'ranged-ai-analysis.json', 'finalize-live-recovery-rate-report.py', 'audit-live-recovery-rate-fullcheck.py', 'task15-live-recovery-rate-next-notes.md', 'live-recovery-rate-test-count.txt', 'live-recovery-rate-checkpoint-summary.txt']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T190500':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'88aa0c7a07fc1f03b3577b9b992b510d5ddf65e6','previousArchiveTree':'b8fb035a75f7903a17b7ce490c1e2617c3f835fa','fullCheckReceipt':gate,'tests':{'vitest':8608,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/'live-recovery-rate-checkpoint-summary.txt').read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
