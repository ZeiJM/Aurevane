from pathlib import Path
import json,re,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=Path(gate['log']).read_text();expected=int((w/'live-recovery-rate-test-count.txt').read_text())
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log);assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
source=(w/'live-recovery-rate-tested-source.txt').read_text().strip();reviewed=(w/'live-recovery-rate-reviewed-source.txt').read_text().strip();assert reviewed=='df53d50ba49ea70094fceb7945927018d9a031fb'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source and not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
observed=json.loads((w/'live-recovery-rate-reader-analysis.json').read_text());assert observed['source']==source and observed['records']==294 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged']
review=(w/'live-recovery-rate-review-outcome.md').read_text();rulings=(w/'live-recovery-rate-review-rulings.md').read_text();new=expected-8574
report=f'''# Healing Down combined recovery rates — verified development checkpoint

The shared live-effect reader now shows Healing Down's combined HP and MP recovery rates from its recorded applications. Values explicitly say **before rounding**, because native recovery rounds down after each applied modifier and caps restoration by missing resources. Two25% modifiers show56.25% before rounding; an actual9-point recovery restores4, rather than a nominal5.0625. Default then20% shows60% under current application stacking and80% under historical whole-row rules.

The captured recovery policy is independent of stacking policy. Current recovery rules apply Healing Down to HP, MP and Absorb. Historical rules leave MP recovery and Absorb unchanged; the reader explicitly retains that exception and shows MP100%. Previously captured percentage recovery keeps its recorded amount despite later status changes. Actual future ticks after cleansing and replacing Healing Down verify the existing captured56HP/MP (or100legacyMP), without recalculation or a second reduction.

Exact nominal rates use the existing shared BigInt ratio utilities. The damage helper now imports the same extracted functions with no arithmetic changes. Rates requiring more than two decimal places carry an approximation marker: two33.33% reductions show≈44.45% before rounding, while native10,000-point recovery is4444 after per-modifier truncation. A positive rate below displayed precision is never called zero. Extreme nominal precision beyond the shared65,536-bit capacity is unavailable, even when native integer recovery has already reached zero; the reader does not invent an exact nominal value or run an unbounded calculation.

The existing gold/orange summary rows and accessible report share the same HP/MP facts and qualifications. Pending rows say on activation. Exact known ID/version checks retain unavailable rules for unsupported captures. Covert retains its existing polarity rule: positive Damage Up is hidden from a spectator, while negative Healing Down remains public. No new public metadata, native operator, validation, persistence, schema, command, AI, manifest, control, CSS, artwork or geometry change.

## Verification and review

- BASEb4e3e537d01817b78e75ecb6810500009e8a3120 → initial reviewed `{reviewed}` → final tested `{source}`. Five initial web source/test files; **{new}new cases overall**. The final report is a docs-only descendant of tested production source.
- Initial190903562217 had32 valid missing-rate/qualification failures, one incorrect Covert fixture expectation and one unsupported-version guard passing. The unchanged production filter intentionally retains negative debuffs under Covert. The corrected fixture checks positive Damage Up hidden and Healing Down visible with its rate. Corrected190949897695:33 valid missing-fact RED plus one guard GREEN. No privacy behavior was changed to fit a test.
- First implementation191017896193 passes64tests in two files:34new recovery-rate cases plus all30 previous damage-strength cases after extracting their arithmetic unchanged. Final initial focused **974tests/86files GREEN191122445549**, native Recovery/percentage/Absorb **125tests/5files GREEN191122446669**, web types191122448673 GREEN and zero-warning scoped lint191122445251 GREEN. Exact body and accessible HP/MP values, approximation/precision, pending, unknown rules, input immutability, capture freeze and Covert are covered.
- Native command cases cover flat HP/MP rounding across the full stacking/recovery-policy cross-product; actualMPDrain remains unmodified; actual restoration is capped by missingHP/MP. A real100damage command under25%Absorb and two25%HealingDown modifiers recovers13HP/MP under current recovery policy and25 under historical policy, matching the reader's explicit exception.
- Final exact-source full check: **{expected:,}Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds GREEN. Receipt `{Path(gate['log']).stem}`, {gate['started_utc']} → {gate['completed_utc']}. Package counts: {', '.join(a+' '+b for a,b in counts)}. Complete final root build tail and package-log hash audit preserved. The initial fresh root191248136192 exited0 with all test counts and complete web package build log, but its combined saved stdout omitted the final build-summary lines. Initial audit/package logs are preserved; ONE cached root replay supplies this complete final receipt. No production source changed between them.
- All294 named Skill reports and HTML strings remain exactly unchanged from the preceding damage-strength checkpoint:294records,297groups,604effects; raw observation SHA256 `{observed['rawSha256']}`. Manifest and six AI/native source hashes are unchanged. No new289-case gameplay matrix is claimed for this presentation-only cohort.

{review}

The new tests execute real native casts, turns, public spectator projection, shared report and actual SSR body. Only the server-only import marker is mocked. Source parity and SSR are not mounted DOM, native browser, assistive-technology or physical geometry acceptance. Both breakpoints and shared PvE/PvP/spectator readers inherit the same facts; native acceptance remains required.

## Remaining release work

The modular foundation already live, proposed Skill rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance remain pre-release requirements. Other non-damage/conditional strength and whole-action readiness, noncompact trigger summaries, historical Chronicle and public Manual references remain open. Full roster cycles, natural pacing/twelve-round balance, current Owner edits, hosted authority/CAS, Atlas motion and human acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is made here. High remains sufficient for routine integration. The provisional16–30activehours/roughly2–4fullworkingdays is an uncertain working estimate, not a calendar launch promise or a mechanically reduced count.

## Deferred Minors

Thirteen inherited items remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status input-immutability witness; legacy duplicate component keys. Any new reviewed Minor is listed in the review outcome above.

## Initial implementation decisions

1. Show nominal combined rate before integer rounding, with actual caps and frozen-capture qualifications. Reason: a rate alone cannot represent per-step truncation or missing resources. Cost if wrong: actual captures/outcomes remain necessary for exactHP/MP.
2. Keep recovery policy independent of stacking policy. Reason: native MP and Absorb paths check their own captured flag. Cost if wrong: cross-product coverage is required to prevent historical changes.
3. Extract and reuse the existing web ratio and percentage functions. Reason: damage and recovery nominal rates should not duplicate exact arithmetic. Cost if wrong: old30damage cases and full-root checks must guard the refactor.
4. Bound nominal exact precision and show unavailable at the existing shared capacity. Reason: native integer recovery can stop at zero while a positive formal fraction requires arbitrarily large precision. Cost if wrong: extreme valid nominal rates may be unavailable even when actual recovery is zero; no invented zero nominal value is shown.

## Every parent set-aside ruling

{rulings}
'''
(root/'docs/verification/2026-10-16-live-effect-recovery-rate-readers.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Final Healing Down combined-rate checkpoint\n'+report+'\n')
print('Wrote guarded final recovery-rate report and ledger.')
