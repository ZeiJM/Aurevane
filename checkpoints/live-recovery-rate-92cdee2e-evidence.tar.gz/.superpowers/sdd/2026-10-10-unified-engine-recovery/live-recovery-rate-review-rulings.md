1. Final: Ruling: Final HP/MP forecasts — Keep nominal rates with rounding/cap/capture qualifications; final state is absent. Cost if wrong: Exact restoration still needs actual capture/outcome.

2. Final: Ruling: Conditional opponent/source/facing/HP damage — Leave unchanged context-aware damage integration for later. Cost if wrong: Conditional combined magnitude remains open.

3. Final: Ruling: Other non-damage strength — Keep separate from Healing Down. Cost if wrong: Other categories remain unfinished.

4. Final: Ruling: Controlled readiness — Keep captured action-state ownership. Cost if wrong: Controlled readiness acceptance remains open.

5. Final: Ruling: Other whole-action readiness — Keep separate state-aware integration. Cost if wrong: Other readiness remains open.

6. Final: Ruling: Noncompact EffectModifiers triggers — Retain unchanged individual deltas; popup/report only here. Cost if wrong: Trigger summary audit remains open.

7. Final: Ruling: Manual/authored-content acceptance — Keep separate public content reader gate. Cost if wrong: No full Manual/content acceptance.

8. Final: Ruling: Historical Chronicle/modal redesign — Keep unchanged historical fallback for later integration. Cost if wrong: Historical readers remain unfinished.

9. Final: Ruling: Ordinary incoming-damage summary arithmetic — Keep unchanged summary; extracted ratio module is separate. Cost if wrong: No fresh ordinary-summary arithmetic audit.

10. Final: Ruling: Legacy global damage budget — Do not infer a global clamp from an isolated rate. Cost if wrong: Full legacy damage-budget presentation remains open.

11. Final: Ruling: Mounted mouse — Leave native acceptance open; no browser session. Cost if wrong: Mouse behavior unverified.

12. Final: Ruling: Mounted touch — Leave native acceptance open; no browser session. Cost if wrong: Touch behavior unverified.

13. Final: Ruling: Mounted keyboard/focus — Source parity and SSR are insufficient. Cost if wrong: Native keyboard/focus acceptance remains open.

14. Final: Ruling: Assistive technology — Keep shared strings without claiming actual AT execution. Cost if wrong: AT output remains unverified.

15. Final: Ruling: Long-report layout — Reuse existing layout with physical gate open. Cost if wrong: Added text may expose overflow.

16. Final: Ruling: Small-screen geometry — No mounted viewport evidence closes this gate. Cost if wrong: Small-screen clipping remains unverified.

17. Final: Ruling: 200%zoom geometry — No physical zoom evidence closes this gate. Cost if wrong: Zoom clipping remains unverified.

18. Final: Ruling: Button/popup CSS sizing — No geometry changes or physical evidence. Cost if wrong: Physical sizing remains unverified.

19. Final: Ruling: Inspection backdrop dismissal — Retain unchanged outside-click ownership. Cost if wrong: Outside inspection still closes the whole inspection.

20. Final: Ruling: Whole malformed persisted validation — Keep parser authority; relevant constraints traced only. Cost if wrong: Whole-parser audit remains open.

21. Final: Ruling: Whole malformed pending validation — Keep pending parser authority; relevant projection traced. Cost if wrong: Full pending malformed-state acceptance remains open.

22. Final: Ruling: Whole summon validation — Summon behavior unchanged and separate. Cost if wrong: No fresh summon-parser audit.

23. Final: Ruling: Live expiry/revocation — Keep unchanged authority under Task8/16 gate. Cost if wrong: Hosted expiry/revocation acceptance required.

24. Final: Ruling: Alternate selected-character authority — Keep unchanged selected-character enforcement gate. Cost if wrong: No fresh alternate-character authority evidence.

25. Final: Ruling: Direct RPC/CAS bypass — Keep unchanged hosted authority gate. Cost if wrong: Hosted direct-RPC/CAS verification remains required.

26. Final: Ruling: No-input bounded gameplay — Execution unchanged; keep gameplay gate. Cost if wrong: No fresh complete no-input acceptance.

27. Final: Ruling: Duplicate payment/extra turns — Native payment/turn authority unchanged. Cost if wrong: Fresh complete payment/turn acceptance remains open.

28. Final: Ruling: Interrupted Move origins — Movement execution unchanged. Cost if wrong: Reached-origin gameplay acceptance remains open.

29. Final: Ruling: Publication/build/claim concurrency — Transactions/workers unchanged. Cost if wrong: Hosted concurrent operations remain unaccepted.

30. Final: Ruling: Recovery/settlement concurrency — Settlement authority unchanged. Cost if wrong: Reader tests do not establish concurrency safety.

31. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Witness still starts at origin.

32. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; capture test unchanged. Cost if wrong: Exact version coverage remains incomplete.

33. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; identity test unchanged. Cost if wrong: Identity witness remains weaker.

34. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

35. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission wording unchanged. Cost if wrong: Duplicate prefix wording remains.

36. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; no native change. Cost if wrong: Negative witness remains preparation-only.

37. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; event test unchanged. Cost if wrong: Events lack independent HP reconciliation.

38. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact historical value/label coverage incomplete.

39. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; no incidental editorial repair. Cost if wrong: Grammar defect remains.

40. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; Burn unchanged. Cost if wrong: Burn boundary wording remains imprecise.

41. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry remains unverified.

42. Final: Ruling: Cross-status input-immutability witness — Keep inherited Minor deferred; separate cohort. Cost if wrong: Its direct-input witness remains weaker.

43. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: no new status rows or demonstrated mounted failure. Cost if wrong: Expiry/replacement may misassociate popup state.

44. Final: Ruling: Whole-roster balance — Keep separate balance gate. Cost if wrong: Roster balance remains unaccepted.

45. Final: Ruling: Full natural combat cycles — Representative native fixtures cannot establish exhaustive cycles. Cost if wrong: Natural/full-cycle acceptance remains open.

46. Final: Ruling: Original combat/editor/control completion — A bounded reader does not complete those systems. Cost if wrong: Original combat integration remains unfinished.

47. Final: Ruling: Full Task15/16 — Keep whole-task acceptance separate. Cost if wrong: Task15/16 remain unfinished.

48. Final: Ruling: Owner-hosted acceptance — No hosted execution establishes acceptance. Cost if wrong: Hosted gate remains open.

49. Final: Ruling: Atlas motion/acceptance — Unchanged and outside reader checks. Cost if wrong: Atlas gate remains open.

50. Final: Ruling: Human gameplay acceptance — Source review and fixtures cannot establish human acceptance. Cost if wrong: Human gate remains open.

51. Final: Ruling: Publication/activation/migration readiness — Review supplies no operational approval. Cost if wrong: No content activation or hosted migration is authorized here.

52. Final: Ruling: Merge/deployment/release readiness — Keep final integration and release gates open. Cost if wrong: Combat update remains unreleased.
