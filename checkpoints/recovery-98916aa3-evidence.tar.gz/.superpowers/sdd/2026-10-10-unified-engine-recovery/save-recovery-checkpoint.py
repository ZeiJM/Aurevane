import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'recovery-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'recovery-tested-source.txt').read_text().strip();base='7d2b4765e9009518080026f62f4fff9aeeb31b5e'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==6 and all(p.startswith('apps/web/src/components/character/') or p=='docs/verification/2026-10-16-canonical-recovery-reader-prose.md' for p in paths),paths
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()];gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8295
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'recovery-reader-final-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['changed']==170 and observed['rawSha256']==sha(w/'recovery-reader-final-observation.json')
bundle=w/('recovery-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'recovery-bundle-verify.log').write_text(v.stdout)
evidence=w/('recovery-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-recovery-reader-prose-brief.md', 'task15-recovery-reader-review.md', 'recovery-review-rulings.md', 'record-recovery-review.py', 'recovery-tested-source.txt', 'recovery-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-recovery-checkpoint.py', 'recovery-readers-diagnostic.test.tsx', 'vitest-recovery-reader.config.ts', 'recovery-reader-observation.json', 'recovery-reader-analysis.json', 'recovery-readers-final-diagnostic.test.tsx', 'vitest-recovery-reader-final.config.ts', 'recovery-reader-final-observation.json', 'recovery-reader-final-analysis.json', 'remaining-status-reader-inventory.json', 'elemental-wrapper-reader-candidates.json', 'task15-status-reader-next-brief.md','recovery-fullcheck-audit.json','recovery-turbo-logs.tar.gz']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T142100':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'prerequisite':base,'previousArchiveCommit':'074f7ef31fca1c817afeddf09e76225e7e2b8ad7','previousArchiveTree':'bf09b6f38b4a0dc70696bcb1139d83185fdab06d','fullCheckReceipt':gate,'tests':{'vitest':8295,'node':7},'bundle':info(bundle),'evidence':info(evidence),'acceptance':'Canonical recovery/movement/Reveal non-damage prose170effects, truthful structured periodic applications/clock and Reveal owner-start lifetime. Review0C1I corrected current-turn skip via actualengine+reader RED→GREEN;23new cases,720covering. Frozen8295Vitest+7Node verified. Final294record297group604effect static observation170changed434unchanged; digits521to353/non-direct-damage350to182 auditcandidates only.8priorMinorsdeferred. Manifest/AI/executor/prices/defaultfixture unchanged; no duplicate289. Original combat integration/readers/status/prose/native and full balance/Owner/hosted/Atlas/human/release OPEN. No publication/activation/migration/merge/deploy.'}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
