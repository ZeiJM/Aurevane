
## Combined review, one fix wave and individual rulings

One fresh gpt-6-astra High combined review7d2b4765..9f6a9ac5 finds0Critical/1Important/0newMinor. Parent confirms the Important: the initial Then fact includes an already-started recipient turn although `scheduleAfterRecovery`/`resolveEndOfTurnRecovery` skip its ending. The single fix wave changes only that fact to **End of each recipient turn that starts after activation**. Valid RED `143054628577` reports5failed/18passed, including actual core execution before the false report assertion for both self and off-turn ally; a preceding unexported test-helper import failure `143039734501` is not behavior evidence. After correction, **720tests/seven files pass** `143139469121`, including23new reader cases. Each new self/ally witness executes flat HP, flat MP and percentage recovery, verifies pending counters across the actual first/following recipient endings, then checks report and rendered reader. No HP/resource/state patch or mechanics change. Final types `143140006481`, app-configured ESLint `143140006519` and Prettier pass. No rereview; prior eight Minors remain unchanged.

Initial frozen9f6a9ac5 full check `142548898732` passes8,293Vitest+7Node,14:25:48–14:29:49UTC, but does not close the review finding. Post-fix frozen full gate is required; expected8,295Vitest+7Node remains unconfirmed until completion.

Final: Ruling: Stale-browser authority and revocation — No authority boundary changes here; retain Task16 stale-session execution gate — Cost if wrong: Revoked authority may remain unverified.

Final: Ruling: Alternate selected-character authority — Report formatting cannot establish selected-character enforcement — Cost if wrong: Wrong-character authority may remain unverified.

Final: Ruling: Direct RPC expiry and CAS — No direct RPC exercise in this reader delta; retain protected RPC gate — Cost if wrong: A direct-call defect may remain.

Final: Ruling: Malformed nested-data rejection — Existing parser remains authoritative; this cohort uses valid payloads — Cost if wrong: Malformed recovery inputs may remain unverified.

Final: Ruling: Malformed captured/pending/summon data — No capture or summon validator changes; retain serialization gate — Cost if wrong: Malformed historical data may remain unverified.

Final: Ruling: Recursive transport confidentiality — Inspected public-reader path is narrower than transport-wide confidentiality — Cost if wrong: Another transport could expose private data.

Final: Ruling: All immutable-history capture paths — Raw legacy helper and recorded definitions are unchanged; keep full history acceptance — Cost if wrong: Another historical path may remain wrong.

Final: Ruling: No-input and timeout execution — No scheduler or timeout execution changes — Cost if wrong: Timeout behavior may remain unverified.

Final: Ruling: Free priming and repeated-event bounds — Controlled instructions are retained without changing its execution — Cost if wrong: A priming/event-bound defect may remain.

Final: Ruling: Duplicate payment and extra turns — Reader facts do not establish payment/turn authority — Cost if wrong: Payment or turn defects may remain.

Final: Ruling: Interrupted Move and reached-origin legality — Move prose preserves restrictions; no path execution changes — Cost if wrong: An interrupted movement path may remain unverified.

Final: Ruling: Concurrent publication coherence — Local roster publication tests do not establish hosted concurrency — Cost if wrong: Concurrent publication may still need correction.

Final: Ruling: Concurrent build and claim coherence — No build/claim writes here; retain actual concurrency gate — Cost if wrong: A duplicate build/claim result may remain.

Final: Ruling: Concurrent recovery and settlement coherence — New sequential recovery clock witnesses do not test concurrency — Cost if wrong: A settlement race may remain.

Final: Ruling: Hosted rollback locks and retry/no-contest — No hosted operation; retain actual database gate — Cost if wrong: Database-only rollback/locking defects may remain.

Final: Ruling: Long-name native layout — Static markup provides no browser geometry — Cost if wrong: Long names may overflow.

Final: Ruling: All missing historical metadata consumers — Captured old Healing Down context is narrower than every historical consumer — Cost if wrong: Another missing-metadata fallback may remain wrong.

Final: Ruling: Native keyboard and focus — No native interaction execution — Cost if wrong: Focus behavior may remain wrong.

Final: Ruling: Touch and mobile — No native device execution — Cost if wrong: Touch readers may remain inaccessible.

Final: Ruling: 200% zoom overflow and contrast — Shared classes are reused; no browser layout/contrast evidence — Cost if wrong: Zoom or contrast may remain inadequate.

Final: Ruling: Native Targeting controls — Keep original Targeting integration gate before release — Cost if wrong: A targeting path may remain unfinished.

Final: Ruling: Native Move controls — Keep original Move integration gate before release — Cost if wrong: A movement gesture may remain unfinished.

Final: Ruling: Editable five-Basic integration — Native Move price distinction does not accept every editable Basic — Cost if wrong: An edited Basic may remain misrepresented.

Final: Ruling: Controlled prime release and cancel — Instructions remain intact; no command-interaction acceptance — Cost if wrong: A prime/release interaction may remain wrong.

Final: Ruling: Rewind anchors and history — No Rewind source change; retain full original integration gate — Cost if wrong: An anchor/history interaction may remain unverified.

Final: Ruling: Every editor preview popup and public reader — Shared local/public SSR and publication coverage are narrower than all mounted surfaces — Cost if wrong: Another consumer may remain stale.

Final: Ruling: All294 descriptions and status/DoT secondary facts — 170 explanations changed and434 stayed exact; remaining semantic audit stays open — Cost if wrong: Other explanations may repeat or omit important facts.

Final: Ruling: Actual orange references links and popup interaction — Existing highlighted fact class is reused; full reference/interaction audit remains — Cost if wrong: Other references may remain inconsistent.

Final: Ruling: Every distinct gameplay cycle — Recovery clock execution witnesses are narrower than full roster cycles — Cost if wrong: A different cycle may remain ineffective.

Final: Ruling: AI strategic quality and289 acceptance — Planner/authority/fixture defaults unchanged; do not duplicate289for reader-only delta — Cost if wrong: Broader strategic quality remains open.

Final: Ruling: Natural pacing and twelve-round balance — No balance experiment or parameter change in this reader cohort — Cost if wrong: Sustain stalls or pacing mismatch may remain.

Final: Ruling: Current Owner-edit reconciliation — Require fresh release-time Owner data — Cost if wrong: Stale publication could overwrite newer Owner work.

Final: Ruling: Atlas and human gameplay — Existing Atlas bound and human acceptance remain open — Cost if wrong: Motion or gameplay feel may remain unacceptable.

Final: Ruling: Final frozen full-project result — Accept only actual completed post-fix output below — Cost if wrong: Unchecked regressions could be accepted.

Final: Ruling: Publication activation migration merge and deployment readiness — Do none here; retain all original release gates and lock — Cost if wrong: Premature release could bypass unfinished work.

Final: Ruling: Broader Master-panel completion — Follow combat release per approved ordering — Cost if wrong: Unrelated Master work remains unfinished until that stage.
