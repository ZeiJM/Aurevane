from pathlib import Path
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery')
rulings=[
('Stale-browser authority and revocation','No authority boundary changes here; retain Task16 stale-session execution gate','Revoked authority may remain unverified'),
('Alternate selected-character authority','Report formatting cannot establish selected-character enforcement','Wrong-character authority may remain unverified'),
('Direct RPC expiry and CAS','No direct RPC exercise in this reader delta; retain protected RPC gate','A direct-call defect may remain'),
('Malformed nested-data rejection','Existing parser remains authoritative; this cohort uses valid payloads','Malformed recovery inputs may remain unverified'),
('Malformed captured/pending/summon data','No capture or summon validator changes; retain serialization gate','Malformed historical data may remain unverified'),
('Recursive transport confidentiality','Inspected public-reader path is narrower than transport-wide confidentiality','Another transport could expose private data'),
('All immutable-history capture paths','Raw legacy helper and recorded definitions are unchanged; keep full history acceptance','Another historical path may remain wrong'),
('No-input and timeout execution','No scheduler or timeout execution changes','Timeout behavior may remain unverified'),
('Free priming and repeated-event bounds','Controlled instructions are retained without changing its execution','A priming/event-bound defect may remain'),
('Duplicate payment and extra turns','Reader facts do not establish payment/turn authority','Payment or turn defects may remain'),
('Interrupted Move and reached-origin legality','Move prose preserves restrictions; no path execution changes','An interrupted movement path may remain unverified'),
('Concurrent publication coherence','Local roster publication tests do not establish hosted concurrency','Concurrent publication may still need correction'),
('Concurrent build and claim coherence','No build/claim writes here; retain actual concurrency gate','A duplicate build/claim result may remain'),
('Concurrent recovery and settlement coherence','New sequential recovery clock witnesses do not test concurrency','A settlement race may remain'),
('Hosted rollback locks and retry/no-contest','No hosted operation; retain actual database gate','Database-only rollback/locking defects may remain'),
('Long-name native layout','Static markup provides no browser geometry','Long names may overflow'),
('All missing historical metadata consumers','Captured old Healing Down context is narrower than every historical consumer','Another missing-metadata fallback may remain wrong'),
('Native keyboard and focus','No native interaction execution','Focus behavior may remain wrong'),
('Touch and mobile','No native device execution','Touch readers may remain inaccessible'),
('200% zoom overflow and contrast','Shared classes are reused; no browser layout/contrast evidence','Zoom or contrast may remain inadequate'),
('Native Targeting controls','Keep original Targeting integration gate before release','A targeting path may remain unfinished'),
('Native Move controls','Keep original Move integration gate before release','A movement gesture may remain unfinished'),
('Editable five-Basic integration','Native Move price distinction does not accept every editable Basic','An edited Basic may remain misrepresented'),
('Controlled prime release and cancel','Instructions remain intact; no command-interaction acceptance','A prime/release interaction may remain wrong'),
('Rewind anchors and history','No Rewind source change; retain full original integration gate','An anchor/history interaction may remain unverified'),
('Every editor preview popup and public reader','Shared local/public SSR and publication coverage are narrower than all mounted surfaces','Another consumer may remain stale'),
('All294 descriptions and status/DoT secondary facts','170 explanations changed and434 stayed exact; remaining semantic audit stays open','Other explanations may repeat or omit important facts'),
('Actual orange references links and popup interaction','Existing highlighted fact class is reused; full reference/interaction audit remains','Other references may remain inconsistent'),
('Every distinct gameplay cycle','Recovery clock execution witnesses are narrower than full roster cycles','A different cycle may remain ineffective'),
('AI strategic quality and289 acceptance','Planner/authority/fixture defaults unchanged; do not duplicate289for reader-only delta','Broader strategic quality remains open'),
('Natural pacing and twelve-round balance','No balance experiment or parameter change in this reader cohort','Sustain stalls or pacing mismatch may remain'),
('Current Owner-edit reconciliation','Require fresh release-time Owner data','Stale publication could overwrite newer Owner work'),
('Atlas and human gameplay','Existing Atlas bound and human acceptance remain open','Motion or gameplay feel may remain unacceptable'),
('Final frozen full-project result','Accept only actual completed post-fix output below','Unchecked regressions could be accepted'),
('Publication activation migration merge and deployment readiness','Do none here; retain all original release gates and lock','Premature release could bypass unfinished work'),
('Broader Master-panel completion','Follow combat release per approved ordering','Unrelated Master work remains unfinished until that stage'),
]
text='\n## Combined review, one fix wave and individual rulings\n\nOne fresh gpt-6-astra High combined review7d2b4765..9f6a9ac5 finds0Critical/1Important/0newMinor. Parent confirms the Important: the initial Then fact includes an already-started recipient turn although `scheduleAfterRecovery`/`resolveEndOfTurnRecovery` skip its ending. The single fix wave changes only that fact to **End of each recipient turn that starts after activation**. Valid RED `143054628577` reports5failed/18passed, including actual core execution before the false report assertion for both self and off-turn ally; a preceding unexported test-helper import failure `143039734501` is not behavior evidence. After correction, **720tests/seven files pass** `143139469121`, including23new reader cases. Each new self/ally witness executes flat HP, flat MP and percentage recovery, verifies pending counters across the actual first/following recipient endings, then checks report and rendered reader. No HP/resource/state patch or mechanics change. Final types `143140006481`, app-configured ESLint `143140006519` and Prettier pass. No rereview; prior eight Minors remain unchanged.\n\nInitial frozen9f6a9ac5 full check `142548898732` passes8,293Vitest+7Node,14:25:48–14:29:49UTC, but does not close the review finding. Post-fix frozen full gate is required; expected8,295Vitest+7Node remains unconfirmed until completion.\n\n'
text+='\n\n'.join(f'Final: Ruling: {name} — {why} — Cost if wrong: {cost}.' for name,why,cost in rulings)+'\n'
(w/'recovery-review-rulings.md').write_text(text)
p=Path('docs/verification/2026-10-16-canonical-recovery-reader-prose.md');s=p.read_text().replace('A new exact-source all294 static consumer observation will compare the visible fallback inventory, without overwriting prior evidence.','Exact initial-source9f6a9ac5 all294 static consumer observation `142658455990` confirms297groups/604effects, exactly170changed explanations and434unchanged. Digit-bearing explanation candidates decrease521→353; excluding direct Damage/Pierce,350→182. These are observational counts, not182proven violations. Initial raw SHA256 `b8082d78c8aed0fabcccbbc7d6fcf42941f666619999dd5c70cfea234f8bb8e7`; a final post-clock observation must retain this prior record.')
p.write_text(s+text)
with (w/'progress.md').open('a') as f:f.write(text+'\nTask15recoveryreaderwave:0C1I accepted/fixed, actualclockRED143054628577→GREEN720/7 143139469121. New23tests. Types143140006481/lint143140006519GREEN. Initial8293+7GREEN142548898732notfinalacceptedsource. Freezepostfix for8295+7fullgate. All36declinedjudgments individually ruled;8priorMinorsunchanged,norereview.\n')
