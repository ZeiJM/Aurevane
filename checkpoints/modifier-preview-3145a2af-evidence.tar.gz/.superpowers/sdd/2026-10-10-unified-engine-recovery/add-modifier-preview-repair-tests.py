from pathlib import Path
p=Path('apps/web/src/server/master/master-modifier-preview.test.tsx');s=p.read_text();s+='''
it.each(['pve','pvp'] as const)('quotes the exact selected modifier bundle with a current Controlled reference in %s', async (combatContext) => {
  const api = fixture()
  const root = records.find((r: {id:string}) => r.id === 'farstrider.longshot').after
  await api.store.publish({contentKey:root.id,contentKind:'skill',definition:root,expectedBaseVersion:null,versionFloor:root.contentVersion-1,actorUserId:owner})
  const definition = records.find((r: {id:string}) => r.id === 'farstrider.keen-focus').after
  const response = await api.request({definition,behaviorId:'keen-focus',previewRootSkillId:root.id,previewRootBehaviorId:'longshot',combatContext})
  expect(response.status,JSON.stringify(await response.clone().json())).toBe(200)
  const {preview} = await response.json()
  expect(preview).toMatchObject({legal:true,behaviorId:'keen-focus',referenceAction:{id:root.id,contentVersion:root.contentVersion,behaviorId:'longshot'},simulation:{preparation:'free-controlled-prime',rngConsumed:false},costs:{actionEconomy:70,mp:6,hp:0}})
  expect(preview.projections.effects.some((e:{effectType:string;before:number;after:number}) => e.effectType==='damage'&&Number(e.before)>Number(e.after))).toBe(true)
  expect(JSON.stringify(preview)).not.toMatch(/sourceInstanceId|manualModifiers|capturedAbilitySources|effectOrigins|chanceBasisPoints/)
})
''';p.write_text(s)
p=Path('apps/web/src/components/master/combat-content/resonance-preview-interaction.test.tsx');s=p.read_text();s=s.replace("function skillModifierFixture(kind: 'skill' | 'essence')", "function skillModifierFixture(kind: 'skill' | 'essence', disabled = false)");s=s.replace('  const skill = record.after','  const skill = { ...record.after, enabled: !disabled }');s=s.replace('skill: { ...baseEssence.after.skill, ability: skill.ability },','skill: { ...baseEssence.after.skill, ability: skill.ability, enabled: !disabled },');s=s.replace('''    panel,
    run,
    sent,''','''    panel,
    run,
    sent,
    store,
    id: kind === 'skill' ? skill.id : essence.essenceId,''');s+='''
it.each(['skill','essence'] as const)('publishes a disabled %s modifier revision without an enabled simulation', async (kind) => {
  const f=skillModifierFixture(kind,true)
  await f.run('onValidate')
  expect(f.panel().validation?.valid).toBe(true)
  await f.run('onDiff')
  expect(f.panel().previewRequired).toBe(false)
  const sent = f.sent.length
  await f.run('onPreview')
  expect(f.sent).toHaveLength(sent)
  expect(f.panel().preview).toBeNull()
  expect(find(CombatContentReviewPanel(f.panel()), n=>n.type==='button'&&n.props.children==='Publish')!.props.disabled).toBe(false)
  f.panel().onRequestPublish()
  f.panel().onConfirmPublish()
  await vi.waitFor(()=>expect(f.panel().busy).toBe(false))
  const published=await f.store.findPublished(f.id,kind)
  expect(published?.definition.flavorLine).toBe('Edited modifier.')
  if(kind==='skill') expect(published?.definition.enabled).toBe(false)
  else expect((published?.definition.skill as {enabled:boolean}).enabled).toBe(false)
})
''';p.write_text(s)
