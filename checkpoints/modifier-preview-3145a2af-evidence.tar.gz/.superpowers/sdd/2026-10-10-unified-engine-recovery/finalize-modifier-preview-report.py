from pathlib import Path
import json,subprocess,re,hashlib,datetime
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
git=lambda *args: subprocess.check_output(['git',*args],text=True).strip()
tested=(w/'modifier-preview-tested-source.txt').read_text().strip();reviewed=(w/'modifier-preview-reviewed-source.txt').read_text().strip()
assert git('rev-parse','HEAD')==tested and not git('status','--porcelain')
assert reviewed=='f9b0a60efa6042bec4186c10caa370d0919a1044'
assert 'No unresolved Critical or Important' in (w/'modifier-preview-review-outcome.md').read_text()
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
r=next(x for x in reversed(receipts) if x['argv']==['pnpm','--reporter=append-only','check'])
s=Path(r['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',s)
assert r['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8900
completion=json.loads((w/'modifier-preview-root-tool-completion.json').read_text());assert completion['source']==tested and completion['receipt']==r and completion['transportExitCode']==0 and '2 successful, 2 total' in completion['observedFinalBuildTail']
assert 'ℹ pass 7' in s and 'ℹ fail 0' in s
assert datetime.datetime.fromisoformat(r['started_utc'])>=datetime.datetime.fromisoformat(git('show','-s','--format=%cI',tested))
for name in ['reader','legacy','actions']:
 a=json.loads((w/f'modifier-preview-{name}-analysis.json').read_text());assert a['source']==tested
assert json.loads((w/'modifier-preview-reader-analysis.json').read_text())['allReportsAndHtmlExactlyUnchanged']
assert json.loads((w/'modifier-preview-legacy-analysis.json').read_text())['allLegacyNativePreviewsExactlyUnchanged']
assert json.loads((w/'modifier-preview-actions-analysis.json').read_text())['exact']
rows=json.loads((w/'modifier-preview-review-rulings.json').read_text());assert len(rows)==37
minors=[
'Rewind witness origin.','Supporting Shot version pin.','Ongoing pair dynamic identity pin.','Repeated bounded AI discovery.','Admission double-prefix provenance.','Ranged negative preparation lacks a direct-commit witness.','Defense-positive events lack independent HP reconciliation.','Exact Arsenal historical values and labels.','Singular status-clock grammar.','Burn ordinary tick-boundary wording.','Master inline-reference button minimum height/font.','Cross-status immutability witness compares a different parsed definition from the actual direct input.','Legacy same-status popup duplicate component keys; no mounted failure established.','Unknown-reference Manual fixture does not isolate matching-text rejection; production guard is correct.'
]
report=f'''# Manual modifier preview — verified development checkpoint

Master Skill, inner Essence Skill and Resonance authoring can now preview a Manual modifier as part of a real reference action. Previously the selector and service only accepted Manual action groups, leaving modifiers without a meaningful battle context. The author chooses a reference Skill identity and, where required, its exact Manual group. The existing authenticated service resolves its current published version, then prepares the complete native command.

The default reference is Basic Attack. The dropdown offers built-in Skill identities, resolved current on the server; an optional group field supports a current published definition with several Manual actions. Unknown, disabled, malformed and ambiguous references reject explicitly. A separate source is required; a modifier never becomes an independent cast. Skill/Essence capture retains its real source, Resonance capture retains its exact sorted pair, and native historical Skill roots use the existing native adapter rather than a fabricated Ability. Canonical roots use the existing shared preparation path.

Costs and projections describe the whole root-plus-modifier command. The root's classification, attack family and intrinsic Discipline determine qualification. Native unmet Requirements or root incompatibility produce an informative illegal preview with no invented costs or outcomes. The fixed fixture does not supply arbitrary statuses or resources to force success. Actual amplified damage, aggregate AP/MP, current reference version/group, Basic binding, input immutability and no-RNG behavior are covered.

All three editors clear preview and publication confirmation when the reference or selected group changes. Revision guards discard late responses. Enabled Skill/Essence modifiers still require a completed current preview; fixture illegality remains informative. Pure-modifier Resonances retain their prior validation/diff publication workflow with optional preview. Disabled modifier Skill and inner-Essence revisions can publish valid edits while retaining their disabled state, without any enabled simulation. Normal action publication defaults and the existing server CAS remain unchanged.

## Independent review and the single repair wave

One fresh gpt-6-astra High reviewer inspected the frozen range: **0 Critical, 2 Important, 0 new Minor**. Both Important findings were accepted and fixed in ONE RED→GREEN repair wave, without rereview. Fourteen inherited Minors remain deferred.

1. **Controlled reference bundle mismatch.** Free priming omitted the selected modifiers and release correctly failed native capture matching. The same exact Manual bundle now goes into availability, prime and release. Actual current published Longshot plus Keen Focus passes in PvE and PvP, reports its free prime and combined **70 AP / 6 MP**, and projects real damage without private captures.
2. **Disabled modifier publication deadlock.** Skill and inner-Essence editors required a preview that the service correctly rejects while disabled. Their panel and direct publication callback now use validation/diff for disabled modifiers. Actual client → authenticated handler → service → local repository publication preserves both disabled state and text. Enabled preview gates remain.

The four repair cases failed on frozen source in isolated diagnostic copies (`222829000570Z-5eba6746`) and again in their final canonical test files (`222855610870Z-5c867454`), then passed (`222910445468Z-11229b4d`). Final focused suite: **454 tests / 23 files**, receipt `222925643401Z-449baa2c`; typecheck `222925637698Z-21e1be8b`; scoped web-config ESLint `222925643390Z-751385e9`.

## Verification and preservation

Final tested implementation `{tested}`; independently reviewed implementation `{reviewed}`; cohort BASE `5e4e97fd1ca2b377e936bfb746f7b95d55f176a2`. The report is the only subsequent tracked change. No combat engine, schema, SQL, roster manifest, AI source, CSS, artwork or battle-control change.

The cohort adds **23 tests**: 17 authenticated service/native cases and six controlled editor-callback cases. All four accepted Manual modifiers are selected and either quoted or truthfully blocked by native Requirements. A prior test titled Automatic-only accidentally selected a Manual modifier; its fixture now actually selects Automatic-only behavior, preserving its original rejection intent.

| Check | Result |
| --- | --- |
| Full repository quality gate | **8,900 Vitest + 7 Node checks**, format/lint/all types/both builds pass; receipt `{Path(r['log']).stem}` |
| Default native previews | All **141** full JSON results exactly unchanged:136 native Skills + five Basics |
| Proposed Manual action previews | All **284** full JSON quotes exactly unchanged across Skill/Essence/Resonance/Basic |
| Named shared reports and rendered HTML | All **294** records /297 groups /604 effects exactly unchanged |
| Proposal manifest and six AI/native source hashes | Exactly unchanged |
| Review repairs | Four cases RED→GREEN; one repair wave, no rereview |

The exact default native JSON SHA256 remains `49050e22e414dd9ada6e16f69e809170c09b8b0dab2f57b915dd44bf337b3127`; proposed Manual action quote SHA256 remains `8b513e1284d6275fd410f405aead301ecf589748e12c8e9e68068295d1a43cfc`. Baseline preview module is extracted from exact cohort BASE with only its relative viewer-projection import rebased. All receipts, native/current baselines, reader observations, hash analyses, review package, rulings and recovery scripts are retained in the checkpoint evidence.

Reviewed source also passed its complete **8,896+7** gate (`222504521116Z-67e3dbe0`) before repairs; its audit/package logs are preserved separately. Automatic approval review rejected continuation of the initial attempt because of possible telemetry to an untrusted destination; that partial attempt has no completion claim. Subsequent full checks explicitly disable Turbo and Next telemetry. The first final-source8900+7 run (`222955726436Z-d0befea9`) returned exit0 but its root stdout omitted the completed build tail; package logs and the initial audit are retained. ONE cached exact-source replay also returns exit0. Its native tool completion includes both successful builds, while the saved root log again ends before the build output. Both raw root logs, complete package logs and the separately observed native tool completion tail are retained; no third replay was run. The inherited Vite native-loader configuration advisory remains visible; ESLint has no warnings.

Callback tests substitute React lifecycle and fetch transport plus Next navigation/server-only markers. The actual client, authenticated handler, service, native engine and in-memory publication execute. These witnesses are not mounted DOM, native keyboard/touch, AT, browser geometry or hosted database acceptance.

## Initial integration rulings

1. **Native historical reference roots** — use the existing native Skill adapter with explicit Manual refs rather than synthesize an Ability. Cost if wrong: unsupported native capabilities reject; this does not promise every possible context.
2. **Conditional sample legality** — report native rejection honestly while allowing a completed modifier review to inform publication. Cost if wrong: fixture legality is not a proof of all gameplay conditions.
3. **Pure-modifier Resonance workflow** — retain validation/diff publication and provide optional preview. Cost if wrong: authors may publish a validated modifier without simulating every qualifying root.

## Every parent set-aside decision

'''
for i,(name,reason,cost) in enumerate(rows,1):report+=f'{i}. **{name}** — Ruling/reason: {reason} Cost if wrong: {cost}\n\n'
report+='## Deferred minors\n\n'
for i,m in enumerate(minors,1):report+=f'{i}. {m}\n'
report+='''
## Remaining combat and launch gates

Automatic event, Ongoing lifecycle and historical sequence/immediate authoring simulation remain unfinished. Completed targeting, captured readiness, canonical Manual action and rooted Manual modifier preview work must not be redone. Full Task15/16 integration, actual equipped cycles, natural twelve-round balance, current Owner-content reconciliation/hosted CAS, native editor/battle keyboard/touch/AT/geometry, Atlas motion and human acceptance remain open. The already-live modular foundation is distinct from this unreleased combat integration and proposed roster. Broader Master Panel work follows combat. High remains sufficient for the next routine integration work.

No hosted publication, activation, migration application, merge or deployment occurred. Deployment lock remains disabled. Recovery uses the previously authorized nondeploying `agent/overhaul-source-backup-20261016` branch, preserving its archive ancestors; remote object/ref verification is recorded separately after checkpoint creation.
'''
(root/'docs/verification/2026-10-16-manual-modifier-preview.md').write_text(report)
print(json.dumps({'report':'docs/verification/2026-10-16-manual-modifier-preview.md','tested':tested,'rootReceipt':r,'counts':counts,'rulings':len(rows),'minors':len(minors)}))
