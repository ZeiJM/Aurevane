from pathlib import Path
import json, hashlib
w=Path(__file__).resolve().parent
a=w/'modifier-preview-legacy-observation.json';b=w/'modifier-preview-legacy-baseline.json'
x=json.loads(a.read_text());assert len(x)==141 and a.read_bytes()==b.read_bytes()
assert all('result' in row for row in x)
d={'source':(w/'modifier-preview-tested-source.txt').read_text().strip(),'records':141,'allLegacyNativePreviewsExactlyUnchanged':True,'rawSha256':hashlib.sha256(a.read_bytes()).hexdigest(),'baselineSha256':hashlib.sha256(b.read_bytes()).hexdigest(),'baselineModuleSha256':hashlib.sha256((w/'modifier-preview-legacy-baseline-module.ts').read_bytes()).hexdigest()}
(w/'modifier-preview-legacy-analysis.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d))
