import datetime
import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='modifier-preview';payload=w/(prefix+'-backup-payload.json')
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip();base='5e4e97fd1ca2b377e936bfb746f7b95d55f176a2'
report='docs/verification/2026-10-16-manual-modifier-preview.md'
assert git('diff','--name-only',tested,head).splitlines()==[report]
paths=set(git('diff','--name-only',base,head).splitlines());assert paths=={'apps/web/src/components/master/combat-content/combat-content-editor.tsx', 'apps/web/src/server/master/master-modifier-preview.test.tsx', 'apps/web/src/server/master/combat-content-authoring-handler.ts', 'apps/web/src/server/master/combat-content-authoring-service.ts', 'apps/web/src/components/master/combat-content/essence-content-editor.tsx', 'apps/web/src/components/master/combat-content/combat-content-review-panel.tsx', 'apps/web/src/components/master/combat-content/resonance-content-editor.tsx', 'apps/web/src/components/master/combat-content/ability-preview-selector.tsx', 'apps/web/src/components/master/combat-content/combat-content-workflow.ts', 'apps/web/src/server/master/master-resonance-preview.test.tsx', 'apps/web/src/components/master/combat-content/resonance-preview-interaction.test.tsx', 'docs/verification/2026-10-16-manual-modifier-preview.md', 'apps/web/src/server/master/combat-content-preview.ts'},paths
assert reviewed=='f9b0a60efa6042bec4186c10caa370d0919a1044' and len(tested)==40
subprocess.run(['git','merge-base','--is-ancestor',reviewed,tested],check=True)
expected=int((w/(prefix+'-test-count.txt')).read_text());receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert datetime.datetime.fromisoformat(gate['started_utc']) >= datetime.datetime.fromisoformat(git('show','-s','--format=%cI',tested))
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
completion=json.loads((w/(prefix+'-root-tool-completion.json')).read_text());assert completion['source']==tested and completion['receipt']==gate and completion['transportExitCode']==0 and '2 successful, 2 total' in completion['observedFinalBuildTail']
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/(prefix+'-reader-analysis.json')).read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged'] and observed['rawSha256']==sha(w/(prefix+'-reader-observation.json'))
legacy=json.loads((w/(prefix+'-legacy-analysis.json')).read_text());assert legacy['source']==tested and legacy['records']==141 and legacy['allLegacyNativePreviewsExactlyUnchanged'] and legacy['rawSha256']==sha(w/(prefix+'-legacy-observation.json')) and legacy['baselineModuleSha256']==sha(w/(prefix+'-legacy-baseline-module.ts'))
actions=json.loads((w/(prefix+'-actions-analysis.json')).read_text());assert actions['source']==tested and actions['records']==284 and actions['exact'] and actions['sha256']==sha(w/(prefix+'-actions-observation.json'))
bundle=w/(prefix+'-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/(prefix+'-bundle-verify.log')).write_text(v.stdout)
evidence=w/(prefix+'-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','task15-modifier-preview-brief.md',prefix+'-combined-review-package.md','task15-modifier-preview-combined-review.md',prefix+'-review-outcome.md',prefix+'-review-rulings.md',prefix+'-implementation-notes.md',prefix+'-tested-source.txt',prefix+'-reviewed-source.txt',prefix+'-bundle-verify.log','verification.jsonl','run.py','save-'+prefix+'-checkpoint.py',prefix+'-readers-diagnostic.test.tsx','vitest-'+prefix+'-reader.config.ts',prefix+'-reader-observation.json',prefix+'-reader-analysis.json','analyze-'+prefix+'-readers.py',prefix+'-fullcheck-audit.json',prefix+'-turbo-logs.tar.gz','captured-preview-feedback-reader-observation.json','ranged-ai-analysis.json','finalize-'+prefix+'-report.py','audit-'+prefix+'-fullcheck.py','task15-'+prefix+'-next-notes.md',prefix+'-test-count.txt',prefix+'-checkpoint-summary.txt']
names += [prefix+'-actions-diagnostic.test.ts','vitest-'+prefix+'-actions.config.ts',prefix+'-actions-baseline.json',prefix+'-actions-observation.json',prefix+'-actions-analysis.json',prefix+'-legacy-baseline-module.ts',prefix+'-legacy-diagnostic.test.ts',prefix+'-legacy-baseline.json',prefix+'-legacy-observation.json',prefix+'-legacy-analysis.json','vitest-'+prefix+'-legacy.config.ts','analyze-'+prefix+'-legacy.py']
for n in [prefix+'-reviewed-fullcheck-audit.json',prefix+'-reviewed-turbo-logs.tar.gz',prefix+'-initial-fullcheck-audit.json',prefix+'-initial-turbo-logs.tar.gz',prefix+'-repair-notes.md']:
 if (w/n).exists():names.append(n)
names += [prefix+'-root-tool-completion.json',prefix+'-review-rulings.json','add-'+prefix+'-repair-tests.py','vitest-'+prefix+'-repair.config.ts',prefix+'-repair-master-modifier-preview.test.tsx',prefix+'-repair-resonance-preview-interaction.test.tsx']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T221500':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'7aebf965b004d38bafb3bfcef8ec8098bb3d00ca','previousArchiveTree':'e6e21ab7d0bb7005b6d91e1ca34025cb32403cee','fullCheckReceipt':gate,'tests':{'vitest':expected,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/(prefix+'-checkpoint-summary.txt')).read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
