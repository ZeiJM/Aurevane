import { isValidElement, type ReactElement, type ReactNode } from 'react'
import { readFileSync } from 'node:fs'
import { afterEach, beforeEach, expect, it, vi } from 'vitest'
const hooks = vi.hoisted(() => ({ index: 0, cells: [] as unknown[] }))
vi.mock('react', async (original) => ({
  ...(await original<typeof import('react')>()),
  useState(initial: unknown) {
    const i = hooks.index++
    if (!(i in hooks.cells))
      hooks.cells[i] = typeof initial === 'function' ? (initial as () => unknown)() : initial
    return [
      hooks.cells[i],
      (next: unknown) => {
        hooks.cells[i] =
          typeof next === 'function' ? (next as (old: unknown) => unknown)(hooks.cells[i]) : next
      },
    ]
  },
  useRef(initial: unknown) {
    const i = hooks.index++
    if (!(i in hooks.cells)) hooks.cells[i] = { current: initial }
    return hooks.cells[i]
  },
  useMemo: (fn: () => unknown) => fn(),
}))
vi.mock('server-only', () => ({}))
vi.mock('next/navigation', () => ({ useRouter: () => ({ refresh() {} }) }))
import { InMemoryCombatContentRepository } from '@aurevane/db/combat-content'
import type { AnyResonanceDefinition } from '@aurevane/game-core/combat/resonance'
import { createCombatContentResolver } from '@/server/combat/combat-content-resolver'
import { createCombatContentAuthoringService } from '@/server/master/combat-content-authoring-service'
import { handleCombatContentAuthoringRequest } from '@/server/master/combat-content-authoring-handler'
import { CombatContentEditor } from '@/components/master/combat-content/combat-content-editor'
import { EssenceContentEditor } from '@/components/master/combat-content/essence-content-editor'
import type { MatureSkillDefinition } from '@aurevane/game-core/combat/mature-skills'
import type { EssenceDefinition } from '@aurevane/game-core/combat/essence'
import { ResonanceContentEditor } from '@/components/master/combat-content/resonance-content-editor'
import { CombatContentReviewPanel } from '@/components/master/combat-content/combat-content-review-panel'
import { AbilityPreviewSelector, ModifierPreviewRootSelector } from '@/components/master/combat-content/ability-preview-selector'
type Props = Record<string, unknown> & { children?: ReactNode }
function find(
  node: ReactNode,
  predicate: (element: ReactElement<Props>) => boolean,
): ReactElement<Props> | null {
  if (Array.isArray(node)) {
    for (const child of node) {
      const found = find(child, predicate)
      if (found) return found
    }
  }
  if (!isValidElement<Props>(node)) return null
  return predicate(node) ? node : find(node.props.children, predicate)
}
const records = JSON.parse(
  readFileSync(
    new URL(
      '/workspace/scratch/680b26e4eb86/aurevane/docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json',
      import.meta.url,
    ),
    'utf8',
  ),
).records as { id: string; after: AnyResonanceDefinition; beforeVersion: number }[]
const owner = '11111111-1111-4111-8111-111111111111'
class Store extends InMemoryCombatContentRepository {
  async getOperatorRole() {
    return 'owner' as const
  }
}
beforeEach(() => {
  hooks.index = 0
  hooks.cells = []
})
afterEach(() => vi.unstubAllGlobals())
function fixture(
  id = 'resonance.cinderweaver-tidecaller.linked-sequence',
  overrides: Partial<Pick<AnyResonanceDefinition, 'enabled'>> = {},
) {
  const record = records.find((r) => r.id === id)!
  const definition = { ...record.after, ...overrides }
  const store = new Store()
  const resolver = createCombatContentResolver({
    findCurrentSkill: async () => null,
    findSkillVersion: async () => null,
    findCurrentContent: (key, kind) => store.findPublished(key, kind),
    findContentVersion: async () => null,
  })
  const service = createCombatContentAuthoringService({ store, resolver })
  let release: (() => void) | undefined
  let held = false
  vi.stubGlobal('fetch', async (_url: string, init: RequestInit) => {
    const body = JSON.parse(init.body as string)
    if (body.operation === 'preview' && held)
      await new Promise<void>((resolve) => {
        release = resolve
      })
    return handleCombatContentAuthoringRequest(
      new Request('https://aurevane.test/api/master/combat-content', init),
      { getActor: async () => ({ userId: owner }), createService: () => service },
    )
  })
  function render() {
    hooks.index = 0
    return ResonanceContentEditor({
      resonances: [
        {
          id: definition.id,
          label: definition.name,
          disciplinePair: definition.disciplinePair,
          currentVersion: record.beforeVersion,
          baseVersion: definition.contentVersion,
          draftVersion: null,
          definition,
          initialDraft: { ...definition, flavorLine: 'Edited for preview.' },
          history: [],
        },
      ],
    })
  }
  function panel() {
    return find(render(), (n) => n.type === CombatContentReviewPanel)!
      .props as unknown as Parameters<typeof CombatContentReviewPanel>[0]
  }
  async function run(kind: 'onValidate' | 'onDiff' | 'onPreview') {
    panel()[kind]()
    await vi.waitFor(() => expect(panel().busy).toBe(false))
  }
  function publishDisabled() {
    return find(
      CombatContentReviewPanel(panel()),
      (n) => n.type === 'button' && n.props.children === 'Publish',
    )!.props.disabled
  }
  function select(group: string) {
    const node = find(panel().previewSelectionControl, (n) => n.type === AbilityPreviewSelector)
    expect(node).not.toBeNull()
    ;(node as ReactElement<{ onChange(id: string): void }>).props.onChange(group)
  }
  return {
    definition,
    store,
    render,
    panel,
    run,
    select,
    publishDisabled,
    root(next: { skillId: string; behaviorId?: string }) {
      const node = find(
        panel().previewSelectionControl,
        (n) => n.type === ModifierPreviewRootSelector,
      )!
      ;(node.props.onChange as (next: { skillId: string; behaviorId?: string }) => void)(next)
    },
    hold: () => {
      held = true
    },
    release: () => release?.(),
  }
}

it('uses the real editor callbacks to review each group and invalidates the old group preview', async () => {
  const f = fixture()
  expect(f.publishDisabled()).toBe(true)
  await f.run('onValidate')
  await f.run('onDiff')
  expect(f.publishDisabled()).toBe(true)
  await f.run('onPreview')
  expect(f.panel().preview).toMatchObject({
    behaviorId: 'quench',
    legal: true,
    costs: { actionEconomy: 35, mp: 4 },
  })
  expect(f.publishDisabled()).toBe(false)
  f.panel().onRequestPublish()
  expect(f.panel().publishConfirmationOpen).toBe(true)
  f.select('flare')
  expect(f.panel().preview).toBeNull()
  expect(f.panel().publishConfirmationOpen).toBe(false)
  expect(f.publishDisabled()).toBe(true)
  await f.run('onPreview')
  expect(f.panel().preview).toMatchObject({
    behaviorId: 'flare',
    costs: { actionEconomy: 50, mp: 6 },
  })
  expect(f.publishDisabled()).toBe(false)
  expect(await f.store.findPublished(f.definition.id, 'resonance')).toBeNull()
})

it('discards an in-flight preview after the draft changes', async () => {
  const f = fixture()
  await f.run('onValidate')
  await f.run('onDiff')
  f.hold()
  f.panel().onPreview()
  await vi.waitFor(() => expect(f.panel().busy).toBe(true))
  const input = find(f.render(), (n) => n.props['aria-label'] === 'Resonance flavor line')!
  ;(input.props.onChange as (event: unknown) => void)({
    currentTarget: { value: 'Changed during request.' },
  })
  f.release()
  await vi.waitFor(() => expect(f.panel().busy).toBe(false))
  expect(f.panel().preview).toBeNull()
  expect(f.panel().validation).toBeNull()
  expect(f.publishDisabled()).toBe(true)
})

it('retains illegal native Requirements results as visible fixture information', async () => {
  const f = fixture('resonance.aetherist-edgedancer.linked-sequence')
  await f.run('onValidate')
  await f.run('onDiff')
  await f.run('onPreview')
  expect(f.panel().preview).toMatchObject({ behaviorId: 'gather', legal: false })
  expect(f.publishDisabled()).toBe(false)
  expect(
    find(CombatContentReviewPanel(f.panel()), (n) => n.props['aria-label'] === 'Preview issues'),
  ).not.toBeNull()
  expect(await f.store.findPublished(f.definition.id, 'resonance')).toBeNull()
})

it('preserves the existing review workflow for a Resonance with no Manual action', async () => {
  const f = fixture('resonance.aetherist-farstrider.arcane-hunt')
  await f.run('onValidate')
  await f.run('onDiff')
  expect(f.panel().previewRequired).toBe(false)
  expect(f.publishDisabled()).toBe(false)
  expect(f.panel().preview).toBeNull()
  expect(await f.store.findPublished(f.definition.id, 'resonance')).toBeNull()
})

it('publishes a current reviewed text edit while reporting unmet Covert Requirements truthfully', async () => {
  const f = fixture('resonance.shadehand-vanguard.broken-line')
  await f.run('onValidate')
  await f.run('onDiff')
  expect(f.publishDisabled()).toBe(true)
  await f.run('onPreview')
  expect(f.panel().preview?.legal).toBe(false)
  expect(f.publishDisabled()).toBe(false)
  f.panel().onRequestPublish()
  f.panel().onConfirmPublish()
  await vi.waitFor(() => expect(f.panel().busy).toBe(false))
  const saved = await f.store.findPublished(f.definition.id, 'resonance')
  expect(saved?.definition.flavorLine).toBe('Edited for preview.')
  expect(saved?.definition.ability).toEqual(f.definition.ability)
})

it('publishes a loaded disabled Manual draft without fabricating an enabled preview', async () => {
  const f = fixture('resonance.cinderweaver-tidecaller.linked-sequence', { enabled: false })
  await f.run('onValidate')
  await f.run('onDiff')
  expect(f.panel().validation?.valid).toBe(true)
  expect(f.publishDisabled()).toBe(false)
  expect(f.panel().preview).toBeNull()
  f.panel().onRequestPublish()
  f.panel().onConfirmPublish()
  await vi.waitFor(() => expect(f.panel().busy).toBe(false))
  const saved = await f.store.findPublished(f.definition.id, 'resonance')
  expect(saved?.definition.enabled).toBe(false)
  expect(saved?.definition.flavorLine).toBe('Edited for preview.')
})

it('previews a modifier using the chosen native root and invalidates confirmation on root change', async () => {
  const f = fixture('resonance.aetherist-farstrider.arcane-hunt')
  await f.run('onValidate')
  await f.run('onDiff')
  await f.run('onPreview')
  expect(f.panel().preview).toMatchObject({
    legal: false,
    referenceAction: { id: 'unarmed.basic' },
  })
  f.panel().onRequestPublish()
  expect(f.panel().publishConfirmationOpen).toBe(true)
  f.root({ skillId: 'farstrider.aimed-shot' })
  expect(f.panel().preview).toBeNull()
  expect(f.panel().publishConfirmationOpen).toBe(false)
  await f.run('onPreview')
  expect(f.panel().preview).toMatchObject({
    legal: true,
    referenceAction: { id: 'farstrider.aimed-shot' },
  })
})

it('discards a held modifier preview after a queued root change', async () => {
  const f = fixture('resonance.aetherist-farstrider.arcane-hunt')
  await f.run('onValidate')
  await f.run('onDiff')
  const control = find(
    f.panel().previewSelectionControl,
    (n) => n.type === ModifierPreviewRootSelector,
  )!
  f.hold()
  f.panel().onPreview()
  await vi.waitFor(() => expect(f.panel().busy).toBe(true))
  ;(control.props.onChange as (r: { skillId: string }) => void)({
    skillId: 'farstrider.aimed-shot',
  })
  f.release()
  await vi.waitFor(() => expect(f.panel().busy).toBe(false))
  expect(f.panel().preview).toBeNull()
  expect(f.panel().publishConfirmationOpen).toBe(false)
})

function skillModifierFixture(kind: 'skill' | 'essence', disabled = false) {
  const record = records.find((r) => r.id === 'farstrider.keen-focus')! as unknown as {
    after: MatureSkillDefinition
    beforeVersion: number
  }
  const skill = { ...record.after, enabled: !disabled }
  const baseEssence = records.find(
    (r) =>
      'essenceId' in r.after &&
      (r.after as unknown as EssenceDefinition).sourceDisciplineId === 'farstrider',
  )! as unknown as { after: EssenceDefinition; beforeVersion: number }
  const essence: EssenceDefinition = {
    ...baseEssence.after,
    ability: skill.ability,
    skill: { ...baseEssence.after.skill, ability: skill.ability, enabled: !disabled },
  }
  const store = new Store()
  const resolver = createCombatContentResolver({
    findCurrentSkill: async () => null,
    findSkillVersion: async () => null,
    findCurrentContent: (id, k) => store.findPublished(id, k),
    findContentVersion: async () => null,
  })
  const service = createCombatContentAuthoringService({ store, resolver })
  const sent: Record<string, unknown>[] = []
  vi.stubGlobal('fetch', async (_url: string, init: RequestInit) => {
    sent.push(JSON.parse(init.body as string))
    return handleCombatContentAuthoringRequest(
      new Request('https://aurevane.test/api/master/combat-content', init),
      { getActor: async () => ({ userId: owner }), createService: () => service },
    )
  })
  function render() {
    hooks.index = 0
    return kind === 'skill'
      ? CombatContentEditor({
          skills: [
            {
              id: skill.id,
              label: skill.id,
              sourceDisciplineId: skill.sourceDisciplineId,
              currentVersion: record.beforeVersion,
              baseVersion: record.beforeVersion,
              draftVersion: null,
              derivedTags: [],
              definition: skill,
              initialDraft: { ...skill, flavorLine: 'Edited modifier.' },
              history: [],
            },
          ],
        })
      : EssenceContentEditor({
          essences: [
            {
              id: essence.essenceId,
              label: essence.name,
              sourceDisciplineId: essence.sourceDisciplineId,
              currentVersion: baseEssence.beforeVersion,
              baseVersion: baseEssence.beforeVersion,
              draftVersion: null,
              derivedTags: [],
              definition: essence,
              initialDraft: { ...essence, flavorLine: 'Edited modifier.' },
              history: [],
            },
          ],
        })
  }
  function panel() {
    return find(render(), (n) => n.type === CombatContentReviewPanel)!
      .props as unknown as Parameters<typeof CombatContentReviewPanel>[0]
  }
  async function run(callback: 'onValidate' | 'onDiff' | 'onPreview') {
    panel()[callback]()
    await vi.waitFor(() => expect(panel().busy).toBe(false))
  }
  return {
    panel,
    run,
    sent,
    store,
    id: kind === 'skill' ? skill.id : essence.essenceId,
    root(next: { skillId: string }) {
      const control = find(
        panel().previewSelectionControl,
        (n) => n.type === ModifierPreviewRootSelector,
      )!
      ;(control.props.onChange as (r: { skillId: string }) => void)(next)
    },
  }
}
it.each(['skill', 'essence'] as const)(
  'uses the actual %s editor, client and service for a complete modifier quote',
  async (kind) => {
    const f = skillModifierFixture(kind)
    await f.run('onValidate')
    expect(f.panel().validation?.valid).toBe(true)
    await f.run('onDiff')
    await f.run('onPreview')
    expect(f.panel().preview).toMatchObject({
      legal: false,
      referenceAction: { id: 'unarmed.basic' },
    })
    expect(f.panel().requireLegalPreview).toBe(false)
    f.root({ skillId: 'farstrider.aimed-shot' })
    expect(f.panel().preview).toBeNull()
    await f.run('onPreview')
    expect(f.panel().preview).toMatchObject({
      legal: true,
      referenceAction: { id: 'farstrider.aimed-shot' },
    })
    expect(f.sent.at(-1)).toMatchObject({
      operation: 'preview',
      previewRootSkillId: 'farstrider.aimed-shot',
    })
  },
)

it.each(['skill','essence'] as const)('publishes a disabled %s modifier revision without an enabled simulation', async (kind) => {
  const f=skillModifierFixture(kind,true)
  await f.run('onValidate')
  expect(f.panel().validation?.valid).toBe(true)
  await f.run('onDiff')
  expect(f.panel().previewRequired).toBe(false)
  const sent = f.sent.length
  await f.run('onPreview')
  expect(f.sent).toHaveLength(sent)
  expect(f.panel().preview).toBeNull()
  expect(find(CombatContentReviewPanel(f.panel()), n=>n.type==='button'&&n.props.children==='Publish')!.props.disabled).toBe(false)
  f.panel().onRequestPublish()
  f.panel().onConfirmPublish()
  await vi.waitFor(()=>expect(f.panel().busy).toBe(false))
  const published=await f.store.findPublished(f.id,kind)
  expect(published?.definition.flavorLine).toBe('Edited modifier.')
  if(kind==='skill') expect(published?.definition.enabled).toBe(false)
  else expect((published?.definition.skill as {enabled:boolean}).enabled).toBe(false)
})
