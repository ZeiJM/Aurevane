# Task14 fix1 scoped re-review instructions

Read only the four Important findings in task-14-review-1.md, appended Fix round1 report in task-14-report.md, task-14-brief.md and the supplied c5d942ae..a8df18ef fix diff. The full294/153/136 review has already happened; do not repeat it. Verify each finding and new breakage in this fix only, not unrelated existing rows. Nohelpers/subagents; read-onlycheckout/index/HEAD/branch; no production or externalwrites. Fullreport is finaltext for controller to save.

Fix BASEc5d942ae7d389cc2ffbe5319c192520b0d30af03. HEADa8df18ef3730795bda29510f9ecde40bccefa8c0. Changed four identities: resonance.aetherist-shadehand.veiled-conduit; resonance.edgedancer-wildwarden.linked-sequence; resonance.farstrider-runeblade.linked-sequence; resonance.cinderweaver-wildwarden.linked-sequence. Their actual kits/current tools and meaningful present-day decision are the issue. Do not accept renamed/scalar/cooldown copies, future Armor-only distinction or one-off hashes as experiential proof. No new Handler is claimed. Verify new supported sacrifice/reposition/resource-denial/containment mechanics, costs/Requirements/recipients/order/hit/miss/Barrier/paths, actual2+2earned kits, updated coverage/audits and targeted tests.

Final affected scope777tests/2files:736guards+41candidate kernel cases.64unchanged contracts retain earlier828run; no fresh841six-file run claimed. Verify report/actual full verbose log20261016T015447519960Z and distinct hygiene receipts. Do not rerun passing suites unless a concrete unanswered doubt arises; focused only. Prior empty-exit0 output was discarded.

Latest Owner allows weird/underused supported tags and no-Requirement pairs if balanced/unique; everyclass8Skills+Essence remains in runtimebalance scope. All actual combat systems and battle/SkillManagement/effectpopup descriptions/readers must pass before coordinated combat release. Latest prose: short/natural; do not duplicate non-damage values already inSkillEffects or timing already inCharacteristics. Structured exact values/clocks/brackets/orange remain. Full editorial and consumer audit is Task15 beforepublication, explicitly not claimed complete at this design-only fix. BroaderMaster/worldfollowscombat-first. These scope facts do not waive missing Task14 mechanical design.

## Binding global constraints (verbatim)

- Structured definitions determine mechanics; descriptions never create rules. Stable IDs, typed units and explicit effect order are mandatory.
- Build on `ee5d49de449851c9b9aa61438735c4cd27ca6af4` or newer main. Preserve elemental policy 2, Suppress percentages, all historical optional policies, captured effects and exact-version battle snapshots.
- Do not change unrelated damage formulas, progression, AP economy, movement limits or resource recovery. Preserve current roster balance through Tasks 1–13/3A; Tasks 14–15 design and implement the Owner-authorized final roster rebalance through new immutable versions. Current `armor`/`ward` mean Physical/Mystic Defense, not future equipment Armor.
- New HP costs leave at least 1 HP and do not emit damage events. AP/MP/HP costs commit together once per legal activation.
- Self and Ally are separate. New ordinary targeting permits up to the configured count of distinct legal selections. Line and caster-centered square-ring Circle retain existing geometry. New All bypasses Range while independently configured LoS/elevation remains; historical geometry v2 is preserved.
- Controlled first use primes the whole Manual action without ordinary payment, action consumption or cooldown; one prime per character/ability/battle. Legal release pays once and consumes the prime; invalid release retains it. Rewind captures its existing position anchor on prime. No arbitrary expiry, automatic release or refunds.
- Pierce power is 1–20; Armor Ignored is 0–100% of the recipient's explicit future equipment Armor contribution, separate from scaling and all other mitigation. Without equipment Armor, explain that configured bypass has no current advantage. Preserve legacy `piercing:true` semantics in historical definitions.
- Selecting Fire/Ice/Water/Storm damage inserts explicit required companion mechanics, locked in authoring and enforced by validation/execution. Preserve policy-2 application conditions, magnitudes, timing and expiry; no duplicates.
- Public field order is Type, Cost, Cooldown, Requirements, Effects, Range, Target, Method, Target Elevation, Line of Sight. Values use brackets; independent entries use a middle dot. Public API/RSC/preview payloads omit authoring accuracy fields.
- Save Draft is not Publish. Publish appends a complete atomic version with optimistic concurrency. Restore copies a complete prior snapshot into a draft, then publishes a new version. UI shows current plus two previous published versions; older referenced snapshots remain physically readable.
- Six primary destinations: Game Content, Combat Rules, Events & Live Ops, Players, Staff & Access, Site Music. Preserve the global character rail, header/account entry and footer; compact desktop layouts remain usable at mobile and 200% zoom.
- Staff grants belong only to the explicitly selected linked character and are checked for expiry/revocation on every protected server/RPC operation. Single Game Owner and nondelegable powers remain protected. Ambiguous legacy grants fail closed until explicitly bound.
- Administrative battle recovery is durable no contest/no rewards, never ordinary surrender/defeat; identify all affected participants before voiding a shared encounter. Late workers/retries cannot grant rewards or records. Do not invent resource refunds.
- Routine written reasons are removed from forms, relevant TS validation and SQL contracts without fabricated reasons; automatic actor/time/action audit remains.
- New migrations use `pnpm exec supabase migration new` after CLI help, preserve existing migration files and service-only grants/RLS, and are tested locally/PGlite. Never mutate hosted production during Tasks 1–16. The Owner-authorized final release applies only reviewed necessary hosted changes after acceptance, independent whole-branch review and current-state reconciliation. Preserve `apps/web/vercel.json` Git deployment lock.


## Official scoped rubric

# Scoped Re-Review Prompt Template

Use this template when dispatching a re-review after a fix round. The
re-reviewer verifies the findings were addressed and checks the fix diff for
new breakage. It is not a fresh review — the full review already happened.

**Purpose:** Verify each finding from the previous review was addressed, and
that the fix itself broke nothing.

```
Subagent (general-purpose):
  description: "Re-review Task N fix round R"
  model: [MODEL — REQUIRED: choose per SKILL.md Model Selection; an omitted
         model silently inherits the session's most expensive one]
  prompt: |
    You are re-reviewing one task's fix round. A previous review produced
    findings; an implementer has attempted to fix them. Your job is to
    verdict each finding and inspect the fix diff — nothing else.

    ## The Task

    Read the task brief: [BRIEF_FILE]

    ## The Findings Under Verification

    [FINDINGS]

    ## The Fix

    Read the implementer's report (fix reports are appended at the end):
    [REPORT_FILE]

    **Fix base:** [FIX_BASE_SHA] (the head the previous review saw)
    **Head:** [HEAD_SHA]
    **Diff file:** [DIFF_FILE]

    Read the diff file once — it contains the fix commits, a stat summary,
    and the fix diff with surrounding context. Do not re-run git commands.
    If the diff file is missing, fetch the diff yourself:
    `git diff --stat [FIX_BASE_SHA]..[HEAD_SHA]` and
    `git diff [FIX_BASE_SHA]..[HEAD_SHA]`.

    Your review is read-only on this checkout. Do not mutate the working
    tree, the index, HEAD, or branch state in any way.

    ## You Do Not Dispatch Subagents

    Do all of this review yourself. Never spawn a subagent to review part
    of the diff, and never spawn another reviewer for a second opinion.
    This process already provides every review seat the work gets; a
    reviewer you spawn duplicates one of them at full cost, and its
    verdict counts for nothing. If the diff feels too large for one
    pass, review it in passes yourself and say so in your report.

    ## Scope

    Your scope is the findings list and the fix diff. Verdict every finding.
    Inspect the fix diff for new problems the fix itself introduced. Do NOT
    re-review code the fix did not touch: if you notice an issue entirely
    outside the fix diff, report it under Out-of-Scope Observations — it
    does not block this task and does not extend the loop. A broad
    whole-branch review happens after all tasks are complete.

    ## Tests

    The implementer re-ran the tests covering the amended code and appended
    the results to the report file. Treat the report as unverified claims:
    confirm the fix report names the covering tests and shows their output,
    and verify the claims against the diff. Do not re-run the suite to
    confirm their report. Run a test only when reading the code raises a
    specific doubt that no existing run answers — and then a focused test,
    never a package-wide suite.

    ## Output Format

    Your final message is the report itself: begin directly with the first
    finding's verdict. Every line is a verdict, a finding with file:line,
    or a check you ran — no preamble, no process narration.

    ### Finding Verdicts

    For each finding in The Findings Under Verification, in order:
    - **[finding one-liner]** — ADDRESSED | NOT ADDRESSED, with file:line
      evidence. "Attempted" is not addressed: the specific defect must no
      longer exist.

    ### New Breakage in the Fix Diff

    Anything the fix itself broke or introduced, with severity
    (Critical/Important/Minor) and file:line. "None" if clean.

    ### Out-of-Scope Observations

    Issues you noticed entirely outside the fix diff. Non-blocking; the
    controller ledgers these for the final review. "None" if none.

    ### Verdict

    **Fix round:** [All findings addressed, no new Critical/Important
    breakage | Findings remain open] — list the open ones.
```

**Placeholders:**
- `[MODEL]` — REQUIRED: reviewer model per SKILL.md Model Selection; scoped
  re-reviews of small fix diffs take a cheap-to-mid tier
- `[BRIEF_FILE]` — the task brief file (same file the implementer worked from)
- `[FINDINGS]` — the Critical/Important findings and spec gaps from the
  previous review, copied verbatim, one per bullet
- `[REPORT_FILE]` — the implementer's report file (fix reports appended)
- `[FIX_BASE_SHA]` — the head the previous review saw
- `[HEAD_SHA]` — current commit
- `[DIFF_FILE]` — the path `bash scripts/review-package PLAN_FILE FIX_BASE HEAD` printed

**Re-reviewer returns:** per-finding verdicts (ADDRESSED / NOT ADDRESSED),
new breakage in the fix diff, out-of-scope observations, and a round verdict.
