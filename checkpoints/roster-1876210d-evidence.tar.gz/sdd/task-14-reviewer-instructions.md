# Task14 combined independent review instructions

Task-scoped design/validation gate only. Read task-14-brief.md, task-14-continuation-context.md, task-14-report.md and exact source/test evidence. BASE6790f4c9ff9343dee7b39e2f87999c2f1a3d7454; HEAD and generated review diff supplied at dispatch. One reviewer, no helpers, no production write, no checkout/index/branch mutation. Return full review as final text; controller saves it.

The approved design-only task does not implement/activate294 new live roster versions. Actual player controls, canonical Ground bridge, scenario previews, Library tier UI and full balance/AI/Level100/no-input release acceptance are explicit Task15/16 deliverables. Flag an omitted complete design/contract as missing; do not demand premature roster activation or call deferred implementation already delivered. All promised definition mechanics must be supported or honestly provisional behind named complete extension contracts.

Latest Owner21:16Trinidad explicitly reconfirms that all8class Skills and each Essence across all17classes require rebalance. Review the actual136class Skill and17Essence designs individually and as full class cycles; Resonance emphasis cannot reduce that scope. Whole-kit runtimebalance remains Task15/16 acceptance.

Latest Owner20:46and20:53Trinidad repeated steering makes experiential Resonance uniqueness and whole136pair combination identity a hard gate. Check actual named tools from both kits, existing mixed capacities/4Skill limit, new build/turn decision, payoff window and counter. Reject skin/element/status/scalar swaps that do not change decisions. Check the scalar-stripped collision audit on merits; absence of equal JSON is not experiential proof. Check canonical-presence guards and honest unlock/mastery availability of entry loadouts.

Latest Owner20:46Trinidad steering makes experiential Resonance uniqueness a hard gate. Audit repeated payoff templates, not merely exact JSON duplicates: prior draft had13Manual10AP/3MP→112% and8Ongoing110% variants. Verify those clusters are meaningfully reworked/justified by different actual decisions; a renamed/qualified identical bonus alone does not meet the creative brief. Shared primitives are legitimate when the pair creates a different playable cycle.

Review every294-row identity/typed behavior and individual setup/payoff/counterplay across all17 classes and136 pairs; do not replace this with a few random samples. The raw JSON diff is very large because it contains full immutable source envelopes. You may consume it programmatically and print compact semantic projections (all changed values/behaviors/unique rationale), checking preserved fields against existing actual validator/digest evidence, instead of flooding context with repeated indentation/media. Full raw diff remains authoritative. Read nondata hunks once; inspect concrete outside-diff code risks once each and name them. No package-wide rerun of passing tests, no broad codebase crawl.

Additional controller findings to verify: original32Skill+4Essence acceptance summaries/legal cases were generic; all153class records need actual individual mechanic/outcome/counter/opportunitycost plans. Ironfist Hundredfold Rush and Edgedancer Sevenfold Cut initially differed only3vs7packets and price; verify the final class-cycle decision distinction, actual queue evidence and accurate25AP remainder/counter timing.

Known controller findings already sent for fixes (verify final diff actually resolves): paid Automatic no-op resource/turn-limit spending (Consecrated Form without a cleansable affliction and Renewed Force at fullHP), strictly harmful4MP→3MP Runeblade/Stormsinger reaction, completed-action vs hit claim for Renewed Force, Mercys Edge miss vs full-Barrier sustain distinction, omitted canonical accuracy causing guaranteed hostile attacks, and deliberate Standard choices for hostile nondamage unit packets. Preserve private projection boundary and historical versions. Confirm the19-effect/26-status/Requirement/activation coverage artifact is registry-derived and points to meaningful obtainable content or honest system/historical/future classifications; metadata presence alone is not an authoritative runtime outcome. Check real guards, selected Ground contract, all17 justified Library-only tiers/useful4-Skill loadouts, budgeting and concrete tests. Do not confuse level1 mechanic preflights with Level100 whole-roster balance.

Source baseline19 CI workflows had18success and one unresolved World-motion failure; this is carried integration scope, not a Task14 introduced runtime regression. New Node dev typings may be appropriate for real fs/crypto source/digest tests, if same pinned repository version with lockfile correctness and no unnecessary runtime dependency.

Latest Owner21:24Trinidad permits new/underused tags, deliberate no-Requirement Resonances and unusual combinations if balanced and unique. Evaluate whether the design uses real supported interactions and meaningful varied decisions. Do not require every pair to have a Requirement; costs/clock/cooldown/slot/counterplay can carry balance. No unrelated tag stuffing or invented handlers.

## Binding global constraints (verbatim)

- Structured definitions determine mechanics; descriptions never create rules. Stable IDs, typed units and explicit effect order are mandatory.
- Build on `ee5d49de449851c9b9aa61438735c4cd27ca6af4` or newer main. Preserve elemental policy 2, Suppress percentages, all historical optional policies, captured effects and exact-version battle snapshots.
- Do not change unrelated damage formulas, progression, AP economy, movement limits or resource recovery. Preserve current roster balance through Tasks 1–13/3A; Tasks 14–15 design and implement the Owner-authorized final roster rebalance through new immutable versions. Current `armor`/`ward` mean Physical/Mystic Defense, not future equipment Armor.
- New HP costs leave at least 1 HP and do not emit damage events. AP/MP/HP costs commit together once per legal activation.
- Self and Ally are separate. New ordinary targeting permits up to the configured count of distinct legal selections. Line and caster-centered square-ring Circle retain existing geometry. New All bypasses Range while independently configured LoS/elevation remains; historical geometry v2 is preserved.
- Controlled first use primes the whole Manual action without ordinary payment, action consumption or cooldown; one prime per character/ability/battle. Legal release pays once and consumes the prime; invalid release retains it. Rewind captures its existing position anchor on prime. No arbitrary expiry, automatic release or refunds.
- Pierce power is 1–20; Armor Ignored is 0–100% of the recipient's explicit future equipment Armor contribution, separate from scaling and all other mitigation. Without equipment Armor, explain that configured bypass has no current advantage. Preserve legacy `piercing:true` semantics in historical definitions.
- Selecting Fire/Ice/Water/Storm damage inserts explicit required companion mechanics, locked in authoring and enforced by validation/execution. Preserve policy-2 application conditions, magnitudes, timing and expiry; no duplicates.
- Public field order is Type, Cost, Cooldown, Requirements, Effects, Range, Target, Method, Target Elevation, Line of Sight. Values use brackets; independent entries use a middle dot. Public API/RSC/preview payloads omit authoring accuracy fields.
- Save Draft is not Publish. Publish appends a complete atomic version with optimistic concurrency. Restore copies a complete prior snapshot into a draft, then publishes a new version. UI shows current plus two previous published versions; older referenced snapshots remain physically readable.
- Six primary destinations: Game Content, Combat Rules, Events & Live Ops, Players, Staff & Access, Site Music. Preserve the global character rail, header/account entry and footer; compact desktop layouts remain usable at mobile and 200% zoom.
- Staff grants belong only to the explicitly selected linked character and are checked for expiry/revocation on every protected server/RPC operation. Single Game Owner and nondelegable powers remain protected. Ambiguous legacy grants fail closed until explicitly bound.
- Administrative battle recovery is durable no contest/no rewards, never ordinary surrender/defeat; identify all affected participants before voiding a shared encounter. Late workers/retries cannot grant rewards or records. Do not invent resource refunds.
- Routine written reasons are removed from forms, relevant TS validation and SQL contracts without fabricated reasons; automatic actor/time/action audit remains.
- New migrations use `pnpm exec supabase migration new` after CLI help, preserve existing migration files and service-only grants/RLS, and are tested locally/PGlite. Never mutate hosted production during Tasks 1–16. The Owner-authorized final release applies only reviewed necessary hosted changes after acceptance, independent whole-branch review and current-state reconciliation. Preserve `apps/web/vercel.json` Git deployment lock.


## Combined-review rubric/template

# Task Reviewer Prompt Template

Use this template when dispatching a task reviewer subagent. The reviewer
reads the task's diff once and returns two verdicts: spec compliance and
code quality.

**Purpose:** Verify one task's implementation matches its requirements (nothing
more, nothing less) and is well-built (clean, tested, maintainable)

```
Subagent (general-purpose):
  description: "Review Task N (spec + quality)"
  model: [MODEL — REQUIRED: choose per SKILL.md Model Selection; an omitted
         model silently inherits the session's most expensive one]
  prompt: |
    You are reviewing one task's implementation: first whether it matches its
    requirements, then whether it is well-built. This is a task-scoped gate,
    not a merge review — a broad whole-branch review happens separately after
    all tasks are complete.

    ## What Was Requested

    Read the task brief: [BRIEF_FILE]

    Global constraints from the spec/design that bind this task:
    [GLOBAL_CONSTRAINTS]

    ## What the Implementer Claims They Built

    Read the implementer's report: [REPORT_FILE]

    ## Diff Under Review

    **Base:** [BASE_SHA]
    **Head:** [HEAD_SHA]
    **Diff file:** [DIFF_FILE]

    Read the diff file once — it contains the commit list, a stat summary,
    and the full diff with surrounding context, and it is your view of the
    change. The diff's context lines ARE the changed files: do not Read a
    changed file separately unless a hunk you must judge is cut off
    mid-function — and say so in your report. Do not re-run git commands.
    If the diff file is missing, fetch the diff yourself:
    `git diff --stat [BASE_SHA]..[HEAD_SHA]` and `git diff [BASE_SHA]..[HEAD_SHA]`.
    Do not crawl the broader codebase. Inspect code outside the diff only
    to evaluate a concrete risk you can name — one focused check per named
    risk, and name both the risk and what you checked in your report.
    Cross-cutting changes are legitimate named risks: if the diff changes
    lock ordering, a function or API contract, or shared mutable state,
    checking the call sites is the right method.

    Your review is read-only on this checkout. Do not mutate the working
    tree, the index, HEAD, or branch state in any way.

    ## You Do Not Dispatch Subagents

    Do all of this review yourself. Never spawn a subagent to review part
    of the diff, and never spawn another reviewer for a second opinion.
    This process already provides every review seat the work gets; a
    reviewer you spawn duplicates one of them at full cost, and its
    verdict counts for nothing. If the diff feels too large for one
    pass, review it in passes yourself and say so in your report.

    ## Do Not Trust the Report

    Treat the implementer's report as unverified claims about the code. It
    may be incomplete, inaccurate, or optimistic. Verify the claims against
    the diff. Design rationales in the report are claims too: "left it per
    YAGNI," "kept it simple deliberately," or any other justification is the
    implementer grading their own work. Judge the code on its merits — a
    stated rationale never downgrades a finding's severity.

    ## Tests

    The implementer already ran the tests and reported results with TDD
    evidence for exactly this code. Do not re-run the suite to confirm their
    report. Run a test only when reading the code raises a specific doubt
    that no existing run answers — and then a focused test, never a
    package-wide suite, race detector run, or repeated/high-count loop. If
    heavy validation seems warranted, recommend it in your report instead of
    running it. If you cannot run commands in this environment, name the
    test you would run.

    Warnings or other noise in the implementer's reported test output are
    findings — test output should be pristine.

    Evidence you cannot see is not evidence that doesn't exist. If the
    report or its test evidence looks truncated, or you cannot locate the
    results it claims, re-read the file at its stated path — and if it is
    genuinely missing or garbled, report that as a gap for the controller.
    Re-running the suite to regenerate what you failed to read is not
    verification; illegibility of the evidence is not invalidation of it.

    ## Part 1: Spec Compliance

    Compare the diff against What Was Requested:

    - **Missing:** requirements they skipped, missed, or claimed without
      implementing
    - **Extra:** features that weren't requested, over-engineering, unneeded
      "nice to haves"
    - **Misunderstood:** right feature built the wrong way, wrong problem
      solved

    If the brief lists several files each with its own change (a batched
    dispatch), check the diff against that list file by file: every listed
    file must have its corresponding hunk. A listed file the diff never
    touches is a Missing finding, no matter how clean the rest of the
    batch looks.

    If a requirement cannot be verified from this diff alone (it lives in
    unchanged code or spans tasks), report it as a ⚠️ item instead of
    broadening your search.

    ## Part 2: Code Quality

    **Code quality:**
    - Clean separation of concerns?
    - Proper error handling?
    - DRY without premature abstraction?
    - Edge cases handled?

    **Tests:**
    - Do the new and changed tests verify real behavior, not mocks?
    - Are the task's edge cases covered?

    **Structure:**
    - Does each file have one clear responsibility with a well-defined interface?
    - Are units decomposed so they can be understood and tested independently?
    - Is the implementation following the file structure from the plan?
    - Did this change create new files that are already large, or
      significantly grow existing files? (Don't flag pre-existing file
      sizes — focus on what this change contributed.)

    Your report should point at evidence: file:line references for every
    finding and for any check you would otherwise answer with a bare
    "yes." A tight report that cites lines gives the controller everything
    it needs.

    Your final message is the report itself: begin directly with the
    spec-compliance verdict. Every line is a verdict, a finding with
    file:line, or a check you ran — no preamble, no process narration,
    no closing summary.

    ## Calibration

    Categorize issues by actual severity. Not everything is Critical.
    Important means this task cannot be trusted until it is fixed: incorrect
    or fragile behavior, a missed requirement, or maintainability damage you
    would block a merge over — verbatim duplication of a logic block,
    swallowed errors, tests that assert nothing. "Coverage could be broader"
    and polish suggestions are Minor.
    If the plan or brief explicitly mandates something this rubric calls a
    defect (a test that asserts nothing, verbatim duplication of a logic
    block), that IS a finding — report it as Important, labeled
    plan-mandated. The plan's authorship does not grade its own work; the
    human decides.
    Acknowledge what was done well before listing issues — accurate praise
    helps the implementer trust the rest of the feedback.

    ## Output Format

    ### Spec Compliance

    - ✅ Spec compliant | ❌ Issues found: [what's missing/extra/misunderstood,
      with file:line references]
    - ⚠️ Cannot verify from diff: [requirements you could not verify from the
      diff alone, and what the controller should check — report alongside the
      ✅/❌ verdict for everything you could verify]

    ### Strengths
    [What's well done? Be specific.]

    ### Issues

    #### Critical (Must Fix)
    #### Important (Should Fix)
    #### Minor (Nice to Have)

    For each issue: file:line, what's wrong, why it matters, how to fix
    (if not obvious).

    ### Assessment

    **Task quality:** [Approved | Needs fixes]

    **Reasoning:** [1-2 sentence technical assessment]
```

**Placeholders:**
- `[MODEL]` — REQUIRED: reviewer model per SKILL.md Model Selection
- `[BRIEF_FILE]` — REQUIRED: the task brief file (`bash scripts/task-brief PLAN N`
  prints the path; same file the implementer worked from)
- `[GLOBAL_CONSTRAINTS]` — the binding requirements copied verbatim from
  the plan's Global Constraints section or the spec: exact values, formats,
  and stated relationships between components (not process rules — those
  are already in this template)
- `[REPORT_FILE]` — REQUIRED: the file the implementer wrote its detailed
  report to
- `[BASE_SHA]` — commit before this task
- `[HEAD_SHA]` — current commit
- `[DIFF_FILE]` — REQUIRED: the path the controller wrote the review
  package to (`bash scripts/review-package PLAN_FILE BASE HEAD` prints the unique
  path it wrote; the package never enters the controller's context)

**Reviewer returns:** Spec Compliance verdict (✅/❌/⚠️), Strengths, Issues
(Critical/Important/Minor), Task quality verdict
