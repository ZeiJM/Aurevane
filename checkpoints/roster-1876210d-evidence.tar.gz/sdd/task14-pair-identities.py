import json,pathlib,hashlib,collections
ROOT=pathlib.Path(__file__).resolve().parents[3];P=ROOT/'docs/superpowers/specs';d=json.load(open(P/'2026-10-10-roster-rebalance-proposals.json'));rows={r['id']:r for r in d['records']};pairs={tuple(r['after']['disciplinePair']):r for r in d['records'] if r['kind']=='resonance'}
seen=set();signatures=collections.defaultdict(list)
def norm(v,k=''):
 if isinstance(v,list):return [norm(x,k) for x in v]
 if isinstance(v,dict):return {a:norm(b,a) for a,b in v.items() if a not in ['id','key','contentVersion','schemaVersion','sourceDisciplineId','requiredTags','abilityId','description']}
 if k in ['statusId','statusIds','element','defenseKind','source']:return '_'
 if isinstance(v,(int,float)) and not isinstance(v,bool):return '_' if k!='maximumSelections' else v
 return v
for line in (pathlib.Path(__file__).parent/'task14-pair-kits.txt').read_text().splitlines():
 pair,kit1,kit2,why=line.split('|');a,b=pair.split('+');key=tuple(sorted([a,b]));assert key not in seen,key;seen.add(key);r=pairs[key]
 toolIds=[*[a+'.'+s for s in kit1.split(',')],*[b+'.'+s for s in kit2.split(',')]]
 assert len(set(toolIds))==4,(pair,toolIds)
 for id in toolIds:assert id in rows,(pair,id)
 kit=[dict(id=id,contentVersion=rows[id]['after']['contentVersion'],sourceDisciplineId=rows[id]['after']['sourceDisciplineId'],unlockRequirement=rows[id]['after']['unlockRequirement'],actualToolRole=rows[id]['role']) for id in toolIds]
 ability=r['after']['ability'];sig=json.dumps(norm(ability),sort_keys=True,separators=(',',':'));h=hashlib.sha256(sig.encode()).hexdigest();signatures[h].append(r['id'])
 r['playIdentity']=dict(combinationRationale=why,earnedFourSkillKit=kit,capacity='Exactly four Skills:2+2 from the actual pair; Resonance occupies its existing separate slot. The kit is available only after the preserved earned unlocks, never an implied starter grant.',turnDecision=r['acceptance']['payoff'],setup=r['acceptance']['setup'],payoffWindows=[dict(behaviorId=g['id'],activation=g['activation'],mode=g['mode'],requirements=g['requirements'],costs=g['costs'],cooldown=g['cooldown'],orderedClocks=[dict(effectId=e['id'],timing=e.get('timing','instant')) for e in g['effects']]) for g in ability['behaviors']],counter=r['acceptance']['counterplay'],functionalSignature=h)
 r['acceptance']['cases'].append(dict(id=r['id']+':four-skill-decision',status='planned-not-executed',given=dict(earnedKit=toolIds,exactKitVersions=[k['contentVersion'] for k in kit],primarySecondarySwap=True),when='Build the actual legal2+2 mixed loadout in both Primary orders; play its stated setup, choose between one ordinary kit command and the exact Resonance decision, then let the opponent apply the named counter.',then=dict(combinationRationale=why,decision=r['playIdentity']['turnDecision'],counter=r['playIdentity']['counter'],capacity='Four chosen Skills plus one separate exact-version pair Resonance; no Essence and no unselected Skill or helper is silently available.')))
assert seen==set(pairs),(len(seen),set(pairs)-seen)
collisionGroups=[ids for ids in signatures.values() if len(ids)>1]
# Machine signatures are a collision screen, never a substitute for human experiential review.
audit=dict(status='whole136-authored-kit-and-functional-audit-awaiting-independent-review',pairCount=len(pairs),uniqueScalarCosmeticStrippedSignatures=len(signatures),collisions=collisionGroups,normalization='Remove IDs/source Discipline labels/tags/names/descriptions and all numeric tuning except explicit selection count. Replace element/status identities/defense family/scaling source with generic placeholders. Preserve operation sequence, target topology, resource kinds, activation, timing, Requirement tree shapes and explicit recipient decisions.',meaning='No exact cosmetic/scalar-stripped collision is sufficient evidence of fun or balance. The independent gate must assess each authored four-Skill kit, combination rationale, actual turn choice, payoff window and counter.',concreteDecisions=[dict(recordId=r['id'],kit=[k['id'] for k in r['playIdentity']['earnedFourSkillKit']],why=r['playIdentity']['combinationRationale'],decision=r['playIdentity']['turnDecision'],counter=r['playIdentity']['counter'],signature=r['playIdentity']['functionalSignature']) for r in pairs.values()])
(P/'2026-10-10-roster-rebalance-pair-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
(P/'2026-10-10-roster-rebalance-proposals.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
cov=json.load(open(P/'2026-10-10-roster-rebalance-coverage.json'))
for c in cov['classes']:c['availability']='Useful entry loadout after earning the exact preserved Skill unlock/mastery requirements. This is not a grant to a new character.'
for entry in cov['effectCoverage']:
 if entry['id']=='poison':entry['classification']='implemented-kernel-proposed-obtainable-roster (native persistent Ground witness remains provisional separately)'
cov['wholePairAuditRef']='2026-10-10-roster-rebalance-pair-audit.json';cov['uniquenessClusterAuditRef']='2026-10-10-roster-rebalance-uniqueness.json'
(P/'2026-10-10-roster-rebalance-coverage.json').write_text(json.dumps(cov,ensure_ascii=False,indent=2)+'\n')
print('whole pair audit',len(pairs),'actual four-Skill kits;',len(signatures),'scalar/cosmetic-stripped signatures;',len(collisionGroups),'collision groups')
