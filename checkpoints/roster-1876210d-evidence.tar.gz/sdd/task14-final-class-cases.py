import json
from pathlib import Path

root = Path('docs/superpowers/specs')
p = root / '2026-10-10-roster-rebalance-proposals.json'
m = json.loads(p.read_text())
rows = {r['id']: r for r in m['records']}
seven = rows['essence.edgedancer.sevenfold-cut']
b = seven['after']['ability']['behaviors'][0]
b['effects'] = [e for e in b['effects'] if e['payload']['type'] != 'move']
for e in b['effects'][1:]:
    e['timing'] = 'next-round'
seven['role'] = 'Contact opening plus six captured next-round cuts; no attached approach, leaving25AP for a separately paid legal20AP exit step.'
for holder in (seven['after'], seven['after'].get('skill', {})):
    if 'descriptionRef' in holder:
        holder['descriptionRef'] = 'From existing melee contact, commit one Power8 hit now and six fixed Power2 cuts next round. Only the first scales. Pay75AP/8MP once; there is no attached Move or later target reacquisition.'
seven['requiresSurfaceWork'] = sorted(set(seven['requiresSurfaceWork'] + ['typed-conditional-event-preview']))
entries = {}
for line in Path('.superpowers/sdd/2026-10-10-unified-engine-recovery/task14-class-cases.txt').read_text().splitlines():
    if not line.strip(): continue
    identity, setup, payoff, counter, cost = line.split('|')
    assert identity not in entries, identity
    entries[identity] = (setup, payoff, counter, cost)
entries['essence.edgedancer.sevenfold-cut'] = (
    'Owner is already adjacent with75AP/8MP; enemy survives the opening. Compare a target one approach tile beyond melee.',
    'Pay once: Power8 scaled hit now, six fixedPower2 next-round packets. NeutralPower20 outputs18 now plus six2 later after JSON restore. No attached approach;25AP remains for one separately paid legal20AP terrain point.',
    'Deny initial adjacency to reject without payment. Before the next global-round boundary, only actors whose actual initiative remains may install Barrier or recover; no universal response turn, later hit roll or reacquisition is promised. Resolve source-removal and terminal variants under captured queue policy.',
    'Unlike Ironfist immediateMove1→rush, establish contact in advance and choose an exit with the remaining25AP while telegraphing future pressure; an opening late in the round leaves a shorter response window.'
)
classes = [r for r in m['records'] if r['kind'] in ['skill', 'essence']]
assert len(entries) == len(classes) == 153
assert set(entries) == {r['id'] for r in classes}
for r in classes:
    setup, payoff, counter, cost = entries[r['id']]
    acceptance = r['acceptance']
    acceptance.update(setup=setup, payoff=payoff, counterplay=counter)
    planned_id = r['id'] + ':individual-tactical-state'
    r['decisionReview'] = dict(setup=setup, expectedState=payoff, counterScenario=counter, opportunityCost=cost, plannedCaseId=planned_id)
    behaviors = r['after'].get('ability', {}).get('behaviors', [])
    cost_text = '; '.join(b['id'] + ': ' + '/'.join(str(c['amount']) + c['resource'].upper() for c in b['costs']) + ('; cooldown ' + str(b['cooldown']['ownerTurns']) + ' owner turns' if b['cooldown'] else '; no authored cooldown') for b in behaviors)
    if not behaviors: cost_text = str(r['after']['apCost']) + 'AP/' + str(r['after'].get('mpCost', 0)) + 'MP; preserve native Ground clocks/entry claims'
    legal = next(c for c in acceptance['cases'] if c['id'] == r['id'] + ':legal')
    legal.update(given=setup, when='Capture proposed version ' + str(r['after']['contentVersion']) + ' and execute the concrete scenario: ' + cost_text + '. Compare full actual resource/cooldown/target state before and after; require zero payment on invalid selection.', then=payoff)
    negative = next(c for c in acceptance['cases'] if c['id'] == r['id'] + ':counter')
    negative.update(given=setup, when=counter, then='Assert the specific counter changes eligibility, recipient outcome or future payoff exactly as described, without an invented denial/refund: ' + counter)
    acceptance['cases'] = [c for c in acceptance['cases'] if c['id'] != planned_id]
    acceptance['cases'].append(dict(id=planned_id, status='planned-not-executed', given=setup, when='Use the exact captured proposed definition at Level1 and legal Level100 Core40/HP40 builds, compare the paired/counter fixture, and observe ' + cost_text + '.', then=payoff, counterVariant=counter, opportunityCostAssertion=cost, exactDefinitionRef=dict(id=r['id'], contentVersion=r['after']['contentVersion']), behaviorIds=[b['id'] for b in behaviors], testScope='Task15 actual kernel/capture and complete legal four-Skill kit; this authored per-record case has not been executed unless separately named by an actual outcome test.'))
p.write_text(json.dumps(m, indent=2, ensure_ascii=False) + '\n')
print('153 individual Skill/Essence tactical plans; Sevenfold has separate contact/next-round/exit decision. No runtime source changed.')
