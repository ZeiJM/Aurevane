# Task14 continuation contract

Read task-14-brief.md first. This is the resumed design task, not a new scope or replay of accepted foundation tasks.

## Binding global constraints (verbatim from approved plan)

- Structured definitions determine mechanics; descriptions never create rules. Stable IDs, typed units and explicit effect order are mandatory.
- Build on `ee5d49de449851c9b9aa61438735c4cd27ca6af4` or newer main. Preserve elemental policy 2, Suppress percentages, all historical optional policies, captured effects and exact-version battle snapshots.
- Do not change unrelated damage formulas, progression, AP economy, movement limits or resource recovery. Preserve current roster balance through Tasks 1–13/3A; Tasks 14–15 design and implement the Owner-authorized final roster rebalance through new immutable versions. Current `armor`/`ward` mean Physical/Mystic Defense, not future equipment Armor.
- New HP costs leave at least 1 HP and do not emit damage events. AP/MP/HP costs commit together once per legal activation.
- Self and Ally are separate. New ordinary targeting permits up to the configured count of distinct legal selections. Line and caster-centered square-ring Circle retain existing geometry. New All bypasses Range while independently configured LoS/elevation remains; historical geometry v2 is preserved.
- Controlled first use primes the whole Manual action without ordinary payment, action consumption or cooldown; one prime per character/ability/battle. Legal release pays once and consumes the prime; invalid release retains it. Rewind captures its existing position anchor on prime. No arbitrary expiry, automatic release or refunds.
- Pierce power is 1–20; Armor Ignored is 0–100% of the recipient's explicit future equipment Armor contribution, separate from scaling and all other mitigation. Without equipment Armor, explain that configured bypass has no current advantage. Preserve legacy `piercing:true` semantics in historical definitions.
- Selecting Fire/Ice/Water/Storm damage inserts explicit required companion mechanics, locked in authoring and enforced by validation/execution. Preserve policy-2 application conditions, magnitudes, timing and expiry; no duplicates.
- Public field order is Type, Cost, Cooldown, Requirements, Effects, Range, Target, Method, Target Elevation, Line of Sight. Values use brackets; independent entries use a middle dot. Public API/RSC/preview payloads omit authoring accuracy fields.
- Save Draft is not Publish. Publish appends a complete atomic version with optimistic concurrency. Restore copies a complete prior snapshot into a draft, then publishes a new version. UI shows current plus two previous published versions; older referenced snapshots remain physically readable.
- Six primary destinations: Game Content, Combat Rules, Events & Live Ops, Players, Staff & Access, Site Music. Preserve the global character rail, header/account entry and footer; compact desktop layouts remain usable at mobile and 200% zoom.
- Staff grants belong only to the explicitly selected linked character and are checked for expiry/revocation on every protected server/RPC operation. Single Game Owner and nondelegable powers remain protected. Ambiguous legacy grants fail closed until explicitly bound.
- Administrative battle recovery is durable no contest/no rewards, never ordinary surrender/defeat; identify all affected participants before voiding a shared encounter. Late workers/retries cannot grant rewards or records. Do not invent resource refunds.
- Routine written reasons are removed from forms, relevant TS validation and SQL contracts without fabricated reasons; automatic actor/time/action audit remains.
- New migrations use `pnpm exec supabase migration new` after CLI help, preserve existing migration files and service-only grants/RLS, and are tested locally/PGlite. Never mutate hosted production during Tasks 1–16. The Owner-authorized final release applies only reviewed necessary hosted changes after acceptance, independent whole-branch review and current-state reconciliation. Preserve `apps/web/vercel.json` Git deployment lock.

## Current interfaces / approved corrections

- Read current docs/superpowers/specs/2026-10-10-roster-rebalance.md completely. It is the existing play-cycle and mechanical-budget contract, including all17 approved class cycles and the20 existing mechanical preflights. Also read the approved owner brief/design and applicable current AGENTS/domain docs.
- BASE6790f4c9 has41 candidates in the proposals JSON and294 baseline identities/digests in inventory JSON. They are design-only; no candidate is activated. Finish Task14's complete individual design manifest, including existing41 metadata/acceptance completeness. Preserve stable IDs/source/pair/unlocks/earned eligibility/old versions/art associations. Five reviewed Basics may be explicitly retained at their exact original records.
- Use real parsed Ability/effect/Requirement shapes and actual record validators; complete resulting definitions, costs, targeting, recipient/order/clock/limit data, public explanation, role, setup/payoff/counterplay and concrete outcome test plans. Every136 Resonance pair needs its own authored interaction rationale, not a generic pair-name/percentage reskin. Every17 class needs an approachable/useful loadout and justified Library-only complexity tier.
- New record versions append; do not activate/publish/migrate/merge/deploy or alter current source roster/runtime behavior in this design task. Do not change damage/stat/AP/elemental rules or caps to fit candidates. Do not borrow speculative Future Class Ideas.
- The combat-first Owner correction at the plan's top supersedes original unrelated Master-before-roster ordering. All later broad Master/world scope remains open. This task's deliverable is the complete294-record design and independent design gate, not balance-accepted gameplay or a completed combat release.
- Attached Move has no extra walking AP/MP/HP cost; preserve path/reached-origin/Movement legality. Controlled is free once-per-battle prime of whole selected Manual group, paid legal release, no primed decoration/extra button, ready-only light in existing image.
- Existing per-row requiresSurfaceWork flags must remain honest. Explicit Manual modifiers, Automatic-only Skill presentation, conditional/event previews and active Resonance controls need complete actual flows at Task15. Do not count a missing button as a playable Skill.
- Current persistent Ground records and selected enemy position-return mechanics need a bounded real captured contract if included. Raise a precise architectural question to controller rather than invent unsupported payloads or silently drop existing Ground metadata. Keep any future extension clearly provisional until its T15 parser/handler/capture/editor/reader/AI work passes.
- Build an explicit coverage artifact for all19 typed effects,26 registered statuses (including correct generated/system/historical/future classification), supported Requirement forms and selected activation combinations. Record meaningful obtainable content/outcome cases, not prose-only mentions. Pierce's future Armor boundary and system-generated Lowered Guard/compatibility Displaced need honest classification.
- Expand validation meaningfully: a completeness guard should fail for the current partial41 before completing the manifest, then validate all294 actual records/digests/relationships/schema and coverage. Do not add tests that only mirror generated metadata, weaken validators, or claim preview/balance tests ran if only planned.

## Ownership and workflow

One implementer owns this task. Do not spawn helpers or reviewers. Controller handles independent review after a concrete committed diff. Use TDD at real code/validation boundaries; generated design data is verified by actual parser and record validation. Stay scoped to design/proposals/coverage/meaningful validation and durable verification docs; no runtime activation.

Worktree: /workspace/scratch/680b26e4eb86/aurevane
Branch: agent/overhaul-resume-20261016
Task BASE:6790f4c9ff9343dee7b39e2f87999c2f1a3d7454
Use corepack pnpm (repository11.17.0) and Node24. Frozen dependencies are installed in this worktree. Main29506e29 is an ancestor of BASE,55ahead/0behind; recheck freshness before final commit. Keep deployment lock.

Run actual verification commands through `python3 .superpowers/sdd/2026-10-10-unified-engine-recovery/run.py -- <argv...>` so cwd/start/end/exit/full log is recorded immediately. Report source and exact commands/outcomes, original failures, limits, required next surfaces/extensions and all decisions. Do not invent acceptance evidence.

Write report: .superpowers/sdd/2026-10-10-unified-engine-recovery/task-14-report.md. Preserve work/checkpoint before long review or any blockage. Commit coherent design/validation/docs before reporting; no remote push or PR mutation by worker. Return DONE/DONE_WITH_CONCERNS/BLOCKED/NEEDS_CONTEXT, commit(s), one-line test summary, concerns and report path, at most15lines. If blocked, state the exact issue immediately.
