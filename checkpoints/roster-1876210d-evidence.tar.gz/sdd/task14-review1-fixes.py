import json, copy, hashlib
from pathlib import Path
P=Path('docs/superpowers/specs')
path=P/'2026-10-10-roster-rebalance-proposals.json'
m=json.loads(path.read_text());rows={r['id']:r for r in m['records']}
changes={}
def status(id,recipient='primary-unit',turns=1,**extra):return dict(type='apply-status',recipient=recipient,statusId=id,stacks=1,durationTurns=turns,**extra)
def present(id,subject='selected'):return dict(kind='status-presence',subject=subject,statusId=id,present=True)
def effect(id,payload):return dict(id=id,timing='instant',payload=payload)
def revise(id,name,description,role,setup,counter,why,behavior):
 r=rows[id];r['after']['name']=name;r['after']['description']=description;r['interactionIdentity']=name;r['role']=role;r['after']['flavorLine']=description
 r['after']['ability']['behaviors']=[behavior]
 r['acceptance']=dict(setup=setup,payoff=role,counterplay=counter,cases=[])
 for suffix,when,then in [('legal','Execute the specified exact captured proposed group; observe resources, recipient state, ordered effects and cooldown before/after.',role),('counter',counter,'Assert the stated actual counter outcome and atomic rejection where applicable: '+counter),('bounded','Serialize the paid result; retry during cooldown and cross source/terminal boundaries.','Only one payment/activation occurs. No repeated status sacrifice or free recovery on duplicate/no-input/terminal events; retain exact captured versions.')]:
  r['acceptance']['cases'].append(dict(id=id+':'+suffix,status='planned-not-executed',given=setup,when=when,then=then,exactDefinitionRef=dict(id=id,contentVersion=r['after']['contentVersion']),behaviorIds=[behavior['id']]))
 r['accuracyDesign']=[dict(behaviorId=behavior['id'],choice='standard' if behavior.get('accuracy') else 'not-applicable',rationale='Hostile unit effects share the real Standard recipient hit result; self-only utility does not roll against an enemy.')]
 r['playIdentity'].update(combinationRationale=why,turnDecision=role,setup=setup,counter=counter,payoffWindows=[dict(behaviorId=behavior['id'],activation=behavior['activation'],mode=behavior['mode'],requirements=behavior['requirements'],costs=behavior['costs'],cooldown=behavior['cooldown'],orderedClocks=[dict(effectId=e['id'],timing=e.get('timing','instant'))for e in behavior['effects']])])
 kit=r['playIdentity']['earnedFourSkillKit']
 r['acceptance']['cases'].append(dict(id=id+':four-skill-decision',status='planned-not-executed',given=dict(earnedKit=[k['id']for k in kit],exactKitVersions=[k['contentVersion']for k in kit],primarySecondarySwap=True),when='Equip the actual2+2 earned kit; compare this choice with its cited ordinary Skill and apply the counter fixture.',then=dict(combinationRationale=why,decision=role,counter=counter,capacity='Four earned Skills plus the separate pair Resonance; no unselected Skill or Essence.')))
 r['acceptance']['cases'].append(dict(id=id+':review1-present-value',status='planned-not-executed',given=setup,when='Compare the exact ordinary kit tool and pair choice under both qualifying/counter states at Level1 and legal Level100 Core40/HP40 builds.',then=role,counterVariant=counter,kitDecision=why,executedRepresentativeRef='packages/game-core/src/combat/roster-design-outcomes.test.ts; only its named Level1 scenarios are executed, not this complete balance plan.'))
 changes[id]=dict(name=name,experience=why)
 return r
def base(id,ap,mp=0):
 b=copy.deepcopy(rows[id]['after']['ability']['behaviors'][0]);b['costs']=[dict(resource='ap',amount=ap)]+([dict(resource='mp',amount=mp)]if mp else[]);b['classification']='utility';b.pop('attackFamily',None);return b
id='resonance.aetherist-shadehand.veiled-conduit';b=base(id,35)
b['targeting']=copy.deepcopy(rows['vanguard.brace']['after']['ability']['behaviors'][0]['targeting']);b.pop('accuracy',None)
b['requirements']=dict(kind='all',children=[present('guarded','owner'),dict(kind='resource-state',subject='owner',resource='mp',comparison='at-most',basisPoints=9999)])
b['effects']=[effect('sacrifice-guard',dict(type='remove-status',recipient='actor',statusIds=['guarded'])),effect('recover-reserve',dict(type='resource-change',recipient='actor',resource='mp',delta=4)),effect('vanish',status('covert','actor'))]
revise(id,'Dissolving Formula','Shed Guarded to recover mana and slip into concealment.','35AP sacrifices owner Guarded, restores4MP immediately and grants Covert1 while missingMP. Existing Barrier is unchanged; no enemy donor or copy is used.','Use actual Mana Shield to establish Guarded/Barrier and spend reserves. Compare the choice to keep Guarded, borrow an enemy buff with Quick Hands, or sacrifice Guarded while8/20MP.','No Guarded or fullMP rejects without payment. Reapplying Guarded requires a separate real action; Sensory can answer Covert and area pressure still threatens the now unGuarded actor.','Mana Shield produces actual protection at a reserve cost. The pair can cash its Guarded component into immediate mana and Shadehand concealment, giving up mitigation while retaining only finite Barrier. Quick Hands instead copies enemy Buffs and spendsMP without resource recovery; Smoke Vial buys concealment without sacrificing protection. All four kit choices remain distinct.',b)
id='resonance.edgedancer-wildwarden.linked-sequence';b=base(id,40,4);b['targeting'].update(minimumRange=1,maximumRange=3,requiresLineOfSight=True)
b['effects']=[effect('change-angle',dict(type='move',recipient='actor',maximumTiles=2)),effect('reel-quarry',dict(type='displace',recipient='primary-unit',direction='pull',distance=2))]
revise(id,'Pursuit Angle','Circle a Marked quarry, then pull it toward your new position.','40AP/4MP includes Move2 then Pull2 from the actual reached origin against a Marked enemy within1–3. It deals no damage, grants no Blindside, preserves Mark and never pulls onto the caster.','Mark quarry with Hunter’s Mark; choose a legal two-tile route to a new angle, leaving quarry within1–3 of the reached position. Compare Pull placement with keeping quarry distant for Pursuit Shot or approaching for Flanking Cut.','Missing Mark, owner Rooted or an illegal route rejects atomically. A Rooted quarry resists displacement even after a legal paid route. Occupancy/landing can shorten Pull; no extra walking surcharge or overlapping destination is permitted.','Wildwarden establishes a quarry while Edgedancer chooses a real route. The pair changes both positions without attacking: it can reel a ranged quarry toward the new melee angle or away from an ally. Flanking Cut only moves the owner one tile before damaging; Pursuit Shot instead leaves both positions intact. The sacrifice is all immediate attack pressure.',b)
id='resonance.farstrider-runeblade.linked-sequence';b=base(id,40,5)
b['effects']=[effect('erase-mark',dict(type='remove-status',recipient='primary-unit',statusIds=['mark'])),effect('drain-inscription',dict(type='resource-change',recipient='primary-unit',resource='mp',delta=-4)),effect('dampen-command',status('suppress',potencyBasisPoints=2500))]
revise(id,'Disrupting Inscription','Erase a quarry’s Mark to disrupt its offense and drain its mana.','40AP/5MP spends the enemy Mark on a connected Standard utility command: remove Mark first, drain4MP and apply Suppress25%1 at range2–5. It deals no damage and claims no future Armor benefit.','Use Scout’s Mark on an enemy planning a paid attack; choose between retaining source-owned accuracy for Aimed Shot/Aether Cut and erasing Mark to deny enemy reserve/output.','Missing Mark rejects. A Standard miss spends the legal command cost but retains Mark and denies drain/Suppress. Cleanse Suppress before attacking or spendMP before the seal to reduce denial; sight/minimum range remain real.','Farstrider provides a distant source-owned mark and Runeblade turns that information into an explicit hostile mana inscription. Choosing the seal sacrifices the mark’s future aiming value and all direct damage to disrupt an imminent enemy payment/output. Aimed Shot and Aether Cut cannot change enemyMP or outgoing-damage state; Rune Guard instead repairs the owner.',b)
id='resonance.cinderweaver-wildwarden.linked-sequence';b=base(id,50,6);b['classification']='attack';b['attackFamily']='mystic';b['requirements']=dict(kind='all',children=[present('mark'),present('poison')])
b['effects']=[effect('spend-poison',dict(type='remove-status',recipient='primary-unit',statusIds=['poison'])),effect('ignite-quarry',dict(type='damage',recipient='primary-unit',amount=12,defenseKind='ward',scaling=dict(source='mystic-power',coefficientBasisPoints=2500),element='fire')),effect('contain-quarry',status('root')),effect('element-fire',dict(type='remove-status',recipient='actor',statusIds=['frozen']))]
r=revise(id,'Burn the Thicket','Burn away a poisoned, Marked quarry’s affliction to pin it with a Fire strike.','50AP/6MP requires prior Mark and Poison; a connected command removes Poison, strikes with Fire Power12 and applies Rooted1. Mark remains. It adds no Burn; the explicit Fire caster Chilled cleanse remains.','Use Hunter’s Mark and actual native Poison Ground setup. Compare preserving the quarry’s remaining Poison with Cinder Bolt against spending that Poison for immediate damage plus containment.','Removing either prior Mark or Poison rejects without payment. A Standard miss leaves Poison intact and applies no Rooted; connected fullBarrier can still spend Poison and Root. Cleanse Rooted or use a ranged response; no extra Ground tick is invented for standing still.','Wildwarden’s marked poisoned quarry becomes an actual spend decision for Cinderweaver: trade away future Poison attrition to buy a Fire hit and immediate movement denial in one command. Cinder Bolt preserves Poison and adds Burn but cannot Root; Ember Line keeps formation damage. Rooting a quarry does not create entry damage while it stands still. The kit’s native Poison Ground remains provisional for its canonical bridge.',b)
r['requiresSurfaceWork'].append('kit-poison-ground-setup-blocked-until-canonical-group-ground-v1')
def norm(v,k=''):
 if isinstance(v,list):return[norm(x,k)for x in v]
 if isinstance(v,dict):return{a:norm(b,a)for a,b in v.items()if a not in ['id','key','contentVersion','schemaVersion','sourceDisciplineId','requiredTags','abilityId','description']}
 if k in ['statusId','statusIds','element','defenseKind','source']:return '_'
 if isinstance(v,(int,float))and not isinstance(v,bool):return '_'if k!='maximumSelections'else v
 return v
pairs=[r for r in m['records']if r['kind']=='resonance']
for r in pairs:r['playIdentity']['functionalSignature']=hashlib.sha256(json.dumps(norm(r['after']['ability']),sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert len(set(r['playIdentity']['functionalSignature']for r in pairs))==136
path.write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
auditpath=P/'2026-10-10-roster-rebalance-pair-audit.json';a=json.loads(auditpath.read_text())
for c in a['concreteDecisions']:
 if c['recordId'] in changes:
  i=rows[c['recordId']]['playIdentity'];c.update(why=i['combinationRationale'],decision=i['turnDecision'],counter=i['counter'],signature=i['functionalSignature'])
a['reviewRound1']='Four kit-dominated choices reworked through resource/protection sacrifice, route+quarry placement, explicit Mark spend for disruption, and Poison spend for containment. Full independent re-review remains pending.'
auditpath.write_text(json.dumps(a,indent=2,ensure_ascii=False)+'\n')
uPath=P/'2026-10-10-roster-rebalance-uniqueness.json';u=json.loads(uPath.read_text());u['scope']+=' Independent review round1 adds four equipped-tool dominance findings and actual decision reworks.'
u['reworked']=26
for id,c in changes.items():u['clusterAudit'].append(dict(recordId=id,decision='rework',reviewRound=1,experience=c['experience'],finalModes=['manual/action']))
u['independentReviewRound1']=dict(findings=4,fixedCandidates=list(changes),status='implementer-fixes-awaiting-independent-re-review')
uPath.write_text(json.dumps(u,indent=2,ensure_ascii=False)+'\n')
# Rebuild witness paths from actual final mechanics; preserve classification, class tiers and extension contracts.
covpath=P/'2026-10-10-roster-rebalance-coverage.json';cov=json.loads(covpath.read_text());eff={e['id']:[]for e in cov['effectCoverage']};sts={e['id']:[]for e in cov['statusCoverage']};req={e['kind']:[]for e in cov['requirementCoverage']};comb={}
def witness(r,p):return dict(recordId=r['id'],contentVersion=r['after']['contentVersion'],mechanicsPath=p,caseIds=[r['id']+':'+k for k in ['legal','counter','bounded']],requiresSurfaceWork=r['requiresSurfaceWork'],publicationState=r['publicationStatus'])
def requirements(r,n,p):
 if not n:return
 req[n['kind']].append(witness(r,p))
 for i,c in enumerate(n.get('children',[])):requirements(r,c,p+'.children.'+str(i))
def payload(r,v,p):
 eff[v['type']].append(witness(r,p))
 ids=[v['statusId']]if v['type']=='apply-status'else[v['type']]if v['type']in['poison','burn','bleed']else['revealed']if v['type']=='sensory'else[]
 for id in ids:sts[id].append(witness(r,p))
for r in m['records']:
 if r['after'].get('ability'):
  for bi,b in enumerate(r['after']['ability']['behaviors']):
   p='after.ability.behaviors.'+str(bi);comb.setdefault(b['activation']+'/'+b['mode'],[]).append(witness(r,p));requirements(r,b['requirements'],p+'.requirements')
   for ei,e in enumerate(b['effects']):payload(r,e['payload'],p+'.effects.'+str(ei)+'.payload');requirements(r,e.get('requirements'),p+'.effects.'+str(ei)+'.requirements')
 else:
  for ei,e in enumerate(r['after'].get('effects',[])):payload(r,e,'after.effects.'+str(ei))
for e in cov['effectCoverage']:e['witnesses']=eff[e['id']]
for e in cov['statusCoverage']:e['witnesses']=sts[e['id']]
for e in cov['requirementCoverage']:e['witnesses']=req[e['kind']]
for e in cov['selectedActivationCombinations']:e['witnesses']=comb[e['combination']]
covpath.write_text(json.dumps(cov,indent=2,ensure_ascii=False)+'\n')
print('Four distinct current-handler decisions, exact294 preserved,136 signatures distinct, all coverage witnesses rebuilt from actual definitions.')
