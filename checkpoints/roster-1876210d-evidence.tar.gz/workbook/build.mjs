import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';

const repo='/workspace/scratch/680b26e4eb86/aurevane';
const out='/workspace/scratch/680b26e4eb86/outputs/aurevane-roster-preview';
const spec=`${repo}/docs/superpowers/specs/2026-10-10-roster-rebalance`;
const proposal=JSON.parse(await fs.readFile(`${spec}-proposals.json`,'utf8'));
const coverage=JSON.parse(await fs.readFile(`${spec}-coverage.json`,'utf8'));
const pairs=JSON.parse(await fs.readFile(`${spec}-pair-audit.json`,'utf8'));
const before=JSON.parse(await fs.readFile('/tmp/task14-source.json','utf8'));
const rows=proposal.records;
const beforeMap=new Map(['skills','essences','resonances','basics'].flatMap(k=>before[k].map(x=>[x.essenceId??x.id,x])));
const byId=new Map(rows.map(r=>[r.id,r]));
const audit=new Map(pairs.concreteDecisions.map(x=>[x.recordId,x]));
const hash=crypto.createHash('sha256').update(await fs.readFile(`${spec}-proposals.json`)).digest('hex');
assert.equal(hash,'584f45d835bbf7b811a354c33e6618cd2cecb46abdbf5110946070b851f3fdbc');
assert.equal(rows.length,294);assert.equal(beforeMap.size,294);assert.equal(audit.size,136);
const sorted=x=>Array.isArray(x)?x.map(sorted):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,sorted(x[k])])):x;
for(const r of rows){const b=beforeMap.get(r.id);assert(b,`Missing before ${r.id}`);assert.equal(crypto.createHash('sha256').update(JSON.stringify(sorted(b))).digest('hex'),r.beforeDigest,r.id);}

const title=s=>String(s??'').replace(/([a-z])([A-Z])/g,'$1 $2').replace(/[-_]/g,' ').replace(/\b\w/g,x=>x.toUpperCase());
const status=s=>({'frozen':'Chilled','wet':'Wet','root':'Rooted','hexed':'Healing Down','exposed':'Vulnerable','challenged':'Taunt','inspired':'Damage Up','lowered-guard':'Lowered Guard'}[s]??title(s));
const name=a=>a.name??(a.nameRef&&!a.nameRef.startsWith('skill.')?a.nameRef:title((a.id??a.essenceId).split('.').slice(1).join(' ')));
const label=r=>name(r.after);
const kind=r=>({skill:'Class Skill',essence:'Essence',resonance:'Resonance',basic:'Basic'}[r.kind]);
const classIds=r=>r.eligibility?.disciplinePair??(r.eligibility?.sourceDisciplineId?[r.eligibility.sourceDisciplineId]:[]);
const cls=r=>classIds(r).map(title).join(' / ')||'Universal';
const pct=n=>`${Number((n/100).toFixed(2))}%`;
const subject=s=>({owner:'you',selected:'selected target',actor:'you','triggering-subject':'event subject'}[s]??title(s));
const field=(k,v)=>`${title(k.replace('BasisPoints','').replace(/^basisPoints$/,'Rate'))}: ${/basisPoints/i.test(k)&&typeof v==='number'?pct(v):/basisPoints/i.test(k)&&v&&typeof v==='object'?Object.entries(v).map(([a,b])=>`${title(a)} ${pct(b)}`).join(', '):primitive(v)}`;
const primitive=v=>typeof v==='boolean'?(v?'Yes':'No'):Array.isArray(v)?v.map(primitive).join(', '):v&&typeof v==='object'?Object.entries(v).map(([k,x])=>field(k,x)).join('; '):String(v??'None');
function req(q){
 if(!q)return 'None';
 if(q.kind==='all'||q.kind==='any')return `(${q.children.map(req).join(q.kind==='all'?' AND ':' OR ')})`;
 if(q.kind==='not')return `NOT (${req(q.child??q.requirement)})`;
 if(q.kind==='resource-state')return `${subject(q.subject)} ${String(q.resource).toUpperCase()} ${String(q.comparison).replace(/-/g,' ')} ${q.basisPoints!==undefined?pct(q.basisPoints):q.amount}`;
 if(q.kind==='status-presence')return `${subject(q.subject)} ${q.present===false?'does not have':'has'} ${status(q.statusId)}`;
 return `${title(q.kind)}: ${Object.entries(q).filter(([k])=>k!=='kind').map(([k,v])=>`${title(k)} ${primitive(v)}`).join('; ')}`;
}
function behaviors(a){
 const ab=a.ability??a.skill?.ability;if(ab)return ab.behaviors;
 const x=a.skill??a;
 return [{id:'native-ground',activation:'manual',mode:'action',classification:x.effects?.some(e=>['damage','pierce'].includes(e.type))?'attack':'utility',costs:[{resource:'ap',amount:x.apCost??0},{resource:'mp',amount:x.mpCost??0},{resource:'hp',amount:x.hpCost??0}],cooldown:x.cooldown,requirements:x.requirements,targeting:x.target,effects:(x.effects??[]).map((p,i)=>({id:`${p.type}-${i+1}`,timing:'instant',payload:p})),nativeGround:x.groundArea}];
}
const cost=(b,s)=>b.costs?.filter(c=>c.resource===s).reduce((n,c)=>n+c.amount,0)??0;
const single=(bs,fn)=>bs.length===1?fn(bs[0]):'Varies by command';
const activation=b=>`${title(b.activation)}${b.mode==='modifier'?' modifier':''}`;
const rec=(p,t)=>p==='actor'?'You':p==='affected-units'||((t?.maximumSelections??1)>1&&p==='primary-unit')?'Affected units':'Selected unit';
const shape=t=>t?`${title(t.shape?.kind??'single')}${t.shape?.radius!==undefined?` (radius ${t.shape.radius})`:''}${t.shape?.length!==undefined?` (length ${t.shape.length})`:''}`:'None';
const gate=r=>r.kind==='basic'?'Baseline retained':(!r.after.ability?'Ground bridge required':r.requiresSurfaceWork?.length?'Combat integration required':'Runtime balance pending');
const canName=id=>byId.has(id)?label(byId.get(id)):title(id);

const workbook=Workbook.create();
const sheets={};for(const n of ['Start','Disciplines','Skills','Resonances','Commands','Effects','Changes'])sheets[n]=workbook.worksheets.add(n);
const ink='#292238', purple='#392D4D', orange='#B45F16', pale='#F5F1F8';
function col(n){let s='';for(n++;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;}
function table(sheetName,heading,headers,data,widths){
 const s=sheets[sheetName],end=col(headers.length-1),last=data.length+5;
 s.showGridLines=false;s.tabColor=sheetName==='Disciplines'?'#6F568A':purple;
 s.getRange(`A1:${end}${last}`).format.font={name:'Arial',size:10,color:ink};
 s.getRange('A2').values=[[heading]];s.getRange(`A2:${end}2`).format.font={name:'Arial',size:14,bold:true,color:purple};s.getRange('A2').format.rowHeight=28;
 s.getRange(`A3:${end}3`).format.borders={bottom:{style:'thin',color:'#C2B3CF'}};
 s.getRange('A3').values=[['Reviewed design snapshot. Balance and combat integration remain pending.']];s.getRange('A3').format.font={italic:true,color:'#6C6375',size:10};
 s.getRange(`A5:${end}${last}`).values=[headers,...data];
 const t=s.tables.add(`A5:${end}${last}`,true,`${sheetName}Catalog`);t.style='TableStyleMedium2';t.showFilterButton=true;
 s.getRange(`A5:${end}5`).format={fill:purple,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true,rowHeight:32};
 s.getRange(`A6:${end}${last}`).format.wrapText=true;s.getRange(`A6:${end}${last}`).format.verticalAlignment='top';
 widths.forEach((w,i)=>s.getRange(`${col(i)}5:${col(i)}${last}`).format.columnWidth=w);
 data.forEach((row,i)=>{const lines=Math.max(...row.map((v,j)=>String(v??'').split('\n').reduce((n,l)=>n+Math.max(1,Math.ceil(l.length/(widths[j]*0.87))),0)));const rr=s.getRange(`A${i+6}:${end}${i+6}`);rr.format.rowHeight=Math.max(32,lines*13+9);rr.format.fill=i%2?'#FFFFFF':pale;});
 s.freezePanes.freezeRows(5);s.freezePanes.freezeColumns(sheetName==='Disciplines'?1:sheetName==='Skills'?3:2);
 return s;
}
const classCycles=new Map((await fs.readFile(`${spec}.md`,'utf8')).split('\n').filter(l=>l.startsWith('| ')&&l.split('|').length===6).map(l=>l.split('|').slice(1,-1).map(v=>v.trim())).filter(a=>coverage.classes.some(c=>title(c.disciplineId)===a[0])).map(a=>[a[0],a]));
const disciplineData=coverage.classes.map(c=>{const id=c.disciplineId,skills=rows.filter(r=>r.kind==='skill'&&classIds(r)[0]===id),ess=rows.find(r=>r.kind==='essence'&&classIds(r)[0]===id),cycle=classCycles.get(title(id));return [title(id),c.complexity,cycle?.[2]??c.rationale,cycle?.[3]??c.rationale,skills.map(label).join('\n'),label(ess),c.approachableLoadout.map(canName).join('\n'),c.rationale,'Earn these Skills through their existing unlocks. Complexity describes decisions, not strength.'];});
table('Disciplines','The 17 Discipline playstyles',['Discipline','Complexity','Playstyle','Choices and counters','Eight class Skills','Essence','Example four-Skill loadout','Why this tier','Availability'],disciplineData,[20,16,55,68,30,28,30,55,48]);

const skills=rows.filter(r=>r.kind!=='resonance');
const skillData=skills.map(r=>{const bs=behaviors(r.after);return [cls(r),kind(r),label(r),single(bs,b=>cost(b,'ap')),single(bs,b=>cost(b,'mp')),single(bs,b=>cost(b,'hp')),single(bs,b=>b.cooldown?.ownerTurns??0),r.role,bs.map(activation).filter((x,i,a)=>a.indexOf(x)===i).join('\n'),r.eligibility?.unlockRequirement?primitive(r.eligibility.unlockRequirement):'Universal / current Essence eligibility',r.after.contentVersion,gate(r),r.id];});
const sk=table('Skills','Class Skills, Essences and Basics',['Discipline','Kind','Ability','AP','MP','HP cost','Cooldown (owner turns)','Purpose','Activation','Earned eligibility','Proposed version','Remaining work','Record ID'],skillData,[20,14,29,13,13,13,17,65,23,42,15,32,49]);sk.getRange(`D6:G${skills.length+5}`).setNumberFormat('0');
const resonanceData=rows.filter(r=>r.kind==='resonance').map(r=>{const a=audit.get(r.id),bs=behaviors(r.after);return [cls(r),label(r),single(bs,b=>cost(b,'ap')),single(bs,b=>cost(b,'mp')),single(bs,b=>cost(b,'hp')),single(bs,b=>b.cooldown?.ownerTurns??0),a.why,a.decision,a.counter,a.kit.map(canName).join('\n'),gate(r),r.id];});
const re=table('Resonances','The 136 pair Resonances',['Discipline pair','Resonance','AP','MP','HP cost','Cooldown (owner turns)','Why this pair','New decision','Counterplay','Example earned four-Skill kit','Remaining work','Record ID'],resonanceData,[32,29,13,13,13,17,65,65,65,31,32,52]);re.getRange(`C6:F${resonanceData.length+5}`).setNumberFormat('0');

const commandData=[],effectData=[];
for(const r of rows){for(const b of behaviors(r.after)){
 const t=b.targeting??{},timings=[...new Set(b.effects.map(e=>e.timing??'instant'))],notes=[b.activationLimits?.map(title).join(', '),b.nativeGround?`Native Ground: ${b.nativeGround.durationRounds} rounds; canonical bridge pending`:'',r.after.execution?.kind==='basic-move'?'AP is per terrain point, within remaining Movement':''].filter(Boolean).join('\n');
 commandData.push([cls(r),label(r),title(b.id),activation(b),title(b.classification),cost(b,'ap'),cost(b,'mp'),cost(b,'hp'),b.cooldown?.ownerTurns??0,req(b.requirements),t.minimumRange??null,t.maximumRange??null,t.maximumSelections??1,(t.categories??[t.teamPolicy??t.kind]).map(x=>title(x)).join(', '),shape(t),t.requiresLineOfSight?'Required':'Not required',t.maximumElevationDifference??'No limit',timings.map(title).join('\n'),notes,r.id,b.id]);
 b.effects.forEach((e,i)=>{const p=e.payload,ty=p.type,amount=p.amount??p.delta??p.stacks??p.maximumTiles??p.distance??null,rate=p.percentageBasisPoints??p.potencyBasisPoints??p.damageProfile?.basisPoints??p.basisPoints??null,unit=['damage','pierce'].includes(ty)?'Power':ty==='percentage-recovery'?`% maximum ${String(p.resource).toUpperCase()}`:p.damageProfile?'% attack damage':ty==='healing'?'Flat HP':ty==='barrier-change'?'Flat Barrier':ty==='resource-change'?`Flat ${String(p.resource).toUpperCase()}`:ty==='apply-status'?'Stacks':ty==='move'||ty==='displace'?'Tiles':'See details';
 const omit=new Set(['type','recipient','amount','delta','stacks','maximumTiles','distance','percentageBasisPoints','potencyBasisPoints','basisPoints','durationTurns','ticks']);
 const extra=Object.entries(p).filter(([k])=>!omit.has(k)).map(([k,v])=>k==='statusId'?`Status: ${status(v)}`:k==='statusIds'?`Statuses: ${v.map(status).join(', ')}`:k==='scaling'?`Scaling: ${title(v.source)} × ${pct(v.coefficientBasisPoints)}`:k==='armorIgnoredBasisPoints'?`Future equipment Armor bypass: ${pct(v)}. No current advantage without equipment Armor.`:field(k,v)).join('\n');
 const nativeEntry=b.nativeGround?.entryEffectOrdinals.includes(i);
 effectData.push([label(r),title(b.id),i+1,title(ty),rec(p.recipient,t),amount,rate===null?null:rate/10000,unit,nativeEntry?'Native Ground entry':title(e.timing??'instant'),p.durationTurns??null,p.ticks??null,req(e.requirements),extra,r.id,b.id]);
 });
}}
const cmd=table('Commands','Exact command characteristics',['Discipline / pair','Ability','Command','Activation','Type','AP','MP','HP cost','Cooldown (owner turns)','Requirements','Min range (tiles)','Max range (tiles)','Max selections','Targets','Shape','Line of sight','Elevation difference','Timing','Limits / native notes','Record ID','Command ID'],commandData,[30,29,27,22,16,10,10,11,17,62,14,14,15,26,27,18,18,24,48,52,30]);cmd.getRange(`F6:I${commandData.length+5}`).setNumberFormat('0');
const ef=table('Effects','Ordered effects and exact values',['Ability','Command','Order','Effect','Recipient','Amount','Rate','Unit / basis','Timing','Duration (turns)','Applications','Effect requirements','Details','Record ID','Command ID'],effectData,[29,27,10,25,22,13,13,24,25,17,16,62,65,52,30]);ef.getRange(`F6:F${effectData.length+5}`).setNumberFormat('0');ef.getRange(`G6:G${effectData.length+5}`).setNumberFormat('0.0%');ef.getRange(`D6:D${effectData.length+5}`).format.font.color=orange;

function packet(p){return `${title(p.type)}${p.amount!==undefined?` ${p.amount}${['damage','pierce'].includes(p.type)?' Power':''}`:p.delta!==undefined?` ${p.delta} ${String(p.resource).toUpperCase()}`:p.percent!==undefined?` ${p.percent}% ${String(p.resource).toUpperCase()}`:p.percentageBasisPoints!==undefined?` ${pct(p.percentageBasisPoints)} ${String(p.resource).toUpperCase()}`:p.statusId?` ${status(p.statusId)}`:''}`;}
function summary(a){
 if(a.trigger&&!a.ability){const tr=a.trigger;return `Triggered Resonance (${title(tr.mode??tr.kind)}).\n${Object.entries(tr).filter(([k])=>!['kind','mode','resultEffects'].includes(k)&&!k.startsWith('ai')).map(([k,v])=>`${title(k)}: ${primitive(v)}`).join('\n')}\nResult: ${(tr.resultEffects??[]).map(packet).join(', ')}`;}
 return behaviors(a).map(b=>`${title(b.id)}: ${activation(b)}; ${cost(b,'ap')} AP / ${cost(b,'mp')} MP / ${cost(b,'hp')} HP; cooldown ${b.cooldown?.ownerTurns??0}; ${b.effects.map(e=>packet(e.payload)).join(', ')}`).join('\n');
}
const changes=rows.map(r=>[kind(r),cls(r),r.id,name(beforeMap.get(r.id)),label(r),r.beforeVersion,r.after.contentVersion,r.kind==='basic'?'Exact baseline retained':'New proposed immutable version',summary(beforeMap.get(r.id)),summary(r.after),r.decisionReview?.opportunityCost??audit.get(r.id)?.why??r.retentionRationale??r.role]);
table('Changes','Before and proposed update',['Kind','Discipline / pair','Record ID','Before name','Proposed name','Before version','Proposed version','Change','Before command summary','Proposed command summary','Reason / opportunity cost'],changes,[14,30,52,29,29,15,15,31,78,78,72]);

const s=sheets.Start;s.showGridLines=false;s.tabColor=purple;
s.getRange('A1:F29').format.font={name:'Arial',size:10,color:ink};
[['A',53],['B',17],['C',4],['D',5],['E',80],['F',22]].forEach(([c,w])=>s.getRange(`${c}1:${c}29`).format.columnWidth=w);
s.getRange('A2').values=[['AUREVANE roster preview']];s.getRange('A2').format.font={name:'Arial',size:16,bold:true,color:purple};s.getRange('A2').format.rowHeight=29;
s.getRange('A3').values=[['Reviewed design. Gameplay balance and integration are still pending.']];s.getRange('A3').format.font={italic:true,color:'#6C6375'};s.getRange('A3:B3').format.borders={bottom:{style:'thin',color:'#C2B3CF'}};
s.getRange('A5:B10').values=[['Roster','Records'],['Class Skills',null],['Essences',null],['Resonances',null],['Basics',null],['Total',null]];
s.getRange('B6:B10').formulas=[[`=COUNTIFS('Skills'!$B$6:$B$${skills.length+5},"Class Skill")`],[`=COUNTIFS('Skills'!$B$6:$B$${skills.length+5},"Essence")`],[`=COUNTA('Resonances'!$B$6:$B$${resonanceData.length+5})`],[`=COUNTIFS('Skills'!$B$6:$B$${skills.length+5},"Basic")`],['=SUM(B6:B9)']];
s.getRange('A5:B5').format={fill:purple,font:{bold:true,color:'#FFFFFF'},horizontalAlignment:'center',rowHeight:25};s.getRange('A6:B10').format.rowHeight=25;s.getRange('A10:B10').format.font.bold=true;s.getRange('B6:B10').setNumberFormat('0');
s.getRange('E5').values=[['Before the combat release']];s.getRange('E5').format.font.bold=true;
const releaseNotes=['The 17 classes keep their identities, earned unlocks and artwork.','All eight class Skills, every Essence and all pair Resonances are included.','Final costs and balance may change after full-class, mixed-build and AI tests.','Targeting, Move, Basics, Controlled and shared readers must pass together.','Battle text, Skill Management previews and effect popups ship with the roster.','Final descriptions will be short and natural, without repeated values or timing.'];
s.getRange('E6:E11').values=releaseNotes.map(x=>[x]);s.getRange('E6:E11').format.wrapText=true;s.getRange('E6:E11').format.rowHeight=30;
s.getRange('A13:B19').values=[['Reading the numbers','Meaning'],['AP / MP / HP','Payment per activation.'],['Power','Authored power, not guaranteed HP damage.'],['Controlled','First prime is free; valid release pays once.'],['Basic Move','20 AP per terrain point, within remaining Movement.'],['Complexity','Decision burden; all tiers have equal intended strength.'],['Ground','Three native areas need the canonical bridge before publication.']];
s.getRange('A13:B13').format={fill:purple,font:{bold:true,color:'#FFFFFF'},horizontalAlignment:'center',rowHeight:25};s.getRange('A14:B19').format.wrapText=true;s.getRange('A14:B19').format.rowHeight=42;s.getRange('B13:B19').format.columnWidth=43;
s.getRange('E14:E19').values=[['How to browse'],['Filter Skills by Discipline or Kind. Filter Resonances by pair.'],['Commands lists each action or modifier separately, including all costs and targeting.'],['Effects lists every packet in order, with exact values and conditions.'],['Changes compares the saved source roster with this reviewed proposal.'],['The numbers in this workbook are structured design details, not final card wording.']];s.getRange('E14:E19').format.wrapText=true;s.getRange('E14').format.font.bold=true;
s.getRange('A22').values=[['Source snapshot']];s.getRange('A22').format.font.bold=true;
s.getRange('A23:B26').values=[['Design source','a8df18ef3730795bda29510f9ecde40bccefa8c0'],['As of','15 October 2026, Trinidad'],['Design review','Full review plus scoped fix review passed.'],['Execution evidence','41 candidate engine outcomes; full roster balance still open.']];s.getRange('A23:B26').format.wrapText=true;s.getRange('A23:B26').format.rowHeight=32;
s.getRange('E23').values=[['Baseline: saved source at 6790f4c9. Proposed definitions: reviewed a8df18ef manifest. Existing battle versions stay preserved.']];s.getRange('E23').format.wrapText=true;s.getRange('E23').format.rowHeight=42;
s.getRange('E25').values=[['Native Basic adapters retain their execution rules. Three Ground commands are listed with native metadata and remain provisional. Zero cooldown means no cooldown.']];s.getRange('E25').format.wrapText=true;s.getRange('E25').format.rowHeight=42;

for(const [sheetName,column,length] of [['Skills','G',skillData.length],['Resonances','F',resonanceData.length],['Commands','I',commandData.length],['Effects','C',effectData.length],['Changes','G',changes.length]])sheets[sheetName].getRange(`${column}6:${column}${length+5}`).format.borders={right:{style:'thin',color:'#DED6E6'}};
workbook.recalculate();
const counts=s.getRange('B6:B10').values.flat();assert.deepEqual(counts,[136,17,136,5,294]);
const inspect=await workbook.inspect({kind:'table',range:'Start!A5:B10',include:'values,formulas',tableMaxRows:6,tableMaxCols:2,maxChars:2500});
const errors=await workbook.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:30},summary:'Final formula error scan',maxChars:3000});
await fs.mkdir(out,{recursive:true});
for(const sheetName of (process.env.PREVIEW_SHEETS?.split(',')??Object.keys(sheets))){
 const range=sheetName==='Start'?'A1:E19':sheetName==='Disciplines'?'A1:D8':sheetName==='Skills'?'A1:H9':sheetName==='Resonances'?'A1:H8':sheetName==='Commands'?'A1:J8':sheetName==='Effects'?'A1:M9':'A1:H9';
 const image=await workbook.render({sheetName,range,scale:1,format:'png'});await fs.writeFile(`${out}/${sheetName.toLowerCase()}-preview.png`,new Uint8Array(await image.arrayBuffer()));
}
const file=await SpreadsheetFile.exportXlsx(workbook);await file.save(`${out}/AUREVANE_Roster_Update_Preview.xlsx`);
const meta={sourceCommit:'a8df18ef3730795bda29510f9ecde40bccefa8c0',manifestSha256:hash,records:rows.length,disciplines:disciplineData.length,skills:skills.length,resonances:resonanceData.length,commands:commandData.length,effects:effectData.length,changes:changes.length,summaryCounts:counts,inspect:inspect.ndjson,errorScan:errors.ndjson,output:`${out}/AUREVANE_Roster_Update_Preview.xlsx`};
await fs.writeFile(`${out}/validation.json`,JSON.stringify(meta,null,2));console.log(JSON.stringify(meta));
