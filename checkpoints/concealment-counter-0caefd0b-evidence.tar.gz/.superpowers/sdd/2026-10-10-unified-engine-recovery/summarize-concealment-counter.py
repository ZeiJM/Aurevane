from pathlib import Path
import json,hashlib,subprocess
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery')
p=w/'concealment-counter-actual-cycles-frozen.jsonl'
rows=[json.loads(s) for s in p.read_text().splitlines()]
assert len(rows)==24
summary=[]
for r in rows:
 stage=r['stages'][4]
 actor=r['stages'][0]['actorId']
 accuracy=[e for e in stage['events'] if e['event']=='combat_accuracy_resolved' and e['targetCombatantId']==actor]
 assert len(accuracy)==1
 event=accuracy[0]
 expected='cinderweaver.ember-line' if r['kind']=='area-hit' else 'farstrider.scouts-mark'
 assert event['actionId']==expected
 assert event['hit']==(r['kind']!='sensory-miss')
 assert any(c['ownerId']==event['sourceCombatantId'] and c['id']==expected for c in r['captures'])
 before=next(u for u in r['stages'][3]['combatants'] if u['id']==actor)
 after=next(u for u in stage['combatants'] if u['id']==actor)
 summary.append({'kind':r['kind'],'primary':r['primary'],'level':r['level'],'context':r['context'],'seed':r['seed'],'actionId':expected,'hit':event['hit'],'hitChanceBasisPoints':event['hitChanceBasisPoints'],'rollBasisPoints':event['rollBasisPoints'],'hpBefore':before['hp'],'hpAfter':after['hp'],'barrierBefore':before['barrier'],'barrierAfter':after['barrier']})
assert len({(r['kind'],r['primary'],r['level'],r['context']) for r in summary})==24
result={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'traceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'records':24,'actualNativeAccuracyAndCapturedActionChecked':True,'scenarios':summary}
(w/'concealment-counter-observations.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='scenarios'}))
