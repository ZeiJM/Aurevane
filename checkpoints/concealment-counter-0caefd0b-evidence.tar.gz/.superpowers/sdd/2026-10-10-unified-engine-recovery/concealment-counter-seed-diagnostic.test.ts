import { expect, it, vi } from 'vitest'
import type { CombatTargetSelection } from '@aurevane/game-core/combat/actions'
import {
  commitCombatAbilityCommand,
  prepareCombatAbilityCommand,
} from '@aurevane/game-core/combat/combat-ability-command'
import { combatAbilityCommandContext } from '@aurevane/game-core/combat/combat-behavior-runtime'
import { currentBarrierAmount } from '@aurevane/game-core/combat/combat-barrier'
import {
  finishPv1fTurn,
  PV1F_COMBAT_CONTENT,
  readPv1fActionEconomy,
} from '@aurevane/game-core/combat/pv1f-action-economy'
import {
  reattachStatDrivenCombatBridge,
  validateStatDrivenCombatEncounterState,
  type StatDrivenCombatEncounterState,
} from '@aurevane/game-core/combat/stat-driven-combat'
import { createLegalRosterDuel, legalRosterCycleKits } from '@/server/battle/roster-legal-duel.test-utils'

vi.mock('server-only', () => ({}))
const veiled = 'resonance.aetherist-shadehand.veiled-conduit'
const farstrider = legalRosterCycleKits.find(
  (kit) => kit.primary === 'farstrider' && !kit.secondary,
)!
const cinderweaver = legalRosterCycleKits.find(
  (kit) => kit.primary === 'cinderweaver' && !kit.secondary,
)!
const cases = legalRosterCycleKits
  .filter((kit) => kit.name.startsWith(`${veiled}:`))
  .flatMap((kit) =>
    ([1, 100] as const).flatMap((level) =>
      (['pve', 'pvp'] as const).map((context) => ({
        name: `${kit.primary}:${level}:${context}`,
        kit,
        level,
        context,
      })),
    ),
  )
function unit(state: StatDrivenCombatEncounterState, id: string) {
  return state.tactical.battle.combatants.find((row) => row.id === id)!
}
function status(state: StatDrivenCombatEncounterState, id: string, statusId: string) {
  return state.statusState
    .find((row) => row.combatantId === id)!
    .statuses.find((row) => row.statusId === statusId && row.timingState !== 'pending')
}
function restore(state: StatDrivenCombatEncounterState) {
  const next: StatDrivenCombatEncounterState = JSON.parse(JSON.stringify(state))
  expect(validateStatDrivenCombatEncounterState(next)).toEqual([])
  return next
}
function end(state: StatDrivenCombatEncounterState) {
  const id = state.tactical.battle.currentTurn!.combatantId
  return restore(
    finishPv1fTurn(state, state.tactical.placements.find((row) => row.combatantId === id)!.facing)
      .state,
  )
}
function command(
  state: StatDrivenCombatEncounterState,
  actorId: string,
  abilityId: string,
  selection: CombatTargetSelection,
) {
  const source = state.capturedAbilitySources!.find(
    (row) => row.ownerCombatantId === actorId && row.abilityId === abilityId,
  )
  if (!source) throw new Error(`Unequipped command ${abilityId}`)
  return {
    state,
    actorId,
    root: { kind: 'canonical' as const, source },
    selection,
    content: PV1F_COMBAT_CONTENT,
    context: combatAbilityCommandContext(state, source),
  }
}
function cast(input: ReturnType<typeof command>) {
  const before = JSON.stringify(input.state)
  const quote = prepareCombatAbilityCommand(input)
  expect(quote.evaluation.legal, JSON.stringify(quote.evaluation.issues)).toBe(true)
  const out = commitCombatAbilityCommand(input)
  expect(JSON.stringify(input.state)).toBe(before)
  return {
    ...out,
    state: restore(
      reattachStatDrivenCombatBridge(
        out.state,
        (out.state as Partial<StatDrivenCombatEncounterState>).statBridge ?? input.state.statBridge,
      ),
    ),
  }
}
async function concealed(
  scenario: (typeof cases)[number],
  opponentKit: typeof farstrider,
  seed: number,
) {
  const duel = await createLegalRosterDuel({ ...scenario, opponentKit, seed })
  const [actor, opponent] = duel.participants
  expect(actor!.committed.disciplineSkills).toHaveLength(4)
  expect(opponent!.committed.disciplineSkills).toHaveLength(4)
  let state = restore(duel.state)
  for (let turn = 0; state.tactical.battle.currentTurn!.combatantId !== actor!.actorId; turn++) {
    expect(turn).toBeLessThan(2)
    state = end(state)
  }
  const initialMp = unit(state, actor!.actorId).mp
  state = cast(command(state, actor!.actorId, 'aetherist.mana-shield', { kind: 'self' })).state
  expect(status(state, actor!.actorId, 'guarded')).toBeDefined()
  expect(currentBarrierAmount(state, actor!.actorId)).toBe(20)
  state = cast(command(state, actor!.actorId, veiled, { kind: 'self' })).state
  expect(status(state, actor!.actorId, 'guarded')).toBeUndefined()
  expect(status(state, actor!.actorId, 'covert')).toBeDefined()
  expect(unit(state, actor!.actorId).mp).toBe(initialMp - 2)
  expect(readPv1fActionEconomy(state, actor!.actorId)!.current).toBe(30)
  const counterWindow = end(state)
  expect(counterWindow.tactical.battle.currentTurn!.combatantId).toBe(opponent!.actorId)
  expect(status(counterWindow, actor!.actorId, 'covert')).toBeDefined()
  return { actor: actor!, opponent: opponent!, state: counterWindow }
}

it('observes actual post-setup counter rolls for stated candidate seeds', async()=> {
 const scenario=cases.find(row=>row.level===100&&row.context==='pvp'&&row.kit.primary==='aetherist')!
 const observations=[]
 for(const seed of [26,27,28,54,81,108,135,162,189,216]) {
  const {actor,opponent,state}=await concealed(scenario,farstrider,seed)
  const out=cast(command(state,opponent.actorId,'farstrider.scouts-mark',{kind:'unit',combatantId:actor.actorId}))
  const accuracy=out.events.filter(event=>event.event==='combat_accuracy_resolved'||event.event==='combat_status_resistance_resolved')
  observations.push({seed,accuracy,covert:!!status(out.state,actor.actorId,'covert'),revealed:!!status(out.state,actor.actorId,'revealed')})
 }
 const {writeFileSync}=await import('node:fs');writeFileSync('/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/concealment-counter-seed-observations.json',JSON.stringify(observations,null,2)+'\n')
 expect(observations).toHaveLength(10)
})
