# Combined Controlled command availability review
BASE f8ff229b28245151cb22399c3c59f452f167df97
HEAD 465020f2c89f38691b7ad596932e36f14701ee1e
Review all six changed source/test files, including the new346-line fixture. Use the actual code-reviewer.md template at /root/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/requesting-code-review/code-reviewer.md.

Requirements: task15-controlled-command-availability-brief.md; Owner§7/§10 and later ready-only correction; approved docs/superpowers/specs/2026-10-16-manual-modifier-picker-design.md and root/scopedAGENTS. Native controlled phase spent after release/cancel cannot invite a new action. Preserve same-source ordinaryManualgroups/historical absentmetadata/costs/infoaccess/freeprime/primedlegalrelease/lockedmodifiercontracts/customkeys/boardlayout. Shared PvE/PvP/bothbreakpoints. No core/schema/publicprojection/nativecost/control/CSS/art change.

Current checks: initial195400566375 eight real spent descriptor/artwork RED, threeguardsGREEN. Basic fixtures first incorrectly changed unsupported Move timing, then incorrectly attached follow-up effects to per-terrain-point Move; parser correctly rejected. Corrected fixtures use explicit flat overall Move price + one supported Controlled damage payload. Basic gating temporarily removed and corrected195612060404 five valid enabled-spent-commands RED,11skipped, then restored. Final876focused/82filesGREEN195646317858; webtypes195713495744,lint195713495745,native73/4files195713491291GREEN;format/diffcheckGREEN.19newcases, full8652+7 and294staticcomparisonrunning separately. Only server-onlymarker mocked; realnativeprime/release/cancel→ownerprojection→intentfactories/SSR. Do not infer mounted/native/AT/geometry acceptance.

Trace actual source-to-consumer spent gating, everyBasic/Skill/Essence/Resonance, selected/ambiguous groups, cooldown/cost distinction, explicit lockedmodifiers and actualsharedBattleExperience forwarding. Look for a reasonable user's impact, not spec silence. One fresh combined read-only reviewer. No tests, service/browser/native/network, mutations or subagents. Do not independently rerun suites; parent owns receiptverification. Report actual Critical/Important/Minor withfilelines and every considered-but-declined behavior individually withreason; no pooleddeclines. Parent gradesactualimpact, ONECIfix/no rereview.13inheritedMinors remain deferred (see latest verificationreport/progressledger); do not silently close or fix them. No releaseapproval.

## Review Focus (verbatim)

- A stale browser, alternate selected character or direct RPC must not bypass live expiry/revocation/CAS. Task8 exercises these actual authority paths; Task16 verifies them with the finished workspaces.
- Malformed nested/captured/pending/summon data must fail closed without leaking private accuracy or replacing old definitions with current content. Tasks1/5/7 exercise wrong types, recursive serialization and immutable capture.
- No input, free priming, repeated events and interrupted Move must not produce unbounded damage, duplicate payment, extra turns or attacks from an unreached tile. Tasks2/3A/4 and14–16 exercise those paths.
- Concurrent publication/build/claim/recovery/settlement must either commit a coherent result once or return a specific retry/no-contest outcome. Tasks5/6/9/12/16 test actual rollback, locks and late/repeated workers.
- Long names, missing historical metadata, mobile/native keyboard and 200% zoom must retain truthful mechanics and accessible primary controls. Tasks7–13/16 inspect actual components/screens and distinguish fixtures from hosted/human evidence.

