from pathlib import Path
import json,re,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='controlled-command-availability'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
log=Path(gate['log']).read_text();expected=int((w/(prefix+'-test-count.txt')).read_text())
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
source=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip()
assert reviewed=='465020f2c89f38691b7ad596932e36f14701ee1e'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
analysis=json.loads((w/(prefix+'-reader-analysis.json')).read_text())
assert analysis['source']==source and analysis['records']==294 and analysis['allReportsAndHtmlExactlyUnchanged'] and analysis['manifestAndSixAiSourceHashesUnchanged']
review=(w/(prefix+'-review-outcome.md')).read_text()
rulings=(w/(prefix+'-review-rulings.md')).read_text()
assert 'Cost if wrong:' in rulings
report=f'''# Spent Controlled commands — verified development checkpoint

After a Controlled action has been released or its prime cancelled, its captured group can no longer arm an executable command. The shared cockpit disables the artwork when every group is spent. Its information button stays accessible. When another ordinary Manual group remains, artwork instead offers an explicit group chooser. Opening it clears the old group, attachments and targets without selecting or casting a replacement. A stale ready signal or prime hint cannot override the captured spent state or turn a chooser into a ready action. The accessible command label explains “already used this battle”; no new primed decoration, Release button, artwork change or command slot is introduced.

Native once-per-character/ability/battle admission already rejected another prime or release. The defect was in the consumers: captured descriptor resolution and cockpit cost presentation did not consume the terminal phase. The shared descriptor now becomes unavailable for a selected spent Controlled group, so existing target/initial/directional/range factories and the executeIntent guard reject it. The payment adapter separately reports controlledSpent without changing affordability or definition costs. Skill, Essence and active Manual Resonance buttons use that flag; actual BattleExperience forwards availability aggregated from the Basic's owner captures even when no group is resolved to Move, Basic Attack and the current Support artwork.

This applies through the shared playable PvE/PvP cockpit on both breakpoints. Other ordinary Manual groups in the same source remain selectable and legal. Unprimed/free-prime and legally primed release behavior remain unchanged. Historical absence of Controlled metadata retains existing behavior. Private source identity, capture fields, payment, cooldowns, limits, effect execution and prime reconciliation remain native authority.

## Verification

BASE f8ff229b28245151cb22399c3c59f452f167df97 → reviewed {reviewed} → final tested {source}. Six source/test files changed initially; this report is a docs-only descendant. No game-core, schema, public projection, persistence, AI, manifest, control bindings, CSS, artwork or geometry changes.

- Initial RED195400566375Z-893bf67b reproduced eight real failures: spent descriptor intent creation plus enabled Skill/Essence/Resonance artwork after native release/cancel. Three guards passed. The native state already reported spent and rejected reuse.
- Basic fixtures initially attempted unsupported Controlled timing on Move, then attached extra effects to per-terrain-point walking. Both parser rejections were correct. Fixtures were corrected to an explicit flat overall Move price and a supported Controlled damage payload alongside the other effects. No native legality or cost rule changed to fit a test.
- With Basic spent gating removed, corrected RED195612060404Z-1c7abfd1 showed five actual enabled-spent Basic commands, with no fixture error. Restoring that guard made them pass. Default per-terrain-point native walking remains unchanged.
- **35 new native lifecycle cases overall (19 initial plus16 review regressions)** cover prime/release/cancel, owner projection, descriptor/intent factories and actual shared SSR for Skill/Essence/Manual Resonance and all five editable Basics. Basic coverage includes the current equipped Guard/HP Recovery/MP Recovery choices. Ordinary Manual groups remain legal after the same ability's Controlled action is consumed. Cancel spends no HP/MP; the displayed captured11 AP /2 MP /1 HP price remains intact; spectators receive no owner action choices. Before prime there is no readiness glow; a legally primed action remains available with its existing ready signal.
- Final initial focused **876 tests /82 files GREEN**195646317858Z-33b41d99; web types195713495744Z-efd5f02a and zero-warning scoped lint195713495745Z-ce7d94ed GREEN. Correct native Controlled/configured/bundle/composition suite **73 tests /4 files GREEN**195713491291Z-e91fd0bd. An earlier command used a nonexistent bundle filename and therefore ran only the other two matching files (72 tests); the later correctly named four-file run is the evidence for73.
- The combined review found two Important multi-group gaps. ONE correction wave adds a deliberate chooser for a spent selected group with another ordinary group, and independent all-spent Basic aggregation. Review RED200244124487:11 valid failures/19 passing; additional Basic mixed-choice falsification200426997652:five valid failures/30 skipped. Final repaired focused **1,034 tests /88 files GREEN**200454694110Z-7e5f6f2c;types200454709745Z-36739318 and zero-warninglint200454688617Z-0ccff72c GREEN. No rereview.
- Initial reviewed-source full check195801168899 exited0 with8652+7, but saved stdout lacked its final build summary despite the tool completion tail. Initial audit/package logs are preserved. The changed repaired source required the fresh full check below, not a redundant cached replay.
- Final exact-source root: **{expected:,} Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds GREEN. Receipt {Path(gate['log']).stem}, {gate['started_utc']} → {gate['completed_utc']}. Counts: {', '.join(a+' '+b for a,b in counts)}. Complete root build tail and package-log hash audit are preserved.
- All294 named Skill reports and HTML are exactly unchanged from the preceding conditional Ward/Taunt checkpoint:294 records,297 groups,604 effects. Observation SHA256 {analysis['rawSha256']}. Manifest and six AI/native source hashes remain unchanged. This does not claim a fresh289-case gameplay matrix.

## Combined review and parent decisions

{review}

## Evidence limits and next work

Only the server-only import marker is mocked in the new fixture. Actual native lifecycle, projection and shared SSR are tested; this is not mounted browser, physical keyboard/touch, assistive-technology, focus or geometry acceptance. No repeat browser installation or tunnel attempt was made.

The existing Manual picker already carries exact selected references through prime, locked release, preview and direct commit. This checkpoint fixes spent-command availability; it does not replace that implementation or claim every readiness flow accepted. Whole-action current-intent readiness, complete Manual/public references, Chronicle fallback and full editor previews still need final integration/acceptance.

The live modular foundation, proposed rebalance and original unfinished combat integration remain separate. Original Targeting/Move/five editable Basics/Controlled and controls/editors/readers/previews remain pre-release requirements until their complete chains and native acceptance pass. Full Task15/16, full natural cycles, twelve-round pacing/balance, current Owner edits, hosted SQL/CAS, Atlas motion and human acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is performed. Deployment lock retained. High remains sufficient for routine integration. The provisional16–30active-hour estimate remains uncertain and is not a calendar launch promise.

## Deferred Minors

Thirteen inherited Minors remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing-pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal historical values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status direct-input immutability witness; legacy duplicate component keys. Any new reviewer Minor is listed in the review outcome.

## Initial rulings

1. Disable only the selected spent Controlled group, preserving ordinary Manual groups and information access. Reason: native phase owns availability. Cost if wrong: consumed Controlled artwork cannot arm a command; unrelated Manual groups must remain available.
2. Keep definition price/affordability independent of spent availability. Reason: unavailable does not mean free. Cost if wrong: consumers must read the new derived spent flag as well as affordability.
3. Preserve no primed decoration/no extra Release button. Reason: approved cockpit contract. Cost if wrong: readiness still depends on a complete legal current-intent forecast and native acceptance.
4. Correct Basic fixtures to supported flat-price Move composition. Reason: per-terrain-point walking is pure native movement; follow-up effects require a flat overall Skill price. Cost if wrong: this lifecycle test does not claim a new per-tile composition mechanic.

## Every parent set-aside ruling

{rulings}
'''
report=report.replace('Task15/16','Task 15/16').replace('plus16 review','plus 16 review').replace('All294','All 294').replace('displayed captured11 AP /2 MP /1 HP','displayed captured 11 AP / 2 MP / 1 HP').replace('fresh289-case','fresh 289-case').replace('provisional16–30active-hour','provisional 16–30 active-hour')
(root/'docs/verification/2026-10-16-controlled-command-availability.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Final spent Controlled command checkpoint\n'+report+'\n')
print('Guarded final Controlled availability report and ledger written.')

