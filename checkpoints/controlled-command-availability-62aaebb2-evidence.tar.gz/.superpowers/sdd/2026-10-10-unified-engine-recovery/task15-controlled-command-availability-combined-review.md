# Combined review at465020f2c89f38691b7ad596932e36f14701ee1e

Fresh /root/controlled_command_availability_review, gpt-6-astra High/forknone. Read all6changedfiles/native/projection/actualsharedconsumers. No tests/services/browser/native/network/mutations/subagents.

Strengths: uses native phase rather than new usage counter; unavailable descriptor protects initial/directional/target/range/executeIntent; sharedBasic/Skill/Essence/Resonance forwarding; availability separate fromprice/historicalfallback/cooldown/info/ownerprivacy;19actualnative lifecycle tests andhonestSSRlimits.

Critical:none. Important:two. NewMinor:none.

I1 — Spending selected Controlled group can strand a legal ordinary group for pointer/touch. battle-selected-skills.tsx151–174/127–140/119–125; battle-experience.tsx947–966/3559–3585; battle-skill-command.tsx143–149. selectedBehavior persists after release/cancel and leavingaction. Newspentgate disableswholeartwork; groupselectoronlymountswhilearmed; withoutManualmodifiers noModifierspanel. Keyboard/reload recovery does not preservepointerparity. AppliesBasicandSkill/Essence/Resonance. Preservegroupselectionwithoutautomaticreplacement/execute. Originaltest directly suppliedordinarygroup,missingtransition.

I2 — Basic all-spent ambiguouscaptures lose terminalstate. battle-experience.tsx1462–1477/3376/3415/3450; battle-preview-selection.ts101–108; battle-skill-command.tsx143–149. MultipleManualgroupssupported. NativeabilityadmissionconsumedmeansotherControlledgroupsspent. Withoutselectedgroupresolveddescriptorisnull/unavailablewithoutcontrolled; forwardingonlycontrolledlosesallspentaggregate. Artworkenabledaftercancel/reloaddespitenolegalchoice. NonBasiccostadapteralreadyaggregatesallspent;Basicneedsindependentcapturedecision. OriginalsingleBasicfixtureinjectedresolvedcontrolledobject,missingactualaggregation.

## Every reviewer-declined item

1. Changing once-per-group admission — Native ownership is once per battle/character/ability; consume that authority.
2. Making spent costs zero — Availability and payment remain separate.
3. Allowing stale ready to override spent — Component gates suppress readiness; actual readiness also checks descriptor availability.
4. Changing free-prime affordability — Structural admission and paid release are intentionally different.
5. Adding primed decoration or Release button — Approved interaction contract excludes both.
6. Disabling every group when one is spent — Ordinary Manual groups remain native-legal; I1 identifies access regression.
7. Automatically choosing another Manual group — Ambiguity requires deliberate selection.
8. Historical captures without Controlled metadata — Optional metadata does not infer spend; historical envelope/cost fallback remains.
9. Replacing missing canonical captures with current definitions — Missing/ambiguous canonical references fail closed.
10. Changing native/Manual attachment selection — References remain bound through intent metadata; primed metadata exclusively owns captured refs/empty set.
11. Reopening spent attachments for editing — Primed/spent resolution stays locked; spent intents blocked.
12. Keyboard, directional and target-factory bypass — No successful-command bypass; unavailable descriptors stop factories/range/executeIntent; rearm notice not separately graded.
13. Native per-terrain-point Move with Controlled follow-up damage — Unsupported: parser requires pure walking; flat overall price is correct fixture.
14. Changing attached Move prices or reached-origin mechanics — Neither modified.
15. Guided Practice Guard availability — No actual guided encounter exposure of edited Controlled practice Guard established; no hypothetical issue asserted.
16. Stale browser, alternate actor, direct RPC, expiry/revocation/CAS — No new authority; source-only review cannot establish Tasks8/16 acceptance.
17. Malformed nested/captured/pending/summon data and private accuracy — Parser/serialization/projection authority unchanged; full validation remains separate.
18. Duplicate payment, repeated events, no-input turns and interrupted movement — Native execution unchanged; broader matrix unestablished.
19. Concurrent publication/build/claim/recovery/settlement — No affected authority in these files; broader tasks open.
20. Mounted keyboard/touch/native browser behavior — Source reach/SSR is not physical acceptance.
21. AT, long names, narrow screens and200%zoom — Physical/accessibility acceptance unestablished.
22. Full roster cycles and natural/twelve-round balance — No acceptance inferred from bounded availability work.
23. Hosted Owner edits, SQL/CAS, Atlas and human acceptance — Outside available evidence; remain open.
24. Rewind witness origin — Inherited Minor retained; unrelated witness.
25. Supporting Shot version pin — Inherited Minor retained; capture hardening unchanged.
26. Ongoing pair dynamic identity pin — Inherited Minor retained; identity witness unchanged.
27. Repeated bounded AI discovery — Inherited Minor retained; AI unchanged.
28. Admission double-prefix provenance — Inherited Minor retained; wording unchanged.
29. Ranged negative direct-commit witness — Inherited Minor retained; witness remains preparation-only.
30. Independent defense-positive HP reconciliation — Inherited Minor retained; event witness unchanged.
31. Exact Arsenal history values — Inherited Minor retained; historical coverage unchanged.
32. Singular status-clock grammar — Inherited Minor retained; unrelated wording.
33. Burn ordinary tick-boundary wording — Inherited Minor retained; timing description unchanged.
34. Master inline reference-button sizing — Inherited Minor retained; separate geometry surface.
35. Cross-status direct-input immutability witness — Inherited Minor retained; separate cohort.
36. Legacy duplicate component keys — Inherited Minor retained; no mounted reconciliation claim.

Assessment: boundedcheckpoint withfixes;0C/2I/0newM. Source/nativeauthoritysoundforresolvedgroups;realplayeraccess/truthfulavailabilitygapsneedONEauthorizedrepair. No fullTask15/16/merge/releaseapproval.

