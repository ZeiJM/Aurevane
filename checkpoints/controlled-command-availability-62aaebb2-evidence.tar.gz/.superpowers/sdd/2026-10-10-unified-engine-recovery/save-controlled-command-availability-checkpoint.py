import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='controlled-command-availability';payload=w/(prefix+'-backup-payload.json')
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip();base='f8ff229b28245151cb22399c3c59f452f167df97'
report='docs/verification/2026-10-16-controlled-command-availability.md'
assert git('diff','--name-only',tested,head).splitlines()==[report]
paths=set(git('diff','--name-only',base,head).splitlines());assert paths=={report,'apps/web/src/components/battle/battle-captured-action-cost.ts','apps/web/src/components/battle/battle-preview-selection.ts','apps/web/src/components/battle/battle-experience.tsx','apps/web/src/components/battle/battle-selected-skills.tsx','apps/web/src/components/battle/battle-skill-command.tsx','apps/web/e2e/fixtures/controlled-command-availability.test.tsx'},paths
assert reviewed=='465020f2c89f38691b7ad596932e36f14701ee1e' and len(tested)==40
subprocess.run(['git','merge-base','--is-ancestor',reviewed,tested],check=True)
expected=int((w/(prefix+'-test-count.txt')).read_text());receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/(prefix+'-reader-analysis.json')).read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged'] and observed['rawSha256']==sha(w/(prefix+'-reader-observation.json'))
bundle=w/(prefix+'-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/(prefix+'-bundle-verify.log')).write_text(v.stdout)
evidence=w/(prefix+'-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','task15-controlled-command-availability-brief.md',prefix+'-combined-review-package.md','task15-controlled-command-availability-combined-review.md',prefix+'-review-outcome.md',prefix+'-review-rulings.md',prefix+'-implementation-notes.md',prefix+'-tested-source.txt',prefix+'-reviewed-source.txt',prefix+'-bundle-verify.log','verification.jsonl','run.py','save-'+prefix+'-checkpoint.py',prefix+'-readers-diagnostic.test.tsx','vitest-'+prefix+'-reader.config.ts',prefix+'-reader-observation.json',prefix+'-reader-analysis.json','analyze-'+prefix+'-readers.py',prefix+'-fullcheck-audit.json',prefix+'-turbo-logs.tar.gz','live-conditional-strength-reader-observation.json','ranged-ai-analysis.json','finalize-'+prefix+'-report.py','audit-'+prefix+'-fullcheck.py','task15-'+prefix+'-next-notes.md',prefix+'-test-count.txt',prefix+'-checkpoint-summary.txt']
for n in [prefix+'-initial-fullcheck-audit.json',prefix+'-initial-turbo-logs.tar.gz',prefix+'-repair-notes.md']:
 if (w/n).exists():names.append(n)
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T194800':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'509cc491712c4a22fd2909a1ce333903343bff61','previousArchiveTree':'5e8f5e085aa4363795c98cb14836184a28bf9957','fullCheckReceipt':gate,'tests':{'vitest':expected,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/(prefix+'-checkpoint-summary.txt')).read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
