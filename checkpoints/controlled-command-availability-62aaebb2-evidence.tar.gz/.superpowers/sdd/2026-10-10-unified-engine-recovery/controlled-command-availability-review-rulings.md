# Parent rulings

I1 accepted Important: a legal ordinary group must remain reachable from artwork with pointer/touch after consuming selected Controlled group. Repair provides an explicit choose-another-action route, clears group/draft/targets and arms only the group selector, never silently chooses/casts replacement. UI affordability/cooldown no longer prevents opening that chooser; legal execution keeps server/payment guards. Reason: preserving a legal group in data is insufficient if its only selection path disappears. Cost: artwork may remain enabled solely to choose another group, without readiness or a current action claim.

I2 accepted Important: Basic all-spent aggregation must consume actual owner captures independently of group resolution. Shared battleCapturedControlledAvailability serves both cost adapter and actualBasicforwarding. All-Controlled/spent groups disable artwork even with no selected group; mixedordinary groups retain choice. Reason: an ambiguous descriptor intentionally has no selectedcontrolledrecord, which is insufficient evidence ofavailability. Cost: Basicforwardingnowtakesderivedaggregateavailability;selectedgroupstillownsmechanics.

ONE Critical/Important repair wave. InitialnewrepairRED20024412448711validfailures/19passes. AdditionalBasicmixedchoicefalsification200426997652fivevalidfailures/30skippedbeforecorrectbranchrestored. GREEN repairedfocused1034/88files200454694110/types200454709745/lint200454688617.35newnativecasesoverall(19initial+16repair). No rereview;13inheritedMinorsremain;no newMinor.

1. **Changing once-per-group admission** — Ruling/reason: Native ownership is once per battle/character/ability; consume that authority. Cost if wrong: Native once-per-ability admission remains; no per-group reprime.

2. **Making spent costs zero** — Ruling/reason: Availability and payment remain separate. Cost if wrong: Price still shows the captured activation cost.

3. **Allowing stale ready to override spent** — Ruling/reason: Component gates suppress readiness; actual readiness also checks descriptor availability. Cost if wrong: Readiness is not accepted without a legal current intent.

4. **Changing free-prime affordability** — Ruling/reason: Structural admission and paid release are intentionally different. Cost if wrong: Free admission still differs from paid release.

5. **Adding primed decoration or Release button** — Ruling/reason: Approved interaction contract excludes both. Cost if wrong: No primed decoration/extra Release control is added.

6. **Disabling every group when one is spent** — Ruling/reason: Ordinary Manual groups remain native-legal; I1 identifies access regression. Cost if wrong: Ordinary-group access must be preserved by I1 repair.

7. **Automatically choosing another Manual group** — Ruling/reason: Ambiguity requires deliberate selection. Cost if wrong: The player must choose the group explicitly.

8. **Historical captures without Controlled metadata** — Ruling/reason: Optional metadata does not infer spend; historical envelope/cost fallback remains. Cost if wrong: Historical metadata remains weaker but is not invented.

9. **Replacing missing canonical captures with current definitions** — Ruling/reason: Missing/ambiguous canonical references fail closed. Cost if wrong: Missing canonical captures remain unavailable.

10. **Changing native/Manual attachment selection** — Ruling/reason: References remain bound through intent metadata; primed metadata exclusively owns captured refs/empty set. Cost if wrong: Exact attachment ownership/locked set remains required.

11. **Reopening spent attachments for editing** — Ruling/reason: Primed/spent resolution stays locked; spent intents blocked. Cost if wrong: Captured attachment editing remains forbidden.

12. **Keyboard command bypass** — Ruling/reason: Unavailable descriptors still guard executeIntent; no native authority change. Cost if wrong: Actual mounted keyboard acceptance remains open.

13. **Directional/target/range bypass** — Ruling/reason: Existing factories consume descriptor unavailability. Cost if wrong: Physical input and full targeting acceptance remain open.

14. **Rearm notice** — Ruling/reason: Not an independent Important; corrected chooser branch explains deliberate selection. Cost if wrong: Other rejected hotkey notices may remain generic.

15. **Per-terrain-point Move follow-up damage** — Ruling/reason: Unsupported by native parser; preserve pure walking. Cost if wrong: Controlled composed Move must use a flat overall Skill price.

16. **Attached Move price** — Ruling/reason: Unchanged included-cost contract. Cost if wrong: No new per-tile fee is authorized.

17. **Reached-origin mechanics** — Ruling/reason: Execution unchanged. Cost if wrong: Interrupted Move acceptance remains open.

18. **Guided Practice Guard** — Ruling/reason: No real exposure established; do not change hypothetical practice content. Cost if wrong: If edited Controlled practice Guard becomes reachable, it needs an explicit gate.

19. **Stale browser** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

20. **Alternate selected actor** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

21. **Direct RPC bypass** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

22. **Live expiry** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

23. **Revocation** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

24. **Authority CAS** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

25. **Malformed nested state** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

26. **Malformed captured data** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

27. **Malformed pending data** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

28. **Malformed summon data** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

29. **Private accuracy serialization** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

30. **Duplicate payment** — Ruling/reason: Native execution unchanged; representative reader tests are narrower. Cost if wrong: Broader execution acceptance remains required.

31. **Repeated events** — Ruling/reason: Native execution unchanged; representative reader tests are narrower. Cost if wrong: Broader execution acceptance remains required.

32. **No-input/extra-turn bounds** — Ruling/reason: Native execution unchanged; representative reader tests are narrower. Cost if wrong: Broader execution acceptance remains required.

33. **Interrupted movement** — Ruling/reason: Native execution unchanged; representative reader tests are narrower. Cost if wrong: Broader execution acceptance remains required.

34. **Concurrent publication** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

35. **Concurrent build** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

36. **Concurrent claim** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

37. **Concurrent recovery** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

38. **Concurrent settlement** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

39. **Mounted keyboard** — Ruling/reason: Source/SSR does not establish physical interaction. Cost if wrong: Actual interaction acceptance remains open.

40. **Mounted touch** — Ruling/reason: Source/SSR does not establish physical interaction. Cost if wrong: Actual interaction acceptance remains open.

41. **Native browser** — Ruling/reason: Source/SSR does not establish physical interaction. Cost if wrong: Actual interaction acceptance remains open.

42. **Assistive technology** — Ruling/reason: No physical/AT execution. Cost if wrong: Physical/accessibility acceptance remains open.

43. **Long-name layout** — Ruling/reason: No physical/AT execution. Cost if wrong: Physical/accessibility acceptance remains open.

44. **Narrow-screen geometry** — Ruling/reason: No physical/AT execution. Cost if wrong: Physical/accessibility acceptance remains open.

45. **200%zoom** — Ruling/reason: No physical/AT execution. Cost if wrong: Physical/accessibility acceptance remains open.

46. **Full roster natural cycles** — Ruling/reason: Bounded availability cases do not establish whole-roster acceptance. Cost if wrong: Gameplay/balance acceptance remains open.

47. **Natural pacing** — Ruling/reason: Bounded availability cases do not establish whole-roster acceptance. Cost if wrong: Gameplay/balance acceptance remains open.

48. **Twelve-round balance** — Ruling/reason: Bounded availability cases do not establish whole-roster acceptance. Cost if wrong: Gameplay/balance acceptance remains open.

49. **Current hosted Owner edits** — Ruling/reason: Outside this source-only cohort; no hosted changes. Cost if wrong: The named final acceptance gate remains open.

50. **Hosted SQL/CAS reconciliation** — Ruling/reason: Outside this source-only cohort; no hosted changes. Cost if wrong: The named final acceptance gate remains open.

51. **Atlas motion** — Ruling/reason: Outside this source-only cohort; no hosted changes. Cost if wrong: The named final acceptance gate remains open.

52. **Human acceptance** — Ruling/reason: Outside this source-only cohort; no hosted changes. Cost if wrong: The named final acceptance gate remains open.

53. **Rewind witness origin** — Ruling/reason: Inherited Minor retained; unrelated witness. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

54. **Supporting Shot version pin** — Ruling/reason: Inherited Minor retained; capture hardening unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

55. **Ongoing pair dynamic identity pin** — Ruling/reason: Inherited Minor retained; identity witness unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

56. **Repeated bounded AI discovery** — Ruling/reason: Inherited Minor retained; AI unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

57. **Admission double-prefix provenance** — Ruling/reason: Inherited Minor retained; wording unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

58. **Ranged negative direct-commit witness** — Ruling/reason: Inherited Minor retained; witness remains preparation-only. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

59. **Independent defense-positive HP reconciliation** — Ruling/reason: Inherited Minor retained; event witness unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

60. **Exact Arsenal history values** — Ruling/reason: Inherited Minor retained; historical coverage unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

61. **Singular status-clock grammar** — Ruling/reason: Inherited Minor retained; unrelated wording. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

62. **Burn ordinary tick-boundary wording** — Ruling/reason: Inherited Minor retained; timing description unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

63. **Master inline reference-button sizing** — Ruling/reason: Inherited Minor retained; separate geometry surface. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

64. **Cross-status direct-input immutability witness** — Ruling/reason: Inherited Minor retained; separate cohort. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

65. **Legacy duplicate component keys** — Ruling/reason: Inherited Minor retained; no mounted reconciliation claim. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

