import subprocess, pathlib, hashlib, json, tarfile, base64, sys
root=pathlib.Path.cwd()
workspace=root/'.superpowers/sdd/2026-10-16-manual-modifier-picker'
if len(sys.argv)>1:
 data=json.loads((workspace/'backup-payload.json').read_text())
 key,index=sys.argv[1],int(sys.argv[2])
 content=base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
 print(json.dumps({'chunk':content[index*12000:(index+1)*12000]}))
 sys.exit()
def git(*args): return subprocess.check_output(['git',*args],text=True).strip()
assert not git('status','--porcelain'), 'checkpoint requires clean source'
head=git('rev-parse','HEAD'); tree=git('rev-parse','HEAD^{tree}')
receipt=json.loads((workspace/'20261016T050914546728Z.json').read_text())
assert receipt['exitCode']==0
assert all(path.startswith('docs/') for path in git('diff','--name-only','80aff517','HEAD').splitlines())
bundle=workspace/('manual-picker-'+head[:8]+'.bundle')
subprocess.run(['git','bundle','create',str(bundle),'HEAD','^8b50b7a401db6fa5ed26bc43b5a85cda669fe5f2'],check=True)
verified=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True)
(workspace/'backup-bundle-verify.log').write_text(verified.stdout)
evidence=workspace/('manual-picker-'+head[:8]+'-evidence.tar.gz')
excluded={'backup-payload.json'}
with tarfile.open(evidence,'w:gz') as archive:
 for file in sorted(workspace.rglob('*')):
  if not file.is_file() or file.name in excluded or file.suffix=='.bundle' or file.name.endswith('.tar.gz') or 'browsers' in file.relative_to(workspace).parts: continue
  archive.add(file,arcname=str(file.relative_to(root)))
 parent=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
 for name in ['progress.md','task-15-brief.md','task-15-continuation-preflight.md']:
  file=parent/name
  if file.exists(): archive.add(file,arcname=str(file.relative_to(root)))
def info(path):
 data=path.read_bytes()
 return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'blobSha':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'chunks':(len(base64.b64encode(data))+11999)//12000}
meta={'sourceHead':head,'sourceTree':tree,'testedSource':git('rev-parse','80aff517'),'fullCheckReceipt':'20261016T050914546728Z.json','tests':{'vitest':7081,'node':7},'prerequisite':'8b50b7a401db6fa5ed26bc43b5a85cda669fe5f2','previousArchiveCommit':'f3a7d0bc9b27835360577d711851cc97e7df32e3','previousArchiveTree':'d0a4944dc12b49a19370e931b19e41b3cf57cd68','bundle':info(bundle),'evidence':info(evidence),'acceptance':'Native interaction remains OPEN; no hosted writes/activation/release.'}
(workspace/'backup-payload.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta))
