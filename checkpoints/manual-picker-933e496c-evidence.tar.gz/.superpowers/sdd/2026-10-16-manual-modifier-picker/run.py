import sys,subprocess,datetime,json
from pathlib import Path
root=Path(__file__).resolve().parent
args=sys.argv[1:]
if args and args[0]=='--': args=args[1:]
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
log=root/(stamp+'.log')
with log.open('w') as out: result=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT)
receipt={'command':args,'exitCode':result.returncode,'log':str(log),'stamp':stamp}
(root/(stamp+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
print('\n'.join(log.read_text().splitlines()[-55:]))
sys.exit(result.returncode)
