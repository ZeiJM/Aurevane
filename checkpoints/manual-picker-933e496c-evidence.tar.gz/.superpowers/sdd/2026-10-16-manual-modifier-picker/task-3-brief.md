### Task 3: Additive controls with preserved custom chords

**Files:** Modify `packages/validation/src/player/combat-controls.ts` and `.test.ts`, `apps/web/src/components/settings/combat-controls-settings.tsx` and `.test.tsx`; create `apps/web/src/server/player-profile/player-controls-service.test.ts` against the existing service's repository boundary. Do not add a database migration.

**Interfaces:** Add `'modifiers'` to `CombatKeybindAction` and `{ code: 'KeyM', shift: false }` to defaults. `parseCombatKeybindMap(input: unknown): CombatKeybindMap | null` remains the normalization/validation entry. Settings copy is **Modifiers**, describing deliberate preparation before use/priming. Existing GET/Save shapes remain unchanged.

- [ ] **Step 1: Write failing tests.** `old_custom_m_preserved` keeps an old M command and allocates Shift+M; `old_m_shift_m_and_fkeys_preserved` fills the 22 old action entries with M, Shift+M and F1–F20 and expects F21. `historical_slot_items_then_modifier_normalization` asserts all old normalization results stay exact before allocating the new key. `explicit_modifier_binding_retained` keeps a supplied Shift+F24 binding. `duplicate_unknown_and_malformed_rejected` preserves parser/Save rejection. `read_does_not_write_and_save_roundtrips` proves load performs no persistence and explicit Save retains the normalized map; mock the existing admin-client boundary for Save, without invoking hosted RPCs. `settings_modifier_capture` verifies the row can record/rebind/reset/save using existing capture rules.

  ```ts
  expect(normalizedWithCustomM?.modifiers).toEqual({ code: 'KeyM', shift: true })
  expect(normalizedCrowdedOldMap?.modifiers).toEqual({ code: 'F21', shift: false })
  expect(explicitMap?.modifiers).toEqual({ code: 'F24', shift: true })
  expect(saveRpc).not.toHaveBeenCalled() // after read only
  ```

- [ ] **Step 2: Run RED.** `pnpm --filter @aurevane/validation exec vitest run src/player/combat-controls.test.ts` and `pnpm --filter @aurevane/web exec vitest run src/components/settings/combat-controls-settings.test.tsx src/server/player-profile/player-controls-service.test.ts`. Expected: missing action/allocation/copy assertions fail.
- [ ] **Step 3: Implement normalization after historical slots/Items.** Reserve every valid existing chord; for an absent modifier binding try M, Shift+M, F1–F24, Shift+F1–Shift+F24 in that order. Preserve strict parsing and existing malformed-settings read-failure behavior. Add settings copy through the existing typed map; no read rewrite or hardcoded independent listener.
- [ ] **Step 4: Run GREEN.** Repeat parser/settings/Save tests and relevant types. Expected: old maps retain their prior command meanings, custom new bindings survive round trips, no SQL change.
- [ ] **Step 5: Commit:** `feat: preserve custom controls when adding modifier shortcut`.

