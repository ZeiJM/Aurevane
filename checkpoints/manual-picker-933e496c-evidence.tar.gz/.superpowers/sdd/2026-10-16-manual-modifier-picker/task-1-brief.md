### Task 1: Shared compatibility facts and safe owner metadata

**Files:** Create the compatibility module and its `.test.ts`; modify `packages/game-core/package.json`, `combat-manual-modifier-references.ts`, `combat-modifier-composition.ts`, `combat-controlled.ts`, `pv1f-action-economy.ts`, `battle-live-viewer-projection.ts`, `battle-preview-selection.ts`, `battle-basic-actions.ts` at the paths above. Extend existing `combat-controlled-modifiers.test.ts`, `battle-live-viewer-projection.test.ts` and `battle-ability-controls.test.ts`.

**Interfaces:**

- Export `CombatModifierCompatibilityFacts = { readonly payloadsSupported: boolean; readonly requiresExplicitUnit: boolean }`.
- Export `CombatModifierRootFacts` with readonly `classification: AbilityBehavior['classification']`, `targetKind: CombatTargetSpec['kind'] | undefined`, `persistentGround: boolean`, `hasPrimaryRecipient: boolean`.
- Export `combatModifierCompatibilityFacts(behavior: AbilityBehavior): CombatModifierCompatibilityFacts`, `combatCanonicalModifierRootFacts(behavior: AbilityBehavior): CombatModifierRootFacts`, `combatNativeModifierRootFacts(target: CombatTargetSpec, classification: AbilityClassification): CombatModifierRootFacts`, and `combatModifierFactsCompatible(modifier: CombatModifierCompatibilityFacts, root: CombatModifierRootFacts): boolean` from the new module. Retain `combatModifierRootCompatible` as the existing thin behavior-to-facts adapter, with one comparison implementation.
- Owner modifier rows add exact captured `abilityId`, `contentVersion`, shared sanitized `report: BattleAbilityBehaviorReport`, and `compatibility: CombatModifierCompatibilityFacts`. Manual-action/Basic presentation rows add optional `modifierRoot: CombatModifierRootFacts`; optionality supports historical public snapshots.

- [ ] **Step 1: Write focused failing tests.** `canonical_area_and_ground_primary_rejected` asserts Line/Circle/All and Ground-only Single reject primary-unit modifiers, while actor/affected-unit supported payloads remain allowed. `canonical_default_shape_and_native_selected_center_preserved` distinguishes canonical default geometry from historical unit-centered native area roots. `unsupported_payload_stays_rejected` keeps Move/Summon/persistent Ground unsupported. `owner_choices_pin_version_and_sanitize_report` asserts exact captured version/report/facts for mixed and modifier-only sources; ally/opponent/spectator views omit choices and recursively omit private definitions/accuracy/runtime. `selected_resonance_group_classification` asserts an attack and recovery group retain their own meanings despite the same artwork/menu location.

  Key assertions on the authored fixtures:

  ```ts
  expect(combatModifierFactsCompatible(primaryUnitFacts, canonicalLineFacts)).toBe(false)
  expect(combatModifierFactsCompatible(actorFacts, canonicalLineFacts)).toBe(true)
  expect(combatModifierFactsCompatible(primaryUnitFacts, legacyUnitCenteredAreaFacts)).toBe(true)
  expect(spectator.snapshot.manualModifierAvailability).toEqual([])
  ```

- [ ] **Step 2: Run RED.** `pnpm --filter @aurevane/game-core exec vitest run src/combat/combat-modifier-compatibility.test.ts src/combat/combat-controlled-modifiers.test.ts` and `pnpm --filter @aurevane/web exec vitest run src/server/battle/battle-live-viewer-projection.test.ts src/components/battle/battle-ability-controls.test.ts`. Expected: the new facts/projection assertions fail for missing behavior, not invalid fixtures.
- [ ] **Step 3: Implement the interfaces.** Extract current supported-payload/primary-unit checks, applying canonical default geometry through the existing canonical target adapter. Reuse the facts in paid composition and Controlled admission/restore. Native classification remains the trusted adapter's existing attack/recovery/utility mapping; native selected-center geometry stays intact. Owner projection builds reports from captured records and existing effect/timing context, never from opaque ID parsing or another catalogue version. Export the new pure module through the package's existing subpath convention.
- [ ] **Step 4: Run GREEN.** Repeat the focused commands and affected package typechecks. Expected: all new assertions pass and existing admission/restore legality remains unchanged.
- [ ] **Step 5: Commit** only this metadata/compatibility slice: `feat: expose safe modifier compatibility metadata`. Keep the whole milestone unaccepted until Task 6.

