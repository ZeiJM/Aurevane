# Combined review,9cf4d53f

Read-only fresh reviewer: gpt-6-astra/High; no subagents or suite rerun. Base8b50b7a4; one review, one fix pass. NoCritical; fiveImportant; noadditionalMinor; initial verdictNo.

1. battle-experience.tsx:1684/708/718/1963 — attack-first mixed recovery group falls back through catalogue recovery menu to BasicRecovery. Resolve explicit owned selected group independently of catalogue category.
2. battle-experience.tsx:1941–1948/1971–1990 — selecting primed/spent clears draft and mode, losing locked root. Retain empty contextual draft, captured availability alone owns refs.
3. battle-modifier-picker.module.css:10–11/68–69 —620px child inside320px measured parent overflows paper/viewport. Size measured outer popover and fill its content.
4. battle-modifier-picker.module.css:16–19/31–38 — dark inherited text/dark navy rows, pale headings/paper and disabled opacity conflict. Use consistent paper palette.
5. battle-modifier-picker.tsx:207–216 — visible Automatic clocks absent from Manual choice list are labelled with root name. Resolve exact public metadata, root-only matching fallback, otherwise generic.

Strengths: shared compatibility used by core/UI; safe prepared quote/shared clocks; custom chord preservation; stale-reference retention/captured-empty authority; honest evidence limits.

Declined to judge: inheritedAtlas timing; Groundsubset wording; unavailableManualResonance Passivecaption; parentroster/alltag/AI-Level100/event-reader work; hosted/authenticated release readiness. Every item has an executor ruling in progress.md. Browser unavailable, zero native assertions/screenshots. Scenarios absent/unverified remain explicit in report. Final picker command requiresAV_CANONICAL_MODIFIERS=1.
