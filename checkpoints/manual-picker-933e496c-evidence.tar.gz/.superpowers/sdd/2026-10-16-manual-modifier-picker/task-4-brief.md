### Task 4: One transient draft and identical intent references

**Files:** Create `apps/web/src/components/battle/battle-modifier-draft.ts` and `.test.ts`; modify `battle-preview-selection.ts`, `battle-range-previews.ts`, `use-battle-range-previews.ts` and their existing tests. Controller callbacks integrate in Task 5.

**Interfaces:**

- `BattleModifierContext`: readonly `battleSessionId: string`, `battleVersion: number`, `actorId: string`, `actionId: string`, optional `behaviorId: string`, `rootContentVersion: number | null` and `rootFingerprint: string` (the selected immutable target/classification/cost contract).
- `BattleModifierPinnedSelection`: readonly `sourceInstanceId`, `abilityId`, `behaviorId` strings, `contentVersion: number`, `fingerprint: string`. Fingerprint only immutable captured report/cost/clock-definition/compatibility metadata, excluding current eligibility/reasons/ticks.
- `BattleModifierDraft = { readonly context: BattleModifierContext; readonly selected: readonly BattleModifierPinnedSelection[] }`.
- Export `prepareBattleModifierDraft(context: BattleModifierContext): BattleModifierDraft`; `toggleBattleModifierDraft(draft: BattleModifierDraft, choice: BattleModifierPinnedSelection): BattleModifierDraft`; and `resolveBattleModifierDraft(draft: BattleModifierDraft | null, context: BattleModifierContext, choices: readonly BattleModifierPinnedSelection[], controlled: BattleControlledActionAvailability | undefined): { manualModifiers: readonly ManualCombatModifierSelection[]; stale: boolean; locked: boolean }`. Toggle only manipulates exact pins/order; admission/read-only rules stay in the caller. Resolve compares immutable identities/fingerprints synchronously, and primed resolution ignores the draft entirely.
- `BattlePreviewSkill.manualModifiers?: readonly ManualCombatModifierSelection[]`. Extend `selectBattleControlledPrimeIntent(captures, actionId, behaviorId?, manualModifiers?)` with the same exact references; cancel carries none. Add optional `classification` and `modifierRoot` on the descriptor, sourced from the selected group/recognized native facts.

- [ ] **Step 1: Write failing tests.** `same_root_arm_preserves_set` keeps refs across target/path clearing; `changed_root_group_actor_or_version_clears` resolves old context as unusable before effects run. `same_version_metadata_mismatch_blocks` marks stale and disallows submission instead of returning a usable empty set. `same_context_blocked_selection_retained` distinguishes immutable pins from changing eligibility. `primed_absent_means_empty` and `reconnected_prime_ignores_local` assert captured empty/nonempty authority. `all_intent_factories_keep_exact_refs` table-tests initial/self/unit/plural/tile/Line/Circle/All/Move factories, preserving existing geometry. `range_memo_changes_on_set` asserts request identity changes with attachments and old results become unavailable. `prime_gets_set_cancel_gets_none` covers the free command boundary.

  ```ts
  expect(resolvedChangedMetadata.stale).toBe(true)
  expect(resolvedPrimedAbsent).toEqual({ manualModifiers: [], stale: false, locked: true })
  expect(previewIntent.manualModifiers).toEqual(commitIntent.manualModifiers)
  expect(primeIntent.manualModifiers).toEqual(commitIntent.manualModifiers)
  ```

- [ ] **Step 2: Run RED.** `pnpm --filter @aurevane/web exec vitest run src/components/battle/battle-modifier-draft.test.ts src/components/battle/battle-preview-selection.test.ts src/components/battle/battle-range-previews.test.ts src/components/battle/battle-preview-request.test.ts`. Exercise hook request-key changes through the existing component harness or an adjacent hook test, rather than source-string assertions. Expected: refs/lifecycle assertions fail for currently missing binding.
- [ ] **Step 3: Implement pure draft resolution and binding.** Normalize code-unit order without mutating inputs. Invalid pins make the command unavailable/stale; absence on a prime remains the authoritative empty set. Bind refs through the existing `movedBattleSkillIntent` path and direct range Line/Circle/All factories; include them in hook destructuring/dependencies/request descriptor. Never copy refs into a cancel or allow a stale draft to become a plain cast.
- [ ] **Step 4: Run GREEN.** Repeat focused tests and web types. Expected: all factory payloads match and old response keys cannot become current after a set change.
- [ ] **Step 5: Commit:** `feat: bind transient modifier drafts to battle intents`.

