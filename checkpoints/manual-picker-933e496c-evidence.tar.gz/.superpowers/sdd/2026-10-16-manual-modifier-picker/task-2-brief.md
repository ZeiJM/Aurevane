### Task 2: Exact prepared-command resource and visible-clock quotes

**Files:** Modify `pv1f-action-economy.ts` and `apps/web/src/server/battle/battle-preview-service.ts`; create `apps/web/src/server/battle/battle-command-quote.ts` and `.test.ts`; extend `battle-preview-service.test.ts`, `packages/game-core/src/combat/combat-ability-command.test.ts`, `packages/game-core/src/combat/pv1f-action-economy.test.ts` and `battle-live-viewer-projection.test.ts` for the public boundary.

**Interfaces:**

- Add optional private `quote: Pick<PreparedCombatAbilityCommand, 'costs' | 'participants'>` to `evaluatePv1fAction` and `evaluatePv1fMatureSkill` return types. Populate it from the already returned preparation result on every composed canonical/native/Mature branch; carry the same data through the service's direct canonical/Essence branch.
- Export public `BattleCommandQuote` from the new server module: readonly `commandCosts: readonly { resource: 'ap' | 'mp' | 'hp'; amount: number }[]` and `commandCooldowns: readonly { actionId: string; contentVersion: number; behaviorId?: string; role: 'root' | 'manual-modifier' | 'automatic-modifier'; ownerTurns: number; ticksRemaining: number }[]`.
- Export `projectBattleCommandQuote(state: StatDrivenCombatEncounterState, actorId: string, input: { quote: Pick<PreparedCombatAbilityCommand, 'costs' | 'participants'> } | { native: { action: CombatActionDefinition; apCost: number } }): BattleCommandQuote`. Add these fields optionally to `BattleActionPreview` for old-response compatibility. Private participants never become public DTO fields.

- [ ] **Step 1: Write failing outcome tests.** `quote_equals_atomic_payment` builds root AP2/MP3/HP1 plus explicit AP1/MP2/HP2 and admitted Automatic AP1/MP1/HP1: expect `[{resource:'ap',amount:4},{resource:'mp',amount:6},{resource:'hp',amount:4}]`, and compare commit deltas. `shared_clock_uses_maximum` gives visible durations2/4 on one clock and expects effective4 without duplicate payment/clock starts. `hidden_automatic_clock_privacy` adds a hidden contributor with duration5 and expects exact totals/effective5 on the visible shared row, with no hidden identity/key/source/report/suppression inventory. `all_adapter_branches_preserve_quote_once` covers canonical Skill/Basic, native, Mature and Essence; spy only at the preparation seam to assert no second preparation. `native_uncomposed_uses_trusted_cost` expects actual AP/MP plus HP0, never prepaid action zeros. `preview_has_no_settlement` compares state/RNG/clocks/usage before and after. Retain real HP-leaves-one, miss/all-gated payment and paid-interruption outcome cases.

  ```ts
  expect(quote.commandCosts).toEqual([
    { resource: 'ap', amount: 4 },
    { resource: 'mp', amount: 6 },
    { resource: 'hp', amount: 4 },
  ])
  expect(quote.commandCooldowns).toEqual([
    expect.objectContaining({ ownerTurns: 4, ticksRemaining: 0 }),
  ])
  expect(stateAfterPreview).toEqual(stateBeforePreview)
  ```

- [ ] **Step 2: Run RED.** `pnpm --filter @aurevane/web exec vitest run src/server/battle/battle-command-quote.test.ts src/server/battle/battle-preview-service.test.ts` and `pnpm --filter @aurevane/game-core exec vitest run src/combat/combat-ability-command.test.ts src/combat/pv1f-action-economy.test.ts`. Expected: missing quote fields/incorrect totals fail while fixture legality is valid.
- [ ] **Step 3: Implement the quote handoff and projection.** Copy exact prepared totals into AP/MP/HP entries including zeros; enforce safe integer output. Group clocks privately before emission, using the real maximum duration and authoritative remaining ticks. Allowlist only current owner-visible public equipped participants under existing visibility rules; do not expose raw source or clock identifiers. The historical uncomposed branch uses its actual trusted AP adapter, authored MP and HP0. Do not re-materialize/prepare or change settlement.
- [ ] **Step 4: Run GREEN.** Repeat focused core/service tests and affected typechecks. Expected: exact quote/commit comparison, privacy, no-settlement and legacy response assertions pass.
- [ ] **Step 5: Commit:** `feat: project exact composed battle command quotes`.

