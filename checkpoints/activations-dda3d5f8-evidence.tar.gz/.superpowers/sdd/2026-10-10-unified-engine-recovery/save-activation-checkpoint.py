import subprocess, pathlib, hashlib, json, tarfile, base64, sys

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'activation-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = (workspace / 'activations-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
assert '4083 passed (4083)' in log and '3429 passed (3429)' in log
prerequisite = 'ea04a581392e57b867c7f6fd2350072f030c4e7c'
bundle = workspace / ('activations-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + prerequisite], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'activations-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('activations-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T0*.log')):
        if file.name >= '20261016T072900':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-activation-review.md', 'task15-activation-review.diff', 'task15-ai-cycle-preflight.md', 'task15-activation-preflight.md', 'activations-tested-source.txt', 'activations-bundle-verify.log', 'save-activation-checkpoint.py']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

manifest = root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'tests': {'vitest': 7758, 'node': 7}, 'prerequisite': prerequisite, 'previousArchiveCommit': 'f0d50e9304dbe048116d5814c396930606bad399', 'previousArchiveTree': '7c1ebe5b64824119bb5264504651d5582bae491a', 'manifestSha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': 'Bounded selected4activation/mode executable inventory,5tests; no production/manifest change. Earlier19effect/24status/8Requirement checkpoints retained. Task15/16 OPEN: every294record/equippedcycles/realAIattachmentplanning-Level100balance/nativebrowser/readers/Owneredits-hostedCAS/Atlas. No hosted write, activation, merge or deployment. See committed verification report for exact review findings and full gate counts.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
