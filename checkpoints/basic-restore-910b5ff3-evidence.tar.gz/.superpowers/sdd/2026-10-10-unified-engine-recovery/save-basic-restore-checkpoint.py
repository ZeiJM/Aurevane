from pathlib import Path
import subprocess,json,hashlib,tarfile,datetime
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='basic-restore'
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip();base='82d9276f915a1adb8ee4d2f1de6f1efe2c60906f'
report='docs/verification/2026-10-17-basic-restore-to-draft.md'
assert git('diff','--name-only',tested,head).splitlines()==[report] and tested==reviewed
audit=json.loads((w/(prefix+'-fullcheck-audit.json')).read_text());gate=audit['receipt']
assert audit['source']==tested and gate['exit_code']==0
assert len(audit['counts'])==7 and sum(int(n) for _,n in audit['counts'])==9129
assert audit['rootBuildTailComplete'] or audit.get('multiArtifactEvidenceComplete')
assert datetime.datetime.fromisoformat(gate['started_utc'])>=datetime.datetime.fromisoformat(git('show','-s','--format=%cI',tested))
focused=json.loads((w/(prefix+'-focused-report.json')).read_text());assert focused['success'] and focused['numPassedTests']==168 and focused['numFailedTests']==0
preserve=json.loads((w/(prefix+'-preservation.json')).read_text());assert preserve['source']==tested
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')==preserve['manifestSha256']
for name,digest in preserve['sixProtectedHashes'].items():assert sha(root/name)==digest
assert git('rev-parse','HEAD:apps/web/vercel.json')==preserve['deploymentLockBlob']
stem=prefix+'-'+head[:8];bundle=w/(stem+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(w/(prefix+'-bundle-verify.log')).write_text(v.stdout)
evidence=w/(stem+'-evidence.tar.gz')
names=[p for p in w.glob('*basic-restore*') if p.is_file() and p.suffix not in ['.gz','.bundle'] and p.name!=prefix+'-backup-payload.json']
names += [w/'progress.md',w/'verification.jsonl',w/'run.py',w/'ranged-ai-analysis.json']
with tarfile.open(evidence,'w:gz') as a:
 for p in names:a.add(p,arcname=str(p.relative_to(root)))
 for p in sorted((w/'evidence').glob('20261018T*.log')):
  if p.name >= '20261018T013100':a.add(p,arcname=str(p.relative_to(root)))
 a.add(w/(prefix+'-turbo-logs.tar.gz'),arcname=str((w/(prefix+'-turbo-logs.tar.gz')).relative_to(root)))
 if (w/(prefix+'-failed-build-turbo-logs.tar.gz')).exists():a.add(w/(prefix+'-failed-build-turbo-logs.tar.gz'),arcname=str((w/(prefix+'-failed-build-turbo-logs.tar.gz')).relative_to(root)))
 if (w/(prefix+'-second-failed-build-turbo-logs.tar.gz')).exists():a.add(w/(prefix+'-second-failed-build-turbo-logs.tar.gz'),arcname=str((w/(prefix+'-second-failed-build-turbo-logs.tar.gz')).relative_to(root)))
def item(p,remote):
 b=p.read_bytes();return {'local':str(p),'path':remote,'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
d={'source':head,'tree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedSource':reviewed,'prerequisite':base,'parentArchive':'cca706f0fdde751145fd6d3fd4baa202b15c2d5d','parentTree':'f8a0342d7e3947165395f5c8a440608cee180558','mainObservedAtCheckpoint':git('rev-parse','origin/main'),'mainChangedByThisWork':False,'mainReconciliation':json.loads((w/(prefix+'-main-reconciliation.json')).read_text()),'fullCheckReceipt':gate,'tests':{'new':39,'focused':168,'vitest':9129,'node':7},'rootBuildTailComplete':audit['rootBuildTailComplete'],'multiArtifactEvidenceComplete':audit.get('multiArtifactEvidenceComplete',False),'preservation':preserve,'acceptance':(w/(prefix+'-checkpoint-summary.txt')).read_text().strip(),'bundle':item(bundle,'checkpoints/'+stem+'.bundle'),'evidence':item(evidence,'checkpoints/'+stem+'-evidence.tar.gz')}
meta=w/(stem+'.json');meta.write_text(json.dumps(d,indent=2)+'\n');latest=w/(prefix+'-LATEST.txt');latest.write_text('Aurevane catalogue timing checkpoint\nSource '+head+'\nTested '+tested+'\nMetadata checkpoints/'+stem+'.json\n'+d['acceptance']+'\n')
d['metadata']=item(meta,'checkpoints/'+stem+'.json');d['latest']=item(latest,'LATEST.txt');(w/(prefix+'-backup-payload.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k not in ['preservation','acceptance','mainReconciliation']}))
