from pathlib import Path
import subprocess,json,hashlib,tempfile
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';meta=json.loads((w/'basic-restore-backup-payload.json').read_text());archive=(w/'basic-restore-archive-sha.txt').read_text().strip()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
assert git('rev-parse','origin/agent/overhaul-source-backup-20261016')==archive
assert git('show','-s','--format=%P',archive)==meta['parentArchive']
remote=w/'basic-restore-remote-bytes';remote.mkdir(exist_ok=True);proof=[]
for key in ['bundle','evidence','metadata','latest']:
 item=meta[key];data=subprocess.check_output(['git','show',archive+':'+item['path']]);p=remote/Path(item['path']).name;p.write_bytes(data)
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
 row=git('ls-tree',archive,'--',item['path']).split();assert row[:3]==['100644','blob',item['blobSha']]
 proof.append({'path':item['path'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'blobSha':row[2],'mode':row[0],'type':row[1]})
restored=Path(tempfile.mkdtemp(prefix='basic-restore-restored-',dir=w));subprocess.run(['git','init','--bare',str(restored)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
subprocess.run(['git','-C',str(restored),'fetch','--depth=1',str(root),meta['prerequisite']],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
assert subprocess.run(['git','-C',str(restored),'cat-file','-e',meta['source']+'^{commit}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE).returncode!=0
bundle=remote/Path(meta['bundle']['path']).name
for operation in ['verify','unbundle']:
 result=subprocess.run(['git','-C',str(restored),'bundle',operation,str(bundle)],check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(w/('basic-restore-remote-bundle-'+operation+'.log')).write_text(result.stdout)
assert subprocess.check_output(['git','-C',str(restored),'rev-parse',meta['source']+'^{tree}'],text=True).strip()==meta['tree']
refs=git('ls-remote','origin','refs/heads/main','refs/heads/agent/overhaul-source-backup-20261016');assert archive+'\trefs/heads/agent/overhaul-source-backup-20261016' in refs and meta['mainObservedAtCheckpoint']+'\trefs/heads/main' in refs
result={'source':meta['source'],'sourceTree':meta['tree'],'testedSource':meta['testedSource'],'archive':archive,'archiveTree':git('rev-parse',archive+'^{tree}'),'archiveParent':meta['parentArchive'],'allFourRemoteBytesAndModesVerified':True,'entries':proof,'incrementalRestore':{'prerequisite':meta['prerequisite'],'destination':str(restored),'sourceTipAbsentBeforeUnbundle':True,'restoredSourceTipAndTreeVerified':True,'coldOlderArchiveChainRestoration':False},'earlierColdChainProof':'catalogue-timing-remote-proof.json verified82tip/tree restoration from prerequisite93; earlier cold47bundle proof retained separately','freshLsRemoteMatches':True,'mainObservedAtCheckpoint':meta['mainObservedAtCheckpoint']}
(w/'basic-restore-remote-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
