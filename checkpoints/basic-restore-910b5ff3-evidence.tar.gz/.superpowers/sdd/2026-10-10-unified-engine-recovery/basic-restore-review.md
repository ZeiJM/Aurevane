# Basic Restore to Draft — combined checkpoint review

Reviewed base `82d9276f915a1adb8ee4d2f1de6f1efe2c60906f` through final head `6fee6f3698de97a33566d0df7474bda812126aee`. The originally assigned head `5d8b483d9bed42e603c10a47dc962024f47b0341` differs only by indentation of one test assertion. This is the same single review, not a second review.

Read the review package, bounded brief, relevant progress/rulings, the complete seven-file feature change (926 additions, four deletions), and the requesting-code-review reviewer template. Inspected the actual handler/client, editor and shared panel, page hydration, preview selection and Basic preview execution, current/pinned resolver and validator, in-memory repository, production RPC store, relevant draft authorization/CAS SQL and typed-kind amendment, normal publication/version floor, and battle admission/capture consumers. Source, index, HEAD and branch were not changed. No subagents, hosted operations, broad test reruns or incidental repairs were performed.

## Strengths

- `apps/web/src/server/master/combat-content-authoring-handler.ts:204` and `combat-content-authoring-service.ts:757`: restore is an explicit operation with operator authorization before historical reads, canonical Basic identity and positive safe-integer checks. The handler passes identity/version/CAS only; a forged client definition cannot become the restored payload.
- `apps/web/src/server/master/combat-content-authoring-service.ts:774–816`: stored current and selected history pass the exact Basic identity/version validator, ambiguous selected versions fail closed, and a builtin is used only for its exact version. The complete parsed record, including disabled state, is cloned into the existing draft store. The operation does not repoint publication, alter history, select a support slot, or touch battle captures.
- `apps/web/src/components/master/combat-content/basic-content-editor.tsx:131–184`: response identity, target version and both counters are checked; successful restore advances draft CAS even when newer local edits must be retained. Review results are invalidated after success, while a failed operation retains the draft/history/review. Record-bound confirmation, busy guards and mutual publish/restore exclusion are implemented without a second editing state machine.
- `apps/web/src/components/master/combat-content/basic-content-editor.tsx:525` and `combat-content-review-panel.tsx:445`: the optional callback keeps other categories' existing behavior. Basic history displays current plus two recent records while the complete internal history still feeds the next-version floor. Controls are semantic buttons with version-specific accessible names.
- The two new test files exercise real handler/service/resolver/editor callbacks, ordinary preview/publication, all five Basic identities, both builtin and published history, draft conflicts, publication racing restore, forged payloads, malformed/ambiguous history, disabled records, cancellation and local-edit preservation. The Guard execution witness checks an actual 29 versus 17 AP outcome and old-capture immutability, beyond merely asserting copied JSON.

## Issues

### Critical — must fix

None found in the reviewed change and integration paths.

### Important — should fix

None found in the reviewed change and integration paths.

### Minor — nice to have

No new Minor finding. The 20 inherited deferred Minors remain deferred; this verdict neither fixes nor closes them.

## Evidence and recommendations

Independently read the focused JSON report: success true, 168 passed, zero failed; its six result files contain 31 new service cases and eight new interaction cases. The tests use the actual client/handler/service/local repository but controlled React hook scheduling, navigation, timing policy and transport. I inspected the typecheck log; the parent owns the reported exit-code receipt and exact-source full-root gate. The final-head delta is only assertion indentation, with no product behavior change.

The draft-only concurrency ruling is sound for this checkpoint: a publication between the base read and draft save can produce a stale-base draft, but cannot rewrite the winning publication. Existing normal publication authority must continue to reject the old observed base. This is not an atomic catalogue snapshot, and the test accurately demonstrates that narrower guarantee. No additional code repair is recommended from this review. Finish the parent-owned exact-source quality and durable backup checks, then carry the acceptance limits below forward explicitly.

## Declined to judge

Each line identifies a considered boundary, its reason, and its cost. These are acceptance limits for the executor to disposition, not findings silently waived because the brief is narrow.

1. **Hosted authorization, deployed grants/RLS and live revocation timing:** I inspected actual authorization calls, RPC actor binding and SQL operator checks, but the supplied execution uses a local repository and fixture actor. No hosted operation was authorized for this review. **Cost:** no proof of the deployed RPC/security state or real concurrent revocation behavior; hosted/direct-RPC acceptance remains open.
2. **Atomic publication snapshot during restore:** the approved design intentionally reuses the existing draft-CAS RPC after an observed-base read. I judged the implemented stale-draft/ordinary-publish protection, not a new transaction guarantee. **Cost:** a racing publication may require refresh/review before subsequent publication; restore itself cannot promise a single catalogue-and-draft snapshot.
3. **Physical desktop/mobile browser, native keyboard, focus behavior, assistive technology, long-name wrapping and 200% zoom:** semantic controls and their code were inspected, but callback fixtures do not lay out or operate a browser. The original native workflow was not executed here. **Cost:** actual accessibility, geometry and complete native Restore acceptance remain unverified and must not be reported as complete.
4. **Fresh-account routing, real fetch/network failure recovery and a hosted end-to-end editor session:** transport is connected locally to the real handler, but authentication, Next navigation and hook scheduling are controlled. **Cost:** this proves local application wiring, not a deployed session or real network/lifecycle behavior.
5. **All-five fresh battle admission and full combat outcome runs:** all five restore/preview/publication/pinned-capture paths are exercised; Guard alone has the new actual execution outcome witness. I inspected real admission/capture integration but did not run five full admitted battles. **Cost:** no new comprehensive battle-outcome acceptance claim for every restored Basic or every build route.
6. **Saved support-slot/build changes and cross-character authority:** restore never writes these and actual admission captures the separately selected support action. I did not rerun the broader selected-character/build mutation authority suites. **Cost:** existing Task8/Task16 authority evidence is still required; this checkpoint does not renew it.
7. **Malformed pending/captured/summon trees and privacy over the whole engine:** selected Basic history is validated through the canonical parser, and capture boundaries were inspected; a fresh exhaustive engine serialization/privacy audit is outside this seven-file change. **Cost:** prior broader fail-closed/privacy coverage remains necessary, with no newly claimed acceptance for unrelated nested structures.
8. **No-input, free priming, repeated events, interrupted Move, recovery/claim/settlement races and other full combat cycles:** restored capture identity and one Guard outcome were judged; the runtime is unchanged and these broader engine paths were not re-executed. **Cost:** no balance, finite-event, payment, movement or settlement completion claim from this review.
9. **Restore-to-draft redesign for non-Basic categories and generic Master create/archive/dependency workflows:** the approved ruling deliberately leaves the legacy Rollback API/panel behavior intact. **Cost:** other categories retain their existing workflow; this does not complete a broader Master content-editor redesign.
10. **An all-history picker or restoring a hidden older version from the visible Basic panel:** the approved current-plus-two display contract is implemented and complete server history is preserved. **Cost:** older versions are not selectable through this recent-history surface, although the explicit server operation still resolves exact retained targets.
11. **New publication semantics for disabled Basics:** the new operation preserves disabled records as editable drafts; existing preview/publication legality is intentionally reused. **Cost:** this checkpoint does not establish a new disable/archive or disabled-definition publication workflow.
12. **A full audit of generic draft RPC behavior and arbitrary malformed persistence outside the selected Basic target:** I inspected the existing store/SQL to assess authorization and draft CAS reuse, while the feature validates current/selected history and leaves the generic persistence implementation unchanged. **Cost:** no general database-integrity certification or expanded guarantees for unrelated kinds/corrupt rows.
13. **The 20 inherited Minor findings:** they are explicitly deferred in the checkpoint and no incidental fixes are allowed; I did not individually re-review their original scopes. **Cost:** all remain open with their existing costs and must not disappear from the final ledger.
14. **The unmerged 104-file mobile/social/World main-branch delta:** it is not in the supplied review range and the branch has not been jointly integrated. **Cost:** no current-main compatibility or complete integrated UI verdict.
15. **Fresh broad root gates, protected-file hash audit and durable remote source restoration:** the parent is already running/owning those exact-source checks; duplicating them would not expand the focused review. **Cost:** this report alone is not the final quality receipt or a verified source-backup claim.
16. **Task16 whole-branch release, remaining combat/editor cycles, comprehensive balance, Atlas/human acceptance and deployment readiness:** this is a bounded continuation of the approved Basic editor requirement, with the preceding execution limits still open. **Cost:** no final release/main-merge/deployment authorization or overall overhaul-completion claim.

## Assessment

**Ready to merge? Yes for this bounded Basic Restore checkpoint, subject to the parent-owned exact-source gates. Not a Task16 or whole-branch release approval.**

**Reasoning:** The explicit restore path uses trusted history and existing authority/CAS boundaries, preserves immutable publications/captures, and handles editor races without dropping newer edits. I found no Critical, Important or new Minor defect in the complete change and inspected consumers; the local integration evidence is appropriately narrower than hosted/native acceptance.
