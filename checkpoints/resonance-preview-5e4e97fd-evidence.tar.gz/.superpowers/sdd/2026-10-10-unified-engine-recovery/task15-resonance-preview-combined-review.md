# Fresh combined review — normalized record

Reviewer /root/resonance_preview_review, gpt-6-astra High, fork none. Six changed files and surrounding editor/client/authenticated handler/service/native preparation/projection reviewed at5b55bb6f4c992d04d1e38f3e4a72e42b63e554f9 againstab359650becb091b5eb87887c653a0a498753dca. Read-only: no execution, services, network, browser, native tests, mutation or subagents. Supplied full8873+7/141preview/294reader receipts were not independently reproduced.

Strengths: actual strict Resonance envelope lane and exact native pair-source capture; native costs/Move/Controlled/Summon; draft revision and group invalidation; legacy/passive workflow; safe shared projection; real client/handler/service/native tests with explicit substitutions.

Critical:0. Important:3. New Minor:0. Fourteen inherited Minors deferred.

I1: editor270–274/ReviewPanel773 uses fixture-specific legal=true as publication eligibility. Actual single-group Broken Line requires Covert absent from fixed fixture, so even a flavor-only edit cannot publish. Native illegality is truthful; the gate is wrong. Recommendation: completed matching current preview, with native illegality informative, preserve strict Skill/Basic defaults; real callback conditional publication/stale guards.

I2: editor142/270–274 requires preview for disabled canonical Manual drafts, while service591–596 rightly rejects disabled simulation. Validation/publication support disabled records and loaded initialDraft can be disabled. Authoring deadlocks even if legal=false previews become allowed. Recommendation: disabled drafts keep an authoring/publication path without fabricating an enabled cast; real loaded-disabled callback publication, preserve direct disabled-preview rejection.

I3: preview geometry876–881 omits groundFire unlike Skill/Basic. Shared previewSelection149–158 omits ground:true for geometry2 Fire Ground Circle/Line. Native elementalActionIntent(actions-legacy1113–1122) normalizes Enemy intent/removes persistence, while canonical projection808–820 can show authored Ground persistence. Recommendation: derive groundFire from selected behavior like existing paths; authenticated geometry2 Fire area regressions and preserve geometry3 categories.

Assessment: Ready to merge with fixes. Native integration/stale responses sound, but two authoring deadlocks and one targeting-intent mismatch require the single repair pass. No review of later repairs or release acceptance implied.

## Declined to judge (each separately)

- Automatically satisfying authored Requirements — would conceal truthful native failures; fix publication instead.
- Expanding fixture to every resource/status scenario — separate authoring work.
- Filling every plural cap — bounded fixture need not invent combatants.
- Making conditional/interrupted Move succeed — native legality remains authoritative.
- Automatic simulation — event-context work.
- Ongoing simulation — lifecycle-context work.
- Manual modifiers without root — distinct root-context workflow.
- Historical sequence/immediate simulation — retain non-cast workflow.
- Live expiry/revocation — unchanged Tasks8/16 authority evidence.
- Alternate-character/direct gameplay RPC — not established by endpoint review.
- Database publication concurrency — CAS inspected, locks/rollback not executed.
- Build/claim/recovery/settlement concurrency — outside changed files.
- Malformed historical captured/pending/Summon persistence — authoring admission inspected, recovery not exercised.
- No-input combat — unchanged execution.
- Repeated-event boundedness/duplicate payment — unchanged execution.
- Interrupted Move settlement/unreached-origin attack — preparation inspected, execution separate.
- Mounted keyboard/AT — callbacks/SSR insufficient.
- Mobile/long-name/200% zoom — no native/browser visual evidence.
- Creative balance/roster — no roster mutation or balance judgment.
- Inherited14 Minors — explicitly deferred.
- Hosted publication/migration/deployment/release readiness — outside authorized review.

Full required five-paragraph Review Focus remains verbatim in resonance-preview-combined-review-package.md; reviewer considered it and distinguished source review from execution evidence.
