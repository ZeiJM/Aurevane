1. **Automatically satisfying Requirements** — Ruling/reason: Native fixture failures remain truthful; I1 changes publication eligibility instead. Cost if wrong: A completed preview does not prove that every real battle can satisfy the definition.

2. **Every resource scenario** — Ruling/reason: A fixed sample is narrower than a scenario editor. Cost if wrong: Resource-specific scenario acceptance remains open.

3. **Every status scenario** — Ruling/reason: No fabricated Covert or other status is added. Cost if wrong: Status-conditioned actions may correctly be unavailable in the sample.

4. **Filling every plural cap** — Ruling/reason: The fixture uses available actors within the authored cap. Cost if wrong: Maximum population is not demonstrated for every definition.

5. **Conditional Move succeeds** — Ruling/reason: Native Requirements retain authority. Cost if wrong: A conditional Move may correctly fail in the sample.

6. **Interrupted Move succeeds** — Ruling/reason: No execution transition is changed. Cost if wrong: Interrupted execution acceptance remains open.

7. **Automatic simulation** — Ruling/reason: This work adds Manual action preview only. Cost if wrong: Event-context preview remains unfinished.

8. **Ongoing simulation** — Ruling/reason: No lifecycle simulator is added. Cost if wrong: Ongoing preview remains unfinished.

9. **Manual modifiers without root** — Ruling/reason: A modifier is not an independent cast. Cost if wrong: Root-context preview remains unfinished.

10. **Historical sequence simulation** — Ruling/reason: Existing non-cast workflow is retained. Cost if wrong: Sequence simulation remains unfinished.

11. **Historical immediate simulation** — Ruling/reason: Existing non-cast workflow is retained. Cost if wrong: Immediate event simulation remains unfinished.

12. **Live expiry** — Ruling/reason: Authoring authorization remains unchanged; no hosted expiry witness. Cost if wrong: Task8/16 expiry acceptance remains open.

13. **Live revocation** — Ruling/reason: No hosted revocation witness is produced. Cost if wrong: Revocation acceptance remains open.

14. **Alternate-character authority** — Ruling/reason: Local actor injection is narrower than live selected-character admission. Cost if wrong: Hosted alternate-character acceptance remains open.

15. **Direct gameplay RPC** — Ruling/reason: The authoring endpoint is not the gameplay RPC path. Cost if wrong: Direct gameplay authority acceptance remains open.

16. **Database publication concurrency** — Ruling/reason: Local immutable publication is exercised, not simultaneous physical sessions. Cost if wrong: Concurrency acceptance remains open.

17. **Publication lock ordering** — Ruling/reason: No real database locks are executed. Cost if wrong: Lock-order acceptance remains open.

18. **Publication rollback** — Ruling/reason: No hosted/physical rollback race is executed. Cost if wrong: Rollback acceptance remains open.

19. **Build concurrency** — Ruling/reason: No build transaction change exists. Cost if wrong: Build concurrency acceptance remains open.

20. **Claim concurrency** — Ruling/reason: No claim transaction change exists. Cost if wrong: Claim concurrency acceptance remains open.

21. **Recovery concurrency** — Ruling/reason: No recovery transaction change exists. Cost if wrong: Recovery concurrency acceptance remains open.

22. **Settlement concurrency** — Ruling/reason: No settlement transaction change exists. Cost if wrong: Settlement concurrency acceptance remains open.

23. **Malformed historical captures** — Ruling/reason: Authoring admission does not establish all persisted restore paths. Cost if wrong: Historical capture acceptance remains open.

24. **Malformed pending persistence** — Ruling/reason: No pending restore parser change exists. Cost if wrong: Pending restore acceptance remains open.

25. **Malformed Summon persistence** — Ruling/reason: Edited Summon preview uses native preparation, not saved battle restore. Cost if wrong: Summon persistence acceptance remains open.

26. **No-input execution** — Ruling/reason: Preview is preparation and does not execute full lifecycles. Cost if wrong: No-input acceptance remains open.

27. **Repeated-event bounds** — Ruling/reason: No native event executor change exists. Cost if wrong: Repeated-event acceptance remains open.

28. **Duplicate payment execution** — Ruling/reason: Preview costs are deterministic but no real battle payment commits here. Cost if wrong: Execution payment acceptance remains open.

29. **Interrupted settlement** — Ruling/reason: Native preparation was inspected; actual interruption is not executed by these new cases. Cost if wrong: Settlement acceptance remains open.

30. **Unreached-origin attacks** — Ruling/reason: Move command authority is unchanged. Cost if wrong: Full execution acceptance remains open.

31. **Mounted keyboard** — Ruling/reason: Controlled hook callbacks are not mounted native input. Cost if wrong: Keyboard acceptance remains open.

32. **Assistive technology** — Ruling/reason: No AT session is performed. Cost if wrong: AT acceptance remains open.

33. **Mobile geometry** — Ruling/reason: No browser measurements are made. Cost if wrong: Mobile acceptance remains open.

34. **Long-name geometry** — Ruling/reason: No browser measurements are made. Cost if wrong: Long-name acceptance remains open.

35. **200% zoom** — Ruling/reason: No browser measurements are made. Cost if wrong: Zoom acceptance remains open.

36. **Creative balance** — Ruling/reason: No balance definition is changed. Cost if wrong: Natural gameplay/balance acceptance remains open.

37. **Roster mutation** — Ruling/reason: Accepted definitions are inputs only and hashes stay unchanged. Cost if wrong: No proposed roster is activated by this checkpoint.

38. **Fourteen inherited Minors** — Ruling/reason: Approved deferred backlog is unchanged; no incidental repair. Cost if wrong: All fourteen remain unresolved and are listed in this report.

39. **Hosted publication** — Ruling/reason: Only in-memory test publication is performed. Cost if wrong: Current Owner hosted publication acceptance remains open.

40. **Migration** — Ruling/reason: No schema or migration is changed/applied. Cost if wrong: Hosted migration readiness remains separate.

41. **Deployment** — Ruling/reason: The deployment lock is retained. Cost if wrong: This checkpoint is not live.

42. **Release readiness** — Ruling/reason: This is one editor integration slice. Cost if wrong: Original combat/native/balance/human release gates remain open.

43. **Full Task15** — Ruling/reason: Event/root previews and other original integration remain. Cost if wrong: Task15 is unfinished.

44. **Full Task16** — Ruling/reason: Final acceptance exceeds local fixtures. Cost if wrong: Task16 is unfinished.

45. **Natural twelve-round balance** — Ruling/reason: Existing full checks run their current coverage; no new balance matrix is claimed. Cost if wrong: The final natural-cycle/balance gate remains open.

46. **Atlas motion** — Ruling/reason: No Atlas implementation or measurements change. Cost if wrong: Recorded motion acceptance remains open.

47. **Human playtest** — Ruling/reason: Automated checks are narrower than human play. Cost if wrong: Human acceptance remains open.

