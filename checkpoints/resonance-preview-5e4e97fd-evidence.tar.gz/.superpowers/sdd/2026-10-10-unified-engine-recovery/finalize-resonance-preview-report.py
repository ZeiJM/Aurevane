from pathlib import Path
import datetime, hashlib, json, re, subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='resonance-preview'
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
source=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip()
assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
assert reviewed=='5b55bb6f4c992d04d1e38f3e4a72e42b63e554f9'
subprocess.run(['git','merge-base','--is-ancestor',reviewed,source],check=True)
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
log=Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8877,counts
assert datetime.datetime.fromisoformat(gate['started_utc'])>=datetime.datetime.fromisoformat(git('show','-s','--format=%cI',source))
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
a=json.loads((w/(prefix+'-reader-analysis.json')).read_text());b=json.loads((w/(prefix+'-legacy-analysis.json')).read_text())
assert a['source']==b['source']==source and a['records']==294 and b['records']==141
assert a['allReportsAndHtmlExactlyUnchanged'] and a['manifestAndSixAiSourceHashesUnchanged'] and b['allLegacyNativePreviewsExactlyUnchanged']
for suffix,data in [('reader',a),('legacy',b)]:assert data['rawSha256']==hashlib.sha256((w/(prefix+'-'+suffix+'-observation.json')).read_bytes()).hexdigest()
outcome=(w/(prefix+'-review-outcome.md')).read_text();rulings=(w/(prefix+'-review-rulings.md')).read_text()
assert 'No unresolved Critical or Important' in outcome and 'Cost if wrong:' in rulings
replay=''
if (w/(prefix+'-initial-fullcheck-audit.json')).exists():replay=' The initial root run omitted a complete summary despite exit0; its audit/package logs are retained, and ONE cached exact-source replay supplies the complete receipt.'
text=f'''# Resonance Manual-action preview — verified development checkpoint

The Master Resonance editor can now select a canonical Manual action group and simulate it through the existing combat engine. Previously the editor used a null preview and no-op callback, while the endpoint ignored the Resonance content kind and sent its definition through Skill validation. A valid Resonance therefore could not use the shared battle preview.

The existing authenticated endpoint now passes the typed Resonance lane to strict Resonance validation. The service requires a supported selected Manual/action group, with an explicit choice when several exist, and rejects disabled, malformed, unknown and absent-ability definitions instead of falling back to legacy mechanics. The native capturedResonanceAbilitySource retains the exact sorted Discipline pair, version and resonance source kind. No Skill alias or invented source Discipline is used.

The existing fixture and native command preparation own targeting, Requirements, pricing, Controlled priming and outcomes. The shared canonical public projection and existing safe Summon projection are reused. An edited Summon shows its actual profile and selected spawn position. Attached Move remains included in the authored overall cost. Preview does not execute or pay a real battle command and consumes no battle RNG.

The actual editor uses the shared action selector and client/handler/service path. Switching groups clears the previous preview and closes publication confirmation. Draft edits invalidate review; late preview responses cannot restore the stale result. An enabled canonical Manual action needs a completed current matching preview before the existing Publish confirmation can proceed. Historical sequence/immediate and canonical sources with no Manual action retain their prior validation/diff workflow; they are not fabricated as independent casts. Their event or root-context simulation remains unfinished.

## Source and verification

BASE ab359650becb091b5eb87887c653a0a498753dca → reviewed {reviewed} → final tested {source}. Eight implementation/test files; this report is the only subsequent docs change. No native engine, schema, SQL, roster, AI, CSS, artwork, battle control, server publication authority or deployment change.

- **155 new root tests**: 149 real handler/service/native/SSR cases and six controlled React-hook callback cases. All **130 accepted Manual Resonance groups** prepare through the actual authenticated handler and strict typed service. A valid definition is not automatically legal in the fixture: native resource/status/other Requirements remain authoritative.
- Actual Steamfront Quench/Flare and Aether in Poise Release are covered in PvE/PvP. Costs remain 35 AP/4 MP, 50 AP/6 MP and 50 AP/8 MP respectively; Release's Move is included. The selected group, recipients, effects, deterministic repeat, privacy, no RNG and input immutability are checked. Edited Controlled and Summon paths, malformed/disabled/ambiguous/unknown/unauthorized admission, historical sequence handling and truthful native Requirements are covered.
- The actual editor callbacks drive the real client/handler/service/native chain. They check group invalidation, confirmation closure, draft edits during an in-flight preview, informative native illegality, successful local conditional/disabled publication and preservation of passive review workflow. Only React hook lifecycle, navigation/server-only marker and the transport boundary are substituted. No mounted DOM, keyboard, touch, assistive technology, focus or layout acceptance is claimed.
- Missing-lane/selector **11 valid RED** failures214759158391Z-cb7f08c1; firstGREEN214849086629Z-7484f307. The original editor was temporarily restored for a three-case callback regression witness, **RED215034429951Z-77bc46fd**, then the implementation was restored. Edited Summon profile stayed RED after correcting an initially guessed name to the actual existing Verdant Stalker, receipt215023868348Z-694baa83. Tests and types caught an incorrect native input field; the implementation now uses SpawnCombatSummonInput.position. A passive workflow RED215157912308Z-fce676e9 narrowed the preview gate to Manual/actions only.
- Final focused **431 tests /22 files GREEN**, receipt220310077981Z-88ffcc8f. Final repair web types220310616343Z-405bea80 and correct web-config zero-warning lint220246712429Z-8f4bef2e passed; final root rechecks both on the frozen source. An earlier root-config lint invocation ignored web files and is not counted as lint coverage.
- All **136 latest built-in native Skill previews plus five default Basic previews** exactly match the prerequisite's full JSON results. Final frozen diagnostic220410820635Z-7095d30d; SHA256 {b['rawSha256']}. Exact BASE module SHA256 {b['baselineModuleSha256']}, with only its relative viewer-projection import rebased for the isolated diagnostic. Latest/default coverage does not mean every historical version.
- All **294 named Skill reports and HTML** remain exactly unchanged:297 groups/604 effects. Final frozen diagnostic220410818347Z-6ecd9983; observation SHA256 {a['rawSha256']}. Proposal manifest and six AI/native source hashes remain unchanged. No new gameplay balance matrix is claimed.
- Exact final root **8,877 Vitest tests plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN. Receipt {Path(gate['log']).stem}, {gate['started_utc']} → {gate['completed_utc']}. Package counts: {', '.join(name+' '+n for name,n in counts)}. Complete root build tail and package-log hash audit retained.{replay}

## One review repair pass

The independent review found 0 Critical / 3 Important / 0 new Minor. Parent accepted all three by actual author impact. I1: a valid single-group Covert-dependent Resonance could not publish even a text edit because the fixed fixture was not legal; require a completed current matching preview and show unmet conditions, preserving the strict default for Skill/Basic callers. I2: disabled Manual drafts could neither simulate nor publish; retain their prior validation/diff publication path without an enabled cast. I3: geometry2 Fire Ground Circle/Line lost explicit Ground intent; derive the selected behavior's Fire flag as the existing Skill/Basic paths do.

Conditional and disabled publication cases reproduced RED220138361397Z-7fa2be76. That run also had a real Circle Ground failure and one Line-fixture range error; after correcting authored Line reach, both area regressions were valid RED220301349245Z-de6cbe6d with the missing-flag behavior temporarily restored. Corrected implementation then passed 431 tests / 22 files, receipt 220310077981Z-88ffcc8f. Actual conditional and disabled publication use only an in-memory store; saved versions retain the original Ability and disabled flag. No hosted publication occurred. A test-helper override type was narrowed after TypeScript exposed an overly broad union. Shared ReviewPanel/workflow default still requires legal previews for existing Skill/Basic callers. No rereview or incidental Minor repair.

## Restoration and evidence limits

Automated maintenance removed the previous local checkout. The verified recovery branch f18e515740520cabcb85a99a5e41fc4c3b8c8e07 was cloned; all41 saved Git bundles were imported with native bundle verification. Exact source ab359650/tree65b82b5a877a560ae49032c86f7883a70913855b was restored. Latest bundle/evidence sizes and SHA256 matched saved metadata; archive paths were inspected before safe extraction. Offline dependency restore left the lock unchanged. The restored baseline passed44 tests/3files. The missing ignored evidence-local dependency link initially caused diagnostic import failures, then both diagnostics passed after its restoration. The pre-existing Vite native-loader advisory remains visible and is not suppressed.

These are local deterministic authoring fixtures, static rendering and controlled callbacks. No signed-in browser, hosted persistence/publication, physical concurrency, native input, assistive technology or human acceptance is established. Full Task15/16, Automatic/Ongoing/event and modifier-root previews, legacy sequence simulation, complete combat cycles, natural twelve-round balance, current Owner hosted edits, SQL CAS, Atlas motion and human/release gates remain open. Original unfinished combat integration must still finish before the rebalance release; broader unrelated Master work follows combat. Modular foundation is already live; this checkpoint is not deployed. High remains sufficient.

## Independent review

{outcome}

## Initial rulings

1. Reuse native Resonance capture and command authority. Reason: the preview must preserve pair/source identity and actual rules. Cost if wrong: a fixture still cannot establish live build ownership or execution acceptance.
2. Add typed contentKind to the existing preview service interface rather than a parallel endpoint. Reason: retain the current shared client/authentication/validation chain. Cost if wrong: the legacy method name previewSkillDefinition now also supports an explicit Resonance lane; a future rename is separate cleanup.
3. Gate enabled canonical Manual actions by completed current matching preview; preserve prior disabled/legacy/passive workflow. Reason: the fixed sample cannot satisfy every valid conditional action, and disabled versions have no legal cast. Fixture illegality stays visible, while definition validation remains mandatory. Cost if wrong: completing a preview does not prove its Requirements can be met in the final roster; gameplay/balance acceptance remains required.
4. Factor existing safe Summon/canonical projection for reuse. Reason: a native edited Summon needs truthful visible preview data without duplicating its serialization contract. Cost if wrong: default Basic and legacy Skill behavior must remain protected by the exact141-result comparison; arbitrary historical versions remain separate.
5. Restore source and evidence before coding after maintenance. Reason: exact checkpoint identity outranks reconstructing code from memory. Cost if wrong: current source integrity is verified, but ignored historical evidence outside the latest archive still lives in the retained older recovery archives.

## Every parent set-aside decision

{rulings}

## Deferred minors

Fourteen inherited findings remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal historical labels/values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline-reference sizing; cross-status direct-input immutability witness; legacy duplicate component keys; unknown-reference matching-text witness. New review Minors, if any, are listed in the review outcome above.
'''
for a0,b0 in [(' /22',' / 22'),(':297',': 297'),('all41','all 41'),('passed44','passed 44'),('tests/3files','tests / 3 files'),('full Task15/16','full Task 15/16'),('Full Task15/16','Full Task 15/16'),('exact141','exact 141')]:text=text.replace(a0,b0)
(root/'docs/verification/2026-10-16-resonance-manual-preview.md').write_text(text)
(w/'progress.md').open('a').write('\n## Resonance Manual-action preview verified checkpoint\n'+text+'\n')
print('Guarded report and ledger written.')
