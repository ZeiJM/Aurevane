# Parent disposition — one repair wave, no rereview
Accept I1–I5 Important as concrete user defects, not deferred native acceptance. Accept parent I6: root fixture equality failure caused by new viewerflag. Repair all six in one RED→GREEN wave. M1 remainsMinor/deferred,13total. No implementer or secondreview. Source frozen10ad untilthisdisposition.

I1 design: shared information-only Ctrl+Alt+E entry (combat custom bindings support code+Shift only), visible discoverable Effects heading help plus main accessible instruction, scoped arrows/Home/End among actual instance controls, Escape returns to origin. Install with existing shared battle Tab guard used playable/spectator, before combat listeners; leave textentry/unrelateddialogs/modifiers/pickers/nativeEnterSpace untouched. Inspection owns initial focus and returns it. No combat command or configured binding replaced.
I2 design: shared inspection section owns portal host context and focus boundary; effect portal renders inside actual modal section. Existing session and topmost Escape retained, no second popup framework.
I3 design: overwrite optional application potency/blindside fields even when absent; captured defaults remain defaults rather than latest root fields.
I4 design: captured profile percentage/progression from actual stage/remainingticks, public pending profile retained; unknown futureHP unavailable. No roster defaults.
I5 design: shared policy normalization for summaries plus existing full lifetime reader for visible duration labels; preserve geometry/classes.
I6 design: bring independent percentageDot presentation fixture into parity with public viewer-only stacking context, retain equality guard and kernelauthority immutability. No engine fixture behavior change.

## Every declined behavior: parent ruling, reason and cost

1. Incoming rate versus exact HP forecast: retain the scoped rate. Reason: per-hit rounding, Pierce and other effects require the actual forecast. Cost: this summary cannot predict exact HP loss.

2. Combined outgoing damage: leave open. Reason: this cohort implements supported incoming rates only. Cost: outgoing summaries still need their native operator projection.

3. Combined conditional damage: leave open. Reason: attacker and recipient conditions are absent from an isolated status row. Cost: contextual strength needs separate projection.

4. Combined non-damage categories: leave open. Reason: each category has different native operators. Cost: complete category summaries remain unfinished.

5. Controlled readiness: leave open. Reason: readiness belongs to the whole captured action. Cost: Controlled reader acceptance remains required.

6. Recovery HP/MP amounts: leave open. Reason: the public row has counts without its captured amount. Cost: safe amount projection remains necessary.

7. Barrier remaining amount: leave open. Reason: the combatant total does not identify one Barrier instance. Cost: safe per-instance projection remains necessary.

8. Historical Chronicle fallback: retain for now. Reason: a log name does not identify a live capture. Cost: the historical modal and dictionary integration remain unfinished.

9. Oldest fixed Storm percentage: retain conservative common rules. Reason: modern stacking cannot be assumed. Cost: the exact oldest magnitude remains undisplayed.

10. Native mouse/touch/keyboard acceptance: leave open, while fixing I1 now. Reason: native browser access is unavailable. Cost: actual device verification remains required.

11. Assistive-technology acceptance: leave open, while fixing I2 now. Reason: structural ownership can be corrected without claiming AT execution. Cost: actual AT behavior remains unverified.

12. Long mixed reports, mobile geometry and 200% zoom: leave open. Reason: static CSS is not physical evidence. Cost: overflow and clipping still require inspection.

13. Button CSS inheritance: retain the reviewed styles. Reason: review found no additional definite regression and geometry tokens are preserved. Cost: physical sizing remains unverified.

14. Inspection backdrop dismissal: retain the existing outside-card behavior. Reason: this cohort does not redefine inspection dismissal. Cost: clicking outside inspection closes the whole inspection.

15. Unknown or malformed persisted validation: retain the existing parser authority. Reason: this presentation change does not replace validation. Cost: reader tests do not re-audit malformed persistence.

16. Expiry/revocation/CAS and direct RPC access: retain the separate Task8/16 gate. Reason: no security path changes here. Cost: hosted authority acceptance remains required.

17. No input, duplicate payment, interrupted Move and attack origin: retain the gameplay gate. Reason: execution paths are unchanged. Cost: reader tests cannot establish fresh gameplay acceptance.

18. Publication/build/claim/recovery/settlement concurrency: retain its separate gate. Reason: transactions and workers are unchanged. Cost: hosted concurrency acceptance remains required.

19. Rewind witness origin: defer the inherited Minor. Reason: no related execution change belongs in this reader repair. Cost: the witness still starts at the origin.

20. Supporting Shot version pin: defer the inherited Minor. Reason: the unrelated capture assertion is unchanged. Cost: exact version-pin coverage remains incomplete.

21. Ongoing pair dynamic identity: defer the inherited Minor. Reason: the unrelated test is unchanged. Cost: its identity pin remains weaker.

22. Repeated bounded AI discovery: defer the inherited Minor. Reason: no AI code changes here. Cost: redundant bounded discovery remains.

23. Admission double-prefix provenance: defer the inherited Minor. Reason: the admission path is unchanged. Cost: duplicate prefix wording remains.

24. Ranged negative direct-commit witness: defer the inherited Minor. Reason: six guarded AI/native sources are unchanged. Cost: the negative witness remains a preparation check.

25. Defense-positive HP reconciliation: defer the inherited Minor. Reason: execution is unchanged. Cost: event assertions do not independently reconcile HP.

26. Exact Arsenal history values: defer the inherited Minor. Reason: the history cohort is unchanged. Cost: exact label/value coverage remains incomplete.

27. Singular status-clock grammar: defer the inherited Minor. Reason: unrelated editorial cleanup is excluded. Cost: the grammar defect remains.

28. Burn ordinary tick-boundary wording: defer the inherited Minor. Reason: it is distinct from I4’s missing captured profile. Cost: boundary wording remains imprecise.

29. Master inline reference-button sizing: defer the inherited Minor. Reason: these battle styles do not own it. Cost: inline geometry acceptance remains open.

30. Cross-status direct-input immutability: defer the inherited Minor. Reason: it is a different test cohort. Cost: that direct-input witness remains weaker.

31. Full Task15/16, balance, Owner hosted, Atlas, human acceptance and release: leave open. Reason: a bounded reader review cannot close them. Cost: the combat update remains unreleased.

32. New duplicate legacy keys: defer M1 as Minor. Reason: review established a static collision without executing a mounted failure. Cost: same-status expiry/replacement may misassociate popup state until a separate fix.
