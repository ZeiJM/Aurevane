import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'live-effect-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'live-effect-tested-source.txt').read_text().strip();reviewed=(w/'live-effect-reviewed-source.txt').read_text().strip();base='54a1ab343cac44d7d346c2c1fee052551e0679a1'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==35 and all(p.startswith('apps/web/') or p=='docs/verification/2026-10-16-captured-live-effect-readers.md' for p in paths),paths
assert reviewed=='10adca11d86a3e02cda989857199f92680199225' and tested=='20038c54c80f97a4a192dfcd128009759ded77c3'
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8509,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'live-effect-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged'] and observed['rawSha256']==sha(w/'live-effect-reader-observation.json')
bundle=w/('live-effect-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'live-effect-bundle-verify.log').write_text(v.stdout)
evidence=w/('live-effect-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-live-effect-reader-brief.md', 'live-effect-implementation-notes.md', 'live-effect-combined-review-package.md', 'task15-live-effect-combined-review.md', 'live-effect-review-rulings.md', 'live-effect-repair-notes.md', 'live-effect-tested-source.txt', 'live-effect-reviewed-source.txt', 'live-effect-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-live-effect-checkpoint.py', 'live-effect-readers-diagnostic.test.tsx', 'vitest-live-effect-reader.config.ts', 'live-effect-reader-observation.json', 'live-effect-reader-analysis.json', 'analyze-live-effect-readers.py', 'live-effect-fullcheck-audit.json', 'live-effect-initial-fullcheck-audit.json', 'live-effect-initial-turbo-logs.tar.gz', 'live-effect-turbo-logs.tar.gz', 'cross-status-reader-observation.json', 'ranged-ai-analysis.json', 'finalize-live-effect-report.py', 'audit-live-effect-fullcheck.py', 'task15-live-effect-strength-next-notes.md', 'live-effect-checkpoint-summary.txt']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T173600':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'3736ca45b386cc995d2f0dc9b82812c788b1bf94','previousArchiveTree':'b4e4db3561f417d77fc632df0ddc42c726ee2253','fullCheckReceipt':gate,'tests':{'vitest':8509,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/'live-effect-checkpoint-summary.txt').read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
