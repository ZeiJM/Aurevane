from pathlib import Path
import json, re, subprocess

root = Path.cwd()
w = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
receipts = [json.loads(x) for x in (w / 'verification.jsonl').read_text().splitlines()]
gate = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
log = Path(gate['log']).read_text()
counts = re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed', log)
assert gate['exit_code'] == 0 and len(counts) == 7 and sum(int(n) for _, n in counts) == 8509
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert '2 successful, 2 total' in log.rsplit('$ turbo run build', 1)[-1]
source = (w / 'live-effect-tested-source.txt').read_text().strip()
reviewed = (w / 'live-effect-reviewed-source.txt').read_text().strip()
assert reviewed == '10adca11d86a3e02cda989857199f92680199225'
assert source == '20038c54c80f97a4a192dfcd128009759ded77c3'
observed = json.loads((w / 'live-effect-reader-analysis.json').read_text())
assert observed['source'] == source and observed['allReportsAndHtmlExactlyUnchanged']
assert not subprocess.check_output(['git', 'status', '--porcelain'], text=True).strip()
rulings = (w / 'live-effect-review-rulings.md').read_text().split('## Every declined behavior: parent ruling, reason and cost\n', 1)[1]
report = f'''# Captured live-effect readers — verified development checkpoint

Actual captured effect details now share one report and popup across compact/full/All battle rails and five migrated desktop/mobile PvE, PvP and spectator surfaces. Supported current incoming strength is explicitly scoped to this effect, with actual stacks, captured application strengths and remaining lifetime. Pending effects do not claim active incoming modification. Unsupported versions retain identity and counters with rules unavailable rather than borrowing current rules. No private source identity or execution metadata is shown.

The public viewer adds the encounter's captured stacking-policy flag without changing persistence or execution. Current applications retain their individual strengths; ordinary historical rows retain native whole-row semantics. Default Guard followed by authored 20% now explains 15% and 20%, matching the combined −32% incoming rate. Omitted application-specific fields do not inherit the latest root override. Visible incoming summaries and lifetime labels use the same interpretation as the popup, including recovery applications, round boundaries and Barrier depletion.

Captured DoT profiles now expose actual percentages and Burn's remaining progression from its captured stage and lifetime. Pending Burn 30% with 10-point decay and three ticks shows 30% → 20% → 10% without inventing future HP damage. Active captures retain actual captured HP and next-tick HP; an actual affected-turn tick advances the reader to 20% → 10%. Historical and current special-trigger wording remain distinct.

Keyboard-only information entry uses **Ctrl+Alt+E**, shared by playable and spectator battle roots. Up/Down/Home/End choose actual effect buttons; Enter/Space and the existing popup own opening. Escape closes the report and returns to its trigger, then returns to the prior focus or the battle root. Plain Tab/Shift+Tab stay disabled. Code+Shift custom combat bindings, text fields, pickers and unrelated modal input remain under their existing owners. The information chord is consumed even when repeated or no effect exists. Accessible instructions and visible Controls-settings help describe it.

Three inspection dialogs establish initial focus and restore their opener. Their effect readers portal into the actual inspection section, inside its declared modal boundary. Oversized modal-owned readers use the inspection's existing scroll flow rather than viewport-relative absolute positioning within a relative scroll box. Existing popup ownership, outside dismissal, topmost Escape and no-X effect readers remain shared. Legacy dictionary assist yields to actual native readers; historical Chronicle fallback remains separate unfinished work. Existing chip/art/card geometry tokens are preserved; physical layout acceptance is not claimed.

## Verification and review

- Initial frozen source `{reviewed}`: 24 new cases, 829 focused tests in 79 files and web types pass. The first full root check `{175035629955}` failed ten independent percentage-DoT presentation-fixture equality assertions because that fixture omitted the new public flag; 4,081 other web tests passed. This run is not reported as GREEN.
- One fresh read-only combined review examined all 16 initial changed files and their real consumers: **0 Critical, 5 Important, 1 new Minor**. Parent accepts all five Important findings, adds the fixture mismatch as I6, and repairs them in **one RED→GREEN wave**, without rereview or implementers. The new duplicate-key Minor joins 12 inherited deferred Minors; 13 total.
- The repair covers inaccessible keyboard entry, detached modal portal ownership, root-value inheritance, missing available DoT strength/progression, contradictory visible summaries/lifetimes, and the fixture mismatch. TDD provenance, including invalid fixture attempts and corrected type/lint failures, is retained in `live-effect-repair-notes.md` in the recovery evidence. No failing command is relabelled as passing.
- Final tested source `{source}`: **875 focused tests in 83 files GREEN** (`180937773476`), web typecheck GREEN (`180937770373`), zero-warning scoped lint GREEN (`180937813314`). **60 new cases overall**:24 initial plus 36 repair. The cohort changes 34 web source/test/style files; no core execution or schema file changes.
- Exact tested source passes **8,509 Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds. The fresh full run `181018586167` passed from18:10:18 to18:14:18UTC; its combined stdout omitted the completed build tail, while the preserved web package log contained the full route table. One cached root replay `{Path(gate['log']).stem}` provides the complete final receipt: {gate['started_utc']} → {gate['completed_utc']}. No source changed between them. Both audits preserve package log hashes and test summaries.
- Final all 294 diagnostic `181018588403`:294 records, 297 groups, 604 effects. Every named Skill-reader report and HTML string is byte-identical to the previous cross-status checkpoint. Raw observation SHA256 `{observed['rawSha256']}`. Manifest and six AI/native source hashes are unchanged. No fresh 289-case gameplay matrix is claimed for viewer/presentation-only changes.

The automated evidence includes real native capture→viewer→reader cases, actual inspection component trees and layout callbacks, actual registered EventTarget handlers alongside the Tab guard, actual popup Escape callbacks, and real React portal objects with the supplied modal container. Controlled refs, fake elements and SSR are **not mounted DOM, native browser, assistive-technology or physical geometry acceptance**. Three keyboard entry labels invoke the same shared handler; they are not three independently mounted mode flows. Both actual root components use the shared hook. Native acceptance remains required; no repeated browser installation or tunnel attempt was made.

## Remaining release work

The modular foundation already live, proposed Skill rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance must finish before combat release. Other live strength categories, safe recovery/Barrier per-instance amount projection, Controlled whole-action readiness, historical Chronicle readers, public Manual rich references and remaining prose/reference coverage remain open. Distinct/full roster cycles, natural pacing/twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion, human and release gates remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

This development checkpoint publishes, activates, applies migrations, merges and deploys nothing. High remains sufficient for routine integration. The provisional 16–30 active working hour estimate (roughly 2–4 full working days) has not become a calendar launch promise or been mechanically reduced by this checkpoint.

## Deferred Minors

Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status direct-input immutability witness; and new legacy duplicate keys around stateful same-status popup instances. No incidental Minor fix is included.

## Every parent set-aside ruling

{rulings}
'''
(root / 'docs/verification/2026-10-16-captured-live-effect-readers.md').write_text(report)
with (w / 'progress.md').open('a') as f:
    f.write('\n## Final captured live-effect checkpoint verification\n' + report + '\n')
print(json.dumps({'source': source, 'reviewed': reviewed, 'vitest': 8509, 'node': 7, 'newCases': 60, 'rulings': 32, 'deferredMinors': 13, 'rootReceipt': gate}))
