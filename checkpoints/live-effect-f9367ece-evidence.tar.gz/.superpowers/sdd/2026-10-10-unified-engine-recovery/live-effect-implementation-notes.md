# Live-effect implementation and verification notes
BASE54a1ab343cac44d7d346c2c1fee052551e0679a1. Initial frozen10adca11d86a3e02cda989857199f92680199225.16source/test/stylefiles;24newcases. Onefreshcombinedreview/parentindividualreason-costdeclines/ONECIfixwave/no rereview;12inheritedMinorsdeferred.

Originalcombat/Owner§10/Task15inline. Previous8449+7/full294/durable3736ca45 verified; main29506e29/backup3736ca45 unchanged17:33. Brief task15-live-effect-reader-brief.md written before edits. Sharedactualinstance report/content/popover; compact/full/Allrail plus5legacydesktop/mobilePvE/PvP/spectatorsurfaces. Preservetriggercontents/tones/art;2stylesheetscarryoldchipdeclarationstobutton/transparentinnerrowcontrol. Nativeassistownershipguard; historicalChroniclefallbacknotconverted. Existingnativepopupsession/hover/focus/outside/Escape/noX reused. New referenceTrigger marker follows existing scoped parent navigation; deliberately assess reachability under disabled battleTab and existing inspection modal behavior.

Viewer-onlyeffectStackingPolicyVersion1 nowcarriesimmutableencountercontext, notpersistedstate/engineauthority. OrdinaryoldlegacyignoresheterogeneousapplicationModifiers like engine; currentflag1usesindividualstrengths. ModernWet/Conductive retainindependentelementalpolicy. OldestlegacyStormcommonhelpdoesnotpromiseunsupportedstacking/percentage. Realprojection→reader givescurrent−28% vslegacy−19%; originalinputsameobjectimmutabilityassert. Pendingnotactive; unsupportedcapturedversion/unknownpositional/prototypeidentitytruthfulunavailable. SourceIDs/provenancenotshown; Covert/privacyprojectionstillauthority.
Incoming summary reusesexisting bounded presentation arithmetic; labelled fromthiseffect, notallstatuses/forecastHP. Mixedgroupsdisplayactualapplicationfactswithoutinventedrootdefaultnarrative. Nativepending/recovery/depletion/roundlifetimes retained. VisiblemagnitudeusesexistingorangeCompactEffectSummary. Fullcombinedoutgoing/conditional/othercategories andControlledreadinessnotpresentinstatusrowarenotclaimedfinished.

TDD:
-173645145534 initial5validRED2existingguardsGREEN→34/3GREEN173740111292.
-173842835511 includes2validunknownidentity/terrainRED plusintegrationfixtureerrors.
-173925558144 fourvalidsurfaceRED+3nativeownershipcallbackRED/1legacyguardGREEN+1mobileassetfixtureerror. Do not callall8failuresvalid.
-17401691984544GREEN/1mobileassetfixtureerror. MobilehunkrestoredtoHEAD; validassetfixture;1741215677861validmissingnativecontrolRED4skipped; reapplysamehunk. Testassertions scrubirrelevantembeddedimageURLsonly; noartsourcechange.
-1741057118332validRED scoping/mixeddefault→47/5GREEN174200382890.
-Typefailures174256177267/174335548959 missingcharacterLevelfixture fixedasrealfield; firstnexttypegenexit2withoutdetail174200857678 notclaimedpass. 3unusedimportwarnings removed; cleanlint174356876508.
-825/79GREEN174355643933/types174356857877.
-1746029969002validRED capturedlegacy/profileprojectionflag.174639542750additionaloldestStormRED withsameearlierlegacyfailure.
-174704486617 twofixture-contextfailures: globalcurrentflagkeptlegacyfixturescurrent; correctedflagonlycurrentcases.828/79GREEN174733493913/types174734094615/cleanlint174734082095.
-1748415069911validvisiblemagnitudeRED13GREEN; wireexistingCompactEffectSummary→829/79GREEN174908456606,types174908817005.
24newcases:14reader,5actualcontrolled-stateSSRsurfaces,4actualcallbackownership,1realprojection→reader. Notnative/browser/AT/physicalacceptance.
Reactcondensedcheck: no new fetch/dependencies/waterfalls/statehooks; pureboundedcalculation/directimports/existingclientpopoverboundary; actualbuttons/ARIA-describedbysafeplaintext; finitecontent; existinglistener/observercleanup. TypeScriptclean; originalnativecontrols/custombindings/art retained. Fullgate/all294nowrunning.
No core/native/schema/manifest/AI/fixturechanges; sixhashguardsunchanged; nonew289claimed. No hostedwrite/publication/activation/migration/merge/deploy.

Ruling: incoming summary is scoped to this effect and uses existing summary arithmetic — other statuses/conditions/per-step HP rounding are not a forecast — cost if wrong: other strength categories need their own native operator projection.
Ruling: mixed application groups use actual individual strengths, with no invented aggregate base potency — most recent/root potency cannot describe every application — cost if wrong: long groups need physical geometry inspection.
Ruling: add viewer-only captured stacking context because history otherwise cannot choose the correct existing application handling — never persist or apply a rule change — cost if wrong: other categories may need additional captured policy context.
Ruling: unavailable versions retain recorded identity/counters but do not borrow current rules — supported native versions and verified transient/terrain families only — cost if wrong: future known versions need explicit presentation support.
Ruling: preserve unmigrated historical message fallback, yielding to native owners — log segment names are not actual live-instance capture — cost if wrong: old historical modal/dictionary remains unfinished work.
Ruling: migrate both desktop/mobile PvE/PvP/spectators through shared authority and preserve geometry declarations — native physical acceptance unavailable — cost if wrong: later physical inspection may reveal CSS obstruction.
Fullcontrols/native/allcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. Highsufficient.
