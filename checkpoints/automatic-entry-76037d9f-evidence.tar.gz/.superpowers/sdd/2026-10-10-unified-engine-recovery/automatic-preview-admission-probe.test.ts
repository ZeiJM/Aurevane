import {readFileSync} from 'node:fs'
import {expect,it,vi} from 'vitest'
import {InMemoryCombatContentRepository} from '@aurevane/db/combat-content'
import {createCombatContentResolver} from '@/server/combat/combat-content-resolver'
import {createCombatContentAuthoringService} from '@/server/master/combat-content-authoring-service'
import {handleCombatContentAuthoringRequest} from '@/server/master/combat-content-authoring-handler'
vi.mock('server-only',()=>({}))
const rows=JSON.parse(readFileSync('/workspace/scratch/680b26e4eb86/aurevane/docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json','utf8')).records
const owner='11111111-1111-4111-8111-111111111111'
class Store extends InMemoryCombatContentRepository {async getOperatorRole(id:string){return id===owner?'owner' as const:null}}
const store=new Store()
const resolver=createCombatContentResolver({findCurrentSkill:async()=>null,findSkillVersion:async()=>null,findCurrentContent:async()=>null,findContentVersion:async()=>null})
const service=createCombatContentAuthoringService({store,resolver})
const automatic=rows.filter((r:any)=>r.after.ability?.behaviors.some((b:any)=>b.activation==='automatic'))
expect(automatic).toHaveLength(7)
async function request(row:any,userId=owner){
 const behaviorId=row.after.ability.behaviors[0].id
 return handleCombatContentAuthoringRequest(new Request('https://aurevane.test/api/master/combat-content',{method:'POST',body:JSON.stringify({operation:'preview',contentKind:row.kind,definition:row.after,behaviorId})}),{getActor:async()=>({userId}),createService:()=>service})
}
it.each(automatic)('needs real event preview support for $id',async row=>{
 const validation=row.kind==='resonance'?service.validateResonanceDefinition(row.after):service.validateSkillDefinition(row.after)
 expect(validation.issues).toEqual([])
 const response=await request(row)
 expect(response.status,JSON.stringify(await response.clone().json())).toBe(200)
})
it.each(['farstrider.aimed-shot','resonance.aetherist-ravager.linked-sequence'])('preserves the completed preview lane for %s',async id=>{
 const row=rows.find((r:any)=>r.id===id)
 const response=await request(row)
 expect(response.status).toBe(200)
 const result=await response.json();expect(result.preview.simulation.rngConsumed).toBe(false)
})
it('retains operator authorization before any Automatic simulation',async()=>{expect((await request(automatic[0],'outsider')).status).toBe(403)})
