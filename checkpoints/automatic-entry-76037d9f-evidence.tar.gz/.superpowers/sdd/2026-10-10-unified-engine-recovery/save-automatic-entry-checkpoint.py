from pathlib import Path
import subprocess,json,hashlib,tarfile,base64,sys
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'automatic-entry-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());data=base64.b64encode(Path(d[sys.argv[1]]['local']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':data[i*12000:(i+1)*12000]}));raise SystemExit()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');base='4eb8780087d7d83bf9167fb0f6b61c2c10532443';report='docs/verification/2026-10-16-automatic-preview-entry-audit.md'
assert git('diff','--name-only',base,head).splitlines()==[report]
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()];probe=next(r for r in reversed(receipts) if 'vitest-automatic-preview-admission.config.ts' in ' '.join(r['argv']))
assert probe['exit_code']==1 and '7 failed | 3 passed' in Path(probe['log']).read_text()
stem='automatic-entry-'+head[:8];bundle=w/(stem+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(w/'automatic-entry-bundle-verify.log').write_text(v.stdout)
evidence=w/(stem+'-evidence.tar.gz')
names=['automatic-preview-admission-probe.test.ts','vitest-automatic-preview-admission.config.ts','automatic-preview-case-inventory.json','automatic-entry-bundle-verify.log','save-automatic-entry-checkpoint.py','run.py','verification.jsonl','progress.md','task15-automatic-preview-next-notes.md']
with tarfile.open(evidence,'w:gz') as a:
 for name in names:a.add(w/name,arcname=str((w/name).relative_to(root)))
 a.add(Path(probe['log']),arcname=str(Path(probe['log']).relative_to(root)))
def item(path,remote):
 b=path.read_bytes();return {'local':str(path),'path':remote,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
d={'source':head,'tree':git('rev-parse','HEAD^{tree}'),'prerequisite':base,'parentArchive':'e506de6d7b038452e8d1b67b87215d5da4f480d5','parentTree':'0423ab049632acd605c43545d6dffe5fa203da63','probe':probe,'gapWitness':{'expectedUnsupported':7,'passingControls':3,'normalSuiteDiscoveryUnaffected':True},'productBaseline':{'vitest':8910,'node':7,'status':'Inherited completed Ongoing checkpoint; not rerun for documentation-only audit'},'runtimeChanged':False,'deployment':False,'mainUnchanged':'29506e293e81abef1b0b8a46099618ab3ae3f0ae','bundle':item(bundle,'checkpoints/'+stem+'.bundle'),'evidence':item(evidence,'checkpoints/'+stem+'-evidence.tar.gz')}
payload.write_text(json.dumps(d,indent=2)+'\n')
meta=w/(stem+'.json');meta.write_text(json.dumps(d,indent=2)+'\n');latest=w/'automatic-entry-LATEST.txt';latest.write_text('Aurevane Automatic preview entry audit\nSource '+head+'\nPrerequisite '+base+'\nMetadata checkpoints/'+stem+'.json\nExpected admission gap7/3controls pass; no completed Automatic implementation claim. Product baseline8910+7 retained, not rerun for docs-only checkpoint. No runtime/roster/AI/schema/UI/hosted/migration/deployment change. Owner canceled Claude collaboration. Next trusted native event context and child quote/editor integration; full combat/native/balance/release gatesOPEN. Main29506e29 unchanged;Highsufficient. Preserve archive ancestors.\n')
d['metadata']=item(meta,'checkpoints/'+stem+'.json');d['latest']=item(latest,'LATEST.txt');payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
