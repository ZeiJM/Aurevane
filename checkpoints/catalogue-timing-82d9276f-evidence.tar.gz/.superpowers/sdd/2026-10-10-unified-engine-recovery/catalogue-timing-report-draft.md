# Canonical Essence catalogue timing and roster reconciliation — October 17

The catalogue timing validator now selects the own-root Essence ability used by battle and authoring validation. This fixes false rejection of compatible root mechanics and false acceptance of incompatible root Automatic/Controlled mechanics. It also avoids materializing obsolete nested envelopes that throw cooldown/range errors for valid proposed root definitions. Production change: 8 lines in one server validator. Runtime, roster, shared helpers and prior duel fixtures are unchanged.

Base 93f469d572e1a75e10825e346b587cc20652dde5; frozen tested/reviewed source77d9c653ba3b37e427dc55f5da418d6d37d29c9d. Five-file 330-line change includes three test files and the historical read-only observation. Tasks 15/16 and release remain open.

## Actual evidence

Fresh targeted RED 834f71e2 reproduces 6 precedence failures, including both actual local policy-writer outcomes. Catalogue RED ed1e2f4b reproduces 18/19 failures (all 17 root Essences plus combined catalogue). The fix preserves native/historical nested canonical timing, disabled top-level gating and input immutability without invoking runtime usability on drafts. No simulated RPC writer call is made for incompatible root Automatic content; compatible root Manual content forwards the exact captured catalogue token once despite its incompatible nested envelope.

All 644 focused checks pass, including actual Master authoring/publication/current/pinned history and 28 new cases. Resumed focused receipt 0c4df866 exits 0 but stdout cuts after the Vite advisory. One scoped JSON-reporter capture 624d736b records success:true, 644 passed/0 failed; the first incomplete stdout is preserved and is not the count authority.

The actual resolver reconciles all 294 before identities/kinds/versions/canonical digests,289 new versions advancing by 1, five exactly retained Basics, complete after definitions, enabled state and captured policy without mutation. All 17 proposed Essences have own-root canonical abilities and are compared with the actual battle selector across every registered permitted Controlled default. This proves selected mechanics/timing compatibility, not every policy combination, encounter, playability or balance.

Read-only hosted observations at 2026-10-17T11:04:17.539348Z and 2026-10-18T00:10:59.928402Z agree: 0 versions/0 publications/0 drafts; policy 7 sets Summon/displace/MP-drain/remove-status Instant and Rewind Delayed. Catalogue reader/content-v3/policy-v2 guarded RPCs remain absent. Tracked JSON preserves the historical capture; fresh raw/parsed proof is archived separately. No hosted mutation. The local zero token is explicitly a fixture, not hosted CAS authority; refresh before actual publication remains required.

## Recovery, current main and quality

The usage interruption left original 71485845b, first root gate and final review verdict undurable. Scratch reopened at d34. Authenticated backup metadata/hashes restored exact 083 and 93 trees from incremental bundles/evidence; only the isolated work branch fast-forwarded. Main was untouched. Same five-file change was replayed and fresh REDs/checks replace incomplete original acceptance. The same resumed reviewer independently confirms all five postimage blob prefixes match the originally inspected diff. No original incomplete gate/interim review is claimed complete.

Current main b2d275269433f69ab1824e1f4ce110f730f9aa1a advances 3d6594f79 with 104 mobile/social/World files. Commit/path summaries and empty combat-kernel/server-combat/Master/battle/deployment-lock diffs were inspected; no bounded five-file overlap. The full 104-file UI delta is not reviewed, merged or jointly verified here. Original combat/UI/current-main integration remains required; unrelated live work is preserved.

QUALITY_PENDING

All six protected AI/helper/native-display hashes, manifest SHA256 b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05 and deployment-lock blob b8a4e0e3c57b95a8da49c05d1fe5f60ba2181b5f match. Only this verification report follows frozen source. High remains sufficient.

## Review and rulings

ONE combined gpt-6-astra High review resumed its interrupted seat, re-read the complete recovered diff/actual consumers and reports 0 Critical/0 Important/0 new Minor. Parent accepts those grades. No repair wave or rereview.20 inherited Minors remain deferred, including M20's local Summon-service replay adapter conflicting-key gap; none is changed or waived.

1. Ruling: hosted reads and local placeholder-token resolution are observation/dry-run only. Reason: required RPCs are absent and external transport is simulated. Cost if wrong: publication-time state refresh and real SQL/CAS/security acceptance remain required.
2. Ruling: compare before definitions with actual builtins while hosted tables have 0 rows. Reason: no Owner override/history is observed. Cost if wrong: future Owner edits can invalidate the baseline; refresh before publication.
3. Ruling: recover metadata-hashed durable source, replay bounded unarchived changes and run fresh checks. Reason: interrupted local gate/commit is not durable acceptance. Cost if wrong: original partial results cannot establish release readiness.
4. Ruling: freeze separately from concurrent 104-file main advance. Reason: bounded files do not overlap, while broader UI needs deliberate reconciliation. Cost if wrong: combined main integration/CI/browser acceptance remains open.
5. Ruling: retain 20 inherited Minor deferrals. Reason: approved policy reserves the single repair wave for Critical/Important. Cost if wrong: prior lower-severity limits remain and must reach Task 16.
6. Ruling: use successful scoped JSON report for 644 counts after console truncation. Reason: its assertions/receipt directly preserve the result. Cost if wrong: initial focused stdout is incomplete and cannot be called complete.

Parent independently adopts each of the following 16 review dispositions with its stated cost. Reviewer wording is retained as the considered scope; these are explicit non-claims, not waivers of real defects:

1. **Publication-time current Owner edits and policy** — zero-row read-only observations justify the builtin comparison only at their recorded times; I did not assert that those facts remain current when publication occurs. Cost: refresh and reconcile actual content, drafts, policy and relationships immediately before publication.
2. **Hosted catalogue CAS, row locks, atomic rollback and direct-RPC bypass resistance** — the required RPCs are absent in the observation and the new writer tests simulate transport. Cost: actual reviewed SQL/migration and operational concurrency acceptance remain open; exact token forwarding alone does not establish them.
3. **Live selected-character permissions, stale-browser access, expiry and revocation** — no authority implementation changes in this diff and the fixtures do not exercise a signed-in hosted actor. Cost: Task 8/16 actual authority-path acceptance remains required.
4. **Arbitrary malformed captured/pending/summon envelopes and recursive private-accuracy serialization** — inspected the relevant Essence admission boundary, but this checkpoint neither changes nor comprehensively tests every downstream serialized envelope. Cost: Tasks 1/5/7/16 privacy and fail-closed integration evidence remain necessary.
5. **Full current-versus-historical public/battle reader truth** — definition equality and existing local current/pinned tests support bounded immutability, not every reader, missing-metadata fallback or old battle. Cost: the Task 7/16 reader audit remains open.
6. **No-input, free priming, duplicate payment, repeated events and interrupted Move execution** — timing compatibility is admission validation; this production change does not modify execution, payment, movement or turn authority. Cost: the corresponding Tasks 2/3A/4/14–16 runtime and service cases remain independently required.
7. **Every roster cycle, AI behavior, targeting geometry, playability and balance** — comparing the actual selected ability to the timing compiler does not execute each encounter or prove meaningful balance/counterplay. Cost: outstanding distinct-cycle and full integration evidence remains open; the unchanged independent duel matrix was not repeated.
8. **Concurrent build, claim, recovery, reward and settlement correctness** — these services and worker/lock paths are outside the five-file change and not exercised by the new tests. Cost: Tasks 5/6/9/12/16 retain their real race, retry, no-contest and late/repeated-worker gates.
9. **Physical desktop/mobile interaction, native keyboard/touch, long names, accessibility and 200% zoom** — no component/UI code changes here; static/local validation is insufficient evidence. Cost: final real-screen workflow and human/assistive-technology acceptance remains open.
10. **Every gameplay tag's complete editor→publication→execution→reader chain** — all registered Controlled defaults are sampled for the 17 root Essences, but that is not exhaustive playable-tag coverage or all policy combinations. Cost: the Task 15/16 complete tag-to-content checklist and authoritative outcomes remain required.
11. **Releasing pending migrations and publishing/activating the 289 proposed versions** — local hypothetical catalogue resolution and in-memory publication are not hosted mutations or release authorization. Cost: reviewed publication/backfill procedure, history/earned-fact protection and final operational acceptance remain open.
12. **Current-main combined integration** — the parent reports main at `b2d275269` with 104 mobile/social/World files and no bounded-file overlap; I did not merge or review that separate current-main delta. Cost: current-main reconciliation, joint verification and final whole-branch review remain required before release.
13. **New remote backup completeness and a fresh restore of this final checkpoint** — inspected recovery metadata and the restored base tree, but did not perform hosted writes or independently reproduce the final yet-to-be-created archive. Cost: the parent must complete byte/hash/expected-parent checks and fresh restoration for the final durable checkpoint.
14. **Fresh complete root quality after reconstruction** — the parent owns the running root gate; this review inspected source and existing receipts without duplicating the suite. Cost: pending gate results and any stdout truncation must be resolved/disclosed before checkpoint completion; original interrupted evidence is not substituted.
15. **The 20 inherited Minor findings** — explicitly deferred by scope and not re-adjudicated or repaired here. Cost: their prior concrete limitations stay on the final ledger and must be carried into Task 16.
16. **Final Task 16 whole-overhaul acceptance, release/deployment state, Atlas and broader Master/world completion** — this is a single catalogue-timing checkpoint, not the required final integrated review or Owner gameplay acceptance. Cost: those later gates and exact release receipts remain open.

## Remaining work and checkpoint

Original Targeting/Move/five editable Basics/Controlled editor→battle→reader/native controller acceptance, remaining distinct earned cycles/full-match balance, hosted publication/concurrency/authority, current-main integration, actual browser/keyboard/touch/AT/mobile/zoom/Atlas and human acceptance remain open. Tasks 15/16 and combat release are unfinished; broader Master/world/Environment and creative-library complexity labels follow combat. No launch ETA follows from this bounded fix.

Save reviewed source/evidence to the existing non-deploying backup branch with expected-parent protection, byte/hash/type/mode checks and fresh prerequisite-only incremental restoration. No hosted content write, migration, publication/activation, main merge or deployment is performed.
