from pathlib import Path
import json,re,hashlib,tarfile,subprocess,datetime,sys
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery');receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
r=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);s=Path(r['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',s)
expected=int((w/'catalogue-timing-test-count.txt').read_text());source=(w/'catalogue-timing-tested-source.txt').read_text().strip()
rootCounts=counts
partial='--partial-evidence' in sys.argv
if partial:
 counts=[]
 for folder in [Path('apps'),Path('packages')]:
  for p in sorted(folder.glob('*/.turbo/turbo-test.log')):
   matches=re.findall(r'Tests\s+(\d+) passed',p.read_text())
   if matches: counts.append((p.parent.parent.name,matches[-1]))
assert r['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert datetime.datetime.fromisoformat(r['started_utc'])>=datetime.datetime.fromisoformat(subprocess.check_output(['git','show','-s','--format=%cI',source],text=True).strip())
nodeLog=Path('apps/web/.turbo/turbo-test.log').read_text() if partial else s
assert 'ℹ pass 7' in nodeLog and 'ℹ fail 0' in nodeLog
complete=('$ turbo run build' in s and '2 successful, 2 total' in s.rsplit('$ turbo run build',1)[-1] and len(rootCounts)==7 and 'ℹ pass 7' in s)
if not partial: assert complete
logs=[];tag='catalogue-timing'+('-reviewed' if '--reviewed' in sys.argv else '-repair-initial' if '--partial-evidence' in sys.argv else '-initial' if '--initial' in sys.argv else '')
with tarfile.open(w/(tag+'-turbo-logs.tar.gz'),'w:gz') as archive:
 for folder in [Path('apps'),Path('packages')]:
  for p in sorted(folder.glob('*/.turbo/turbo-*.log')):
   b=p.read_bytes();logs.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});archive.add(p,arcname=str(p))
d={'source':source,'receipt':r,'counts':counts,'countsSource':'package logs' if partial else 'root stdout','rootCounts':rootCounts,'rootBuildTailComplete':complete,'logs':logs}
(w/(tag+'-fullcheck-audit.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}))
