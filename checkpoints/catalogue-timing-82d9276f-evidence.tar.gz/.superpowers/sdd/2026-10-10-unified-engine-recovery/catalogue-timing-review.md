# Catalogue timing checkpoint — combined review

Base: `93f469d572e1a75e10825e346b587cc20652dde5`  
Head: `77d9c653ba3b37e427dc55f5da418d6d37d29c9d`  
Review resumed: 2026-10-18. This completes the SAME interrupted review seat, not a second review. The unavailable original `71485845b` commit is not claimed as a durable accepted checkpoint.

## Strengths

- `apps/web/src/server/combat/combat-catalogue-timing-compatibility.ts:26–33` makes the surgical correction required: an own root Essence ability overrides the historical nested ability, matching `essenceCombatSkill` (`packages/game-core/src/combat/essence.ts:701`) and both canonical and Master authoring validation (`essence.ts:603`; `combat-content-authoring-service.ts:423`). It preserves the top-level enabled gate and does not invoke runtime usability on disabled authoring records.
- `combat-catalogue-timing-compatibility.test.ts:87–157` checks both directions of disagreement, native and historical canonical envelopes, disabled behavior and input immutability. These are behavioral regressions, not merely assertions that the new branch exists.
- `apps/web/src/server/master/combat-publication-compatibility.test.ts:63–122` exercises the real local policy writer with real snapshot parsing/resolution: incompatible root Automatic content produces no writer call; compatible root Manual content forwards the exact snapshot token once. RPC transport is explicitly simulated. Inspection of `combat-effect-timing-policy-store.ts:34–76` and `supabase-combat-content-authoring-store.ts:261–375` confirms both policy and content publication consumers validate the resolved prospective catalogue before forwarding its token.
- `roster-catalogue-reconciliation.test.ts:71–144` reconciles complete identities, kinds, versions and canonical before digests, all 289 proposed advances, the five retained Basics, full after definitions, enabled state, captured policy, and immutability. All 17 root Essences are compared against the battle selector across registered Controlled defaults. The existing `roster-publication-readiness.test.ts:56–148` supplies actual Master validation for all 294 definitions and local publication/current/pinned-history tests for the 289 advances; the new test is not being treated as a substitute for that boundary.
- `docs/verification/2026-10-17-combat-catalogue-observation.json:2–25` clearly labels the observation as historical and not approval. The reconciliation token is explicitly a local placeholder. The refreshed read-only receipt dated 2026-10-18 again reports zero version/publication/draft rows, policy 7 and absent guarded catalogue RPCs. No hosted operational success is implied.

## Issues

### Critical

None found in the reviewed checkpoint.

### Important

None found in the reviewed checkpoint.

### Minor

No new Minor findings. The 20 inherited deferred Minors remain deferred and unchanged; this report neither fixes nor dismisses them.

## Review method and evidence

Read the review package, bounded brief, Owner brief, relevant parent-plan requirements and all five Review Focus statements, progress/rulings, preservation data and recovery/read-only refresh receipts. Inspected the complete five-file diff and the actual resolver, runtime selector, canonical parser/validator, Master authoring validation, policy writer and content writer consumers. The recovered diff has the same five postimage blob prefixes as the originally inspected diff: `da31840a6`, `c52489ed2`, `0637276eb`, `2ec4ab2f2`, `ec1e682c1`. This supports continuation of the existing review without pretending the old commit survived.

Independently verified current HEAD, clean tracked status, `git diff --check`, recovered base tree `58d1ebd99f349dc6d55f47c5f8e15c248d2bfed9`, all six protected file hashes, unchanged manifest SHA-256 and unchanged deployment-lock blob. Only the timing validator is production code in this range. No source/index/HEAD/branch mutation, hosted operation, extra agent or duplicated suite was performed by this reviewer; only this ignored report was written.

Before interruption I inspected the original six intentional precedence failures, 18/19 catalogue failures, the focused 644-pass transcript and successful web types. Those original receipts are not fresh acceptance evidence for reconstructed HEAD. On resumption the parent reports fresh six targeted RED failures (`834f71e2`), 18/19 catalogue RED failures (`ed1e2f4b`) and focused exit 0 (`0c4df866`) with truncated stdout; fresh full root gate remains parent-owned and running at this verdict. The parent must inspect actual receipts and retain any capture limitations. This review does not claim the pending root gate passed.

Malformed own-root values were considered, not silently ignored: real catalogue consumers validate Essence definitions before timing validation, and canonical validation rejects malformed own abilities. The timing helper's typed input is therefore not the raw untrusted authoring boundary. The new precedence branch does not introduce an unvalidated publication path. Historical nested-only/native behavior and the disabled gate remain in place. No separate defect was identified from those cases.

## Recommendations

Accept this bounded correction once the parent confirms the fresh exact-head quality gate and preserves the final evidence/checkpoint. No repair wave is requested by this review. Retain each decline below in the executor's rulings with its cost; do not turn this local compatibility verdict into Task 15/16 completion, whole-branch merge approval or hosted release approval.

## Declined to judge

Each item is a deliberately bounded non-claim, not a newly discovered defect or a waiver of its eventual acceptance requirement.

1. **Publication-time current Owner edits and policy:** zero-row read-only observations justify the builtin comparison only at their recorded times; I did not assert that those facts remain current when publication occurs. Cost: refresh and reconcile actual content, drafts, policy and relationships immediately before publication.
2. **Hosted catalogue CAS, row locks, atomic rollback and direct-RPC bypass resistance:** the required RPCs are absent in the observation and the new writer tests simulate transport. Cost: actual reviewed SQL/migration and operational concurrency acceptance remain open; exact token forwarding alone does not establish them.
3. **Live selected-character permissions, stale-browser access, expiry and revocation:** no authority implementation changes in this diff and the fixtures do not exercise a signed-in hosted actor. Cost: Task 8/16 actual authority-path acceptance remains required.
4. **Arbitrary malformed captured/pending/summon envelopes and recursive private-accuracy serialization:** inspected the relevant Essence admission boundary, but this checkpoint neither changes nor comprehensively tests every downstream serialized envelope. Cost: Tasks 1/5/7/16 privacy and fail-closed integration evidence remain necessary.
5. **Full current-versus-historical public/battle reader truth:** definition equality and existing local current/pinned tests support bounded immutability, not every reader, missing-metadata fallback or old battle. Cost: the Task 7/16 reader audit remains open.
6. **No-input, free priming, duplicate payment, repeated events and interrupted Move execution:** timing compatibility is admission validation; this production change does not modify execution, payment, movement or turn authority. Cost: the corresponding Tasks 2/3A/4/14–16 runtime and service cases remain independently required.
7. **Every roster cycle, AI behavior, targeting geometry, playability and balance:** comparing the actual selected ability to the timing compiler does not execute each encounter or prove meaningful balance/counterplay. Cost: outstanding distinct-cycle and full integration evidence remains open; the unchanged independent duel matrix was not repeated.
8. **Concurrent build, claim, recovery, reward and settlement correctness:** these services and worker/lock paths are outside the five-file change and not exercised by the new tests. Cost: Tasks 5/6/9/12/16 retain their real race, retry, no-contest and late/repeated-worker gates.
9. **Physical desktop/mobile interaction, native keyboard/touch, long names, accessibility and 200% zoom:** no component/UI code changes here; static/local validation is insufficient evidence. Cost: final real-screen workflow and human/assistive-technology acceptance remains open.
10. **Every gameplay tag's complete editor→publication→execution→reader chain:** all registered Controlled defaults are sampled for the 17 root Essences, but that is not exhaustive playable-tag coverage or all policy combinations. Cost: the Task 15/16 complete tag-to-content checklist and authoritative outcomes remain required.
11. **Releasing pending migrations and publishing/activating the 289 proposed versions:** local hypothetical catalogue resolution and in-memory publication are not hosted mutations or release authorization. Cost: reviewed publication/backfill procedure, history/earned-fact protection and final operational acceptance remain open.
12. **Current-main combined integration:** the parent reports main at `b2d275269` with 104 mobile/social/World files and no bounded-file overlap; I did not merge or review that separate current-main delta. Cost: current-main reconciliation, joint verification and final whole-branch review remain required before release.
13. **New remote backup completeness and a fresh restore of this final checkpoint:** inspected recovery metadata and the restored base tree, but did not perform hosted writes or independently reproduce the final yet-to-be-created archive. Cost: the parent must complete byte/hash/expected-parent checks and fresh restoration for the final durable checkpoint.
14. **Fresh complete root quality after reconstruction:** the parent owns the running root gate; this review inspected source and existing receipts without duplicating the suite. Cost: pending gate results and any stdout truncation must be resolved/disclosed before checkpoint completion; original interrupted evidence is not substituted.
15. **The 20 inherited Minor findings:** explicitly deferred by scope and not re-adjudicated or repaired here. Cost: their prior concrete limitations stay on the final ledger and must be carried into Task 16.
16. **Final Task 16 whole-overhaul acceptance, release/deployment state, Atlas and broader Master/world completion:** this is a single catalogue-timing checkpoint, not the required final integrated review or Owner gameplay acceptance. Cost: those later gates and exact release receipts remain open.

## Assessment

**Ready to merge? Yes for the bounded code change, conditional on the parent verifying the fresh exact-head root gate; no authorization to merge or release the whole branch is implied.**

The correction aligns catalogue admission with the already-authoritative Essence mechanics while retaining disabled, historical and immutable-definition behavior, and the tests exercise the real local consumers and complete proposed catalogue. No Critical, Important or new Minor defect was found; final Task 16 acceptance and the explicitly listed operational/integration work remain open.
