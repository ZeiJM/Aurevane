# Implementation and evidence

Only the shared Master preview fixture and its regression test changed. Native target categories, enumeration and resolution own eligibility; native command preparation owns full legality and payment. Preferred target remains first, Self/unit-actor identity is normalized, and plural selection stops at authored maximum or available candidates. Category-aware placement fixes friendly and Ground recipients and the raw self-envelope overlap.

22 new tests. Focused276/20, native59/4, web types and zero-warning lint GREEN. All294 named Skill reports/HTML unchanged; all136 latest built-in native preview JSON outputs exactly unchanged on frozen452161. Review0C0I0newM. Fourteen inherited Minors deferred.

Initial full root receipt210842919351Z-76dac2b3 exits0 with all8722 Vitest and7 Node checks and complete web package route output, but the root log omits Turbo's completed build summary. Initial audit and package logs preserved before ONE cached exact-source root replay. No source change or third run authorized by this diagnostic. Final replay result is recorded by guarded finalizer.

No native engine, roster, schema, API, controls, CSS, art, publication or execution mutation. Editor preview remains a fixture: native Requirements/resource failures remain truthful, available target population is bounded, and SSR is not mounted/native acceptance. Automatic/Ongoing/event and Manual Resonance editor preview integration remain open.
