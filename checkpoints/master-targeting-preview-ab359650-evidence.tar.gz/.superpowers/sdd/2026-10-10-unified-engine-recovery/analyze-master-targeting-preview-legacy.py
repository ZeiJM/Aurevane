from pathlib import Path
import json,hashlib,subprocess
w=Path(__file__).resolve().parent
old=(w/'master-targeting-preview-legacy-baseline.json').read_bytes();new=(w/'master-targeting-preview-legacy-observation.json').read_bytes()
assert old==new
rows=json.loads(new);assert len(rows)==136
module=(w/'master-targeting-preview-legacy-baseline-module.ts').read_bytes()
assert hashlib.sha256(module).hexdigest()=='1806a9251de5a151d91ba40c7053d48682f2e79b63b9080dd668c4971702fc41'
result={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'prerequisite':'578f755487da3727268498681040f6cffd6a1769','records':136,'allLegacyNativePreviewsExactlyUnchanged':True,'successful':sum('result' in r for r in rows),'retainedErrors':sum('error' in r for r in rows),'rawSha256':hashlib.sha256(new).hexdigest(),'baselineSha256':hashlib.sha256(old).hexdigest(),'baselineModuleSha256':hashlib.sha256(module).hexdigest()}
(w/'master-targeting-preview-legacy-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

