# SDD ledger — plan: docs/superpowers/plans/2026-10-10-unified-engine-recovery.md

## Continuation identity — 2026-10-16 UTC / October 15 Trinidad

Owner: Nick. Controller: current recovered-chat continuation. User explicitly requested exact continuation of the original scope/workflow and confirmed Sol 6.1 Extra High. Keep checkpointed effort-switch pauses in both directions. No product code, hosted mutation or deployment has yet occurred in this continuation.

Isolated worktree: `/workspace/scratch/680b26e4eb86/aurevane`.
Own branch: `agent/overhaul-resume-20261016`.
Resume BASE: `6790f4c9ff9343dee7b39e2f87999c2f1a3d7454`, tree `cd439cd3b2c2b9533f35996dbe644a43aef6790e`.
Fresh main: `29506e29` (resolve full SHA in source receipt); current main is an ancestor of BASE, 55 feature commits ahead / 0 behind after restoring shallow history. Initial no-merge-base result was a shallow-clone limitation, not divergent histories; bounded deepen corrected ancestry. Original checkout remained clean and untouched by product edits; no process had that checkout as its cwd at preflight.

Authoritative recovered handover: `/workspace/scratch/680b26e4eb86/aurevane_chat_recovery/AUREVANE_HANDOVER_2026-10-15.txt`; exact source scope/approvals retained in the companion recovery package. Repository truth and later Owner corrections override dated checkpoint status.

## Carried task state — do not redispatch accepted foundation

| Task | Current carried state / internal consistency |
| --- | --- |
| 1 | Accepted foundation, released through #896; current typed registry is the source. |
| 2 | Accepted foundation, released through #896; preserve current captures/reactions. |
| 3 | Targeting checkpoint and Owner acceptance retained in #899; combine/release acceptance still required. |
| 3A | Move/Basics/auxiliary combat-critical integration retained in #904; final combat gate open. |
| 4 | Controlled/Rewind/readiness combat-critical integration retained in #904; final combat gate open. |
| 5 | Combat publication portions implemented; full create/archive/restore/dependencies remain open. |
| 6 | Full Discipline/earned-relationship authority remains open; preserve native authority now. |
| 7 | Significant canonical readers/privacy implemented; final consumer/combat audit open. |
| 8 | Staff workspace/live authority completion open. |
| 9 | General Players/no-contest completion open; separate urgent timer hotfix is not this task. |
| 10 | Combat editor portions implemented; full category/reference/media/history workflow open. |
| 11 | Combat timing portions implemented; broader Rules/Music completion open. |
| 12 | Events/Live Ops completion open. |
| 13 | Combat-critical integrated evidence retained; full-overhaul acceptance remains open. |
| 14 | IN PROGRESS: all17 class cohorts authored (158 candidate/retained rows); correct17 new shape errors, finish136 pair designs, earlier-row metadata, coverage, and independent gate. |
| 15 | Pending accepted14 manifest plus actual selected mechanics/surfaces/outcomes. |
| 16 | Pending combat release acceptance, then later full-overhaul acceptance separately. |

## Relevant continuation interface preflight

| Producer / consumer | Shared interface | Finding / handling |
| --- | --- | --- |
| T1 / T14–15 | Typed effects, status catalogue, Requirement nodes | Inventory lists19 effects/26 statuses; distinguish derived/system/historical statuses from directly authored ones. |
| T2 / T14–15 | Manual/modifier/Automatic/Ongoing, paid reactions | Real finite cost/clock/counterplay; no event ownership inferred from prose or self target alone. |
| T3 / T14–15 | Plural selection, geometry and per-effect recipient | Preserve canonical geometry3 and native history; no text-only target behavior. |
| T3A / T14–15 | Attached Move and editable Basics | Attached movement is included in Skill price; standalone baselines retained; no extra slots. |
| T4 / T14–15 | Controlled/Rewind and ready-only artwork | No unsupported automatic release or enemy self-Rewind reuse; selected extensions require explicit contracts. |
| T5 / T14–16 | Stable identities, versions, before digests, Owner overrides | Reconcile hosted state at actual publication; candidate design cannot overwrite seeds/live records. |
| T6 / T14–15 | Intrinsic source, earned eligibility and pair identity | Preserve actual IDs/source/unlocks and existing build rules; no speculative classes. |
| T7/T10 / T14–15 | True public/cockpit/editor presentation | Current flags for Automatic-only Skills, conditional previews, modifiers and active Resonance must remain open until actual surfaces exist. |
| T11 / T14–16 | Shared timing policy and compatibility | No independent competing timing source or repeated Rewind reset. |
| T14 / T15 | Complete reviewed candidate manifest | Partial41 cannot be treated as full294 or balanced; design precedes applying/activating new immutable versions. |
| T14–15 / T16 | All-tag observable outcomes and balance | Mechanical preflights are not Level100/whole-roster/no-input acceptance; complete cases required. |
| T13 / T14 release order | Original full-panel-before-roster dependency | Explicit October14 combat-first correction supersedes original unrelated full-panel ordering; combat-critical dependencies remain required. |
| T8–12 / post-combat continuation | Full Master/operations/world scope | Preserve outstanding ledger; combat partial does not close them. |

## Carried findings / release limits

- Latest known #904 Actions:18 successful runs / Living Atlas failure; inspect exact latest failed-run evidence before finalization. Do not weaken peer-motion bounds or assume unrelatedness.
- Inherited Minor M1 native Vite config-loader advisory remains carried to final integration/review until exact current behavior is diagnosed.
- Six hosted migrations listed in #904 remain a checkpoint claim, not a fresh hosted audit. No hosted writes before reviewed release sequencing.
- Last source says41 candidates /20 mechanic preflights; no roster candidate is activated or accepted as final balance.
- Entire current branch and previous checkpoints preserve `apps/web/vercel.json` deploymentEnabled false. Keep this invariant.
- Old source chat's Working display did not establish backend activity; new branch isolates this continuation and remote ref is checked again before backup/finalization.

## Live task ownership

Task14 implementer: `/root/roster_design_continuation`, dispatched on the isolated continuation branch. Exactly one implementer; no helpers. Controller owns coordination and independent review dispatch. Task14 design judgment uses confirmed Extra High in controller; ordinary implementation worker uses Sol6.1 High as the original plan requires. No review seat until the implementer reports a concrete diff.

## Continuation verification and design decisions

- Frozen install passed using Node24 and repository-pinned pnpm11.17.0, receipt `20261016T001856721038Z.log`.
- Focused unchanged-source baseline passed: three core files /100 tests (`combat-definition`, `combat-tag-registry`, `combat-ability-command`), receipt `20261016T002004352936Z.log`.
- Selected Ground direction: retain the three real persistent Ground records/metadata and define a bounded canonical-group bridge for T15; no invented accepted schema key and no publication based solely on native validation. Preserve captured caster, content, origins, source visibility and entry/expiry policy.
- Enemy position-return is not selected; preserve actual once-primed self Rewind. This is a design choice, not a claim that enemy-return is implemented.

## T15 surface preflight — source BASE6790f4c9, read-only

| Interface | Existing source | Remaining exact work |
| --- | --- | --- |
| Manual modifiers | `battle-live-viewer-projection.ts` projects controlled-owner availability; `battle-session-service.ts` projects references and submits explicit `manualModifiers`; Zod already bounds/distinguishes references. | Cockpit contains no consumer of `manualModifierAvailability`. Bind deliberate selection to root/group/actor/version, submit identical selection for forecast/commit, clear stale state, and preserve keyboard/touch plus privacy. Do not create new effect execution. |
| Active Resonance | `combat-action-source.ts` captures exact pair identity; Manual action projection includes active Resonance groups. | `battle-selected-skills.tsx` still renders only artwork/span and `Resonance · Passive`. Complete action/behavior/category/prime/forecast/keyboard/touch in existing special footprint; do not infer active usability from kernel support. |
| Automatic-only Skill | `battle-selected-skills.tsx` always renders Skill artwork as a cast button and uses fallback native costs when no Manual captures exist. | Safe captured activation presentation and non-cast state for equipped Automatic/Ongoing/modifier-only content; do not restore fallback false actions. |
| Conditional/event Master preview | `CombatContentPreviewOptions` has only behaviorId/seed/combatContext; `evaluateCanonicalPreview` quotes Manual command with a fixed scenario. | Bounded typed state controls and engine-issued events for actual Automatic/conditional outcomes, preserving deterministic quote/RNG/privacy boundaries. No arbitrary fabricated prior event or legal receipt. |
| Persistent Ground | `CombatGroundAreaDefinition`, create/advance/entry handlers already capture caster/content/origins/visibility and bound timing/entry ordinal types. `AbilityBehavior` has no Ground field. | Canonical group declaration and compiler bridge to existing handler, typed editor/readers/AI/capture tests; native fallback alone cannot complete selected modular content. |

## Fresh inherited CI inspection

GitHub read at continuation BASE6790f4c9:19 workflow runs,18 success and Living Atlas browser failure. Browser smoke, CI, Skill Engine, Controlled browser, modular reader browser and database suites are successful for that exact BASE. Latest Atlas run38809891021/job116680165388 fails `world-presence-case.ts:552`: actual peer-motion delta0.8305681550415329, required `<0.75`;49 passed,1 failed,82 skipped. This confirms the latest failure's exact symptom, not its root cause or unrelatedness. No rerun, bound change, waiver or World code edit was made. Keep the failure in the final integration ledger and diagnose the actual timing/source path before claiming complete gate success.

## T14 implementer checkpoint

Source audit independently matches all294 before digests. Meaningful completeness RED observed against original41:300 failures/36 passes including253 missing identities (implementer receipt; detailed logs must accompany report). All13 remaining Discipline cohorts authored for158 total rows (136 Skills,17 Essences,5 Basics). Actual validator exposed17 new Line/Circle min-range draft errors; authoring correction underway with validators unchanged. All136 Resonances and earlier-row metadata still pending; no blocker or completion claim. Requested coherent158-row checkpoint commit after focused native/parser checks; full294 completeness must remain honestly incomplete at that checkpoint.

## Atlas artifact diagnosis — bounded read-only follow-up

Retrieved exact BASE failing browser artifact12007939713, SHA256 from Actions5c6003bd97744718eb10c2eb63b57672fbffb8fd008519340879e6f37ef89d22. Extracted native moving-observer samples to private evidence/atlas-base/motion-0.json (duplicate payload motion-1). The failure is peer0:18 observed draws; largest delta0.8305681550415329 over RAF frame timestamps5640.8→5807.5 (166.7ms), paint timestamps5795.5→5880.8. Recorded long task starts5715.5 for96ms and earlier5098.4 for85ms. The largest observed displacement is consistent with roughly4.98 tiles/sec across that long frame gap; this suggests frame starvation rather than establishing a route teleport. Root cause remains unproven: need correlate renderer/main-thread work and live receipt/route continuity under representative physical browser execution. No code/test limit changed and no claim of World acceptance. This investigation is carried to final integration; do not replace the0.75 bound with a guessed waiver.

## Exact-source158-row checkpoint and backup recovery

Task14 checkpoint commit6051477d3f6f9a69831c8412fc8d5ab9d3d077fa, tree534be874e1b171266d072590e979c61622bbed22. Actual record+Ability validators158pass (log20261016T002923515924Z). Full guard316pass/137expectedfail:136missing Resonance identities plus total count (log20261016T002905436365Z). Only3files: proposals/design MD/meaningful completeness test. No temporary export/diagnostics tests committed. Worker continues pair design; task remains incomplete.

Shell GitHub push was initially rejected by automatic review for missing explicit export authorization. Recovered original direct Owner approval R0234–R0235 names ZeiJM/Aurevane backup; current user requests exact continuation. Auth evidence is github-backup-authorization.json. Connected GitHub verified same public repo1335303167/admin+push rights. Same direct push retried with new evidence passed approval but failed with no shell Username/credentials. No attempt to bypass the review or extract credentials. Purpose-built connected GitHub backup instead uploaded verified exact-source Git bundle ff355492f854b092aeaef8a5fe4df046303c027c,108209bytes,SHA256db2455e69297f6165e7413dde8a314c59ed4fe662188409599dbe1181663839e. Bundle preserves exact local6051477d and requires existing BASE6790f4c9. Backup-only commit09559175800464c74d64a6db73de61d29d8bde47 has explanatory README and bundle atop BASE, with Git deployment lock retained. Its tree is6c406f89fded5e947eb91d715894d13ccfbbc987. Verified remote branch agent/overhaul-source-backup-20261016 at09559175800464c74d64a6db73de61d29d8bde47 via git ls-remote. This branch is a recovery archive, not implementation PR or production release; do not mix API-created backup commits with the local implementation ancestry.

Fresh read-only hosted design inventory at2026-10-16~00:32Z: verified projectluazfeupwfgnilohfsya ACTIVE_HEALTHY; combat_content_versions=0,publications=0,drafts=0. Executed in explicit READ ONLY transaction. This confirms no canonical Owner overrides at design time only; mandatory fresh publication-time CAS/Owner-edit reconciliation remains.

## Owner ETA status — October15,20:34 Trinidad

Owner asked eta during active execution. Response: rough45–75minutes to current full roster design+independent review/fixes checkpoint; expressly excludes gameplay integration, balance acceptance, combat live release and broader overhaul. No reliable overall live ETA claimed. Continue bounded work; prompt and truly pause for return to High after Extra High design phase. Implementer asked to report concrete pair progress and flag estimate mismatch promptly.

## Owner scope/ETA clarification — October15,20:35 Trinidad

Owner recalled old chat's roughly6days for full update and asked whether scope was missing. Clarified no dropped scope:45–75minutes was current roster-design gate only; complete roster runtime/surfaces/AI/balance, combat partial release, full Master/Staff/Players/Events/Music, weather/day-night/world and final verification remain. Old multi-day scale may remain reasonable but no revised full-project finish promised. Keep stage/checkpoint, combat-release and full-overhaul ETA explicitly distinct. Active task continues.

## Creative judgment corrections before independent gate

- Full294 draft milestone: all136 pair rows present;589 actual parser/identity/source/before-digest checks pass (worker log20261016T003503079121Z). Completion remains provisional pending coverage/outcomes/metadata/independent review.
- Ruling: runeblade-stormsinger Automatic4MP→3MP was strictly harmful extra payment with no benefit; replace with useful2MP→3MP finite once-per-owner-turn rebate following real paid owner Runeblade Attack, plus actual duplicate/no-input/miss cases. Positive finite rebate does not itself establish an infinite loop; causal root, paid actions and usage govern the bound. Wrong choice costs balance tuning at T15, not weakening runtime.
- Ruling: Renewed Force combat_action_used/after qualifies completed attacks including misses; describe/test that actual trigger rather than falsely claiming a successful hit.
- Ruling: Mercys Edge's confirmed hit still grants its5% recovery when full Barrier absorbs all HP damage, per existing authoritative tests. Correct counterplay text so Barrier only mitigates pressure, and range/accuracy/recovery reduction counters sustain. Preserve Owner's miss-linked HP healing contract.
- Outcome test exposed absent canonical accuracyRule, including earlier41 candidates: changing actor Accuracy alone does not create a hit check when AbilityBehavior.accuracy is omitted. Explicitly author Standard for ordinary hostile damage in new candidates and audit nondamaging hostile effects for a deliberate accuracy choice. No shared default, before version, formula or public private-field boundary changes. Add guard and actual hit/miss tests; parser-valid alone was never balance acceptance.
- Latest historical ETA retrieved exactly: R0569 gives12–20activehours combat partial and24–40activehours full batch. Earlier R0433 gave60–100activehours, so estimates varied. These are historical planning ranges, not a new promised finish. User was told the latest exact values after clarifying multi-day full scope.

## Owner experiential-uniqueness steering — October15,20:46 Trinidad

Owner explicitly repeats that especially Resonances must not feel copied like current ones. This raises the design acceptance check beyond absence of exact duplicate JSON. Existing draft cluster audit found13Manual modifiers with same10AP/3MP→112% and8Ongoing modifiers with same110% payoff under different conditions. Asked implementer to rework repetitive clusters for meaningful pair-specific planning/timing/position/resource/recipient/support/control choices within real supported contracts, and provide a compact retained/reworked cluster rationale. Shared primitives remain legitimate; qualifiers/names alone do not establish experiential uniqueness. Do not rush an independent gate that ignores this explicit steering. Earlier45–75min checkpoint ETA remains provisional and may need revision if uniqueness pass expands materially.

## Provisional full294 checkpoint saved

Commit36ab9b192146ab78228f594d1a15efae4d91d543, exact tree36e64907684a915cb812ec0737436da352d1e465, contains full294 typed draft,19-effect/26-status/8Requirement/4activation-mode coverage,17complexity tiers/4Skill entry loadouts and16real-kernel cases.611focused assertions green (595manifest/coverage+16outcomes), scoped lint/core types/frozen offline install recorded. Node24.1.0dev typings match already pinned repository version; lock diff3importer lines, no runtime dependency. Owner uniqueness rework of21rows remains pending; no design acceptance.

Verified backup-only branch advanced by CAS/fast-forward to7fb7f69cb415e1aee46ab5022fb4c94d289385ca, remote git ls-remote matched. New bundle preserves exact original36ab9b19 objects and requires BASE6790f4c9;256254bytes,SHA256aa5758cc9a66aae5425421901009ecdb84733472746c1cd31067fe1202e6fff5,Git blob475956a7555cf34432187e46bb390fad0dc5edbf. Archive treeea7f46c2ebedbabcb73ddea60c6e3dc8ebc76b33. Earlier605bundle retained. Backup is not a runtime activation/implementation PR/deployment.

Main/source reconciliation2026-10-16~00:47Z: main still29506e293e81abef1b0b8a46099618ab3ae3f0ae and original904branch still6790f4c9. No newer overlap found. Fresh finalization check still required later.

## Whole-pair identity audit expansion — Owner October15,20:53

Owner repeats that Resonances define combinations and must not be copy skins. Implementer has authored repeated-bonus rework and kept611checks green; remaining work is explicit all136 kit/build/turn-decision identities, scalar-stripped functional collision audit, concrete per-pair outcomes and honest unlock/capacity discussion. Estimated additional15–25minutes before independent review; original checkpoint range remains provisional but upper bound currently plausible. Controller asks original21 cluster IDs/counts to reconcile with an additional repeated active heal/attack rework. Crystal Impact must have present-day decision/counter distinction; future Armor bypass cannot justify current uniqueness.

Canonical completeness guard must reject accidental missing after.ability for every new non-Ground Skill/Essence/Resonance; three provisional Ground rows and exact retained Basics are deliberate exceptions, not implicit legacy fallback permission. Confirmed-hit HP recovery vs full Barrier and independent nondamaging recovery remain distinct actual contracts. Avoid invented all-new-player4Skill ownership when real mastery unlocks apply.

## Pre-review paid-Automatic no-op findings

Controller read actual new Consecrated Form: after an owner Ironfist attack andHP≤60%, it paid4MP to Cleanse even without a removable affliction. Requested actual Any status-presence over Cleanse-removable statuses including policy-added Suppress, preventing a no-op payment/usage consumption. Renewed Force also paid4MP for4%HP at full HP; requested deliberate wounded eligibility. Implementer must test no-benefit fullHP/unafflicted no-spend, qualifying real benefit, miss, duplicates and owner binding, and audit other paid Automatics. No generic engine rule change or fake successful-hit claim. Keep these open until actual final diff/tests resolve them.

Coordination/archive backup verified at84770fe991319c130bb7bcf40d96de87e5ff82f7 with branch CAS/fast-forward and git ls-remote match; preserves then-current ledger, nextTask15 preflight and verification receipts alongside exact605/36ab source bundles. Later rulings continue locally until final accepted checkpoint backup.

## Owner asks pre-creative completion status — October15,21:03 Trinidad

Owner asked whether everything from previous chat was complete before creative balance. Answered explicitlyNo. Foundation completed/released; targeting/Move/editableBasics/Controlled/readers substantial saved implementation but combined acceptance open. Remaining combat controls/previews/roster integration/balance must finish before combat release. Broader Master/Staff/Players/Events/Music/world/environment remain outstanding under later Owner combat-first partial-release order. Reaching Task14 design never closes those tasks. No cancellation or reorder instruction received; active design gate continues unless Owner directs otherwise. Carry this exact distinction into every checkpoint/final handoff.

## Whole136 audit status reported

Implementer reports actual earned2+2 four-Skill kit, combination rationale and exact turn/payoff/counter per pair; scalar/cosmetic-stripped signatures found additional clusters and reworked Ember Watch, Brittle Conductor and Steamfront. Crystal Impact changed to a current Pull→Physical hit→Root transition on a Chilled target at2–3tiles rather than relying on future Armor/formula distinction. Forecasted Thunder now uses self-obtainable Conductive, and owner Burn became optional Smoke from the Scar payoff. Reports remain provisional pending final source/evidence and independent review. Paid-Automatic no-op gates/outcomes are being added; still open until verified.

## Final pre-review evidence and continuation — October15,21:06–21:13 Trinidad

Owner clarified targeting completion then said “aite carry on.” Continued current creative gate; no scope cancellation. Targeting has accepted backend/interaction checkpoints but combined new-consumer and desktop/mobile/keyboard acceptance remains open.

Implementer final focused verification receipt20261016T011107539690Z reports823passing tests across6files:733manifest/coverage/real-pair-capacity/public-projection guards;26actual candidate kernel outcomes;64retained Requirement/Ground/confirmed-hit/timeout contract cases. This is not823runtime outcomes or whole-roster balance acceptance. Every pair’s actual2+2 four-Skill kit validates in bothPrimary orders; unearned kits are rejected. Source report/final commit and independent gate still pending.

Final lint/typecheck initially collided on recorder timestamp011336040804Z when batched. Worker identified the collision, discarded the shared log as evidence and is rerunning sequentially with distinct receipts. Both original commands exited0 but collided output is not accepted proof.

Fresh remote read at~01:13Z confirms main29506e293e81abef1b0b8a46099618ab3ae3f0ae,904source6790f4c9ff9343dee7b39e2f87999c2f1a3d7454 and backup archive84770fe991319c130bb7bcf40d96de87e5ff82f7 unchanged.

## Owner reiterates entire-class rebalance — October15,21:16 Trinidad

Owner explicitly says every Essence and all8class Skills need rebalancing for every class. Confirmed whole17class scope:136class Skills+17Essences, alongside136Resonances and5reviewed editableBasics. Full294manifest coverage is required; Resonance uniqueness attention does not narrow the overall creative/balance scope. Subsequent actual runtimebalance must assess every complete class kit and Essence, legal4Skillchoices and mixedbuilds, not just pairedResonances. Reiterated to implementer; carry to independent reviewer and Task15/16dispatch. No new cancellation or release reorder.

## Owner makes combined combat acceptance an explicit release gate — October15,21:19 Trinidad

After reconfirming that Targeting/Move/editableBasics/Controlled/sharedreaders remain open, Owner instructs “ensure its done before things go live.” Root confirmed these exact systems must pass combined acceptance with the actual new roster before combat deployment. This reinforces existing combat release prerequisites; it does not cancel the later combat-first ordering for broaderMaster/world. Do not activate/publish/deploy the roster merely after Task14 design. Carry as an explicit Task15/16/release gate.

Pre-review scope gap confirmed by worker:32Skill+4Essence rows from original41 retained generic acceptance summaries despite individually typed mechanics. Worker is replacing all153classSkill/Essence plans with actual ordered outcomes/costs/recipients/clocks and individual tactical counter/opportunitycost rationale; estimates10–15minutes before report/commit. All remain planned unless actually executed. Final distinct pre-correction receipt20261016T011535116785Z has824tests (734manifest+26candidateoutcomes+64retainedcontracts), replacing earlier823count because a five-Power-exception guard was added before that run. Any later metadata edits need the relevant final verification before review.

## Pre-review complete-Essence creative check

Controller read all17actual Essence Ability definitions. Hundredfold Rush and Sevenfold Cut currently share Move1→melee Physical multipacket20Power with one2500coefficient, differing only packet count3vs7 and price. Requested a supported class-cycle decision/payoff/counter distinction or actual kit interaction evidence; scalar/packetcount rhetoric alone is insufficient. This remains open before independent gate. Other representative Essence differences include chosen immediate-vs-scheduled support, multicommand shared-cooldown rescue, reserve-sensitive AoE, selected Mark payoff, delayed Root and Controlled Line; these observations do not replace independent full153class/136pair review.

Focused unchanged-source recipient risk check: Tidal Crown authors primary-unit with maximumSelections3; combat-targeting-shapes.ts canonicalCombatEffectRecipients lines59–66 deliberately promotes primary-unit→affected-units for plural selection. Thus primary-unit alone does not prove a first-recipient-only design defect. No runtime change made; actual per-recipient outcome acceptance remains required.

## Owner widens Resonance creative freedom — October15,21:24 Trinidad

Owner explicitly permits use of new/underused tags, deliberately requirement-free Resonances and unusual outside-the-box combinations, provided balance and uniqueness hold. Root confirmed cost/timing/cooldown/slot/counterplay can balance an immediately usable pair; do not impose a Requirement solely to distinguish otherwise identical designs. Passed to implementer. This is steering within authorized creative scope, not an invitation to invent unsupported handlers or cram unrelated tags into one record. Carry to independent experiential review and actual balance acceptance.

## Essence distinction selected, verification pending

Worker proposes retaining Ironfist immediate Move1→three-packet rush, while Edgedancer Sevenfold Cut requires existing adjacency, no attached approach, one scaled immediate packet and six fixed captured next-round packets. This creates a current-versus-future pressure and paid-exit choice.75AP leaves25AP, permitting one ordinary20AP terrain point if legal, not30APGuard (worker corrected own draft sentence). Root accepts the direction subject to real queue/JSON/terminal/source-removal outcomes, exact captured-recipient behavior and truthful initiative-dependent counter window. Do not invent later accuracy rolls, pursuit/reacquisition or a guaranteed intervening turn for every initiative position. Independent gate must verify final definitions/evidence.

## Class-plan and Essence correction checkpoint

Worker reports all153classSkill/Essence plans now individually authored, with specific state/payoff/counterfixture/opportunitycost and generic-carryover guard. Two design files764pass:735manifest+29actual candidate kernel outcomes. Final six-file combined receipt pending (expected828 including64retainedcontracts); do not count an expected run as executed.

Sevenfold amendment actual outcomes: opening18HP then six captured next-round2HP packets; separately paid20AP exit leaves5AP from the25remainder; JSON restore; inactive source retains already captured queue; preboundary Barrier absorbs all six packets; terminal turn command rejects with no mutation. These are controlled mechanic fixtures, not Level100/class balance. Worker final hygiene/spec/report/commit approximately5minutes; independent fullrange gate still pending.

## Owner reconfirms actual description surfaces — October15,21:32 Trinidad

Owner asks whether updated battle descriptions, SkillManagement previews and effect popup descriptions are included. Root confirms yes: battle Skill/Essence/Resonance descriptions/forecasts; actual SkillManagement cards/previews; effect descriptions/linked terms/popups with applicable real magnitude/stacks/remainingduration. These must describe the same executed captured mechanics and receive final new-roster consumer audit as part of the combat release gate. Existing shared reader migrations do not prove all consumers already pass. Carry to Task15/16 and release checklist.

## Owner description voice requirement — October15,21:34 Trinidad

Owner explicitly requires easy-to-follow, nonrobotic, simple plain language. Root confirms natural concise player sentences explaining actual action/recipient/condition/result, required exact values/brackets and consistent characteristics, with unfamiliar terms explained through accessible linked popups rather than raw internal rule trees/tag dumps. Readability and mechanical truth both belong to final actual battle/SkillManagement/effect-popup audit. Example style uses real UnbrokenStrike confirmed-hit5%HP recovery; it is not a new mechanic or completed UI claim.

## Owner coordinated next-update confirmation — October15,21:34 Trinidad

Owner asks whether all just-discussed work goes live together with next update. Root confirms planned coordinated combat release: full class/Essence/Resonance rebalance, finished combat systems, updated battle descriptions, SkillManagement previews and effect popups, all after combined acceptance. BroaderMaster/world remains the following stage under existing combat-first order. Do not split unreadable/stale descriptions into postrelease cleanup or infer that this answer makes current design live.

## Owner reconfirms effect/value colour — October15,21:34 Trinidad

Owner asks whether effect names use the same colour as effect Power in brackets. Root confirms exact original R0478 requirement: effect/tag labels use the same orange as bracketed values wherever referenced, including Skill/Essence/Resonance battle/public/SkillManagement previews and effect popups. Include this in actual shared consumer display audit before coordinated combat release; no claim current surfaces already pass.

## Full committed Task14 deliverable and independent gate

Implementer DONE_WITH_CONCERNS: exact headc5d942ae7d389cc2ffbe5319c192520b0d30af03,tree1c1031375ce4ffa91047ab37a43ad11e88152875,clean worktree. Entire task range6790f4c9..c5d942ae includes6051477d/36ab9b19/c5d942ae. Complete294records;153specific class plans;136realpair identities;5exact retainedBasics with concrete nativeplans;1520plannedcases. Final828tests across6files:735guards+29proposed outcomes+64retainedcontracts, distinct final receipt20261016T013200178188Z. Types/lint/format/frozenlock pass, fullreport task-14-report.md and committed docs/verification/2026-10-16-complete-roster-design.md. No runtime activation/hosted write/deploy. Concerns are disclosed pending design review and actualTask15/16surface/Ground/AI/balance gates.

Official fullrange review package generated: review-6790f4c9..c5d942ae.diff,5000980bytes,3commits. Single fresh combined reviewer /root/task14_design_review dispatched on Sol6.1High, fork none, binding brief/context/report/constraints and all latest Owner steering. Read-only/nohelpers/no duplicate passing-suite runs. LargeJSON may be consumed programmatically in compact semantic projections while every294design/153classplan/136pair is judged. No acceptance yet.

## Complete-design pre-review remote recovery checkpoint

Verified exact-source bundle for c5d942ae7d389cc2ffbe5319c192520b0d30af03:441663bytes,SHA256a6d9ac44e9932c843d1802d97c75d7ae29cb1dd85166529b41bbddaa6a865458,Gitblob48bbb97bd201ec2e685e1d7c175fc8b53832602f; git bundle verify passes,requiresBASE6790andadvertises refs/checkpoints/roster-c5d942ae. ConnectedGitHubarchive advanced with expectedSHA/CAS and noforce to deec9059d5ee06f286cf6f3bb789fd74607f2c59,treea9960d6148f06859a421e3c79c641d5cc2d87c00. Remote git ls-remote confirms exactarchivehead; original904branch6790andmain29506unchanged. Archive includes fullsourcebundle plus currentledger/preflight/report/verificationreceipts/metadata, explicitly independent-review-pending. It is not an implementationPR/runtimeactivation/release. Earlier605/36abbundles retained.

Controller read actual final828test log and distinct type/lint/format output, independently matched manifestSHA256fa70a6f2dc14bf9c5f5d799d6d1477ef3bf2a5572d44be6799180069347235b3 and currentfalseGitdeploymentlock. No redundant suite rerun. Reviewer has read brief/context/report/nondatachanges and is consuming full294semantic projection and pair/class plans once.

Latest Owner21:35 says priorchat/handover and all confirmed requirements remain scope, then carryon. Root reconfirms fullscope under agreedcombat-first order and continues active review.

## Owner brevity requirement — October15,21:44 Trinidad

Owner says effect-description writeups must not be too verbose. Root confirms short, scannable, natural descriptions: main effect first, then only necessary conditions/values/timing; no filler or repeated explanation. Preserve required mechanical truth and accessible concise details. Add to actual battle/SkillManagement/effect-popup reader acceptance and coordinated combat release.

## Independent full review FAIL and fix round1 dispatched

Reviewer /root/task14_design_review completed all294designs,153classplans,17cycles/tiers and136pairs. SpecFAIL/taskqualityNeedsFixes:4Important pair-versus-own-equipped-Skill redundancies; noCritical/minors. Exact report saved task-14-review-1.md. BorrowedFormula duplicatesQuickHands at worsecost/gate; PursuitAngle repeatsFlankingCut with lowerPower/higherMP/Mark; PiercingInscription repeatsAimedShot worseprice/Power/clock with futureArmoronlydistinction; BurnThicket requiresMark/Poison for inferiorCinderBolt. All4mustresolve; independentcooldown ordifferenthash notnewpairidentity.

Fix round1/5 resumed originalworker with exactreport/verbatimfindings, FIX_BASEc5d942ae. Scopeall4together: realpresentdaychoices, consistentmanifest/audits/coverage/plans, actualtargetedkernelcases inroster-design-outcomes.test.ts andmanifestguards/loadouts, relevantaffectedchecks, appendedfixreport andcommit. No newreviewseat until concretefixreport/diff. Rootnotfixingproductsource.

Cannot-verify items resolved by controller scope/evidence: actualcontrols/previews/Ground/Librarypresentation/fullAI/PvEPvP/Level100balance remain explicitT15/16gates and mustnotbeclaimedcomplete; currenthostedinventoryread0/0/0at00:32design-time only; remotesfreshlyverifieddeecarchive/6790original/29506main. No missingTask14runtimeactivationrequirement.

## Owner numeric-prose clarification — October15,21:45 Trinidad

Owner says apartfromdamage no need to reference values in descriptions because values already appear inSkillEffects. Root confirms descriptionprose explainsinteraction/condition without duplicatingnumbers; damage values may appearwhereuseful, othernumbers remaininstructured effectdetails. This supersedes root's earlier5%recovery proseexample as desiredstyle. Preserve exacttyped numericEffects/Requirements/characteristicentries, bracket/orangestyling, and actualliveinstancemagnitude/stacks/duration fields; do notdeleteauthoritativevalues orreplacepreciseeligibilitywith prose-onlymechanics. Avoidrepetitionbetweenproseandstructuredentries in actualbattle/SkillManagement/popupdisplayaudit.

## Owner timing-prose clarification — October15,21:45 Trinidad

Owner also says timing already has its own place inSkillCharacteristics and should not be duplicated in prose. Root confirms timing stays in structured characteristics; description explains action/interaction without repeating timing/effectvalues alreadyshown. Keep actualtypedclocks/triggerconditions and requiredcharacteristicentries precise. Passed bothnumeric/timingprose refinements to activefixworker for amendedrecords and Task15consumer audit.

## Fix1 directions and final-prose boundary

Worker verified all4reviewed designs were dominated by kittools and is implementing actualdecisionchanges: Aetherist/Shadehand sacrificesSelfGuarded forMP+Covert; Edgedancer/Farstrider Move2→Pull2markedquarry fromreachedorigin, nodamage/Blindside; Farstrider/Runeblade spendsMark forenemyMPdrain+Suppress; Cinderweaver/Wildwarden spendspriorPoison onmarkedquarry forFirehit+briefRoot. Root acceptsdirections subjecttoactualStandardhit/order/previousstate/targetlanding/costtests, obtainable2+2kits andcollisionaudit; independentfixreviewstillrequired.

Ruling: latest Owner concise/nonduplicative description style is mandatory beforepublication andactualconsumeracceptance. Currentmanifestpublicexplanations aremechanicallyspecific explanatorydrafts; rootcounted262/294descriptionRefswithdigits, so4newproserowscannotbeclaimedwhole-rosterstylecompletion. Preserveacceptedmechanicaldesign andexactBasicrecords atTask14; fullwordingrewriteandactualdisplayaudit are specifiedordinaryHighTask15work. Thiscosts a deliberateeditorialpassbeforelive; ifwrongearlieruserstyleacceptanceisnotmet untilthatpass, so blockrelease ratherthanclaimcompliance. Workeraskedexplicitdurableboundary, notblanketExtraHighrewrite. AnyactualBasicwordingchangethatrequiresrecordpublication appendsa completeimmutableversion whilepreservingmechanicalbaselines/history; no cosmeticversionjustforaccounting.

## Revised combat-live planning range — October15,21:51 Trinidad

Owner asks ETA until live. Root provides revisedprovisional16–30activeworkinghours acrosssessions (roughly2–4fullworkingdays) for nextcombatrelease only, basedonremainingcontrols/Ground/typedpreviews,fullrosterbalance/AI,description/displayupdates,combinedacceptance/releasechecks. BroaderMaster/worldfollowsseparately. Thisisplanningrange, notcalendarpromiseorbackgroundexecution; narrowafterfirstintegratedrostertests. Previous45–75minuteswasdesigncheckpointonly andhasrunoverbecause4independentcreativefindingsrequirefix/re-review. Historical12–20combatand24–40wholebatchestimatesarenotnewdeadlines.

FullreviewreportandlatestOwnerstyle/releasegates backedupbyCAS onarchivefdd35fcffa158ef697ba4404e0eeab0e43e9c5d2,treeab04536af532275534573cdd67e3ef909f20d892. Thisbackup explicitly recordsreviewfailed/fix1inprogress; c5dsourcebundle remains recoverable.

## Fix1 committed and ready for scoped re-review

Worker DONE_WITH_CONCERNS at a8df18ef3730795bda29510f9ecde40bccefa8c0,cleanworktree. Rootread appendedfixreport: exactly4afterdefinitions changed, all294identities/136kits/5exactBasics preserved. Actualtargeted777passed/2files (736guards+41candidateoutcomes) at20261016T015447519960Z,with12newfixscenarios;64unchangedcontractsretainearlier828evidence, nofresh841claim. Types/lint/format distinctreceipts pass. CurrentmanifestSHA256584f45d835bbf7b811a354c33e6618cd2cecb46abdbf5110946070b851f3fdbc. Cases1515planned. Empty-outputexit0testlogdiscardedandverboseproofretained.

Correction to root's earlier shorthand: PursuitAngle's preservedactualpair is Edgedancer/Wildwarden (resonance.edgedancer-wildwarden.linked-sequence), notEdgedancer/Farstrider. Workeranddefinitionsusedthecorrectstablepair; no sourceidentitychange. Otherfixpairs Aetherist/Shadehand,Farstrider/Runeblade,Cinderweaver/Wildwarden.

Officialscopedreviewpackage review-c5d942ae..a8df18ef.diff,269876bytes,1commit. Freshscopedre-review dispatch follows onlyfourfindings+newfixbreakage, originalbindingsandlateststyle/publicationboundaries. User21:53continue isactive-tasksteering, notconfirmationofaneffortswitchthatwasnotyetasked. RootExtraHighphasecontinuesuntilcleancheckpointthenrealreturn-to-Highpause.

## Reviewed design accepted and workbook delivered — 2026-10-15T22:17:16.705796-04:00

Scopedreviewer /root/task14_fix1_review: all4findingsADDRESSED, noCritical/Important/Minornewbreakage, nooutofscopenewobservations. Exactreport task-14-fix1-review.md. Verifiedactual4newchoices, matchingkits/audits/coverage andoriginal777verboseproof+distincthygiene+manifesthash. No suitesrerunbyreviewers.

Task14: fix round1/5 (4addressed,0open; commitsc5d942ae..a8df18ef).
Task14: complete (commits6790f4c9..a8df18ef, reviewclean).

This iscreative/mechanicaldesignacceptanceonly. T15/16actualruntime/surfaces/Ground/AI/whole-rosterbalance/publicationandallcombinedcombatacceptance remainpending; currentprose draftsrequirelatestOwnereditorialpass. OriginalbroadMaster/worldscopepreserved.

Owner22:01requestedcompleteExcelpreviewthencontinuation; createdAUREVANE_Roster_Update_Preview.xlsx,7tabs/17Disciplines/158SkillEssenceBasicrows/136Resonances/297commands/604effects/294beforeafterrows. All294before-source digests independently matched inventory; reviewedmanifesthash584f45...fdbc. Summaryformulasrecalculated136+17+136+5=294; error scan0; all7sheetsvisuallyreviewed; nativeXLSXfilters/frozenheaders+identifyingcolumns/numerictypesverified; noauthoringaccuracyfieldsorunresolvednameRefs. NativebeforeTriggeredResonancesdisplaytheiractualsetup/trigger/result ratherthan inventedmanualcasts.190076bytes.

Workbookcreatedpersistentlyaslibfile_60fac1def614819199574a95f9b5b505,file_0000000038c481f594db0298d235750e,version0;localpath/workspace/scratch/680b26e4eb86/outputs/aurevane-roster-preview/AUREVANE_Roster_Update_Preview.xlsx. Localidentityhelper succeeded. Userreceivedclickablefile; sourcea8df18ef designpreviewnotfinalbalance. Update sameworkbookidentityaftermateriallaterbalancechangeswhenneeded, preservingversionhistory.

Finalreturn-to-Highpause pending savedcoordinatorcheckpoint/recoveryarchive. Owner22:01continue-afterExcel doesnot explicitlyrevokepreviouseffortpauserule; completeartifactandcheckpointthenpromptrealHighswitchbeforeT15.

## Owner confirms return to High — October15,22:17 Trinidad

Owner: “ok we ON HIGH continue.” RootacknowledgesexplicitHighswitchconfirmationandcontinuation. TheboundedExtraHighcreativegateiscomplete; no secondpermissionquestionorfinalpauseisneedednow. FinishexactacceptedcheckpointbackupthenresumeTask15ordinaryimplementationonHigh. Futurecreative/architecturalExtraHighneedsstillrequirecoherentcheckpointandgenuineprompt/pauseunderpersistentOwnerinstruction.

## Task15 High implementation continuation — canonical Ground milestone

Owner confirmed High and explicitly continued implementation. BASE1876210d89d80e6b02de4065d2fc9233041ecb3f; isolated branch remains agent/overhaul-resume-20261016. git fetch/ls-remote confirms main29506e293e81abef1b0b8a46099618ab3ae3f0ae unchanged before edits. Scope is one coherent Task15 extension, not Task15 completion or roster activation.

Ruling: execute specified Ground extension inline as the single implementer, with one fresh combined review of the entire milestone — the existing plan/accepted design already specifies behavior and the executing-plans skill supports inline execution — cost if wrong is weaker per-step independence; fresh milestone review and final combined release review remain required.
Ruling: Ground entry retains the existing immediate native entry pulse and per-cast/per-recipient/turn claims; area activation governs when entry begins — do not introduce a second delayed queue for an entered active area — cost if wrong is a design expectation mismatch; cast packet timing and captured area timing remain explicit and tested.
Ruling: reject Pierce as a selected persistent entry packet until a specialized entry equipment-Armor resolver exists — converting it to ordinary damage would silently discard its authored penetration — cost if wrong is a narrower authoring combination; the three selected designs contain no Pierce and all ordinary/cast Pierce support remains.

Implemented additive schemaVersion1 group.groundArea with stable entryEffectIds; Ground-only/finite/registered-preset/unsupported/Controlled validation; final canonical native packet ordinal mapping; captured entry origins, cast eligibility and timing; persisted JSON alignment/value checks and native entry propagation; shared native editor controls in canonical group editor and shared Target reader; no roster/content/hosted mutation.

Meaningful RED→GREEN receipts: parser unknown-field-only failure022625→67checks022709; missing captured entry metadata and forged metadata022824→69checks023200; actual editor/Target missing controls023228→35checks023324; unsupported repeated Pierce023251→26checks023326. Test-fixture mistakes and type errors are retained in their own failed logs; no production behavior was changed to accommodate those mistakes. Exact accepted three Ground plans plus real captured AI choose/commit pass in30checks023632; PvE/PvP preview/public projection19checks023507. Full pnpm check running. Review pending. Actual protected browser authoring/publication and whole-roster balance/integration remain open.

Excel download follow-up: original workbook was intact and already saved under libfile_60fac1def614819199574a95f9b5b505. Re-exposed exact byte-identical XLSX at /mnt/data/AUREVANE_Roster_Update_Preview.xlsx; Owner thanked and requested carry on. No replacement design or duplicate Library identity created.

Ground combined review completed against original snapshot; report task15-ground-review.md. Two Important findings: conditional-entry DoT/resistance consumers ignored eligibility, and invalid intermediate Ground drafts hid removal controls. Both fixed in one pass with RED→GREEN (Poison/Burn024227→83checks024247; resistance024500→65checks024519; editor024420→33checks024521). New native resistance guard has no effect when historical eligibility masks are absent. Source edits then frozen for final pnpm check.
Final: minor (deferred): shared Target delivery text should identify the selected repeat subset for general groups with cast-only unit packets. All selected3repeat all applicable unit effects; carry to existing Task15 display audit before release.
Final: Ruling: reviewer-declined delayed queue/Pierce implementation and full-roster/hosted acceptance — native immediate entry and explicit unsupported repeated Pierce remain selected; all whole-roster/protected-browser/publication/release gates remain open — cost if wrong is an expectation mismatch or narrower entry authoring, not permission to claim those gates complete.
Final full check running after fixes; do not report prior full6987 as post-fix. Committed verification report prepared at docs/verification/2026-10-16-canonical-ground-groups.md. No new source has been published/activated.

Next consumer source preflight (read-only): BattleSelectedSkills currently gives Resonance nonbutton artwork and literal Passive; battle-experience.tsx only includes runtime.essence in special action lists, descriptor and essence hotkey. Actual owner manualActionTargets already supplies authoritative group costs/cooldowns/report/geometry/Controlled. Reuse those for active Resonance without new slots/art footprint. Automatic-only Skill cards currently fall back to native costs/cast; make truthful noncast states and guard hotkeys/descriptor from phantom native fallback. Explicit modifier projection exists via snapshot.manualModifierAvailability; player selection still absent. Do not mistake these source notes for implemented controls.

Task15 Ground milestone: complete as bounded implementation checkpoint, commit ecdfad4325fa72b00a21049158fd898901939cbf, tree72d35ea20c24c6e8f62fa490cb2c40451f56fcb9. Post-fix full pnpmcheck exit0,6992Vitest+7Node, format/lint/type/build, exact receipt20261016T024614924223Z (02:46:14–02:48:58Z). Fresh-main finalization confirms29506unchanged/ancestor; worktree clean; Vercel Git deployment lock retained. Both Important review findings fixed with RED→GREEN and final fullsuite; Minor subset wording carried to display audit. This is not entireTask15 completion or combat activation/release. Next-controls source map task15-next-controls-preflight.md. Preparing recovery-only remote bundle; do not conflate API archive commit ancestry with implementation source.

Remote recovery checkpoint preserved through connected GitHub, with exact Git blobs matched before tree creation. Source bundle486299bytes/SHA25668dee86a9a180d7998911a8694aff4aaf5d6f9188359ae87d03e569e2d038253/Gitblob60df2a91449ac6d8c2e87fd88d1d5ba4f7de233b; evidence72236bytes/SHA2565400f4339590ea658e0e44d3a571030cc2b266ad7fd3e25f1d7425c2774fc0f5/Gitblob6513772d3f1fcc23262b03a3692b9dd8949f99f9. Archive commitb0383d6844515b2153b25c298a6b0c4c0bb79a8f/tree900bbf7e23451d53b38072ff4c50c8cc581748cf extends exact previous archive037e8553a4cf309c8735d25523357b21f9958425; update_ref used expected_sha and forcefalse. checkpoints/LATEST.md explains restore prerequisiteBASE6790, exact advertised refs/checkpoints/ground-ecdfad43, source ecdfad43 and all remaining gates. Archive is backup-only, original source ancestry/PR904 and main untouched. Metadata ground-checkpoint-bundle.json and connected tool receipts identify all values. Read remote actual ref before reporting backup complete.

## Task15 active special/noncast controls milestone — High, in progress

BASEecdfad4325fa72b00a21049158fd898901939cbf. Ground checkpoint is accepted and remotely backed up; preserve it. Actual source/diff now adds one safe shared adapter for owner-captured Manual Resonance targeting/cost/category presentation, active special artwork controls in existing footprint, authoritative category in owner-only Manual projections (optional in public historical type), controller category menus/target descriptor/keyboard routes, and truthful noncast Automatic/Ongoing/Modifier states with canonical full information instead of stale native readers. No new execution queue, battle slot or endpoint.

RED cards025237→18checks025426; fail-closed canonical missing-Manual reference025527→35checks025710; new owner-only classification projectionRED025720 then fix; noncastEssenceRED025806→35checks025848. Remaining focused74checks030019pass; webtypespass025938; proper web-scoped ESLint maxwarnings0pass030110 (earlier root ESLint command ignored app files; not accepted as lint evidence). Initial property-placement/type mistakes are preserved in failure logs. No complete UI/publication/balance acceptance implied. Broad quality and independent milestone review still pending.

Controls combined review: task15-controls-review.md,0Critical/1Important/2Minor. I1 noncast information shortcuts were behind command gates during opponent/terminal/execution-lock states; extracted the actual slot dispatcher and moved its information route before command-only gate, retaining text/modal/repeat/browser-modifier guards. RED030859 (5failed/1passed) → GREEN47checks030921, webtypes030927pass. Earlier full030213 failed only one exact authority DTO expectation; added classification:attack without loosening assertions,26checks030428pass. Final post-fix full pnpmcheck exit0,7009Vitest+7Node,format/lint/types/build,receipt20261016T030942263491Z,03:09:42–03:11:42Z. Product source frozen throughout. Existing Vite native config advisory remains. Fresh main fetched29506unchanged/ancestor, deploymentlockfalse preserved. Report docs/verification/2026-10-16-captured-ability-controls.md.
Final: fixed I1 — blocked-state noncast readers and enabled/disabled command callbacks RED→GREEN plus controller guard-order regression; final7009+7green. No reviewer rerun or duplicate broad suite.
Final: minor (deferred): M1 canonical Manual Resonance with no active owner reference must say Unavailable rather than Passive; carry before-release display audit.
Final: minor (deferred): M2 captured selected-group attack/recovery semantics must drive Resonance targeting highlighting/category presentation; actual target/command identity remains correct; carry before-release display audit.
Final: Ruling: review-declined browser/physical-layout and complete-roster acceptance remain open — existing artwork/slot geometry is preserved in shared desktop/mobile PvE/PvP code, but static renders and unit gates cannot prove the physical flows; cost if wrong is unobserved interaction/layout failure, so coordinated release remains blocked on those actual checks. No hosted operation, roster activation or release.
Controls checkpoint is bounded source/test completion only; Task15 as a whole is still open. Next explicit modifier preflight found a downstream contract gap: current Controlled prime accepts no manualModifiers and captures no bundle, despite the accepted full-bundle contract. Do not add a picker that silently changes attachments at release; implement/reconcile this existing specified contract before claiming Controlled+modifier integration complete. No new architecture is authorized or needed without tracing the current behavior.

Controls checkpoint committed02628b541e3aaf3d7a1bf1d8d9508abdf2d34cd3/tree8fc9cb0fe924e392695548519b5f194640c79e6d,cleanworktree. Backup-only archive verified at8a2d1b1b3f7a2288572c970c4b54d19b452955f9/tree29d0e468372218ca596f0c84fcd336bfbe0c45e2 by gitlsremote after expected-SHA nonforce update. Source bundle499174bytes/SHA256b65eba074dca42c6fdf44707bd1a77f462dbad090157207a9978ba2a35436072/Gitblob5d3aac08fc1161295eb65233035c3881f73487e2; evidence67304bytes/SHA2564ad647dd9457a0fb66be6bcc56417d752edb07d9327e970fc06f9c7907fd3fe7/Gitblobfa0698b5ad0495ea6861dd3b32ab7fbf78e22dc8. Bundle verify requiresBASE6790, advertisesrefs/checkpoints/controls-02628b54. Main29506unchanged. Archive not implementation ancestry/release.

## Next bounded Task15 milestone — Controlled modifier bundle prerequisite

BASE02628b54. Existing approved manual-modifier-command-design.md section8 explicitly requires exact root+Manual attachment capture at free prime and matching revalidation at release. Current Controlled implementation intentionally accepts no attachments (comment and schema), leaving this downstream integration incomplete. Ordinary High implementation follows the existing selected architecture, not a new creative design.
Preflight: shared core composition already resolves exact refs/owner/active/mode/budget, but its resolver is nested. Extract only structural reference resolution/compatibility for reuse by free-prime admission, without cost/Requirement/clock settlement there. Existing immutable captured sources preserve definitions/history; prime records pin references+ability/version to those exact captures. Optional absent attachment metadata stays historical empty. Release must match the set and validate current availability/Requirements/costs; cancellation/source removal/defeat/terminal reconcile whole bundle. Owner-only availability may return the pinned refs; no private definition/accuracy state leaks. Add strict persistence validation and exact service/Zod tests before UI consumption. No hosted schema/data/deployment change.

Controlled bundle implementation: RED core031629 (10failed/1passed; one initial Requirement fixture typo corrected toresource-state/at-least) → core44checks031812; expanded core58checks032015 incl order normalization,no-input/cancel/cooldown,restore/source removal. ZodRED031859→55checks031940; actual serviceRED031909→52service/projectionchecks031941. Reordered prime fingerprintRED032117→55service/replaychecks032143. Initial types032023caught public readonly-array mismatch; corrected public contract toreadonly, fulltypes032146pass. Final frozen-source pnpmcheck exit0,7023Vitest+7Node,format/lint/types/build,receipt20261016T032213515722Z(03:22:13–03:24:36Z), existing native-config advisory retained. Fresh reviewer controlled_bundle_review reviewing exact diff02628b54..working, SHA256fc45dd635144b77e290701284c629854b792bf430bba8fcbe5ffebc84739b241; review pending, no acceptance/commit yet. UI source-map and real keyboard/prime seam savedtask15-manual-modifier-ui-preflight.md; explicit picker still absent.

Controlled bundle final combined review: reporttask15-controlled-modifiers-review.md,0Critical/1Important/0newMinor. I1 structural primary-unit feasibility was incorrectly assumed at prime and restore, allowing unreleasable Area/Ground-only bundles to spend once-per-battle admission. Reviewer independently reproduced7cases on originalfrozenfc45dddiff; root reproduced admission+persisted-area failures and Ground-only rejection. New fixtures initially had invalid area ranges and one unsupported actor self-Damage positive packet; corrected to legal ranges/actor DamageBonus without loosening product rules. Final RED033117shows13real negative-assertion failures plus that separate actorfixturefailure, then GREEN73checks033146 across4corefiles after the one fix pass. Prime+restore now share shape/category-derived explicit-unit feasibility; supported actor/affected-unit area attachments still prime/release. Intermediate prematurely started fullgate was interrupted130 before any further source edits; it is not accepted evidence. Final post-fix fullgate now running, source frozen again.
Final: fixed I1 — impossible-primary area/Ground-only admission and persisted bundle checks RED→GREEN; await final fullgate before checkpoint.
Final: Ruling: explicit picker/selection/combined interactive preview/keyboard-touch and full AI/whole-roster balance remain downstream — this core/service prerequisite cannot establish those flows; cost if wrong is incomplete player/AI usability, blocked before release.
Final: Ruling: inherited unsupported global Controlled modifier/Automatic/Ongoing timing remains rejected — an explicitly legal Instant modifier on a Controlled root is supported, with no independent modifier release; cost if wrong is narrower authoring capability, requiring explicit subsequent capability work.
Final: Ruling: prior Ground/control display findings remain deferred to required consumer audit — they are unchanged by this prerequisite; cost if wrong is misleading wording/highlighting, and publication remains blocked until fixed.
Final: Ruling: protected browser/editor/physical layout/publication/history and hosted concurrent PvP/CAS/restart/load acceptance remain open — shared actual PvE/PvP routes and local persistence/privacy boundary are traced, but hosted interaction was not performed; cost if wrong is unobserved integration behavior, blocked by existing release gate.

Post-fix full033212 failed only on a test fixture cast widening required maximumSelections tooptional CombatTargetSpec; removed the unnecessary cast/import so the derived typed AbilityTargeting remains exact. No product legality/behavior changed for this correction. Fresh coretypes then fullgate rerun pending. Independent reviewer boundary test source/config preserved at evidence/controlled-independent-review for the recovery archive; their frozen-source outcome is recorded in reviewer report and not rerun as duplicate acceptance.

Controlled bundle prerequisite final post-fix full pnpmcheck exit0,7038Vitest+7Node,format/lint/types/build,receipt20261016T033351374535Z(03:33:51–03:36:10Z). Fresh coretypes033344pass after removing the test-only widening cast. Source frozen throughout finalgate. I1 one-pass geometry/category admission+restore fix verified by REDnegativeassertions and73focusedchecks plus finalfullgreen; no second reviewer/duplicatebroadgate. No newMinor. Reviewer report retains originalWithFixes verdict against frozenfc45dd; this controller's post-fix tests establish bounded checkpoint readiness, not a re-review. Freshmain fetched immediately before finalization remains29506unchanged/ancestor; archivehead8a2d1b1b3f7a2288572c970c4b54d19b452955f9 verified; deploymentlockfalse retained. No unrelated files changed. Prepare exact source commit and remote recovery checkpoint before actual effort pause.

Effort boundary: nextwork is interaction/architecture design for explicit modifier selection before immediate Controlled prime plus real keyboard access under no-Tab/custom-bindings policy and complete safe combined-cost presentation. These interacting transitions are not settled by the accepted mechanical spec. Per persistent Owner instruction, save all current implementation/evidence, then genuinely pause for explicit High→ExtraHigh confirmation. Do not continue this design pass merely on generic carryon until switch confirmed. Routine High implementation should resume only after the corresponding accepted design/checkpoint and real return-to-High pause. Existing combat-first fullscope and all release gates remain active.

Controlled bundle prerequisite checkpoint: source6616c213821b03254f2ef4f7f238521260aa1024/tree93a61a90a252fc58e959917cb5840bab2662c2de,cleanworktree; final7038+7green. Task15 aswhole remainsopen. Saving recovery-only archive before final genuine ExtraHigh switch request; no design/implementation should run across that pause without explicit Owner switch.

Final recovery backup verified by actual gitlsremote atd1a167050ee4dcdf0b07fa1f50c4db8a9a8a9b2c/tree4a563620362b007488eb1bb58ef83779ee20a7f1,extends8a2d1b1b3f7a2288572c970c4b54d19b452955f9 viaexpectedSHA nonforceCAS. Bundle512970bytes/SHA256fb6fb4aa2b5ea3ea56d1878ee46e43f00457a395fb9872fcd973fff2e1428856/Gitblobe3467d9b828852877173ac615431a77c12043878,advertisesrefs/checkpoints/controlled-6616c213,requiresBASE6790; gitbundleverify passes. Evidence111629bytes/SHA256677f2413b441a0b8eb882ddd62242f71c1383976ffcdd96869bf762db95116d3/Gitblobb9dd9d96f1cbd7d5ed27fc6216287d6f2499c99d. RemoteLATEST and companionpreflight preserve actual next ExtraHigh interaction-design pause and all outstanding gates. Main29506unchanged and sourceworktreeclean. Archive is backup-only, not released ancestry. Root genuinely paused at this saved checkpoint for explicit Owner High→ExtraHigh switch confirmation; no background design/implementation. Generic continuation before that confirmation does not satisfy the effort switch.

## Owner resumes Extra High picker design — October15,23:49 Trinidad

Owner direct “ok go” replies to the explicit ExtraHigh switch/design request. Treat this direct affirmation as confirmation to resume the named design pass; no redundant switch question. BASE6616c213,cleanisolatedbranch; currentmain refreshed29506unchanged. No product code/hosted operation or new test run in this design-only pass.

Brainstorming skill c21/brainstorming applied, architectural classification announced: picker/input/quote interfaces interact. Visible context already supplies intent/constraints, so PersonalContext check requires no additional history search. Selected one compact footerModifiers panel/defaultM with collision-preserving account normalization, two real arrow/Space roving lists under existing no-Tab policy, local action/group-bound setup before unchanged direct artwork activation, captured empty/nonempty set locked after prime, safe full AP/MP/HP/visibleclock quote from existing preparation. Existing dimensions/slots/noReleaseButton/readyonlylight/serverauthority/PvEPvP/Moveprice and original whole-scope gates remain.

Ruling: produce one complete proposed written spec for this already-authorized design pass before a single concrete review request — purpose/constraints and effort handoff are supplied, and the controlling workflow requires a reviewable result before asking permission — cost if wrong is an unwanted footer interaction proposal; no product implementation starts without review. Alternatives and the footer-footprint assumption are explicit. This does not treat feature-scope approval as acceptance of a nonexistent implementation plan.

Spec docs/superpowers/specs/2026-10-16-manual-modifier-picker-design.md prepared. Author self-review found/corrected clearing-targets versus abandoning-command ambiguity, explicit offturnreadonly, ordinary versusfreeprime blockedselection, existing malformed-settings readfallback, legacyselected-centerareas, missing versuszero aggregatecosts and composition-order versus actualpacketsettlement wording. No placeholders/undecidedinterfaces remain; formatter/diffcheck pass. This is design self-review, not fresh7038test or independent implementation evidence. Existing source6616 quality receipts retain their exact prior meaning.

Nextstage gate: proposed written spec needs Owner review under brainstorming SKILL hard gate (“the human partner reviews and approves the written spec”). No writing-plans/implementation invoked yet. User's existing inline-executor preference persists and is not re-asked. Save source/spec+reviewstatus to recovery archive, then ask for written-spec approval and real return-to-High switch before planning. Nextturn must read actual review/switch response and carry all gates. No runtime activation/deployment/phase closure.

Picker proposed design committedd7e993d8151d09e886b05bf87709412adbe1b41b/tree6e6dd3f5a53b4bb8fd1a90a3e1023e07048cdc5c; doc-onlychange,cleanworktree,main29506unchanged. Written-spec approval and return-to-High switch remain pending; no product/implementation-plan work authorized by this checkpoint alone. Preserving exact source and this handoff before that pause.

Proposed picker design recovery backup verified by actual git ls-remote at 9160af53730f4b62eccb4dac543defc63ba804f5/tree176fd21516226830c0c02d31baf3cdad5f36e170, expected-SHA nonforce extension of d1a167. Source d7e993d8/tree6e6dd3f5 remains clean. Bundle522718bytes/SHA256133e879fb03a2ca6a7fed44b83fd5326c26c020758b04769984924f71284ad0d/Gitblobf3bd19e5fb2bd9355ef2e482280a8f14325628a8; evidence38925bytes/SHA256b081684fc106760c746484924b95612e05a3ee928543f7f1ebb829f18fb1a539/Gitblob1e05d2850980c6ea0673f63a25e29fea3197e667. Main29506unchanged. Remote LATEST preserves proposed status, written-spec approval and real return-to-High pause. No product work or plan execution across this pause; existing inline preference persists.

## Owner accepts picker design and return to High — October16,00:07 Trinidad

Direct “ok go on. eta til live?” replies to saved written-spec review/return-to-High request, then “continue”. Treat as design approval and named effort return; no redundant switch/method question. Existing inline preference persists. Working estimate communicated as24–48activehours for combat-first release, explicitly low confidence until picker integration/browser blockers; broader Master/world follows, no promised launch.

Writing-plans skill applied. Six-task concrete plan docs/superpowers/plans/2026-10-16-manual-modifier-picker.md prepared against actual shared compatibility/admission/restore, native selected-center geometry, owner projections, canonical/native/Mature/Essence preparation, strict controls/history, transient draft/all target factories, real shared controller/popover and production-component/real-kernel browser harness. Self-review corrected an impossible crowded-controls fixture (22oldactions can fill M,ShiftM,F1–20, yielding F21), nonexistent route-test assumption (new existing-service-boundary test selected), visible stale selected rows, actual Save RPC mocking boundary, and exact optional browser executable override. Spec marked accepted; plan-review remains pending under explicit writing-plans handoff requirement (“wait for that review before implementation”).

Document-only gate: Prettier check and git diff --check pass. No product implementation/tests/hosted operation/publication/deployment in this plan pass; prior7038+7receipt retains only its original prerequisite meaning. Plan SHA256d1e547699ce39562f3cf05e158403a6e51e26d1e1fdbaf387026e8459d89aff9. Preserve exact plan/spec and handoff before written-plan review pause. All original Task15/16 and full combat/roster/browser/AI/balance/reader release gates remain open.

Picker implementation-plan checkpoint 8b50b7a401db6fa5ed26bc43b5a85cda669fe5f2/treedba9203d9dbe139166f017de55dd7b39e81bfbe0; doc-only commit, clean source worktree, main29506unchanged/ancestor. Preparing incremental recovery bundle requiring d7e993d8, which is preserved in prior full picker-design bundle on archive9160af53. Written-plan review pending; no product implementation before review.

Implementation-plan recovery backup verified by actual git ls-remote atf3a7d0bc9b27835360577d711851cc97e7df32e3/treed0a4944dc12b49a19370e931b19e41b3cf57cd68, nonforce expected-SHA extension of9160af53. Incremental bundle13240bytes/SHA2567c6faa214725504c42757bdbc3f7337af33b27f66ad2461ab47f703870bbc878/Gitblob1ecd88c6fad1e472db1d10d605b035de5ad28456, requiresd7e993d8 retained by priorfullbundle; evidence50310bytes/SHA256833fceb09f90ce9547d84e4b991b2a2e970a945d355c213e427fa6f80cd3c084/Gitblob2282e5e3b387beee471cca23a468e28051be1ea7. Main29506unchanged, source8b50b7a4clean. RemoteLATEST preserves actual written-plan review pause and existing inline preference. Design/returnHigh already approved; no redundant switch request. No product implementation across pending plan review.

## Picker implementation checkpoint — October16 continuation

Owner's direct continye approved the written six-task plan; design/returnHigh/inline were already approved. Product Tasks1–5 committed8e841982/0431a735/14c4de7a/63175286/9cf4d53f. One fresh combined gpt-6-astra/High review found5Important/noCritical; one scoped fix pass88893b0a corrects recovery-group/root context and quote names, reader width/palette; no re-review. Final harness/report checkpoint80aff517. Exact final full check050914 at80aff5173858c186f673d15fd4399a7159038fa4 exits0:7,081Vitest+7Node,allformat/lint/8types/2buildtasks. Own authoritative ledger/receipts/review: .superpowers/sdd/2026-10-16-manual-modifier-picker/; report docs/verification/2026-10-16-manual-modifier-picker.md.

Native browser acceptance remains OPEN: Chromium download invalid/truncated ZIP, missing executable before harness assertions; cloud browser cannot reach local loopback. No screenshots/native assertions/hosted play accepted. Long-list200%page-scale harness is not true browser zoom. Missing shortcut/visibility/repeat/outside/version-response/terminal/pending/Resonance native matrix remains before release. CSS source corrected but no rendering claim. Current planTask6 remains acceptance-incomplete; preserve both workspaces.

Task15 accepted roster authority remains a8df18ef/manifest584f45d835bbf7b811a354c33e6618cd2cecb46abdbf5110946070b851f3fdbc,294records. No roster activation/hostedwrite/merge/deploy. Ground/capturedcontrols/Controlled/picker source checkpoints supplement the original BASE map; do not repeat those implementations or redesign accepted roster. Remaining immutable apply/all-tag actual outcomes/AI-Level100 balance/event readers/plain prose/orange effects and final coordinated browser/release gates remain required. Main29506unchanged; deploymentlockfalse. Exact source+evidence backup is being finalized on the authorized backup-only archive, preserving prior bundles and ancestry; consult its LATEST and own ledger for completed remote receipt.

Recovery backup VERIFIED: source933e496cdb892119dfece6182c7771cb4268d370/tree7f4726cbdef645907554e41d943e7fc016687168; final code test80aff517, final descendant documentation-only. Actual remote ref0782bbb8c80a028d23a33251cb237063f3054e4c/tree958b09d354a25a3d6bb2dead3999748c17b4cd48, expected-SHA nonforce extension off3a7d0bc. Bundle59,623bytes/SHA2566711bfb981561132d5969db79e3034d3a4b3c3f431bcf8f7e0d777130e5cf843/Gitblob35bacfb5e5257a22a6f32e9a79fab0bc719a19bd; evidence159,700bytes/SHA2563225b9bf8e23fb81693fd68635df25bd0f38bf311ffaa7d4ec3d500ec8226bb4/Gitblob875ac6b440e24e40e1476d3b469b9eaf5238f887. Both uploaded blob SHAs match local; local git bundle verify passes with prerequisite8b50b7a4 retained by prior plan bundle. Actual git ls-remote verifies new archive/main29506unchanged; implementation worktree clean. Remote LATEST preserves exact restore chain and all open acceptance/release gates. No code/native acceptance/release is inferred from backup ancestry.
Task6 remains acceptance-incomplete because native browser matrix is blocked; source/review/full-check/recovery checkpoint is complete. No further full suite or reviewer without a new supported change/failure. Next authorized parent work remains complete immutable roster application/all-tag outcomes/realAI-Level100 balance/readers, alongside resolving native browser/Atlas gates; do not redo accepted design or picker Tasks1–5.

## Task15 roster publication boundary — High continuation, BASE933e496c

Resume existingTask15, not a new design/approval or execution-method choice. Freshmain29506unchanged. Acceptedmanifest584f45d8exact,294records(136Skills/17Essences/136Resonances/5Basics). New real Master validation regression RED051617:25fail/269pass. Root causes:15root-canonicalEssences revalidate stale native nestedSkill;5Dispel sets contain positiveCovert missing from presentation classification;5explicit selected-status consumption/removal effects classified as fullCleanse. Existing effecthandler adds Suppress for Cleanse, so inferring narrower semantics only from the old statusIds would alter historical captures.
Ruling: add optional removalMode:'specified' to the existing bounded removal payload and stamp only the5approved explicit-removal packets in unpublished proposed versions — preserves older absent-mode Cleanse/Suppress behavior, standard partial-Cleanse rejection and exact intended named removals without a new executor; cost if wrong: parser/editor/reader/capture/native/AI compatibility needs covering evidence, and entire release remains gated. Preserve original accepted manifest source/hash in history and record the small implementation amendment; no numeric/target/price redesign or hosted activation.
Ruling: use existing Task15 brief and inline authorization rather than create another approval-gated plan for this bounded publication-boundary work — the approved plan already requires selected mechanics through actual publication/capture/reader/AI; cost if wrong: narrow policy metadata needs review in the single combined checkpoint gate.

Task15 publication boundary GREEN: core8mode tests052200; original web052202exit0had no usable output and was discarded for counts. Verbose052300/052628:740web tests/4files, including294validation+289real in-memory publications/current+pinned/stale retry+5Basics. Core052303caught5stale uniqueness signatures after the mode amendment; refreshed exactly5 manifest/audit signatures without weakening guards, GREEN052427:907tests/7files. Added real canonical prepare/commit JSON restore and actualAI utility projection,10mode tests052615 pass. Coretypes052504 initially caught optional statBridge in test fixture; reattached actual bridge, coretypes052608pass. Webtypes052504pass; affected lint052504/052508pass. Manifest newSHA591ba6ee... source-comparison confirms only5 mode/signature amendments; accepted original584f45d8 preserved in history. No price/target/Requirements/timing/status-list changes.
Scope boundary: publication tests are actual local service/repository/resolver behavior, not hostedCAS/currentOwner edits/wholecatalogue timing reconciliation or activation. Existing canonical derivedTags validation/catalogue consumers still require the broader reader audit; do not count legacy-derived tags as proof of canonical consumer completeness. Current native editor/reader acceptance remains blocked; no full Task15 claim. One combined checkpoint review follows source commit; no per-record reviewers.

Publication combined review complete:0Critical/2Important/0Minor at41439a0f. I1 reproduced uncaught disabled Essence RangeError; root selection now skips runtime usability while preserving all validation, disabled native nested Skill keeps its historical structured invalid result.4flag cases+6canonical negative guards, RED053416→751webGREEN053537. I2 reproduced historical Covert missing implicit Suppress both immediate/delayed canonical JSON restore, RED053415→860coreGREEN053456. Freeze historical mode-absent classifier; reuse existing specified mode for5new positive Covert sets, displayingDispel. CurrentmanifestSHA256bdceab2a7547845d15f20654c1dc758a97d6c104d2dad76c906364e4504cdd9f; total10packet flags/9Resonance signatures, original584f45d8 and intermediate591ba6ee preserved inGit. Structuralcomparison against933 provesexact284otherrows, no scalar/target/Requirement/clock/statuslist/version changes.
Ruling: explicit positive lists reuse specified mode rather than changing historical classification or adding another executor/mode — preserves already-reviewed positiveDispel intent and exact historical Suppress behavior; cost if wrong is incompatible history or misleading labels, covered by actual native/captured delayed outcomes and shared reader tests.
Ruling: native disabled nested Skill retains preexisting structured rejection rather than broadening generic Skill publication during this fix — review's uncaught regression is fixed; cost if wrong is narrower native disabled authoring capability, not lost historical behavior.
Final: fixedI1/I2 via one scoped fix pass; no rereview. NoMinor findings. Review-declined earlierpicker/wholebranch, canonical derivedTags/editorial, hostedSQL/CAS/currentOwneredits, nativebrowser/accessibility/layout, alltags/roster/AILevel100, Atlasmotion and merge/deploy/activation/fullrelease are individually ruled open in committed report with reason/cost. Initialfull052808 at414 passes7681Vitest+7Node but is pre-fix; await final full. Webtypes053539pass; coretypes initiallycaught unknown events in newtest, structuralnarrowing selected, no productioncast.

Final publication fullgate PASS at efb6fd33e73bd8efecd3dfab64bd32da771ce6ec/tree5ca11eef325598bbb990958ccfba79b11fc4829b: receipt053707343541(05:37:07–05:39:28UTC),exit0,7694Vitest+7Node,format/lint/all8types/2buildtasks. Coretypes053612pass. Freshmain fetched29506unchanged/ancestor, deploymentlockfalse. Final report descendant is docs-only, verify no apps/packages/scriptsdiff. ParentTask15/16 and all actual releasegates remainopen. Preflighttask15-executable-tags-preflight.md records exact19effect/26status/8Requirement/4activationdesigncoverage and why existing typedwitness checks do not prove actual all-tag outcomes. Preserve bothworkspaces/review/evidence. Preparing authorized nonforce recovery backup from933 prerequisite, not a sourcePR/merge/activation.

Recovery backup VERIFIED: sourceeec45d645fa6f8faf51174cc8564e7d040f24ca7/tree5e2ea6ee3f421c61d94a1f92a05be3cc678174c8; testedproductefb6fd33,finaldescendantdocs-only,noapps/packages/scriptsdiff,cleantree. Actual remote refc578c31c6132a647dc605896e489810b9db57d3b/treed5551ecf8636b83c8ff9d759ad42a2061dbf8e15 extends0782bbb8 with expectedSHA/nonforce. Sourcebundle20628bytes/SHA256a520d4717f89ef2070907346c4632e151f5614b69d8d6cd09797767eaebfeb89/Gitblob5ca71fd1fb814f4ca29d4bb75441f3d89bffcfee; evidence185205bytes/SHA256b1a7ad72380c4fecda953b2aaac0ccc5273ce1e8694dd3498e91592843a6b944/Gitblob1076a6e074d615adfede6397f9a24e7437eb386a. Metadata87958703523390e3b3aba356cc490498dd45935f,LATEST9935801e5b400a0ebb18af7160cf40eddddbb1d2; all4uploadedblobSHAsmatchlocal. Bundleverifyokay requires933e496c preserved by priorpickerbundle; all priorentries retained. Actualgitlsremoteverifiesarchive/main29506unchanged. Backup-onlynoimplementationancestry/hostedwrite/activation/merge/deploy. Boundedpublicationcheckpointcomplete; Task15/16/browser/fullcombatremainopen.

## Task15 executable effect completeness — High continuation, BASEeec45d64

Usercontinue01:43Trinidadauthorizes existingTask15 inline. Existing cleanisolatedworktree and freshmain29506unchanged/ancestor verified. Applying existing executing-plans/TDD workflow; no new design or execution-method approval. First bounded scope is all19registered effect IDs linked to exact final proposed record/version and actual outcomes/counters/finite bounds. Status/Requirement/activation completeness remains distinct subsequent work, not inferred from19effect cases. Ruling: retain an explicit registry equality test and real scenario callbacks in test-only code — no new runtime executor or evidence-as-feature subsystem, because the approved requirement concerns executable regression coverage; cost if wrong is a narrower handoff/checklist rather than production drift. Selected Ground tests materialize the already-approved provisional canonical group without claiming the proposal's native records are fully published/activated.

Effect completeness RED054527: missing all19registry witnesses. Implemented20new tests(1registryequality+19realoutcomes), extracted unchanged41existingoutcomeassertions into sharedtestutils. Added only the selected Ground bridge testadapter, preserving nativeautomaticaccuracy as fixed10000 and exact group metadata/costs/packetIDs. NativeArmorassumption disproved by accepteddesign explicitlyfutureequipmentboundary: currentDefense20 mustremainunbypassed(Pierce18damageversus22at0). Initialtestguesses/prices/rounding/Circleunitselection/terrainproperty/finiteclock and missingvariable corrected usingactualdefinitions/formulas/types, no productionrule changes. ExactDoTcapturedprofiles/bases and firsttick losses2/4/3 nowasserted. GREEN055305:829tests/4files incl allnew19effects+old41outcomes+fullmanifest+Groundgroups; coretypes055307pass; scopedlint055220pass after one unusedextractionimport removed. Manifestbdceabunchanged; no runtimefileschanged.
Ruling: classify Pierce's unimplemented equipment-Armor bypass honestly as future and verify current damage/zero extra Defense bypass — accepteddesign expressly requires this and no equipment Armor system exists here; cost if wrong is a narrower current tag benefit, not license to invent damage bypass.
Ruling: shared testfixture extraction preserves existing41assertions and uses nativeautomaticaccuracy on selectedGroundbridge — reuse exact existingfinaldefinitions instead of a parallel fakeexecutor; cost if wrong is changed fixture assumptions, covered by oldoutcomes+Ground+manifest and finalfullgate.
One combined review and fullsourcegate follow frozencommit; allstatuses/Requirements/activation/distinctcycles/realAI-Level100/browser/hosted/Atlasremainopen. Do not closeTask15.

Effect combined review atd8562a2f:0Critical/2Important/2Minor. I1boostassertions eventonly, missingactualHP; I2Movebadpathalsobadattackrange andmodifierreplayinsufficientAP/rootcooldown confound negatives. Accepted asImportanttest-evidence defects, no runtimebug. One test-only fix pass follows. M1primeequalsorigin andM2supportingAimedShotversionunpinned remainMinor because actualdistinctanchorcoveredbyunchangeddedicatedControlledtests and currentcompanionversion5isstilltruthful; defer underselectedworkflow rather than expandingfixpass. No production/manifestrevision authorizedorneeded.

Final: fixedI1test-onlyevidencegap — temporarynegativecontrol(retainordinary974HPwithboosted29event)passesoldtest055757;newrealHPassert974/971RED055808;controlremoved,actualpathsGREEN060007(829tests/4files). No productionbug or fakeexecutorcommitted. Negativecontrolpatchretainedtask15-effects-I1-negative-control.patch.
Final: fixedI2confoundednegativeguards — addpreconditionsto oldfixturesRED055831(2fail);firstroutefixstilloriginaloriginoutofrange055904;finalpairedrouteorigin+endpointwithinrangeassertsonlyexactMove-maxissue. Modifierpairedfixture100AP/20MPusesavailablePinningShotplainlegal, KeenFocusattachedonlycooldown-active. No capturedcooldownreset/resourcesrefundclaim. GREEN060007:829/4files; types/lint055926pass.
Final: minor (deferred): M1proposedRewindwitnessprimeequalsorigin;dedicatedControlledtestsalreadycoverdistinctanchor,carrywitnesshardening.
Final: minor (deferred): M2supportingAimedShotversion5notseparatelypinned;19primaryversionspinned,currentcompaniontruthful,carryversionhardening.
Final: Ruling: all18review-declinedscopeitemsremainindividuallyopenorboundedassetoutinreporttable,withreason/cost — effectIDsarenot24status/8Requirement/4mode/all294records/cycles/realAI-Level100/browser/hosted/releaseproof;parentownsexactfullreceiptswithoutduplicatingreviewerrun;costifwrongisincompleteorunusablecombatandprematurerelease. No re-review. Preservebothplanworkspaces/evidence. Initialfull055349passes7714Vitest+7Nodeatd856pre-fix;finalpostfixfullfollowsfrozencommit.

Executableeffect final fullgate PASS6f246f7b76e5bca52c309c2fb2d8ae772215c073/tree1fdfc822f2606a0cca8024f2eada8fd1f34488fb:receipt060117688565(06:01:17–06:03:35UTC)exit0,7714Vitest(4039core/3429web/246other)+7Node,format/lint/all8types/2buildtasks. BothImportanttest-evidencefindingsfixed;2Minorsdeferred;reviewdeclineditemsallindividuallyruledinreport. Exactold41testbodycomparisonbyteequal,manifestbdceabunchanged,no runtimechanges. Finaldescendantdocs-only;nofullrerunneededwithoutsourcechanges. Preparingrecoverybundle^eec45prerequisite, source/evidenceonlynohostedactivation/merge/deploy. StatusRequirementpreflightpreserved. Task15/16remainopen.

Executableeffect recovery backup VERIFIED:source883b63a7e2b16a7d77f44655b395d050208a38d2/treeb15b82ef3321e370b24114214258e0fbc5b68bbe;tested6f246f7b,descendantdocs-only,nodiffapps/packages/scripts,cleantree. Actualremote353b842d32cdbf4d6818e2a17c902cf6b404c029/treeac35ef152887f84f7e2312390848024dd4efb16d,expectedSHA/nonforceextensionofc578c31c. Bundle13549bytes/SHA256228e64087b0eae5c50fd4cb432a8054f7cab6ce3528dbe88a9276eafeaa54b2f/Gitblob5a83e738e91bdbdedc2e93a625cabccb245283b8;evidence134113bytes/SHA2567ee0157f7af076300b5fe410412888ee79a7a01a4a20a0a0127031ae4d5690e9/Gitblob13e82f86771b15e63cf1d164e180991e69737376;metadataa3da1a272f4bb5d8900ec56fc6e5eb33bba0a242/LATESTe08e5ac10d23a5aa24077e02b2a5482ae4c20e9a. All4uploadedblobSHAsmatchlocal. Localbundleverifyokay requires eec45d64 retainedbypriorpublicationbundle;allpriorarchiveentriesretained. Actualgitlsremoteverifiesnewarchive/main29506unchanged. Noimplementationancestry/hostedactivation/merge/deploy. Bothworkspacespreserved,2Minorsdeferred,all18declinedscopeitemsruledopen/boundedinreport. Bounded19effect-IDcheckpointcomplete; parentTask15/16remainopen;nextstatusRequirementpreflightready.

## Task15 status/Requirement continuation — High, BASE883b63a7

Usercontinue02:51/02:52TrinidadauthorizesexistingTask15inline. WorktreeGitpointerdanglingafterruntimehandoff(old1540commonrepoabsent);preservedpointer,initializedlocalmetadata,read-onlyfetchedmain29506andPR904base6790,verifiedandimportedretaineddesign→plan→picker→publication→effectsbundles,updatedlocalbranch/indexwithoutoverwritingworkingfiles. ExactHEAD883b63a7/treeb15b82ef,cleantree,main29506ancestor,remoteauthorizedarchive353b842unchanged. No source lost/reset/hostedwrite. Offlinefrozenpnpmrestorealreadyuptodate;Node24.19.0/pnpm11.25.0/vitest4.1.10/tsc6.0.3nowavailable. Recovered20effecttestsGREEN065413. SourceauthorizationandHigh/inlinepersist;no redundantapproval.
Firstboundednewwork8RequirementformsusingtypeexhaustivecaseRecordandactualfinal-rosterprepare/commit/nativeeventproduction; status24+system/historyworkfollowsasfeasible. Ruling: useRequirementNode.kindcompiletimeexhaustivenessplusacceptedcoverageenumeration/realparser as completenessauthority instead of addinganunneededproductionregistryAPI — supportsallcurrentlytyped/runtimevalidatedformswithoutnewruntimebehavior;costifwrongisatype/validatorinconsistencyrequiringexpandedregistrywork. No acceptedmanifest/version/formula/targetchange. One combinedreviewatboundedend,notpercase.

## Task15 executable statuses/Requirements bounded implementation

Requirement forms8 and authorable statuses24 now have actual proposed capture/version→prepare/commit→JSON/stat validation outcomes, eligible/counter/no-input/finite bounds as applicable; LoweredGuard uses actual PvP/AI timeout primitives, Displaced actual current Push versus historical restore. Report docs/verification/2026-10-16-executable-status-requirements.md records exact witnesses/limits and RED/GREEN receipts. Requirement crossing operator is inclusive at reached30%; initial strict test assumption corrected, SecondWind prose mismatch carried to reader audit without manifest mutation.
Ruling: fix three real runtime defects exposed by mandated coverage within existingTask15 scope — canonical Skill/Essence Revealed AP (including modifier affordability/availability), generated Sensory positive-only purge, and walking reconstruction retaining selected stacking policy. Reuse existing helper/removal mode/policy rather than add a new mechanic. Cost if wrong: incorrect affordability, losing a negative status or inability to walk while buffed. Historical native prepaid prices/mode-absent removal/absent policy stay covered; no manifest/version/target/formula/timing changes. Current counterpart tests isolate status removal; they do not claim actual Cleanse/refund.
Focused GREEN071729890495:135tests/7files. First canonical/walking RED070931; genuineSuppress/Sensory RED071340; availability price RED071536. Exact current manifest bdceab unchanged. Review and final full check pending. ParentTask15/16, fullroster/activations/cycles/realAI-Level100/readers/nativebrowser/hosted/Atlas remain open. No hosted write/activation/merge/deploy. One combined review of this bounded range follows; no per-case agents or rereview.

Final combined reviewd218bf28:0Critical/0Important/1Minor. Parent regradesM1falseMendhandoffpriceImportant because wrong accepted expenditure may propagate to balance/reader acceptance; independently noticed before reviewer conclusion. One scoped docs-only correction35AP/6MP leaving65AP/14MP, actualacceptedcostauditRED072429861126→GREEN072505416572. Runtime/testsourceunchanged. No deferredcurrentMinor, prior2effectMinorscarried. All20declinedreviewbehaviorsindividuallyruledwithreason/costinreport. No rereview.
Final source gate PASSd218bf2888e348c264dd7c0220da5d5e3f2e4a76/treeb5b71a750094208813f8799db2c31089cc2cced9:receipt072119139523(07:21:19–07:24:26UTC),exit0,7753Vitest(4078core/3429web/246other)+7Node,format/lint/all8types/worker+webbuildcommands. BuildstdouttruncatedafterNextstartup; artifactreceipt072505506776confirmsfreshnonemptyBUILD_ID/build/app/requiredserver/routes/prerendermanifestswrittenwithinfullrun. No unsupportednativebrowserclaim. Vitenativeconfigadvisorycarried. Finaldescendantdocs-only; no repeatfullwithoutnewsourcechange. Main29506freshunchanged/ancestor,deploylockfalse. Preparingincrementalbackup^883b63withallnewreceipts/review/preflight. Task15/16remainopen;nextactivationinventorypreflightpreserved. ExistingExcelpreviewfoundinLibraryandlocal190076bytevalidXLSX;freshdownloadlinkprovidedwithoutduplicatefile/edits.
Recoverybackup VERIFIED actualgitlsremote atf0d50e9304dbe048116d5814c396930606bad399/tree7c1ebe5b64824119bb5264504651d5582bae491a, nonforceexpected353b842. Sourceea04a581392e57b867c7f6fd2350072f030c4e7c/tree1d2c4b1281eae956a0acfcc7989a00bfe8f9f63bclean;main29506unchanged. Incrementalbundle20245bytes/SHA256eacbfc9fb8ee2addbf80926410277d4298000503e93f4be999ae77a8c6d02b19/Gitblob9518b149caa6379a8741b0de035781f68cca4df3 requires883b63, evidence98277bytes/SHA2563b834d60a38f72f9dd11ffce4e18a4fc4ef95da3ac283de519b360008bb28f45/Gitblob0c3f87f592f8af8d8d8ba6450fbb235bd911de36. Metadata5736ee912b0e598351367d84771f6ef40a86121f/LATEST7c29d9c140705b1b85855c42e4e3988d47137b60, all4actualremotetreeblobscheckedagainstlocalhashes andlocalbundleverify. Backup-onlyarchiveancestryneverusedasimplementationbase. ContinuingauthorizedTask15inlineHigh withactivationinventory;no userpermissionneededforalreadyplannedtestcoverage.

## Task15 executable selected activation combinations

ContinuinginlineHigh fromcleanreviewedea04a581, freshmain29506unchanged. Ruling: useacceptedselectedActivationCombinations andactualcapturedgroupactivation/mode as completenessauthority withrealcallbacks; unselectedautomatic/modifier staysunselectedwithoutremovinggenericcapability. Test-only, no production/manifestchange. Costifwrong: labelswithoutactualactivationbehavior. RED072958304889emptyregistry; automaticmanualinvocationinitiallyfailedwrongadmissionstage073055, correctedexplicitrealbehaviorselector;GREEN0731165tests. Addedactualopponentphysicalactionownershipcounter, final105tests/5filesGREEN073309331986. Typedcountertestsdo notfabricateevents or claimlegalcompleteequippedbuilds.
NextAIcyclepreflighttracesactualmissingManualattachmentrefsinplanner/RecruitAiIntent/executor/serverandcurrentnativeLevel100/V3analyticharnesslimits. Treatasopenrequiredintegration, not an automaticclaimthatcoremodifierexecutionprovesAIchoice. Broadercycles/all294/realAIbalance/currentOwnerpublication/readers/nativebrowser/Atlas remainopen. One combinedreviewandfullsourcegatefollowboundedactivationtestcommit.
Activationcombinedreviewf72ea2f3:0Critical/0Important/1Minor. M1primaryOngoingdynamicpairIDnotliteralstableIDassertioncouldsilentlyrebindonfuturereplacement;currentrecordversion/outcomestrue. ParentkeepsMinor/deferredperworkflow;nofixpass/rereview. Prior2effectMinorscarried.All27declinedbehaviorsindividuallyruledwithreason/costinreport. Original20effectcases+entire41outcomefilebyteequal883b63provedreceipt073655408012. Fullfrozen-sourcegaterunning;nextAIcyclepreflightpreserved. No releaseclaim.
FinalactivationgatePASSf72ea2f3b361f959f21613a63c21e3972e397058/treee5c244ed9b0ffc47731e68f835576fae26f6838f:receipt073535418800(07:35:35–07:38:02UTC),exit0,7758Vitest(4083core/3429web/246other)+7Node,format/lint/all8types/2successfulbuildtasks(unchangedworkercached,freshwebcompletedfullroutesummary). PreexistingViteadvisorycarried. Finaldescendantdocs-only, nodefinition/runtime/manifestchangesinthisactivationmilestone, norereview/fullrerunwithoutnewsource. CurrentMinorM1andprior2effectMinorsdeferred. ParentTask15/16/AIcycles/realAIbalance/readers/nativebrowser/hosted/Atlasremainopen. Preserveworkspaces/evidence;preparingincrementalrecovery^ea04a581notactivation/merge/deploy.
Activationrecoverybackup VERIFIEDactualgitlsremote atdd8cc89bd1afb647ab48edf4322e92e182cd5dae/treef82ef2dc66e45ca86bc8149f5f27e57338a4e1b6, nonforceexpectedf0d50e930. Sourcedda3d5f8caa9978d576d73ac283df8a1ca85d2f3/tree473f630a838e5bdf606dfb268f43713ddf292bb2clean;main29506unchanged/ancestor. Bundle8323bytes/SHA256eec4c6ed32171186ecb54b3b432c59513f51cd11df43bc9f80622a6216a676ea/Gitblob4d4e1fabfcd85bb3df061f94e3ca83c622e5be17requires ea04a581; evidence77002bytes/SHA2561bfaad6334d923c520d2efb9615d2542626e4520d9af3d514c47220b3dad7824/Gitblob72de881421ee681f9691e3e41c3699244c347555. Metadatad8af9ed60f69e1f657fd27bc007287411e7594ad/LATEST20e00f12926a57dcd185fac0cefb8407f3d840d5, actualremotetree4entriesverifiedagainstlocalhashes;localbundleverifyokay. Exacttestedsourcef72ea2f3, finaldescendantdocsonly. No processesleftworkingonthistask. Preserveallworkspaces/evidence. Nextauthorizedworkremainstask15-ai-cycle-preflight.md inlineHigh; do notreruncompletedtaxonomymilestonesorreviews. No liveETA/Task15closure/hostedwrite/activation/merge/deploy implied. ExcelexistingLibraryidentitylibfile_60fac1def614819199574a95f9b5b505 andlocaloutputs/aurevane-roster-preview/AUREVANE_Roster_Update_Preview.xlsx valid190076bytes;freshlinkprovidedwithoutduplicatewrite.

## Task15 AI explicit Manual attachment integration — October16 05:07 Trinidad continuation

OwnercontinueauthorizesalreadyplannedTask15 inlineHigh. CleanBASEdda3d5f8caa9978d576d73ac283df8a1ca85d2f3;freshmain29506unchanged. Readcurrentengineering/concurrent/combat,existingManualcommanddesign andactualplanner→intent→executor→serverCAS. Applyingexecuting-plans/TDD; no productscopechange/newmechanic, no redundantapprovalforapprovedTask15AIapplication.
Ruling: optional AI bundles reuse currentManualreference grammar, sharedprepare/commit andexisting utility, not a new executor/cost formula. Deterministic bounded enumeration retains omission/singles and bounded combinations; allcurrentlyselectedfinalManualmodifiers fit within existingprofilecandidatebudgets. AlreadyprimedControlled roots useexactcapturedrefs, never recompute the attachmentset. Structural/target/resource/cooldown/limits remain authoritativequote decisions. Preserveabsentfields/oldplannerbehavior when no ownedManualmodifiers. Costifwrong: expensive planning or incorrect/free AI attachments; test actualdecision→core/servercommit, immutableprime/JSON, counters/performancebounds/terminal beforefullgate. Genericcustomcataloguebeyondbudget isheuristic, not exhaustiveoptimalityclaim. Existingapprovedmanual-modifier-command-design explicitlypermitsAIchoosingaManualbundle onitslegalturn; technicalpropagation/searchiswithinapprovedTask15, notnewdesignscope.
AIimplementation:optionalmanualrefsnowpropagateplanner→internalaction/prime→canonical/nativeSkill/nativeBasicexecutor→actualRecruitserverCAS. BudgetstableBFSomission/singles/combosup toprofile48/72/96,15attachments retained, separatepluralaggregationperbundle; exactprimedsetafterrestore/newsource;equalutilityfewestattachmentsandoldunattachedkeys;sharedatomicquote/admissionneverautodrops. No catalogue/formula/playerflowchange. InitialRED091119missingrefs3/4;actualserverforwardRED091505pays12vs19bothordinary/Controlled→GREEN0916402cases. NativeBasicRED091639→GREEN09171686tests. FinalcoreGREEN09201590tests/4files including14new. TypeclosureNullnarrowingRED091715→hoistvalidatedtargetGREEN091946;webtypes091924green. Rootlint092016coregreen/2appfilesignoredwarn;runactualweblintseparately. Fixturecorrectionsdocumentedwithoutweakeningproductionvalidation:fixedInstantnotglobalControlledoverride,200%vs150%bonuscap,UtilityattackFamily,immutableforeignsourceID,Revealedexplicitactor. Reportdocs/verification/2026-10-16-ai-manual-modifier-integration.md recordsalllimits/rulings. ExistingMinor3carried. Fullservice/lint,freeze,onecombinedreview/finalgatepending.
ActualwebscopedlintGREEN092103096208zeroWarnings;fullRecruitserviceGREEN09210309357139/39including37unchanged. Combinedcovering129tests/5files(core90+web39). FreezingAIintegrationrangeforonefreshcombinedreview. No fullTask15/AIbalanceclaim; remainingactuallegalcurrentbuildcyclesandpriorreleasegatesopen.
Frozensource3a3bce8747cf6daebea83f26f6de47064a615238/tree552f834194294b9f9239a724c4f49a5008e70a08;main29506freshunchanged;6filesonly.AIfreshcombinedreview/root/ai_manual_integration_review(gpt-6-astraHigh)dispatchedread-onlynonsubagents;parentfullgatefollowsatfrozenhead.No repeatedacceptedtaxonomyreview, no sideimplementers.

AIcombinedreviewcomplete3a3bce874:0Critical/0Important/1Minor repeatedtarget/pathdiscoveryperbundle;finitebound/no demonstratedtimeout,parentagreesMinoranddefersoptimization+attachedMoveworkcount. Prior3Minorscarried,total4. All38declinedbehaviorsindividuallyruledwithreason/costincommittedreport. No fixpass/rereview. FinalfullgatePASSunchangedreviewedsource/tree552f8341,receipt092417796554(09:24:17–09:26:34UTC),exit0,7774Vitest(4097core/3431web/246other)+7Node,format/lint/all8types/2buildtasks,freshcompletewebbuildsummary. Freshmain29506unchanged/ancestor,deploylockfalse. Finaldescendantdocs-only; preparingincrementalbackup^dda3d5f8. ParentTask15/16andlegalcycles/balance/readers/browser/hosted/Ground/Atlasremainopen. No hostedwrite/activation/merge/deploy.

AIManualrecoverybackupVERIFIEDsource0354e2c3f849e0c0bd6ccb1f089df1519222bf31/tree0dfb9b903534854957879d506c938da54b992d91,tested3a3bce874,docs-onlydescendant/cleantree. Actualremoteda547b4e89ead1bed8249c5ed29531eb360fdd37/treeac36a9d5a8d33c481fe8c12a6f1c3bb290e95b25expecteddd8cc89nonforce. Incrementalbundle15904bytes/SHA256deedd88625d5567fb05ec4169e46b0e1e54692aa0c7c76b23cebdc83a68ec4b9/Gitblob7e9b2aad746aa169a3e18db1ccfd2e085c27d31crequiresdda3d5f8. Evidence100679bytes/SHA2565d8b5024bff9c8c077e0ccbdfac9a5f42f4af6861ab62a74b73e3f99e91f391a/blobecb94604518eb602f96867fd397855f204686e4e,metadata622f413fc125f448689b0cff99806b2567839a3a/LATEST8b339ee4254ca849215dc88b3c898126cc2cf56a,all4actualremotetreeentries/localblobhasheschecked. Freshmain29506unchanged,deploylockfalse. Noactivation/merge/deploy.

## Task15 legal earned-loadout admission continuation

ContinueinlineHighwithinapprovedTask15,base0354e2c3. Ruling: exerciseexistinglocalsave/load andrealpublication/current+pinnedbattleauthoritywithseededearnedfacts,notchangeearning/equipmentmechanicsorpretendhosteddatabaseproof. Retainhistoricversioninearnedrecords;actualcatalog3battleadmissionlegallyupgradescurrentpublication. Pure2complementary4Skillcoveragekitsper17sources(notnewclassstrategies),existing136authored2+2pairkitsbothPrimaryorders,Level1/100actualpool36/135/currentstatsandPvE/PvPauthority. Costifwrong:illegalorwrongversionfixturesinvalidatethefollowingbalanceevidence. Native3Groundexplicitlyretainactualnativepath,notfakecanonicalcaptures. Initial306fail093224misnamedactorID;correctedactualcharacterprefix093239thenstillfailedhashbecausefixtureSkillkeyorderdifferedactualrepositoryparseSnapshotSkill. ActualrepooutputiscanonicalslotIndexfirst;fixturecorrectedaccordingly,no productionbugclaim. AdmissionGREEN093310312tests/1file,306buildcases(each2levels×2contexts)+coverage+5negativecases. Types093328caughtvi.fninputlostcontextualtyping;explicitSaveDisciplineSkillsInputannotation,properdiscriminatedrowunion. AddingactualdeterministicreadonlyfirstAIcommandthroughadmittedcaptures/buildbridge/currentstats;thisisopeningcommandintegration,notdistinctcycles/balanceoractualearning.

OpeningactualAIcoveringGREEN093423961845312/312,09:34:23–09:36:35UTC130.91sec. Processinspectionpscommand(notVitest)emittedfatal-library-look-up-self;initialmisattributioncorrectedtouser,actualsuiteexit0normal. Diagnosticnarrow0936261/311filteredpass;alreadylaunchedverbose093645repeat312/31209:36:45–09:38:54UTC128.12secpass. No runtimebug/fix. Negativeguardsstrengthenedtoexactmessagesandgenuinelylearned-inactivesourceGREEN0937335/307filtered. AddedexactnonBasiccapture-setassertion,properdiscriminatedmanifestrowtype. Frozen4c7f4b707d456c545a2630930654c3a6d7c115cc/treed555502890e556488edf796334f3bd8159b3e091. Onefreshcombinedlegal-buildreview/root/legal_build_admission_reviewread-only,notperrecord,atthisboundedmilestoneend;parentfinalfullrunning. No product/manifestchanges. Reportexplicitseededearnedfactsnotactuallearning/mastery/advancedprereqs;purecoveragehalvesnotauthoredstrategies;3nativeGroundstillopen;openingcommandmayBasicnotdistinctcycle/balance;singleenemyprofilewithoutbuildnotfullPvPencounter;existingnativeexecutorPvEcontractnotnewPvPmechanicclaim.

Legalbuildcombinedreview4c7f4b70complete0Critical/0Important/1Minoractorprofilefixtureprovenancedoubleprefixcharacter:character:UUID;numericstats/openingoutcomesunchanged,parentagreesMinor/deferperworkflow. Exactcharacterprovenanceidentitynotestablished;fixnextrelevantfixturetouchwithassertion,notpolishnow. Prior4Minorscarried,total5. All10reviewdeclinedscopeitemsindividuallyruledwithreason/costinreport. FinalfullgatePASSunchangedreviewed4c7f4b707d456c545a2630930654c3a6d7c115cc/treed555502890e556488edf796334f3bd8159b3e091receipt09391929828509:39:19–09:42:50UTCexit0,8086Vitest(4097core/3743web/246other)+7Node,format/lint/all8types/2buildtaskswithcompletefreshwebsummary. No sourcefixpass/rereviewneeded. Freshmain29506unchanged/ancestor,deploylockfalse. Finaldescendantdocs-only;prepareincrementalbackup^0354e2c3. ParentTask15/16cycles/balance/Ground/readers/browser/hosted/Atlasremainopen. Distinctcyclepreflightpreserved,notwholecombatacceptance.

LegalbuildrecoverybackupVERIFIEDactualgitlsremote741ba9782298bc8621a6ddac85607f8a0d167baf/tree2194dcd660287f826a1906c3eea48020c259e66c,expectedda547b4enonforce. Source7e7b1def59c81398d6698c8452da02e4e2f4cb3b/treeca79e76c890d231082a4e0d46c867164253c8c88,tested4c7f4b70,finaldocs-only/cleantree,main29506unchanged. Incrementalbundle13146bytes/SHA256198c67e8ca0d23856ef33279ec3c7d90ecce59fa9bc5628faa13d22c541a08eb/Gitblob9dd1abf39d3e94bbd05a4c9abf4c3fa414138215requires0354e2c3. Evidence99132bytes/SHA2569f82aedef21811e3212c79042a287ecf09c9e480f2a04fd721c42aaf76a03e20/blob0497538c5c8c5941d2d17996cc73610c633d4ac3. Metadata2fa78b6b92d936503a61e283cc51ea2604676c09/LATEST8e52901a2340106aa2b3ef338d9040a672dbfbb6all4actualremotetreeentriesandlocalblobhasheschecked;localbundleverifyokay/prereqretained. Noimplementationancestryfromarchive,nohostedwrite/activation/merge/deploy. Bothworkspaces/evidencepreserved,5Minorsdeferred. No runningtaskprocessesleft. NextauthorizedTask15distinctcyclepreflightready;fullTask15/16remainopen. Do notredoacceptedtaxonomy/AIpropagation/legaladmissionmilestones. Groundchaintrace:genericAbilityGroundEditor,canonicalgrounddelivery/areas,actualpreviewandpublicreadersalreadyexist;nextactualmaterializationmustproveall3revieweddefinitionsendtoendbeforeclaimingcanonicalpublication. No creative reprice/newmechanics/actualExtraHighswitchdone.

## Task15 final3 Ground materialization — October16 06:02 Trinidad continuation

BASE7e7b1def59c81398d6698c8452da02e4e2f4cb3b clean;freshmain29506unchanged/ancestor. InlineHigh/TDD persists, no helperimplementers/perrecordreviewers. ExistingAGENTS/brief/spec/groupdefinition/actualparser/compiler/handler/capture/editor/readers/AI traced. Ruling: mechanicallymaterializeexactthreeapprovedprovisionalgroupsintotheirafter.abilityenvelopes,retainingnativeafterfields/prices/targets/versions/payloadorder/entryordinalsandhistoricalbuiltinversions — alreadyselectedTask15contract,nonewdesign/reprice/permissionneeded. Costifwrong:wrongclocks/entries/cast-onlycleanse/history;proveactualaftercapture/publication/executionratherthanreusehelper'stest-onlyGroundconversion. Nativebrowserremainsopen;localmaterializationdoesnotactivatehostedcontent. Onecombinedreviewatboundedmilestoneendonly;prior5Minorsdeferredandbothworkspacespreserved.

GroundactualcaptureRED1005263null;realpublicationafterabilityRED1005573undefined. Addedexactselected3after.abilityonly, nativeenvelope/prices/versions/payloadsretained. ActualcorefirstGREEN2/3at100606;CinderunflaggedactivatecorrectlymeansEnemyintentunderpolicy2, fixturechangedexplicitGroundratherthanweakenruntime. Publication/editor/readers3GREEN100613. ManifeststatusRED1006521/812thenmaterialized-local-not-activecoverage/rowstatus(nativebrowserflagstillopen). Removedtest-onlyGroundfallbackandoldsynthetic3captureconstruction;actualaftercaptureonly.
ActualAIRED100842Cinderselectedwithoutarea;other4failfixturesassumedunselected25%scalingandmissedairbornepolicy. ExistingGroundentryusesauthoredflat7/8 packet under140%/floor,actualHP9/11;correctexplicitexpectationsandairbornepolicy1. IsolatedAIRED1010171/15missingarea. Ruling: canonicalpersistGroundFireundergeometry2/policy2mustsendexistingexplicitGroundintent,notEnemydefault — authoredGroundgroupalreadychoosespersistence;costifwronglosesareaorblocksAirbornecorrectly. Maponlythatownedcandidateboundary,retainplayerEnemyintent/native/history/noareaothers,nonewscore/executor. GREEN101050838/5filesinclold41outcomes/manifest/AIbundles.
ExtraexactGroundcasesnow18:source-removal/JSON/entryonce/HP9or11oractualSlowChilledstackincrease/finiteexpiry;AIall3withexhaustedwalking/diagonalhostiles;atomicunaffordablecounter;genuinesurrender/terminalAI;Airborne;playerEnemycounter;casterCleansecast-only;actualMist→FlameSteamoldexpiry. InitialcasterCleanseexpectinstantunderemptytimingpolicyfailed101218;explicitcapturedremove-statusInstantfixturematchesrequestwithoutrewritingapprovedglobaltiming. CoveringGREEN101252990/11files. Appeditorfileattemptfirstusedwrongcwdthenreadpathoneparenttoofar;correctedfixturepaths,original3baseline101029notnewcoverage. FinalactualappGREEN101227226066620/4filesincl3editorcallbacks3pub/preview/readerexactcases;callbackupdateslifetime/entryorderpreservecastpayloads. Webtypes101227222358pass;coretypes101227225903caughtbroadCombatEncountertypeatsurrender,restorevalidbridgebeforedomaincall,no cast. Prior5Minorscarriedno unrelatedfixes.

GroundauditGREEN101355:exact3after.abilityplusstatus/browserflagmetadataonly,other291recordsexact,allpreexistingafterfields/version/prices/target/eligibility/historyunchanged. NewmanifestSHA256b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05;oldbdceabretainedGit. Coretypes101427724704pass/corelint101427716435pass.
Fullcontrollertracefoundsecondactualgap:resolveBattleCapturedSkillalwaysforcedgroundIntentCapablefalseandcanonicalreaderreportedGroundonly. ActualCinderprojection→sharedcontrollerRED101640policy2false/readerwrongTarget;policy1privacyregexalsoincorrectlymatchedplainwordcaster,changedtomatchJSONkeyonly. Ruling: deriveGeometry2FireGroundcapabilityfromownedcapturedgroupandpinnedpolicy,projectonlysafetrueflag,andconsumeitinsharedPvE/PvPcontroller;useonesmallsharedpredicatealsoforAIandreader,keepGeometry3authoredcategories/oldpolicysemantics — preserveexistingEnemy/Groundmechanicwithoutaddingbuttons/privatepayloadornewexecutor;costifwrongunusableareaorcapabilitydrift. Nativebrowserstillopen. GREEN101714677tests/6files;actualpolicyundefined/1/2/spectator/privacy/stalenativeenvelopeandrealpublicationpublicreaderscovered. Prior5Minorsremainunrelated/deferred;legalbuildtestonlyupdatednativeGroundallowancetoallcanonical,provenanceminoruntouched.

FinalcoveringcoreGREEN101744302321951/9files;webGREEN101714174640677/6files+preview620/4files101227. Finalcore/webtypes101921105522/101921104714pass;weblint1019211008410warnings;exactscopeaudit101905pass. Freshmain29506unchanged/ancestor,deploylockfalse. Freezingall17filesforonecombinedreview/finalfullgate;all1224legalbuildopeningcombinationswillrunwithnofallbackGroundallowance. Reportground-roster-materializationrecordslimits/rulings. No newcreative/formula/timingrevision;nativebrowser/remainingcycles/AIbalance/fullreader/hosted/Atlasstillopen.

## Task15 exact3 Ground materialization — reviewed frozen gate

Source e9e0042d /tree53bd4dd3, range7e7b1def..e9e0042d. Full root check receipt102003079147 exit0 at10:24:16UTC:8113Vitest+7Node, format/lint/8types/2builds. Fresh combined review0Critical/0Important/0newMinor; parent agrees, no fix pass/no rereview. Prior5Minors deferred. Task15/16 open; no hosted writes or activation.

Final: Ruling: Final repository gate — Accept the actual frozen-source full check, exit0, with8113Vitest and7Node tests, formatting/lint/types/builds; the reviewer need not duplicate it — Cost if wrong: unrelated integration regression if the receipt or source attribution is wrong.

Final: Ruling: Native browser interaction — Keep keyboard/pointer/touch/mobile/zoom acceptance open; component and controller tests establish only their actual boundaries, and the known unavailable browser is not a basis for reinstall/tunnel loops — Cost if wrong: usable adapter behavior could still fail in real input flows.

Final: Ruling: Living Atlas/layout acceptance — Keep visual/layout/accessibility acceptance open; static rendering cannot prove the real dimensions or motion bound — Cost if wrong: clipping, accessibility or layout defects could remain.

Final: Ruling: Hosted publication/CAS — Keep hosted persistence and concurrency open; this checkpoint proves local service publication and version capture only — Cost if wrong: hosted CAS or persistence could differ.

Final: Ruling: Owner-edit reconciliation — Do not publish/backfill or overwrite current Owner content; reconcile edited catalogue before any later publication — Cost if wrong: current edits could be overwritten or rejected.

Final: Ruling: Hosted timing-policy reconciliation — Retain explicit captured Instant remove-status evidence and keep remote timing reconciliation open — Cost if wrong: actual cleanup timing could differ from the explicit fixture.

Final: Ruling: Every distinct class/pair cycle — Continue Task15 distinct-cycle work; these three Ground outcomes and previous suites are not a claim for every roster cycle — Cost if wrong: other authored combinations could be ineffective or unusable.

Final: Ruling: Natural Level1/100 PvE/PvP balance — Keep balance, dominance and pacing open; admission and bounded opportunities establish legality rather than budgets or match outcomes — Cost if wrong: imbalance or poor pacing could remain.

Final: Ruling: AI strategic optimality — Accept deterministic existing Ground intent for authored persistent groups as the bounded correctness fix; do not claim optimal Enemy-versus-Ground tactics — Cost if wrong: legal but inferior choices against Airborne or other counters.

Final: Ruling: All custom Fire compositions — Accept the shared geometry/policy capability predicate and actual unconditional proposed groups; arbitrary conditional/modifier/movement combinations remain part of broader authoring acceptance — Cost if wrong: additional capability-versus-execution edge cases could remain.

Final: Ruling: Full reader/editor audit — Accept tested current Skill readers and Ground callbacks; retain broad prose/orange/derivedTags and all authoring combinations as open gates — Cost if wrong: misleading or inconsistent surfaces elsewhere.

Final: Ruling: Every Ground lifecycle permutation — Accept covered entry/expiry/source-removal/JSON/terminal/Airborne/Steam outcomes; do not claim exhaustive overlap/policy/transition sequence coverage — Cost if wrong: uncommon interaction defects could remain.

Final: Ruling: Hosted long-running/restart/load behavior — Keep operational persistence and load acceptance open; JSON restoration and local finite clocks establish narrower contracts — Cost if wrong: production-only lifecycle failures.

Final: Ruling: Activation/release/human acceptance — Keep activation, migration, merge, deployment and human acceptance closed; no such action is part of this bounded checkpoint — Cost if wrong: premature release would bypass remaining gates.

Ref refresh: main29506e293e81abef1b0b8a46099618ab3ae3f0ae unchanged; archive741ba9782298bc8621a6ddac85607f8a0d167baf unchanged. Prepare exact final docs checkpoint bundle next.

Ground final checkpoint5ed4fe9bc2fb6bbb331344ac92edb22dd05ec445 /tree5f7d5915bb155bb1e3a0a97864b505aa6f32810b archived at5354316edf3c0f30fcf274f10c6be8c17b2a08af /tree190b5f9edb32ba70743210d73437e19e5794c9af. Nonforce expected-head741ba978 update succeeded; gitlsremote confirms. All4remotecheckpointentries match localhashes: bundlea7d526f2, evidenceacf90300, metadataf08f577a, LATESTd2a9bf8f. Bundle19253bytes SHA25665343474098da1947f9511ef4b89862d69cefe4d5765628243d89210212aacd9 requires7e7b1def; evidence107306bytes SHA25655edfa24f444b3b2208f7d9a8666ddbd978bcffd433bc68aab73eb515263fdb0. No merge/publish/deployment. Task15 distinctcycles resumes from actualsource, neverarchiveancestry.

## Task15 legal duel/cycle continuation — active

BASE5ed4fe9b. Approved17Libraryentrykits +136exactpairkits bothPrimaryorders=289cases, retainprevious306build/1224openingadmissioncoverage. Extractonlyactualpublication/earnedfactsave-load/currentstatsfixture; oldprovenanceMinorleftuntouched, newduelsusecorrectcharacterIDprovenance. BothopponentshaveactualcommittedfourSkills+exclusiveEssence/Resonance, exactcurrentauthority andcapturedversions inPvE/PvP. InitialnewscaffoldRED102736129041 ismissinghelper, notagameplayregression. FirstrealturnbenchmarkVanguardmirrorLevel1/100bothcontexts; horizonisdiagnosticnotforcedvictory/12roundbalanceacceptance. No definition/formula/strategyrewrite. Needactualpayoff/countercasesnext, thisharnessaloneisnotall153distinctcycles.

Ruling: extract the repeated legal fixture rather than duplicate setup or import a test module — preserve all312admissioncases and default identities unchanged, enable independent real identities for both new participants — cost if wrong: lost old admission coverage or accidental fixture authority change; rerun the original suite alongside the new cycles.

Duel scaffold GREEN103022151382:3tests, actualVanguardmirrorsatLevel1/100bothcontexts; old312admissioncasespassedwithincombined102913208003(the2newfixturetestsfailprovenanceexpectedrawID; correctedexpectedcanonicalcharacter:ID, originaldoubleprefixMinoruntouched). WebtypesGREEN103112428806/103554692688. All289Level100PvP4rounddiagnosticmirrorsrunning103100291324.
Mercycycleinitial103255readAPwrongAPI(testfixture), fixed actualread(state,id). 103311showscurrent80%Level1VitalSevermissroll8930; realcooldownretryimplemented,8casesGREEN103415234065. Strengthened103553nowrequiresactualconnectedpositivepayoffandcounter(notmerelyconditional0recoveryonmiss):fourLevel1failbecauseMercyalsoobservablymissedunder12345. UseaseparatestatedLevel1seed1forconnectedcomparison;noaccuracy/resistance/stats/RNGpatch, noformula/sourcechange. This is fixturechoice, not a runtimebug. Earlierconditional8greenaloneisnotclaimedpositiveLevel1sustainproof.

MercypositiveconnectedcomparisonGREEN103639942921:8cases,Level1seed1/Level100seed12345, bothPrimary/context, actualincomingBasicwindow, ordinaryForcefulvsconditionalResonance,recovery5%maxHPversusactualVitalSever25%reduction, fullcosts/cooldown. ActualLevel1seed12345miss retained as2negativecases; combined13GREEN103722491118 includes3duelbaseline+10Mercy. No runtime/source/formulachange.

Ruling: complete289mirror diagnostic remains an explicit AUREVANE_FULL_ROSTER_CYCLES=1 gate; routine tests retain all17classes andbothPrimaryorders of the four selected pair contracts (25mirrors) — initialcomplete matrix is still running after approximately9minutes versus prior wholecheck4minutes, so repeating it for every unrelated check is disproportionate; execute fullmatrix separately and report it honestly — cost if wrong: a failure unique to an unsampled pair could be missed by routine CI, so any roster/combat release still needs the complete explicit gate. Optional AUREVANE_ROSTER_DUEL_EVIDENCE writes exact local results for balance investigation; no victory or balance inference from its4roundhorizon.

Initialfull289mirrorsGREEN103100291324:653.84s at10:41:54UTC; pre-finalstartupfixturebaselineonly. Replaced directreconciliationwithactualactivateCombatAbilitySources(...,true), matchingrealPvE/PvPcreation; defaultproposalscurrentlyhavenobattle_startautomaticcases, butkeepingactualstartupauthorityisrequired. Preservestartu pevents andrestoresdonotreactivate. Covering22GREEN104249384253 includes4duelcontracts+18payoffcases(Mercy10+Veiled8). Finaltypedtracefieldsandopt-inartifactprepared; scopedWebtypesGREEN104351135145, ESLintzeroGREEN104350446724. Originalencounter+312assertionssuffixbyte-comparisonpass.

Ruling: followactualserverstartupactivationratherthananapproximatecapture-onlyfactory — scopeistestfixtureonly, notproductionstartuprewrite — cost if wrong: missedinitialautomaticconditionsorreactivation; finalfullmatrixmustuseretainedcurrentfactory.

Frozenlegalduelmilestoneb586c2d4d363d2864185b92557c920018013ff5a /tree2baa20f39dcf2d093eb1a5c6f048eaf633aa6356, BASE5ed4fe9b. Covering22GREEN104457638411 afterfinaltracechanges. Mainrefreshunchanged29506e29; deploymentlockallfalse. Startfrozenrootregular25mirrorgateandexplicitfull289withprivateJSONLoutput; onecombinedreviewexactrange,norereviewunlessapprovednewscope. FullenvAUREVANE_FULL_ROSTER_CYCLES=1; evidencepathlegal-duel-final-matrix.jsonl. Turboenvstrictkeepsrootroutine25, directmatrixselects289.

FrozenrootgateGREEN104539928232 at10:49:23UTC:8160Vitest(4115core/3799web/246other)+7Node, format/lint/8types/2builds. Sourceb586c2d4cleanunchanged. Freshcombinedreview0C/0I/0newMinor, parentagrees, nofixpass/norereview. Explicitfinal289stillrunning; partialevidence102casesreadwithoutclaimingfinalsuccess.

Final: Ruling: Final root check — Accept the frozen-source actual receipt104539928232, exit0,8160Vitest+7Node plusformat/lint/types/builds; reviewer does not duplicate the parent run — Cost if wrong: unrelated integration regression if the source/receipt attribution is wrong.

Final: Ruling: Final289mirror gate — Require the final-source explicit gate and its complete289-row evidence audit before checkpoint finalization; the earlier653.84-second capture-only baseline cannot substitute — Cost if wrong: a regression introduced by real startup activation or final trace changes could remain.

Final: Ruling: All153class and136pair cycles — Keep individual setup/payoff/counter acceptance open; two directed choices plus bounded mirrors do not establish all cycles, and these approved kits equip94of136Skills — Cost if wrong: missing or ineffective authored cycles could be overlooked.

Final: Ruling: Ranged/kiting/ally/formation/elevation roles — Name the flat5x3 adjacent single-foe limitation explicitly and retain role-friendly scenarios as open; observed FarstriderBasic-only and WildwardenBasic/FieldRemedy choices are not class weakness or balance conclusions — Cost if wrong: unjustified AI or price changes from an unsuitable opportunity.

Final: Ruling: Full-match balance and12round pacing — Keep completed-encounter distributions, more seeds/contexts, sustain and long-cycle dominance open; no forced completion or formula/price changes — Cost if wrong: unbalanced or slow/degenerate gameplay could ship.

Final: Ruling: Complete AI strategic quality — Accept actual planner/executor integration but retain comprehensive tactics/Modifier/Controlled utilization as open; baseline movement only reduces approach distance, so deliberate ranged spacing needs an explicit strategy judgment — Cost if wrong: legal but inferior choices could conceal intended class roles.

Final: Ruling: Complete counter/interruption/history matrix — Accept only the named cooldown/miss/HealingDown/concealment and genuine terminal contracts here; existing earlier mechanics suites remain evidence at their actual narrower boundaries — Cost if wrong: Barrier/lethal/source-removal/queued/idle-timeout or other legal-kit combinations could fail.

Final: Ruling: Progression and advanced prerequisites — Treat learned/mastered records as seeded fixture facts, retain actual acquisition/award/prerequisite acceptance separately, and preserve eligibility without new grants — Cost if wrong: unearned or inaccessible content could be mistaken for a normal progression route.

Final: Ruling: Native browser and editorial consumers — Keep actual browser/input and broad prose/orange/editor/reader acceptance open; no UI change is part of this test milestone and known browser unavailability does not justify repeating failed install/tunnel loops — Cost if wrong: inaccessible or misleading real input/readers could remain.

Final: Ruling: Hosted authority/persistence/CAS/operations — Keep SQL transactions/concurrent receipts/restart/load acceptance open; local in-memory services and JSON restore establish narrower contracts — Cost if wrong: hosted-only integrity or lifecycle failures could remain.

Final: Ruling: Current Owner edits and release compatibility — Perform the final main refresh and preserve current hosted Owner edits; no publication/reconciliation/backfill/merge/deploy is authorized by this evidence — Cost if wrong: stale publication could overwrite edits or bypass release reconciliation.

Final: Ruling: Human gameplay acceptance — Keep experiential uniqueness/enjoyment and human acceptance open; never infer it from deterministic replays — Cost if wrong: mechanically legal but unsatisfying play could be declared accepted.

Final: minor (deferred): Rewind prime witness starts at its origin; separate Controlled anchor evidence exists.
Final: minor (deferred): Supporting Shot fixture does not pin its version.
Final: minor (deferred): Literal Ongoing pair fixture does not pin its dynamic pair ID.
Final: minor (deferred): AI repeats bounded route/target discovery across candidate modifier bundles; no demonstrated per-command timeout.
Final: minor (deferred): Original admission fixture passes a prefixed actor ID to the character factory, yielding double-prefixed provenance; numeric stats unchanged.

Finalfrozen289GREEN104539928945 at2026-10-16T10:56:33.607046+00:00:289unique cases; evidenceaudited. Actualcommands8227,lifecycles{'active': 289},manual-actionpairroots37of128atthiscontext.94equippedSkills/42outsidekits; noallcycle/balanceclaim. Finalreportincludesall12individualreviewexclusionrulings+5priorMinors. Frozenroot8160+7green; noC/Ifixes. Nextrole-friendlyrangedbrief/draftpreparedbutnotexecuted/notpartfrozenmilestone; no prematureAIretreatfinding. Finaldocscommitanddurablearchivefollow.

Legalduelfinaldocs1461fa3de939e5fb4770d5ab507b8c9561256a05 /treeeb85c415b6be3d253ef769a7072ceb29131c9c80 archivedat948cbbc30edf9eedbde7a8f961495aaa92c83167 /treece79be77f044565558b95eef18fdc940a9c71f45, nonforceexpected5354316eupdate. All4checkpointentrySHAsmatchlocal: bundle90d29444, evidence9eec86bf, metadataf94d04ba, LATESTdf3ddcbf. Bundle18618bytesSHA2563ba1880a0e025e9cf5f1d006c20af7e40f02ed05f1d9482fffa24c595a600016 requires5ed4fe9b; evidence172930bytesSHA256e5aaec5f6ede49e2073655eb4a2ed7f63c11aff14863899121aefcc8f0d8a7eb. Bundleverify+remotechildtreeproofs+gitlsremoteconfirmed. No hostedwrite/activation/merge/deploy. Resume mechanicalrangedtestbrief; no automaticPause/ExtraHighescalationfrombadadjacentopportunity.

## Task15 mechanical role-friendly ranges — active

BASE1461fa3de939e5fb4770d5ab507b8c9561256a05. Readrangedbrief; verifiedarchive948cbbc3beforeactualnewsource. Newrangedtestdraftcopiedtotrackedtestpath; nextrunexpectREDbecausecurrentduelfixtureignorescustomboardandremainsadjacent. No creativeAIstrategydesignneededforacceptedrange/counter/nativewalkingcontract. Onecollectivemilestoneend, noper-recordreview.

Rangednew4RED105844385466:currentfixtureignoredboardandAIonlyBasicatadjacentorigin. Addedonlyoptionalfixturewidth/height/startpositions,preserve5x3adjacentdefaults. Ranged4GREEN110029874919:actualAIrangedopportunity,45APshot,realcooldownwait,enemy40APclosingdeniesrange,20APretreat+45APshot=65AP. Longshot4additionalGREEN110217556406:actualfourlearnedkit replacingAimed,freeprime/invalidreleaseheld/paid20walk+60AP3MPrelease/onceperbattleused. Wildmark4+compatibility1GREEN110403289406:13cases; Wildreal30APmark+50APtwoactualpackets, opposingTideCleanse50AP6MPremovesMarkthenPursuitstilllegal50APonepacket. Defaultfixtureexplicit5x3stateequalsimplicitdefault.
ExtendedKeenFocus4passwithin110634824581,Fieldcraft4failonlyfixtureassumptions:Level100only18HPmissingso4%of500caps18not20; SnareordinaryhitmissesafterPursuit. Actualdiagnostic110741060489confirmsSnareaccuracy9438/roll9695missatLevel100(noRoot), notanexpiry/enginebug. Keepactualmiss/payment/cooldown andwaitrealcooldownbeforeboundedSnareretry; neverinstallRootorrepricechange. ExpectedhealminmissingHP/4%amount. TestsrequiresactualRootbeforeatomicdenialandcompleteHPimmutabilityduringwait. No productioncode/roster/AI/formulachange.

Rangedcohort21GREEN110835935267 afterHPcap/realSnareretryfixturecorrections. Optionalboarddefaultunchanged+explicitdefaultstateequalityguard. NoAI/formula/definitionchanges. Beforebalancejudgment, collect14one-offnaturalPvPbudgetmatches:7actualkits(pureAetherist+3lowManaPairsbothPrimary)×Level1/100,seed1,flat7x3distance3,max32roundsorfactualterminal. UseexistingplayLegalRosterDuel actualplanner/executor; nooutcomeforcing/rating/reprice. TemporaryVitestdriverretainedinignoredcheckpoint evidenceafterrun,notroutineCI. Datahasfinalresources/actualcommands/exactversions; itdoesnotestablisheveryintermediatethresholdeligibilitynorallcontexts/seeddistributions. ThisisconcreteevidencefornextExtraHighstrategy/balancejudgment,notpermissiontodounapprovedstrategychangesonHigh.

Budgetdiagnostic14GREEN111256224945,11:12:56–11:14:29UTC,92.87s. All14genuinecompletedwithin32horizon,noartificialvictory. Level1rounds5–9median6;Level100rounds11–29median13. EveryfinalMP>=70.24%(Level1)/81.25%(Level100). Three sampled lowMana pair actionsneverchosen; thisisactualselected-root/finalresourceevidence,notall-intermediatethresholdeligibility proof. Driverpreservedexactlyasranged-budget-diagnostic-driver.test.ts andremovedfromroutinetestsource; rawJSONL/sourcehashes/analysisretained. Covering68GREEN111257447820 includesnew21+old22+routine25. Nextpreparecombinedranged/budgetreviewandfinalrootgate, thendurablecheckpointforOwnerExtraHighstrategy/balancejudgmentbeforemorepricing/cycleassumptions. No newAI/doctrine/formulapricingchosenonHigh.

## Ranged combined review — frozen8657f3c4
Freshgpt6astraHigh0C/0I/1Minor. Parentregrade:Minorstands, no demonstratedruntimebug; deferdirectrejectedcommit/stateprimehardening. NoC/Ifixpass/norereview.
Final: minor (deferred): ranged Aimed/Longshot invalid-range tests witness rejected preparation, not direct commit; shared commit re-prepares before execution.
Final: Ruling: All distinct Skill/Essence/pair cycles — retain full Task15 individual setup/payoff/counter acceptance; five selected cycles are narrower — Cost if wrong: unexercised authored cycles may fail.

Final: Ruling: Repeat full289 matrix at this head — accept historical289 at its identified source plus unchanged defaults/full equality guard/25 routine mirrors/full root; no production change — Cost if wrong: an unsampled fixture interaction may remain.

Final: Ruling: Optimal ranged retreat/kiting/utility — reserve doctrine and utility changes for the Owner ExtraHigh judgment; a real ranged opportunity is proven — Cost if wrong: legal but inferior tactics could obscure intended roles.

Final: Ruling: Balance/repricing/reserve thresholds/twelve-round acceptance — keep acceptance open; fourteen single-seed mirrors cannot prescribe prices or pacing — Cost if wrong: slow or degenerate roles could ship if this limit is forgotten.

Final: Ruling: Intermediate MP/Requirement eligibility/nonselection causes — make no intermediate-threshold or causal claim from finalMP/command records — Cost if wrong: a mistaken causal explanation could drive wrong design.

Final: Ruling: Wider seeds/PvE naturals/asymmetric opponents/distributions — retain broader natural sampling as open; label sample seed1PvP mirrors — Cost if wrong: unobserved matchup or RNG imbalance.

Final: Ruling: Terrain/elevation/obstacles/allies/all target counts — retain role/geometry contexts as open; selected flat-board cases only — Cost if wrong: unreachable or weak support roles could be missed.

Final: Ruling: Complete Controlled cancellation/defeat/source-removal/interruption/duplicates — accept only named held-prime/release/once-per-battle case here; broader lifecycle gates remain — Cost if wrong: lost prime or duplicate effects in another lifecycle.

Final: Ruling: Every modifier and Controlled attachment composition — accept only actual KeenFocus payment and category rejection here — Cost if wrong: another attachment bundle could have a cost or capture defect.

Final: Ruling: No-input/repeated-event/interrupted-Move/reached-origin finished-engine safety — retain existing narrower evidence and final integration gate; manual turn ends are not idle timeout — Cost if wrong: unbounded/duplicated effects or unreachable-origin attacks.

Final: Ruling: Actual earning/mastery/advanced prerequisites — treat earned records as seeded facts while actual build admission is tested; progression remains separate — Cost if wrong: inaccessible or unearned loadouts could be misrepresented.

Final: Ruling: Hosted concurrency/rollback for publication/build/claim/recovery/settlement — retain physical SQL/concurrency acceptance; local services do not establish it — Cost if wrong: hosted-only integrity or lifecycle failure.

Final: Ruling: Stale-browser/alternate-character/direct-RPC expiry/revocation/CAS — retain Tasks8/16 authority acceptance; no relevant production code changed — Cost if wrong: stale privileged access could survive.

Final: Ruling: Malformed nested/captured/pending/summon and recursive private accuracy — retain hostile-input/serialization gates; valid capture/restore is narrower — Cost if wrong: bad input or private data leakage could remain.

Final: Ruling: Hosted Owner edits/timing/release reconciliation — require current-state reconciliation at final release; no hosted mutation authorized by checkpoint — Cost if wrong: overwritten edits or stale definitions.

Final: Ruling: Complete prose/orange/derived tags/readers/editors/Atlas — retain actual consumer audits and known Atlas issue; no UI acceptance inferred — Cost if wrong: misleading or incomplete presentation.

Final: Ruling: Native keyboard/touch/mobile/long names/history/200percent zoom — retain finished native-browser verification; do not repeat blocked install/tunnel loops without new basis — Cost if wrong: inaccessible controls or overflow could remain.

Final: Ruling: Human gameplay/release acceptance — keep experiential and release gates open; deterministic tests are not human acceptance — Cost if wrong: mechanically legal but unsatisfying or premature release.


FrozenrangedrootGREEN112015038115:11:20:15–11:23:54UTC exit0,8181Vitest+7Node,format/lint/8types/2builds. Frozen8657f3c4 treec9d8b9a5. Actualcombinedreview0C/0I/1newMinor;all18declinedscopeparentrulingsrecorded;noC/Ifixes.14diagnosticsseparate,notcountedinroutine8181. Finishdocs-onlycheckpoint+exactarchiveverification,thenactualOwnerExtraHighpause.

Rangedfinaldocs e7820890256733b51edc00e98895efebe0d3d6fc treefc792417c5ed5ed05a93e1ed55bba25135cb25f3; tested8657f3c4. Verifiedarchive d21131a10595d0b4d60d9a937f53761677a4afb0 tree90bff87df0948aae1faa3c5e18d36d311183ff15 child3e4a230e3a4092125695e1ef72949b42a3442955. Exact4remoteentries matchlocalblobSHA; nonforceexpected948c; lsremoteheadconfirmed. Bundle12959bytesSHA256d627f76df3a1d7e2dc3131ca4b35dee34c61b9378c7024aef0ff90c2df523d41 requires1461fa3d; evidence111596bytesSHA256780817173433de9fca4b9b6f92dbe4e2c0a80536be78f42e0cdb0614d70fe0bc. Mainrefreshstill29506e29. Frozenfull8181+7green;1newMinordeferred(prior5remain). No hostedwrite/activation/merge/deploy.

ACTUALPAUSE: Owner must switch actualrootsettingtoExtraHigh before nextstrategy/balancejudgment. Concretecheckpoint+report+task15-extra-high-handoff.md ready. Do not interpret another genericcontinue as proofsettingchanged; followactualOwnerinstruction/platformsetting. Task15/16OPEN, bothworkspacespreserved. Nextjudgment: currentnatural11–29roundLevel100pacing/finalMP/lowManaopportunities; no automaticreprice/AIretreatdoctrine.

## ExtraHigh continuation, Owner confirmed2026-10-16 07:34:42Trinidad

Owneransweredyesgo tosettingconfirmation. Resumeboundedbalanceinvestigation onactualsaved e7820890. ExistingTask15spec/planapproved; thisisobservationaldiagnostic,noproductbehavior/designimplementation. Ruling: probe20Level100 naturalmatcheswithpercommandactualresource/Requirement/legalquotes:6baseline+6seed17+6PvE+2asymmetric. OriginalactualAIcalledunchangedandexactresultreturnedthroughobservationalspy; assertstateimmutableandoneobservationperactualcommand. Nohelpermodificationorparallelengine; sharedRequirement/evaluatorused. ActualMPthresholdcausescannotbeinferredfromfinal-onlydata. Costifwrong:instrumentationmayalterdecisionorcoverage,guard baselineexactcommandreplayandrecordsourcehash. No cost/threshold/formula/AIchangeauthorizedbyrawabsence.

TypeRED114555465433: onlynewtest genericCombatEncounterState result needs actualstatbridgereattach beforetypedAPread; fixedviaexistingreattachhelper,notcast. ReceiptprobeRED114651222050: diagnosticassumedtop-levelstatuses; actualstatusesliveoneachcombatant. Preservefailedv1source/log, correctedobserveru.statuses; noenginefailureorrepricinginferred. Original20traceAPfieldomissionisdocumented(MP/HPonly); authoritativequotesusedactualAP, allselectedRequirementsownerMPonly.

ExtraHighjudgment:17purekits14completed10–24(median15amongcompleted),3active40(Bastion/Wild/Dawn);12roundacceptanceNOTMET. 20actualMPtraces show3lowManaRequirementsnevertrue;AetherPoisespendMPtrue594/594but0legalnaturalquotes.16directlegalrelease/countercasespassbothPrimary/Levels/contexts.51successfuldiagnosticexecutionsinclude9replays,42completed9activehorizons;notbalanceacceptance. Actual3stallreplayHPeventsreconcile:damage1173/heal750/Bary225;1610/897/0;1537/1471/40 acrossbothunits. Allcommands/finalHPMPexactreplay. Ruling:no globalMP/threshold/defensehealnerf/nohiddenfatigue fromoneflatboard;separateavailability/geometry/role-AI/sustainknobsandcounterroles. Costifwrong:postponedfixversusdamagingalreadyworkingrole/lowLevel/supportbalance. Correction:firstreceiptobserverstatusesfielderror;successfulprobeoptionalcombatant.statusesalsoabsent,omitted,notused;exactAPHPMP/fullactualeventsvalid. Nofullstatushistoryclaim. Nextboundedcorrectionfocusactualranged/setupopportunityplus4sustainrows;largerlookaheadneedsseparatearchitecture/knowledge/latencycontract,nofutureRNG/parallelengine.

## Frozen natural pacing combined review
Freshgpt6astraHigh e7820890..f8abb170:0C/0I/0newMinor; independentraw/hash/replay/HPreconciliationagree. NoC/Ifixpass/norereview;prior6Minorsunchanged.
Final: Ruling: All153class/Essence cycles and136pairs — retain Task15 individual cycle acceptance; selected kits/opportunities are narrower — Cost if wrong: unexercised cycles could remain broken.

Final: Ruling: Broad balance/difficulty/matchup distributions — keep acceptance open; limited flat-board seed/context sampling only — Cost if wrong: unsampled imbalance could ship.

Final: Ruling: Optimal strategy/ranged retreat/kiting/setupAI — retain separate investigation; availability and observed use are not optimality — Cost if wrong: legal but poor tactics could obscure intended roles.

Final: Ruling: Counterfactual recovery prices or reserve thresholds — require exact candidate trials before changing definitions; no uniform repricing from these observations — Cost if wrong: a supposed fix could weaken support or slow combat.

Final: Ruling: Full status history/individual quote-issue causality — retain explicit observer omissions and aggregate-issue limits; only actual HP/MP/AP where recorded, original-state quotes and events are used — Cost if wrong: incorrect causal diagnosis could drive harmful changes.

Final: Ruling: All terrain/elevation/obstacles/allies/target counts — retain role/geometry integration coverage; these are flat duels — Cost if wrong: intended roles could fail elsewhere.

Final: Ruling: Earning/mastery/advanced prerequisites — treat earned facts as fixture inputs while actual save/load/admission is tested; progression remains separate — Cost if wrong: unearned or inaccessible kits could be misrepresented.

Final: Ruling: Complete Controlled lifecycle and modifier composition — retain cancellation/defeat/source-removal/attachment gates; this branch is the named ordinary Aether-in-Poise release — Cost if wrong: lost primes or incorrect attachment costs could remain.

Final: Ruling: No-input/free-prime/repeated-event safety — retain final integration; manual turn ends are not timeouts or recursive-event witnesses — Cost if wrong: unbounded effects, extra turns or duplicate payment.

Final: Ruling: Interrupted Move/all unreached-origin attacks — retain broader interruption checks; one actual reached tile and four rejected paths are bounded evidence — Cost if wrong: an attack could originate from an unreached tile elsewhere.

Final: Ruling: Stale-browser/alternate-character/direct-RPC expiry/revocation/CAS — retain Tasks8/16 authority gates; no corresponding production changes — Cost if wrong: stale or unauthorized access could survive.

Final: Ruling: Malformed nested/captured/pending/summon and recursive privacy — retain hostile-input/parser/serialization gates; valid capture usage is narrower — Cost if wrong: corruption, historical substitution or private accuracy leakage.

Final: Ruling: Concurrent publication/build/claim/recovery/settlement — retain physical concurrency/SQL/coherent-commit/no-contest gates; local fixtures do not establish them — Cost if wrong: duplicate or inconsistent durable outcomes.

Final: Ruling: Owner edits/history/release reconciliation — require final current-state/hosted reconciliation; append-only historical definitions remain unchanged here — Cost if wrong: Owner edits or historical definitions could be overwritten.

Final: Ruling: Complete prose/derivedTags/editors/readers/Atlas — retain full presentation audit and known Atlas gap; no consumer changes here — Cost if wrong: misleading or inaccessible mechanics presentation.

Final: Ruling: Long names/history/mobile/native keys/touch/200percent zoom — retain finished native-browser checks; no new physical browser evidence — Cost if wrong: overflow or inaccessible primary controls.

Final: Ruling: Hosted behavior/human gameplay/release acceptance — keep open; local deterministic evidence does not authorize release — Cost if wrong: premature release or unsatisfying play.

Final: Ruling: Final full gate/durable recovery — require frozen8197+7 actual completion and exact archive blob/head verification; prior gates are not substitutes — Cost if wrong: incomplete checks or unrecoverable evidence could be mistaken for closure.


FrozenbudgetrootGREEN115238205744,11:52:38–11:56:16UTC exit0:8197Vitest+7Node(4115core3836web246other),format/lint8types2builds. Frozenf8abb170 tree120d4e05. Combinedreview0C/0I/0newMinor;prior6Minorsunchanged;18declinedscopesindividuallyruled. Docs-onlyfinalization+backupnext. PacingstillNOTaccepted,Task15/16OPEN,definitions/AI/formulas/pricesunchanged.

Budgetfinaldocs d817d6f22afcc6dc357257a2fb315f0104abd3c7 /treeff8027bc209f488b06f73a8f5f102e6872fde86f. Testedf8abb170fa8b48fd0e7119af0af91624860cc0a5,full8197+7GREEN115238205744. Archived15cd5ca9c505cfeb62043e1122437f82aa26e58f /tree5dcbe1d56c78cca92fcb8e0c9abb60c83f230836 /child768c0253ef4f6f38edf3aa67d6cba1296203fc5d;expected-d211nonforceupdate,all4remoteentrySHAsmatchlocal,gitlsremoteheadconfirmed. Bundle9911bytesSHA256dab58f55928f4e774c4eea76879472ade17777144745dee1919e6d43fff512ea,requires e7820890. Evidence239621bytesSHA25640e4c2c6742e1b55340ba33cb479a47e4b19bbc556096a9cfb7a5dc418a3a910. Metadata198e4e2f,LATEST5876732f;local/remotehashverified. Mainstill29506e29,cleanbranch. No productAI/mechanics/price/formula/definitionchanges,hostedwrite/activation/merge/deploy.

Task15/16OPEN;rough12roundbalanceNOTaccepted. OwnerExtraHighconfirmed,donotaskagainwithoutnewsettingboundary. Nextbrief task15-budget-next-brief.md records narrowed role/setupAI and4sustainrows, no untested numbers or silent architecture selected. Preserveworkspaces/51rawdiagnosticexecutions/failedprobe and6priorMinors. Newboundedjudgment/reportreviewcomplete,noC/Ifixes/norereview; nextworkmustnotreinterpret this as releaseacceptance.

RangedAIinitialpremiseRED120852692630: actualpaidretreat+Aimedforecastvalue/AP is0.70769vsBasic0.73333atL1;0.55385vs0.8atL100. Thisisafalsebetter-choicepremise,NOTAIruntimebug. PreserveefficientBasicnegativeguard; do notforcekiting. Nextvalidcaseactualearned3participantFFA opens2targetVolley; initialtesthelperonly2participants,expectfixtureREDbeforeactualAIdecisioncomparison. Sharednativewalkingcostnotwaived.

RangedAIvalidRED121357007675:4realearnedbuilds seed1actualactor2center,3hostilesadjacent,sharedpaidretreat+3targetVolleyvalue/AP strictlybetterthanBasic;currentAIstillaction. GREEN1216228855878casesafterboundedopportunitymechanism. Actorseedfixtureerrorsrecorded121113/121215/121226;fixedoptionaladditionalKits+facingspreservingdefaults,seed1actualfirstparticipant2diagnosed121326789442,norngfabrication. Coreguards101GREEN122331011442 aftercorrectmovementSpentandonlyonehostileControlledfixture (farotherwasvalidrelease,notAIbug).13coreGREEN122725908731 inclactualGroundpolicy1Circleactivateareas;priorGroundfixtureerrors122415/122548usedwrongselection/missingcurrentGroundpolicy,notenginebugs. Scopedweb124GREEN122506851926. Typescore/web122504489076/491898green;rootlintcommandignoredwebfiles(warnings),properpackage-lints122656268301/269535green.
Performancev1original/currentpairedactualmodule3scenarios5samples:multi231→547ms25→40quotes;close48→170ms9→22quotes;inrange54→54ms9→9. Tightennewone-foeprobe4sharedquotes,keep16/24/32multiwithprofiles+4neighbors;notallfuturecombos. PerformanceREDnewadditional5capthenGREENneeded. Explicitlatency/coverage tradeoff:maymissbetterunexaminedlane/bundle,butkeepsoldimmediatedecisionunlessrealquotedimprovement. No globalcache/newformula/futureRNG.

## Task15 bounded ranged AI spacing — source freeze preparation
BASEd817d6f2; valid old-AI RED121357007675→GREEN121622885587; actualweb8 in affected45GREEN123334328799. Corefinal15GREEN124038376935 after adding actualrough/jumpparameters (prior13run didnotinclude them); capturedflat15AP→85AP, heldControlled70AP6MP→10AP14MP. No runtime repricing/definitions/formulas. Finalprefix4singlefoe;multi16/24/32,4neighbors. Calibratedmulti220.98→520.59ms/quotes25→40;close50.89→103.72/9→14;alreadyrange70.53→63.92/9→9. Pacing5 exactoldreplay123333122853;3sustainhorizonsremainactive. Scopedchecks/fullgate/explicit289/freshcombinedreview/durablebackupfollow.
Ruling: retain boundedprefix and actual300ms multi-enemy overhead — avoids introducing an unapproved whole-turn/cache engine while correcting a proven beneficial opportunity — Cost if wrong: later lanes/bundles may be missed and latency may be unacceptable in unmeasured production cases; broader quality/latency gates remain open.
Ruling: do not force single-targetkiting — actualcombinedAPforecastisworse thanBasic — Cost if wrong: a later tactical benefit is missed; no whole-turn optimalityclaim.
Finalscopedtypes:webGREEN124100011307;coreRED124058767755 onlyGroundfixtureinferredliteralpolicytype correctedwithReturnType<typeof ready>annotation→GREEN124209940649. BothscopedlintGREEN124101227252/124102466796. Lasttestfileformatapplied;fullfrozenrootwillcoverit. Mainfresh29506e29.

Combinedfreshreview2931dfa7:0C/2I/0newMinor. ParentagreesbothImportant. SinglefixwaveRED125352283923: all3validregressionassertionsfailafteractuallegalquotes/resourcepayments/ratiosestablished; priorfailedfixturepremises(VolleyhasnoMPcost,modifiercap15000,powercap20,capturedBasicremovalnotlegacy,rangequoteutility)retainednotruntimefailures. FixrichflatoptionalspacingonlypureAPinstantunconditionalunclockedwalking; exactquoteap/effectmetadatafornativeBasicattachments; positivezeroAPimmediatevalueInfinite.18focusedGREENdirectverbose13:54:55; combined125426005074exit0butemptylognotacceptedastest-countproof; finalfullgatewillprovidecounts. CoretypesGREEN125454943868. No rereview.

## Combined review and parent rulings

Fresh gpt-6-astra High review of d817d6f2..2931dfa7 found0Critical/2Important/0newMinor. Parent agrees with both Important grades and fixes both in one RED→GREEN wave; no rereview. The rich Move regression executes a real15AP/15MP flat Move, leaves5MP and proves the exact held6MP release is illegal. Native Basic plus an actual eligible attachment is compared against a legal ranged quote with greater raw utility but worse paid efficiency; a positive free canonical attack is also immediately legal. All three valid old-behavior RED assertions fail in `125352283923`. Final18 focused tests pass after the fixes; the frozen full gate below supplies retained final suite counts. Earlier fixture errors are retained as fixture errors, not engine regressions.

Flat spacing is now restricted to a single unconditional Instant Move effect, self utility targeting, only AP costs and no cooldown, Requirements or activation limits. Rich edited Move remains executable through its existing command authority, but is excluded from this optional forecast. Native Basic attachment candidates now retain their already-quoted AP cost/effect utility; positive zero-AP alternatives explicitly have infinite value/AP. Existing historical Skill ranking remains guarded.

Final: Ruling: Complete roster cycles — Retain every class, Essence and pair cycle as a Task15 gate; selected ranged cases are narrower — Cost if wrong: An unexercised cycle could remain broken.

Final: Ruling: Whole-turn optimality and kiting — Accept only one bounded movement opportunity; defer whole-turn planning to a separately specified design — Cost if wrong: Legal but inferior longer strategies may remain.

Final: Ruling: Later lanes and attachment bundles — Keep the explicit deterministic prefix and measured budget — Cost if wrong: A better later opportunity can be missed.

Final: Ruling: Line-of-sight or facing-only movement — Keep the stated range-gap trigger; do not claim this wider search — Cost if wrong: Useful repositioning without a distance gap remains unavailable.

Final: Ruling: All reactive movement and interruption forecasts — Restrict flat Move to pure AP/geometry, skip captured Ground and Poison ticks, and replan actual results; broader reactive forecasts remain open — Cost if wrong: An unmodelled automatic consequence can make an optional move less useful.

Final: Ruling: Hosted and worst-case latency — Retain local five-sample measurements only and keep production latency acceptance open — Cost if wrong: A slower unmeasured catalogue or hosted request could exceed acceptable time.

Final: Ruling: Natural sustain pacing — Keep the three active40-round mirrors as unresolved pacing evidence — Cost if wrong: Sustain stalls could ship if this limit is forgotten.

Final: Ruling: Twelve-round balance — Do not accept the benchmark from these unchanged samples — Cost if wrong: Broader matches can remain too long or too short.

Final: Ruling: Repricing and formulas — Keep all current definitions, resource thresholds and formulas unchanged here — Cost if wrong: Balance correction is postponed rather than guessed.

Final: Ruling: Native browser and accessibility — Retain native keyboard, touch, mobile and zoom acceptance; do not repeat blocked installs without new basis — Cost if wrong: Inaccessible controls or layout defects can remain.

Final: Ruling: Complete editor and reader chain — Accept only the new firing-lane reason mapping; retain the full consumer audit — Cost if wrong: Other descriptions, previews or editors can misrepresent mechanics.

Final: Ruling: Hosted Owner edits — Require current hosted reconciliation at release while preserving captured history — Cost if wrong: Stale publication could overwrite current Owner work.

Final: Ruling: Hosted admission and authority — Treat the four hostile participants as local authority fixtures; keep standard hosted admission and concurrency gates — Cost if wrong: A hosted-only admission or integrity defect can remain.

Final: Ruling: Migration, publication, activation, merge and deploy — Perform none in this checkpoint; preserve the deployment lock — Cost if wrong: Premature release could bypass unfinished gates.

Final: Ruling: Final full-root check — Require an actual completed green gate at the final fixed source; the initial8220 run is historical — Cost if wrong: Unchecked regressions could be declared accepted.

Final: Ruling: Final full289 replay — Require a fresh289 unique-case audit at the final fixed source; preserve the earlier run separately — Cost if wrong: A production AI regression outside the selected examples could be missed.

Final: Ruling: Exact recovery backup — Require verified bundle prerequisites, four remote blob SHAs and remote branch head after final docs — Cost if wrong: An incomplete or inaccessible checkpoint could lose source or evidence.


Prior six Minors remain deferred individually; no new Minor and no incidental fixes.

Final: minor (deferred): Rewind prime witness starts at its origin; separate anchor coverage exists.

Final: minor (deferred): Supporting Shot fixture does not pin its version.

Final: minor (deferred): Literal Ongoing pair fixture does not pin its dynamic pair ID.

Final: minor (deferred): AI repeats bounded route/target discovery across modifier bundles; measured extra work is not a fix for that issue.

Final: minor (deferred): Original admission factory has double-prefixed character provenance; numeric stats are unchanged.

Final: minor (deferred): Prior ranged negative tests assert rejected preparation rather than a direct rejected commit; shared commit re-prepares.
Final: fixed Important1 richflatMove and Important2 incompletequotecomparison(includingparentdiscoverednonwinninghistoricalSkillbranch) — validregressions125352283923/125908569732 RED→GREEN125944639162, covering97tests/4files;finalcoretypes125945012809 andlint125945015803GREEN. No second review.19newcore+8newweb =27addedroutinecases; expectedfinal8224+7,claimonlyactualgate. Postreviewdiagnostics1255581249356GREEN,5pacingexactoldreplays;15pairedwarmtimingscrediblebutnotSLO. Exactdiagnostichashprovenanceexplicit: lastmetadataeditonlyinlegacybranchbypassedbycurrentcanonicalkits.

Owner reconfirmed actual ExtraHigh6.1 at09:04:50/09:05:17/09:05:34Trinidad2026-10-16; no further setting confirmation required. Finalfrozen144b476d tree4a95a415 fullrootGREEN130030804571,13:00:30–13:05:28UTC:8224Vitest+7Node,format/lint8types2builds. Explicit289stillrunning; no fullTask15/balance/releaseclaim.

## Verification-discovered single-target turn budget

The144b476d full root passed8,224+7 (`130030804571`) and its explicit289 replay passed (`130030804773`,769.36s):8,227commands, all289 active after four rounds,17pure/272pair-Primary cases,94equippedSkills/42outside these kits and37/128manual pair roots selected. Those are historical source gates, superseded below after the replay exposed one changed command sequence. The complete captured version/ownership/resource audit passed.

The Wildwarden-primary Farstrider/Wildwarden pair initially pays20AP to move,45AP for Aimed Shot, then20AP to walk straight back. A shared-authority diagnostic (`131152067434`) records Basic30AP/forecast16 versus the shot45AP/forecast36, so the original per-AP gate is narrowly satisfied (36/65 versus16/30), yet a genuine three-Basic turn is affordable and has forecast48. FinalHP differences do not establish broad causal balance. The observer's first native-only evaluation call was a diagnostic error (`131126369784`); the corrected observer uses the actual canonical command quote. No source or RNG is changed by observation.

Parent grades this avoidable round trip Important within the still-open verification/fix wave. Four new real learned-build cases prove the actual repeated Basic payments, damage and unchanged starting input; two Level100 PvE/PvP assertions are valid RED `131440350177`, while Level1 already keeps Basic. A conservative single-enemy safeguard now also requires the shot's forecast value to exceed the current AP budget's pure repeatable Basic benchmark. It uses the existing quote, not new command evaluations or simulated future attacks. It applies only to a legal Basic whose captured group has only AP payment, one Instant damage/Pierce effect and no cooldown, Requirement or activation limit; captured MP costs/cooldowns are explicitly excluded and their next real Basic is proven illegal. Native historical Basic retains its ordinary AP-only contract. Timing resolves through the captured shared timing policy, including the ordinary unset Instant default. An initial guard incorrectly required explicit Instant and was corrected after the same regression stayed RED.

This is a conservative current-snapshot comparison. It neither queues repeated attacks nor predicts their random outcomes, reactive changes or every later strategy. It can reject a useful single-target setup whose later benefit is not in this quote; the broader whole-turn gate remains open. The useful three-target Volley and held Controlled walking/release remain covered. There are now21 core guards and12 real learned-build cases. The two additional guard fixtures first used a shot with worse per-AP value than Basic; actual quotes exposed that bad premise, and a supported Power20 shot establishes the intended positive comparison. These fixture errors are not runtime defects.

Final: Ruling: Single-target turn budget — reject the witnessed unnecessary round trip using the current pure Basic quote and available AP, while excluding edited Basic resource/clock restrictions — Cost if wrong: a strategically useful later ranged opportunity may be conservatively missed; no full-turn optimality is accepted.

Final: Ruling: Repeat final source gates after verification finding — freeze again and rerun root plus explicit289 because production decision behavior changed; keep both earlier successful runs with their exact source identities — Cost if wrong: the known regression or a later change could escape acceptance.

Final: fixed parent Important single-target roundtrip — realbuildRED131440350177(twoLevel100contexts;Level1alreadycorrect)→12GREEN131704942954;21kernelguards+oldAIcovering99GREEN131914094432. CapturedBasicMP15/cooldown3positivecontrols proveactualsecondBasicillegalandallowbeneficialpaidspacing, withquotemathverified. FinalcoretypesGREEN132011769639,corelint132011766155,webtypes/lint131756081862/131756081969,scopedformatallGREEN;freshmain29506e29. Sameonefixwave,norereview. Freezeagainandcompleteactual8230+7rootand289,notearlier8224+7.

Owner09:21:24Trinidad asks ETA and earlier unfinished pre-rebalance work, explicitly saysneverthelesscontinue. Restated currentAIcheckpoint15–25minutesifchecks/backupgreen,notlaunchETA; prior16–30active-hourwholecombatplanningrange remainsprovisional,no reliabletighterliveETA. Earlieroriginalcombatintegration(T13)stillrequirescombinednewrosteracceptance:Targeting/Move/editableBasics/Controlled/editors/readers/previews/keyboardmobilebeforecombatlive. LaterOwnercombatfirstorderpreservesbroaderMaster/Staff/Players/Events/Music/worldaftercombatpackage; nothingdroppedorclaimedcomplete. Continuewithoutaskingforanotherconfirmation.
Owner09:24:54asksdirectlaunchETA. Rootanswersbestprovisional16–30MOREactiveworkinghours(roughly2–4fullworkdays)forcombatlaunchincludingunfinishedcombatintegration,balance,finalreleasechecks;planningestimate,notconfirmedcalendardate/backgroundexecution. BroaderMaster/worldfollowscombatrelease. Continueactiveauthorizedwork.
Finalfrozen0cf9f9c3 tree9b6013ac rootGREEN132059391198 at13:20:59–13:25:54UTC,8230Vitest+7Node(4136core3848web246other),format/lint8types2builds. Final289running110cases. Nextcohort12mechanicaldraftmayrunobservationallyonlyafterthisrootfinishes,temporarytestcopyremovedbeforebackup;noproductionmutationorclosingthecurrentreview/rosteracceptancefromthatseparatecohort.

Owner09:28:26Trinidad distinguishes already-live modularfoundation fromrosterrebalance andexplicitlyrequiresnotforgettingthethirdunfinishedprelivework. RetainedasanindependentcombatRELEASEBLOCKER: Targeting/Move/editable5Basics/Controlled(andRewindhistory),remainingcombatcontrols,sharededitorandreaderintegration,SkillManagementpreviews/effectpopups,newrosterconnectionandnativecross-deviceacceptance. NeitherlivefoundationnorTask14/15mechanicalevidenceclosesit. Mustfinishandexplicitlyverifybeforecombatrelease;broaderunrelatedMaster/worldlaterperpriororder. No publication/activation/deploy from current checkpoints.

Owner09:29:44Trinidad continues and asks to flag when High suffices; parent advises High is enough for current verification/integration, ExtraHigh only if a later substantive balance judgment warrants it. Do not claim to change setting automatically. Owner again asks broaderMaster order/Targeting: parent confirms combatcontrols/editor-reader/previews/newroster combined native acceptance beforecombatlive; broaderunrelatedMasterpanels followcombat. Targeting substantial implementation is not complete combined acceptance.
Naturalnextcohort8actualrunsGREEN132837210823 at0cf,8validrawrows,Level1bothkitsround9complete;Level100bothstillactiveafter40 inPvE/PvP. No globalbalancecause/AIdefect inferred;driver/raw/analysis preserved;tempactualsource removed. Twelve workingmechanicalcases remain draftpendingnewcohortreviewandroot.

Finalspacing0cf9f9c3/tree9b6013ac verifiedfullroot8230Vitest+7NodeGREEN13205939119813:20:59–13:25:54UTC;format/lint/8types/2builds. Explicit289GREEN13205938783813:20:59–13:33:34UTC753.99s. Actualaudit289unique17pure272pair-primary8219commandsallactive4rounds94Skills/42outside38of128Manualpairrootsselected,version/ownership/resourcesvalid. SHA256d60cb8110a8ad3f74342c52fbaf368c2c52aa04c6e44f22d0fd1dfcdd6cba280. Exactoldcommandarrays287unchanged;FarWild/WildprimaryandTideWild/Wildprimarychangeafterguard. BothkeepinitialBasicthenadmitlateraffordablelane;noimmediateoutandbackFarfirstturn. Notwholeturn/globalbalanceacceptance. Freshmain29506unchanged;backuparchive15cdunchanged. Finalreportupdated,all19individualdeclined/additionalrulingsand6deferredMinorspreserved. Currentfrozenproductionclean,temporarydiagnosticsremoved;finaldocs-onlycommit/archivepending.

SpacingrecoverybackupVERIFIEDremoteactualgitlsremote d04f84e64d0ecc9be8f9b38f4ca3e8f66d8fb8af/roota7650c68e4313d2c9c4c40e462e3f1abb1c2da9b/checkpoints6d637b7fc440d477156128985cc011f895ecaa16. Fourremoteentriesexact:bundleee44aae84477fe4054f5f5d697e9b451040cddb0(24832bytes/SHA25668d862de42e3285e48560b86810b7f2811b4bd5ee703cbdc91ca314bc5ab8e20),evidencead2ed0d9b45a8c81592916fc216ee5c7aab15007(434419bytes/SHA2569b85c16142a0d09d83e7d1b7ae906522c958630ce3727e69e166e3611b916e56),metadata2a894ec4698f4060e8c40a1bcd747020da35cdec,LATEST22b5669c13f912b9a7eaecce9e745e6263946db7. Sourc034a56fb4fcb3c21996a7e2615a8ddc5dc1176b9/tree8e4b434e649e1b295740ad05f06f804a680f3c26docs-onlydescendanttested0cf;clean;prereqd817retained/bundleverifyokay. Expected15cdnonforce. Noactivation/merge/deploy. Currentboundedmilestoneclosed;parentTask15/16/fullbalance/nativecombatintegrationremainOPEN. Continueprepared12defensecyclecohort.
Ruling: Do not rerun289fornexttest-onlycohort — production/defaultfixture/manifestareunchangedfromtested0cfandnewtestsuseprivatehelpers,fullroot/typeswillverifytestintegration — Costifwrong:anunexpectedtestsideeffectcouldmissmatrix-onlybehavior;actualsourceauditandseparatestatecreationguardthis.

Nextdefensecyclecohortpermanent12GREEN133622941124;webtypes133633102407;actualappscopedESLint133657921664;Prettierpass. Rootconfiguredscopedlintignoredappfileandnotaccepted,evidencecorrectedwithoutclaimingfailureasproductbug. Oneaddedtest/privatehelpersandreportonly;no production/definition/defaultfixturechange. NewreportexplicitlyboundsStalwarttoactualpositiveadditionalpacketnotindependentexactfinaldamageaudit,naturalsnotbalance. Freezeonecombinedreviewand8242+7expectedrootnow.

Defensecombinedreviewbe7d24e6complete0Critical/0Important/1newMinor;parentagrees/deferpositiveevent-vsHPcoherencehardening,nocurrentruntimebug. Prior6Minorsseparate/unchanged,total7. No fixwave/rereview. All15declinedbehaviorsindividuallyruledwhy/costinreport:
Final: Ruling: Independent exact Stalwart final damage — Accept the stated additional positive-packet witness; retain formula audits elsewhere — Cost if wrong: An event/arithmetic regression outside this witness could remain.
Final: Ruling: Full Fortified coupled mitigation and constraints — Keep detailed component arithmetic open; this cohort proves setup/payoff presence and finite expiry — Cost if wrong: A coupled modifier could be miscomputed.
Final: Ruling: Exact two-turn intermediate clock boundaries — Accept bounded actual expiry here, without claiming every intermediate boundary — Cost if wrong: An off-by-one duration could escape this cohort.
Final: Ruling: Fortified Dispel availability — Assert no unsupported remover; find an actual owned counter before such a claim — Cost if wrong: A missing intended counter remains a wider roster concern.
Final: Ruling: Guard Break misses and other timings — Accept the legitimate connected seed only; retain normal miss authority — Cost if wrong: Other counter timings remain unexercised.
Final: Ruling: Every Requirement opportunity — Report selected commands only; the driver does not record all rejected opportunities — Cost if wrong: Natural AI causes cannot be assigned from these logs.
Final: Ruling: Setup AI and whole-turn planning — Keep strategic quality open; no planner change follows from these mechanical witnesses — Cost if wrong: Legal inferior choices can remain.
Final: Ruling: Global sustain and twelve-round balance — Keep Level100 active-after40 evidence unresolved; do not infer a global cure — Cost if wrong: Sustain stalls or broader pacing defects remain.
Final: Ruling: All294 records and remaining distinct cycles — Continue full Task15 coverage; three sequences do not close it — Cost if wrong: Another authored cycle may remain broken.
Final: Ruling: Editor reader and complete combat controls — Continue the independent pre-launch integration gate with the new roster — Cost if wrong: Misleading or unusable consumers could remain.
Final: Ruling: Native keyboard touch mobile and zoom — Retain native browser acceptance and recorded environment blocker — Cost if wrong: Real input/layout defects can remain.
Final: Ruling: Current Owner edits and hosted authority — Require actual release-time reconciliation and authority checks — Cost if wrong: Stale data or hosted-only integrity defects can remain.
Final: Ruling: Atlas and human acceptance — Keep both gates open, including recorded Atlas motion bound — Cost if wrong: Integrated usability/performance can remain unacceptable.
Final: Ruling: Final frozen full project gate — Accept only the actual completed result below; review alone supplies no pass — Cost if wrong: Unchecked test integration could be accepted.
Final: Ruling: Hosted operations and release readiness — Perform no publication/activation/migration/merge/deploy; retain release gates — Cost if wrong: Premature release could bypass unfinished work.
Final: minor (deferred): New defense witness: reconcile positive damage events independently to recipient HP in a future relevant test touch; no current divergence demonstrated.
Final: minor (deferred): Prior Rewind witness primes at its origin; separate anchor coverage exists.
Final: minor (deferred): Prior Supporting Shot fixture does not explicitly pin its version.
Final: minor (deferred): Prior literal Ongoing pair fixture does not pin its dynamic pair ID.
Final: minor (deferred): Prior AI repeats bounded route/target discovery across modifier bundles.
Final: minor (deferred): Prior admission fixture has double-prefixed character provenance; numeric stats unchanged.
Final: minor (deferred): Prior ranged negative cases assert preparation rejection rather than direct rejected commit; shared commit re-prepares.

Owner09:41:50TrinidadconfirmsnowHigh/proceed. ContinueHighroutineintegration;flagonlylaterjudgmentwarrantingExtraHigh,do notaskagainnow. Defensefrozenbe7d24e6fullgateGREEN13380205541313:38:02–13:41:56UTC8242Vitest(4136core3860web246other)+7Node,format/lint/8types/2builds. Production/defaultfixture/definitionsunchangedfrom0cf;no289rerunforthistest-onlysource. Review0C0I1newMinor,total7deferred;all15declinedrulingsinreport. Finaldocs-onlycommit/exactbackupnext,thenactualcombatdisplayaudit.

DefenseexactrecoverybackupVERIFIEDremote f13882a53356c6958ea66af7459f16c16d490e51/rootae8fed05686b02f60fafe7cd83a093f54c66bd13/checkpoints34a7ccdf32de0307db6c90cc701407b59ef80f49. Actualgitlsremoteand4remoteentrySHAsmatch:bundlef20c515292af5297d4c79318ec2e2474be570f55(7983bytes,SHA2562f54d46068765f8dd401d1c4227c38436b0b9c7f6bac610c32c853fa30498595),evidence5432ebc13a1a81f9a2859da6785d030746bd1593(118349bytes,SHA256d7734113454c8887480746e7aef44e06030c61e413403361b8cacca67e928472),metadata6bff13390d9739e3611ab49ec6884b99a96f6a3b,LATEST1abfbdf0e57c911fb6fef5eb784611e41bcdda46. Sourcec33e9004/tree4c041a1a/testedbe7d/prereq034a. Nonforceexpectedd04f. Noactivation/merge/deploy. NewdisplayBASEc33e;brief task15-combat-display-brief.md.
Ruling: Continue existing approved combat-display design underTask15 ratherthan repeatapprovalgates — Owner repeatedly sayscontinueandexplicitlyrequiresunfinishedTargeting/controls/editor-reader/previewsbeforelive; fixesresolvepreviousrecordedbefore-releasefindings,nonewsubsystem — Costifwrong: presentationchoicesmayneedOwneradjustment,butrelease/nativeacceptanceremainopen.

DisplayTDD:8validold-sourceassertionsRED134737030661 acrosscaption3/Groundsubset1/selectedspecialcategory1/ownerDamagefact3;earlier134659/134720usedunsupportedManualActionDamageUpthenGuardedmissingstacksfixtureerrors,notruntimebugs. ExtraDamagefallback/Airborne/selectedcategory3assertionsRED134802174114. Firstfix134927caughtnewoptionalundefined===undefinedselectionaccessbug;guardbothactualselectedBehaviorbeforeidentitycompare. Focused62GREEN134950734711. Covering1396at135040:1393pass/3oldGroundwordingexpectationsfail;updatedexpectedqualifiednote+exactentrymarkercountwithoutweakeningpayloadchecks. Webtypes135010caughtnewrequiredproducerfieldonhistoricalsnapshots;adddealsDamagetohistoricaloptionalprojectionkeysinsteadofrewritingoldfixtures. Weblint135010591509pass. Covering/typesrerunningafteractualcompatibilityfix. No stagedfreeze/reviewyet.

Displayfinalcovering1396/78GREEN135126083142;webtypes135126084974;lint135223417849;allchangedPrettierGREEN;targetedcore135223416078actually12targeting-shapecases/1file,notGroundcoverage(nonmatchingGroundfilter). Manifestb86unchanged/deploylockfalse. Reactchecklistappliednohooks/fetch/effect/cache/artgeometrynew; event-drivenmodechange/selectedmemo dependencycorrect. Freeze17code/testfiles+reportforonecombinedreview/fullroot(expected8253+7only,actualnotclaimed). NoAI/execution/definition/defaultfixturechange;full289notrerunperreportedruling. Whole294prose/nativecontrols/readerforecasts/Owneredits/hosted/Atlas/releaseremainOPEN.

Displaycombinedreviewb915complete0C1I0newMinor;parentindependentlyconfirmsunbounddescriptorAirborneoverrideincludesBasicbeforelaterhelperexclusion;docsCOMBAT966forbids. AcceptImportant/inheritedintegrationdefect,notexecutorregression. OnefixwavewillfirstexactoriginalextractsharedconstructorpaththenactualBasicvsAttackRecoveryUtilityregressionRED→GREEN;no rereview. Keepcurrentlyrunningb915rootfrozenuntilcompletion;notfinalgateafterfix. All33declinedbehaviorsindividuallyruledinreport:
Final: Ruling: Native keyboard switching — No mounted keyboard evidence; retain native gate — Cost if wrong: Shortcut behavior may still fail.
Final: Ruling: Native touch switching — No device interaction evidence; retain native gate — Cost if wrong: Touch switching may still fail.
Final: Ruling: Mobile layout — No native viewport inspection; retain layout gate — Cost if wrong: Narrow layouts may be unusable.
Final: Ruling: Zoom bounds and contrast — SSR does not establish rendering; retain visual gate — Cost if wrong: Overflow or unreadable contrast may remain.
Final: Ruling: Physical board highlighting — Source inputs are checked, actual rendering remains unobserved — Cost if wrong: Wrong displayed footprints may remain.
Final: Ruling: Mounted stale-version and timing races — No mounted async exercise; retain race gate — Cost if wrong: Stale plans might survive a response race.
Final: Ruling: Complete targeting acceptance — Presentation delta covers named paths only — Cost if wrong: Another target or recipient path may be wrong.
Final: Ruling: Move acceptance — Preserve prior implementation and combined native gate — Cost if wrong: Movement gestures or reached-origin behavior may remain unverified.
Final: Ruling: Editable five Basics acceptance — Preserve prior captured implementation and integration gate — Cost if wrong: An edited Basic consumer may be stale.
Final: Ruling: Controlled end-to-end acceptance — Unchanged authority is not fresh native evidence — Cost if wrong: Prime release or cancellation interaction could fail.
Final: Ruling: Rewind and history end-to-end acceptance — Keep existing historical evidence and final integration gate — Cost if wrong: A restored anchor or reader could be wrong.
Final: Ruling: Remaining combat controls — Continue original independent release prerequisite — Cost if wrong: An unfinished control could ship.
Final: Ruling: Every editor reader preview and effect popup — Accept inspected shared consumers only; continue full consumer audit — Cost if wrong: An uninspected surface can misrepresent execution.
Final: Ruling: All294 plain-language descriptions — Complete editorial audit is still required — Cost if wrong: Technical or repetitive prose can remain.
Final: Ruling: All orange effect and value references — Require complete actual visual/editorial audit — Cost if wrong: Colour or link inconsistency can remain.
Final: Ruling: All distinct mechanical cycles — Continue Task15; this display review supplies no gameplay outcome — Cost if wrong: An authored cycle may remain ineffective.
Final: Ruling: Setup AI — No planner changed; keep strategic work open — Cost if wrong: Legal inferior setup choices can remain.
Final: Ruling: AI strategic quality and full289 replay — Do not duplicate unchanged AI/fixture matrix; no strategic acceptance follows — Cost if wrong: Presentation-only integration regressions need covering producer/controller tests.
Final: Ruling: Natural pacing — No new gameplay observation in this display pass — Cost if wrong: Long sustain matches may remain.
Final: Ruling: Twelve-round balance — No balance experiment here; retain benchmark gate — Cost if wrong: Whole-roster pacing may remain outside target.
Final: Ruling: Current Owner-edit reconciliation — Require current release-time data — Cost if wrong: Stale publication may overwrite Owner work.
Final: Ruling: Hosted authority — No hosted check authorized or performed — Cost if wrong: Hosted-only authority defects can remain.
Final: Ruling: Hosted SQL integrity — No hosted SQL verification here — Cost if wrong: Database-specific integrity failures can remain.
Final: Ruling: Hosted CAS behavior — No hosted concurrency exercise here — Cost if wrong: Concurrent writes may require correction.
Final: Ruling: Atlas acceptance — Keep known Atlas evidence and bound open — Cost if wrong: Motion acceptance remains unresolved.
Final: Ruling: Human acceptance — Owner gameplay gate remains required — Cost if wrong: Expected feel or usability may remain unmet.
Final: Ruling: Final frozen full-root result — Require actual completed final-source output — Cost if wrong: Unchecked regressions could be accepted.
Final: Ruling: Browser availability recovery — Known missing/truncated/loopback limits provide no new retry basis — Cost if wrong: Native acceptance remains blocked until environment changes.
Final: Ruling: Publication — Perform no hosted publication in this checkpoint — Cost if wrong: Premature content exposure could bypass gates.
Final: Ruling: Activation — Perform no activation in this checkpoint — Cost if wrong: Unaccepted roster could become playable.
Final: Ruling: Migration application — Apply no migration in this checkpoint — Cost if wrong: Premature schema change could affect live data.
Final: Ruling: Merge — Merge nothing in this checkpoint — Cost if wrong: Unverified source could enter release ancestry.
Final: Ruling: Deployment and release readiness — Keep deployment lock and all broader release gates — Cost if wrong: Premature launch could bypass unfinished acceptance.

Displayonefixwave: initialb915root135352131092exit1onlystrictbattle-essence-authorityownerDTOexpectationmissingdealsDamage:true;8252Vitestpass1fail,nobuildsuccessclaim. Preserveexactshapechecks/addrealnewfact. ImportantactualdescriptorconstructororiginalAirborneoverrideextractedunchanged;actualcapturededitedBasicfixture→ownerprojection→resolveddescriptor→sameconstructorRED135937569481expected1received3. ConstructorBasicexclusion/sharedtargetSpecdelegationfix. Covering1421/79GREEN140004529641;webtypes140004335111;weblint140004330554pendingactualreceipt. Freezepostfixrootnow,onewaveopenuntilgreen,norereview. Prior7Minorsunchanged/individual33declinedrulingsretained.

Postfixweblintactualreceipt140004315676GREEN(14:00:04–14:00:38UTC),not earlierguessedpendingidentifier330554. Finalsource d4cb10384f1b5530dbbde3aa2921bbb6bc547315 frozenfullrootrunning(session41168). No furtherprodtestcopymutationsuntilgate. Editorialpreflightcurrentinventory294rows/258descriptionswithdigits; SkillManagementfocusedSkillactualrenderusesAbilityDefinitionParameters(effectDescriptions),whiledescriptionRefitselfisnotreadinappcomponents. Do notclaimmetadata-onlyrewritefixesvisibleprose. Needactualfallbackper-effectexplanationsandResonanceconsumertracebeforewriting.

Nextconsumerpreflightfindsrealunclosedpath:CharacterArsenalShell EssenceHoverPreview constskill=essence.skill ignoresrootcanonicalability,whileall17actualproposedEssencesrootabilitydiffersfromnestedskill. SharedessenceCombatSkillexistsatcoreessence703;tracepublicSSR/regressionthenreuseaftercurrentarchive. Thisisnextboundedconsumerfinding,notfoldedintodisplayonefixwave. Brief task15-roster-consumer-next-brief.md prepared. Editorialmetadataonlychangeisinsufficient; actualSkillManagement/Battle canonicalreportsuseeffectDescriptions/fallback; Resonancecanonicalreaderpassesonlyability. Currentsourcefrozend4cb/rootrunning,no actualnewcohortcodeyet.

Displayfinalfrozen d4cb10384f1b5530dbbde3aa2921bbb6bc547315 fullrootGREEN14011549619914:01:15–14:05:27UTC8254Vitest(4136core3872web246other)+7Node,format/lint/8types/2builds. OneImportantactualBasicdescriptorRED135937→GREEN1421covering+finalsuite,no rereview. SevenpriorMinorsremainindividuallydeferred;all33declinedrulingspreserved. NoAI/command/definitions/pricing/defaultfixturechange,289notrepeated. AdditionalisolatedWconfigobservationaldiagnostic140442300829GREEN1outsideSRC/routine:294records297groups604effectsall10rows/inputimmutable,350nonDamageexplanationsdigits/217timingwordcandidates. Not8255routinecount/nativenotproved. Raweditorial-readers-observation.json/SHA2563e1e8c6d32da0440f8b7f39769fff0aacebb300d0cb6914593d5ccc34981a9fe/analysis/driver/configretained. NextactualArsenalEssencecanonical/proseconsumercohortprepared;finishcurrentdocsbackupfirst.

DisplayexactrecoverybackupVERIFIEDactualgitlsremotecb6da1ab71309b8a79c125d09a21fa3f236f5039/root6d1002c9aff011bb468f1ae8afecb66f1874e459/checkpoints08676d6d0535d273f44941a3ab6b21e9c8cb0972. Fourremoteentries/localhashesmatch:bundle34fcad317181369173a62f56a704bbcb70bc49c8(16107bytes/SHA256af084a4c4dd0a65b54b45f2f8b3f4be4657df2c01d5065b8edffdc585c848061),evidence3eb52ad8fc0d40b8718ae7c247ede7c2a257a294(236130bytes/SHA256a5d4555b363eae6e5d0def6128a36bd2b41d5039c3d21991e095a906115d1c61),metadata5a6c910d6fe15a1aff2febb4f7fe9e421e574e62,LATEST15f5b28c071c62075eadae9e6db8d0464c8b5ba8. Source8229c4a9/tree d07f2956df337f986ff4c6e97f6be4c8b3d34338/testedd4cb/prereqc33e. Expectedf138nonforce,localbundleverifyvalid,cleanworkingtree. Freshmain29506unchanged. Noactivation/merge/deploy. ContinueactualArsenalEssenceconsumercohortBASE8229c4a9andvisibleeffectproseaudit,Highremainsenough. All294SSRobservationalparse/renderpreflightretainedoutsideSRCcounts.

NewArsenalcohortBASE8229c4a9: exportedexistingEssenceHoverPreviewunchangedforactualSSRboundary;17canonicaloldreaderregressionsRED140925056648(all17missingcanonicalgroupmarkers),realpinnedVanguardhistoricalcasealreadyGREEN. ReuseexistingessenceCombatSkill coreadapterinactualhover,notparallelmodel. GREEN18 140942406908covers17current+publicand1realhistory/inputimmutable/original160art/privatekeys. Onlycomponent2lines+export/testfile;nodefinitions/UIgeometry/authoritychanges. Focusedcovering/types/scopedlintnowrunning. Broadvisibleprose350nonDamagewithdigits/217timingcandidatesremainrequired.

Arsenalcohortcovering618/4GREEN141017719125;webtypes141017717531;actualscopedappESLint141017719775;Prettierpass. Readyfreezeonecomponent+18tests+reportforonecombinedreview/fullrootexpected8272+7. Actualsharedadaptervalidatesfullandpublicdefinitionssuccessfullyall17;realbeforeVersionVanguardhistoricalfallbackpassed. No definition/AI/command/pricing/fixturechange,289notduplicated. Ruling: preserve truthfulstructurednumericsbeforeplainprose — do notregex-strip350nonDamagecandidatesbecauseBurnbacklash/Poisonrefreshcurrentlyarenotfullyincompactmagnitudes — Costifwrong: necessarycounter/behaviorfactswouldbehidden. Nextproseauditrequiresstructured/detailcompletenessandactualconsumertracing,notjust258descriptionmetadatarewrites.

Arsenalcombinedreview70580e93complete0C0I1newMinor(full10labels/exactpinnedhistoryhardening),parentagrees/defer,nocurrentwrongoutput. Total8individualMinors;prior7unchanged. Reportclarifiesdirect2labelboundaryvsfullsharedreadercoverage. All34declinedjudgmentsindividuallyruledwhy/costinreport:
Final: Ruling: Native hover opening and closing — Popover lifecycle is mocked; retain native gate — Cost if wrong: Opening/dismissal may fail.
Final: Ruling: Keyboard navigation and focus — SSR is not interaction evidence — Cost if wrong: Focus behavior may remain wrong.
Final: Ruling: Touch behavior — No device execution; retain native gate — Cost if wrong: Touch information may be unreachable.
Final: Ruling: Mobile layout — No rendered viewport evidence — Cost if wrong: Narrow layouts may overflow.
Final: Ruling: Zoom and overflow — No browser layout evidence — Cost if wrong: Zoom may make readers unusable.
Final: Ruling: Targeting controls — Outside this reader delta; keep original release gate — Cost if wrong: A target path may remain unfinished.
Final: Ruling: Move controls — Keep combined native Move acceptance — Cost if wrong: A movement gesture may remain wrong.
Final: Ruling: Editable five Basics — Keep captured Basic consumer acceptance — Cost if wrong: An edited Basic may be misrepresented.
Final: Ruling: Controlled activation and release — No command executes here; retain full integration gate — Cost if wrong: Prime/release interaction may remain wrong.
Final: Ruling: Rewind interaction and history — One historical Essence does not verify Rewind — Cost if wrong: Anchor/history behavior may remain unverified.
Final: Ruling: Full editor-reader consistency — Only this consumer and shared rendering are traced — Cost if wrong: Another consumer may be stale.
Final: Ruling: Skill Management previews — No fresh independent complete preview audit here — Cost if wrong: Another preview may misrepresent the roster.
Final: Ruling: Effect popup interaction and detail completeness — Lifecycle and separate flows stay open — Cost if wrong: A popup can be inaccessible or incomplete.
Final: Ruling: Actual orange references and links — SSR markers do not establish appearance or interaction — Cost if wrong: References can remain visually or functionally inconsistent.
Final: Ruling: All294 prose quality — Inventory counts are observations, not complete semantic review — Cost if wrong: Technical or repetitive wording can remain.
Final: Ruling: The350 numeric explanations — Treat digits as audit candidates, not automatic violations — Cost if wrong: Blind cleanup could delete required information.
Final: Ruling: The217 timing explanations — Treat timing words as candidates, not automatic violations — Cost if wrong: Trigger rules could be confused with duplicate activation timing.
Final: Ruling: Burn backlash presentation — Audit equivalent structured facts before shortening — Cost if wrong: The backlash value could be hidden.
Final: Ruling: Poison refresh and movement presentation — Audit equivalent structured facts before shortening — Cost if wrong: The movement counter could be hidden.
Final: Ruling: All historical versions and policy contexts — One actual historical consumer fixture is narrower — Cost if wrong: Another historical rendering may be wrong.
Final: Ruling: Malformed or disabled Essence inputs — Use existing validation; no supported-input failure found — Cost if wrong: Malformed-data recovery remains untested.
Final: Ruling: Future Owner-authored explanations — Retain inspected alignment support; these17have none — Cost if wrong: An unusual future edit might expose an alignment defect.
Final: Ruling: Payload confidentiality beyond this component — Transport/hydration audit remains separate — Cost if wrong: Another boundary could expose private data.
Final: Ruling: Each distinct gameplay cycle — Display correction supplies no gameplay outcome — Cost if wrong: Another cycle may remain ineffective.
Final: Ruling: AI behavior and balance — Unchanged planner/fixture; do not repeat289here — Cost if wrong: Strategic quality remains a broader gate.
Final: Ruling: Natural battle pacing — Require actual gameplay evidence — Cost if wrong: Sustain stalls may remain.
Final: Ruling: Twelve-round balance — Require complete balance evidence — Cost if wrong: Broader pacing may miss the benchmark.
Final: Ruling: Current Owner edits — Require current release-time data — Cost if wrong: Stale publication may overwrite newer edits.
Final: Ruling: Hosted SQL and CAS — No hosted operation/concurrency verification here — Cost if wrong: Database-only integrity defects may remain.
Final: Ruling: Atlas acceptance — Retain existing Atlas blocker and bound — Cost if wrong: Motion acceptance remains unresolved.
Final: Ruling: Human acceptance — Keep Owner gameplay acceptance open — Cost if wrong: User expectations may remain unmet.
Final: Ruling: Release acceptance — All original combat prerequisites still apply — Cost if wrong: Premature release could bypass unfinished work.
Final: Ruling: Broader Master panels — Follow combat package per approved ordering — Cost if wrong: Unrelated Master work remains unfinished until that stage.
Final: Ruling: Full project gate — Accept only the actual completed frozen output below — Cost if wrong: Unchecked regressions could be accepted.
Final: minor (deferred): New Arsenal witness checks two characteristic labels and historical path rather than the full ten-label sequence and exact pinned values; defer until relevant test touch.
Final: minor (deferred): Prior Rewind prime witness starts at its origin; separate anchor coverage exists.
Final: minor (deferred): Prior Supporting Shot version is not explicitly pinned.
Final: minor (deferred): Prior Ongoing dynamic pair ID is not explicitly pinned.
Final: minor (deferred): Prior AI repeats bounded route/target discovery across modifier bundles.
Final: minor (deferred): Prior admission fixture has double-prefixed character provenance.
Final: minor (deferred): Prior ranged negatives assert preparation rejection rather than direct rejected commit.
Final: minor (deferred): Prior defense witness does not independently reconcile damage events with recipient HP.

Arsenal reader bounded cohort final: frozen70580e93 full-root141133751551 GREEN8272Vitest+7Node (4136core3890web246other); formatting/lint/8types/2builds pass,14:11:33–14:15:28UTC.0C0I1newMinor deferred,total8. All34declined judgments individually ruled. No rereview. Docs-only finalization; exact recovery backup next. Task15 remainsOPEN for original integration/prose/effect details/native and broader balance/release gates. High sufficient.

Exact Arsenal backup complete074f7ef31fca1c817afeddf09e76225e7e2b8ad7 rootbf09b6f38b4a0dc70696bcb1139d83185fdab06d checkpoints5afd39c55a32c2575ed1f3039908f329af7ed161.4entrySHAs verified;remotehead exact;main29506e29unchanged. Source7d2b4765 tested70580e93. BundleSHA64070684b153b4209bdcc2c26f4d9c55abb7e1d36690a63350a34ab50c2b4bcd; evidence5da9c0b29e91341419de22e755f682107956d56e78f4bfa206c3fd41342350be.
Task15 Ruling: next bounded existing-reader prose pass stays inside approved plain-language/readers design and continuous inline authorization; no new permission loop — canonical recovery/movement/Reveal non-damage values already structured or explicitly add missing application-count/Reveal-clock facts before removing duplicate numeric prose — cost if wrong: some untouched status/fallback explanations remain for subsequent cohort. Retain raw legacy helper unchanged, damage prose, all policy-sensitive statuses/DoTs and Controlled/activation explanations unchanged. New optional presentation-only facts shared by text and React Effects; no stored schema/execution change. TDD source/public consumer witnesses, covering tests/types/lint/full gate and one combined review; no per-record delegation.

Canonical recovery reader cohort pre-review: validRED14214666322216fail2pass after correcting canonical fixture keys; invalidauthoringattempts retainednotmechanics.18initialcasesgreen124/6matchingfiles142251; final21cases+covering718/7GREEN142510284756 after unsupportedfractionalfixturecorrected. Types142258073551/lint142258067941GREEN. Structured count/first/repeat and exactRevealowner-start clock added to shared text/React Effects, rawlegacy/damage/status/DoTs untouched.170actualmanifestpayloads in scope,294auditpending. Manifestb86unchanged. Freeze now for onecombinedreview and8293+7expectedfullroot; Task15OPEN.

## Combined review, one fix wave and individual rulings

One fresh gpt-6-astra High combined review7d2b4765..9f6a9ac5 finds0Critical/1Important/0newMinor. Parent confirms the Important: the initial Then fact includes an already-started recipient turn although `scheduleAfterRecovery`/`resolveEndOfTurnRecovery` skip its ending. The single fix wave changes only that fact to **End of each recipient turn that starts after activation**. Valid RED `143054628577` reports5failed/18passed, including actual core execution before the false report assertion for both self and off-turn ally; a preceding unexported test-helper import failure `143039734501` is not behavior evidence. After correction, **720tests/seven files pass** `143139469121`, including23new reader cases. Each new self/ally witness executes flat HP, flat MP and percentage recovery, verifies pending counters across the actual first/following recipient endings, then checks report and rendered reader. No HP/resource/state patch or mechanics change. Final types `143140006481`, app-configured ESLint `143140006519` and Prettier pass. No rereview; prior eight Minors remain unchanged.

Initial frozen9f6a9ac5 full check `142548898732` passes8,293Vitest+7Node,14:25:48–14:29:49UTC, but does not close the review finding. Post-fix frozen full gate is required; expected8,295Vitest+7Node remains unconfirmed until completion.

Final: Ruling: Stale-browser authority and revocation — No authority boundary changes here; retain Task16 stale-session execution gate — Cost if wrong: Revoked authority may remain unverified.

Final: Ruling: Alternate selected-character authority — Report formatting cannot establish selected-character enforcement — Cost if wrong: Wrong-character authority may remain unverified.

Final: Ruling: Direct RPC expiry and CAS — No direct RPC exercise in this reader delta; retain protected RPC gate — Cost if wrong: A direct-call defect may remain.

Final: Ruling: Malformed nested-data rejection — Existing parser remains authoritative; this cohort uses valid payloads — Cost if wrong: Malformed recovery inputs may remain unverified.

Final: Ruling: Malformed captured/pending/summon data — No capture or summon validator changes; retain serialization gate — Cost if wrong: Malformed historical data may remain unverified.

Final: Ruling: Recursive transport confidentiality — Inspected public-reader path is narrower than transport-wide confidentiality — Cost if wrong: Another transport could expose private data.

Final: Ruling: All immutable-history capture paths — Raw legacy helper and recorded definitions are unchanged; keep full history acceptance — Cost if wrong: Another historical path may remain wrong.

Final: Ruling: No-input and timeout execution — No scheduler or timeout execution changes — Cost if wrong: Timeout behavior may remain unverified.

Final: Ruling: Free priming and repeated-event bounds — Controlled instructions are retained without changing its execution — Cost if wrong: A priming/event-bound defect may remain.

Final: Ruling: Duplicate payment and extra turns — Reader facts do not establish payment/turn authority — Cost if wrong: Payment or turn defects may remain.

Final: Ruling: Interrupted Move and reached-origin legality — Move prose preserves restrictions; no path execution changes — Cost if wrong: An interrupted movement path may remain unverified.

Final: Ruling: Concurrent publication coherence — Local roster publication tests do not establish hosted concurrency — Cost if wrong: Concurrent publication may still need correction.

Final: Ruling: Concurrent build and claim coherence — No build/claim writes here; retain actual concurrency gate — Cost if wrong: A duplicate build/claim result may remain.

Final: Ruling: Concurrent recovery and settlement coherence — New sequential recovery clock witnesses do not test concurrency — Cost if wrong: A settlement race may remain.

Final: Ruling: Hosted rollback locks and retry/no-contest — No hosted operation; retain actual database gate — Cost if wrong: Database-only rollback/locking defects may remain.

Final: Ruling: Long-name native layout — Static markup provides no browser geometry — Cost if wrong: Long names may overflow.

Final: Ruling: All missing historical metadata consumers — Captured old Healing Down context is narrower than every historical consumer — Cost if wrong: Another missing-metadata fallback may remain wrong.

Final: Ruling: Native keyboard and focus — No native interaction execution — Cost if wrong: Focus behavior may remain wrong.

Final: Ruling: Touch and mobile — No native device execution — Cost if wrong: Touch readers may remain inaccessible.

Final: Ruling: 200% zoom overflow and contrast — Shared classes are reused; no browser layout/contrast evidence — Cost if wrong: Zoom or contrast may remain inadequate.

Final: Ruling: Native Targeting controls — Keep original Targeting integration gate before release — Cost if wrong: A targeting path may remain unfinished.

Final: Ruling: Native Move controls — Keep original Move integration gate before release — Cost if wrong: A movement gesture may remain unfinished.

Final: Ruling: Editable five-Basic integration — Native Move price distinction does not accept every editable Basic — Cost if wrong: An edited Basic may remain misrepresented.

Final: Ruling: Controlled prime release and cancel — Instructions remain intact; no command-interaction acceptance — Cost if wrong: A prime/release interaction may remain wrong.

Final: Ruling: Rewind anchors and history — No Rewind source change; retain full original integration gate — Cost if wrong: An anchor/history interaction may remain unverified.

Final: Ruling: Every editor preview popup and public reader — Shared local/public SSR and publication coverage are narrower than all mounted surfaces — Cost if wrong: Another consumer may remain stale.

Final: Ruling: All294 descriptions and status/DoT secondary facts — 170 explanations changed and434 stayed exact; remaining semantic audit stays open — Cost if wrong: Other explanations may repeat or omit important facts.

Final: Ruling: Actual orange references links and popup interaction — Existing highlighted fact class is reused; full reference/interaction audit remains — Cost if wrong: Other references may remain inconsistent.

Final: Ruling: Every distinct gameplay cycle — Recovery clock execution witnesses are narrower than full roster cycles — Cost if wrong: A different cycle may remain ineffective.

Final: Ruling: AI strategic quality and289 acceptance — Planner/authority/fixture defaults unchanged; do not duplicate289for reader-only delta — Cost if wrong: Broader strategic quality remains open.

Final: Ruling: Natural pacing and twelve-round balance — No balance experiment or parameter change in this reader cohort — Cost if wrong: Sustain stalls or pacing mismatch may remain.

Final: Ruling: Current Owner-edit reconciliation — Require fresh release-time Owner data — Cost if wrong: Stale publication could overwrite newer Owner work.

Final: Ruling: Atlas and human gameplay — Existing Atlas bound and human acceptance remain open — Cost if wrong: Motion or gameplay feel may remain unacceptable.

Final: Ruling: Final frozen full-project result — Accept only actual completed post-fix output below — Cost if wrong: Unchecked regressions could be accepted.

Final: Ruling: Publication activation migration merge and deployment readiness — Do none here; retain all original release gates and lock — Cost if wrong: Premature release could bypass unfinished work.

Final: Ruling: Broader Master-panel completion — Follow combat release per approved ordering — Cost if wrong: Unrelated Master work remains unfinished until that stage.

Task15recoveryreaderwave:0C1I accepted/fixed, actualclockRED143054628577→GREEN720/7 143139469121. New23tests. Types143140006481/lint143140006519GREEN. Initial8293+7GREEN142548898732notfinalacceptedsource. Freezepostfix for8295+7fullgate. All36declinedjudgments individually ruled;8priorMinorsunchanged,norereview.

Recoveryreader boundedcohort final: frozen51fe9cf1 actualfull143229599232 exit0; rootstdouttruncatedafterlint,preserveoriginal+hashedfreshpackageoutputs inrecovery-fullcheck-audit.json/turboarchive. Newconcernjustifiedcachedfullreplay143752901750 completeGREEN8295Vitest+7Node,4136core3913web246other/8types/2builds. No sourcechange. Finalall294SSR143248664686 raw13f2eb4c3f3c7148bfd00369190007829bcb5380d728a21bd6a09529239842fa,170changed434unchanged.0C1Ifixed/0newMinor/8priorMinorsdeferred;36individualrulings,norereview. Nextstatus171/20IDs including actualnormal/delayed elemental reader clock candidates recorded, stillTask15OPEN. Docs-onlyfinal thenexactbackup.

Exact recovery-reader backup verified: ed98d7dd4cab81e3b73ed023c69eb581963c1fc7 rootd924fd7168876ea9738e5230b29393aef11d099b checkpoints194c87e4fd7d9db96e74041d1f2660e7e2577e58.4entrySHAs verified;remoteexact/main29506e29unchanged. Source98916aa3 tested51fe9cf1. Bundle18729 SHA87255462f2f2fa6474bd6a6bdf58816cb3c70dfdaa855b7e8d09eae660d2c360/blob361540a83c646af555a05a02767e6a03132b4c43. Evidence314327 SHA33e4efb90b5fd49e9a4ac48445ed2df41f4b8e1b9c11109c75f4e36ea72f0edb/blobd020e5fba2677582f72aeb93052e4566ccd0e180;includesoriginaltruncatedgate+hashedTurbooutputs+completecachedgate. Metadataae80c71fedff8d4316f7bf40cb29191ba53ed462;LATEST7e853d8772077f1ee7e80d84c3b414bd9ea1de01.
Task15 Ruling: next status cohort covers16registeredstatusIDs/154actualeffects, deferring4with unstructured secondary facts (Airborne2,Blindside5,Haste4,Drenched6) until those exactvalues canbestructured — preserve numericdata ratherthanstrip — cost ifwrong:17complexstatus explanations remainforfollowingcohort. Reuse existing nativepreview magnitude withunits/direction forcanonicalstatusfacts, addauthoredStacks, preserve rawlegacy helper andold elementalpolicy prose. Correcttwoactualnormal/delayed elementalwrapper contradictions usingexactwrappermode and damage-settlement condition, with structured affected-turn/full-round duration andactivation facts. Existing materialize/capture/settle/round-scope source confirmswrapperauthority;noengine/pricing/definitionchange. Currentcontrolledstatus releaseisInstant afterpriming andmustnotbeconflatedwithnormal/delayedmismatch. Approvedplain-language/readersTask15design continuousinlineauthorization persists;no permissionloop. Onefreshcombinedreviewforboundedcohortaftertests,oneC/Iwave,norereview,prior8Minorsdefer.

Standardstatusreader cohort pre-review: validRED14441028251722fail6pass/no fixtureerror.16IDs154actualeffects nowstructuredStacks/nativepreviewunits+plainpurpose. ActualChronistFrost/Storm exactmaterializedpacket clocks observed144301189390 R3/R5,2fullrounds; notwholelearnedbuildadmission/canonicalRequirements/payment/AI. Newpermanentactualrecordtestsrepeatengineclock thenlocal/publicResonancereader. Noengine/definitions/priceschanges; metadata shorthandtiming/fulllegalcycle meaningstillrequiresgameplaygate. Protected4types17effects retained untilsecondaryfactsstructured. Covering750/8GREEN144644495756,new30;types144611156491/lint144611158775/PrettierGREEN. Freeze8325+7expectedfullroot andonecombinedreview;Task15OPEN.

## Combined review and individual rulings

One fresh gpt-6-astra High combined review98916aa3..3fc8b7a8 finds0Critical/0Important/1newMinor. Parent agrees with the Minor grade: supported one-duration elemental payloads display “1 affected turns” or “1 full rounds”; value and clock stay truthful. Defer count-aware grammar until relevant authorized follow-up. No fix wave or rereview. Total nine deferred Minors, with the prior eight individually preserved in preceding reports.

Final: Ruling: Stale-browser revocation — Retain stale-session authority gate; no authority execution here — Cost if wrong: A revoked browser may remain unverified.

Final: Ruling: Alternate selected-character binding — Formatting does not establish character binding — Cost if wrong: Wrong-character authority may remain unverified.

Final: Ruling: Direct RPC expiry/CAS — Keep protected RPC gate; no call made — Cost if wrong: A direct-call concurrency defect may remain.

Final: Ruling: Malformed nested definitions — Use existing parser authority; valid fixtures do not replace rejection evidence — Cost if wrong: Malformed definitions may remain unverified.

Final: Ruling: Malformed captured data — No new capture-validation evidence — Cost if wrong: Invalid captures may remain unverified.

Final: Ruling: Malformed pending data — Clock witnesses do not establish malformed-packet rejection — Cost if wrong: Invalid pending packets may remain unverified.

Final: Ruling: Malformed summon data — No summon change or validation exercise — Cost if wrong: Malformed summons may remain unverified.

Final: Ruling: Recursive private-accuracy confidentiality — Shared public readers are narrower than transport-wide inspection — Cost if wrong: Another boundary could expose private data.

Final: Ruling: Every immutable historical consumer — Preserved selected fallbacks do not accept every historical consumer — Cost if wrong: Another historical reader may remain wrong.

Final: Ruling: No-input/timeout execution — Retain scheduler acceptance; no scheduler change — Cost if wrong: A timeout defect may remain.

Final: Ruling: Free priming bounds — Instructions are preserved without execution evidence — Cost if wrong: A prime allowance defect may remain.

Final: Ruling: Repeated-event bounds — No repeated-event or reaction-budget exercise — Cost if wrong: An event loop may remain unverified.

Final: Ruling: Duplicate payment — Native packet witnesses intentionally bypass full admission/payment — Cost if wrong: A payment defect may remain.

Final: Ruling: Extra-turn prevention — No turn-economy change or dedicated acceptance — Cost if wrong: An extra-turn path may remain unverified.

Final: Ruling: Interrupted Move/reached-origin attacks — No movement execution change or native proof — Cost if wrong: An attack origin defect may remain.

Final: Ruling: Concurrent publication — No hosted race/rollback exercise — Cost if wrong: Publication races may remain.

Final: Ruling: Concurrent build writes — No build-write race exercise — Cost if wrong: Concurrent build incoherence may remain.

Final: Ruling: Concurrent claim/idempotency — No claim race exercise — Cost if wrong: Duplicate claims may remain unverified.

Final: Ruling: Concurrent recovery — Sequential clock witnesses do not prove concurrency — Cost if wrong: Recovery races may remain.

Final: Ruling: Concurrent settlement — No late-worker or settlement race exercise — Cost if wrong: Duplicate settlement may remain unverified.

Final: Ruling: Hosted locks/retry/no-contest — Retain actual database gate; no hosted operation — Cost if wrong: Database-only integrity defects may remain.

Final: Ruling: Long-name layout — Static rendering does not establish native geometry — Cost if wrong: Long names may overflow.

Final: Ruling: Missing metadata across every reader — Selected policy fixtures are narrower than all historical metadata — Cost if wrong: Another fallback may remain misleading.

Final: Ruling: Native keyboard/focus — SSR does not execute focus or dismissal — Cost if wrong: Keyboard readers may remain inaccessible.

Final: Ruling: Touch/mobile — No native device interaction — Cost if wrong: Touch controls may remain inaccessible.

Final: Ruling: Zoom/contrast/overflow — No actual200% browser layout/contrast evidence — Cost if wrong: Zoom or contrast may remain inadequate.

Final: Ruling: Native Targeting — Retain original combat integration gate — Cost if wrong: A targeting path may remain unfinished.

Final: Ruling: Native Move — Retain original movement acceptance — Cost if wrong: A movement gesture may remain unfinished.

Final: Ruling: Editable five Basics — Shared readers do not accept every native edited Basic — Cost if wrong: An edited Basic may remain misrepresented.

Final: Ruling: Controlled prime/release/cancel — Instructions remain; full native interaction stays open — Cost if wrong: A release/cancel interaction may remain wrong.

Final: Ruling: Rewind anchors/history — No Rewind source change or full interaction exercise — Cost if wrong: An anchor/history path may remain unverified.

Final: Ruling: Every editor/preview/popup — Shared consumers are narrower than all mounted surfaces — Cost if wrong: Another consumer may remain stale.

Final: Ruling: Airborne secondary facts — Retain exact old explanation until all important values are structured — Cost if wrong: Shortening early could hide immunity or elevation.

Final: Ruling: Blindside secondary facts — Retain exact old explanation until captured multipliers/activation are structured — Cost if wrong: Shortening early could hide facing or trigger rules.

Final: Ruling: Haste secondary facts — Retain exact old explanation until movement floor is structured — Cost if wrong: Shortening early could hide minimum AP.

Final: Ruling: Drenched secondary facts — Retain exact old explanation until Initiative/cap facts are structured — Cost if wrong: Shortening early could hide Initiative rules.

Final: Ruling: Burn backlash — Separate secondary-fact cohort required — Cost if wrong: Backlash magnitude or allowance may remain poorly presented.

Final: Ruling: Poison movement refresh — Separate secondary-fact cohort required — Cost if wrong: Movement refresh could remain poorly presented.

Final: Ruling: Ground presentation — No Ground change in this status delta — Cost if wrong: Ground delivery prose may remain repetitive.

Final: Ruling: All294 prose quality — All294 static observation supplements but does not replace semantic audit — Cost if wrong: Other wording may remain repetitive or incomplete.

Final: Ruling: Orange references/links — Existing fact classes are reused; full appearance/interaction audit remains — Cost if wrong: Other references may remain inconsistent.

Final: Ruling: Active lifetime through expiry — New witnesses assert recorded two-round counter, not actual expiry; retain expiry evidence gate — Cost if wrong: An expiry defect may remain unverified.

Final: Ruling: Learned-build/canonical Requirements — Packet witnesses intentionally do not accept full build or preconditions — Cost if wrong: A legal admission/setup path may remain ineffective.

Final: Ruling: Manifest shorthand/full legal cycles — Existing double-stage queue is not a new balance choice; retain meaningful-cycle review — Cost if wrong: Timing shorthand or cycle value may remain wrong.

Final: Ruling: AI quality/289 replay — Planner/fixture/authority unchanged; do not duplicate289for a reader-only delta — Cost if wrong: Broader strategic quality remains open.

Final: Ruling: Natural pacing — No balance experiment — Cost if wrong: Sustain stalls may remain.

Final: Ruling: Twelve-round balance — Keep full pacing benchmark gate — Cost if wrong: Broader pacing may remain outside target.

Final: Ruling: Current Owner edits — Require fresh release-time Owner data — Cost if wrong: Stale publication could overwrite newer work.

Final: Ruling: Atlas — Retain existing bound and acceptance gate — Cost if wrong: Motion acceptance remains unresolved.

Final: Ruling: Human gameplay — Retain actual Owner gameplay acceptance — Cost if wrong: Feel or usability may remain unmet.

Final: Ruling: Frozen full-project result — Accept only actual completed frozen output below — Cost if wrong: Unchecked regressions could be accepted.

Final: Ruling: Publication/activation/migration/merge/deployment — Do none here; retain original release prerequisites — Cost if wrong: Premature release could bypass unfinished work.

Final: Ruling: Broader Master panels — Follow combat package per approved ordering — Cost if wrong: Unrelated Master work remains unfinished until that stage.

Final: minor (deferred): One-duration elemental labels use plural turn/round grammar; values and clock remain correct.

Standardstatusreview0C0I1newMinor/defer,total9. No fixwave/norereview. Exactall294SSR144820895639 rawaa06f7dfe4136e9d278c7e9134f15c71e31060a35eba96a679ee00aafb4ea2e4:154new/324originalchanged280unchanged/17protectedwordsunchanged.53individualdeclinerulingsretained. Finalfullrootpending; noacceptanceclaimuntilactualoutput.

Standardstatus boundedcohort final: frozen3fc8b7a8 fullroot144738427787GREEN8325Vitest+7Node(4136core3943web246other),format/lint8types2builds,14:47:38–14:51:51UTC.30newcases/750covering.0C0I1newMinor grammardeferred,total9;53individualrulings;no fixwave/norereview. Finaldocs-onlythenexactbackup;next17complexstatusvaluesandBurn/Poison/Ground/referenceaudit, originalintegration/balance/native/releaseOPEN.

Exact standardstatus backup verifiedc28844e3e8abe0a31d72b7fed0a19f615b6d315c root658d64a8d3389189c24f20951c57e7bb028dcdd9 checkpoints2c0b461de0f6b63885288c476413b0e5c6e68d73.4entrySHAs verifiedremoteexact/main29506e29unchanged. Source5e047d59 tested3fc8b7a8. Bundle12070SHAec073ea7060f565b7ac3c3d56ec203b62310559ece19544d0e126ada851ff8ea/blob493117a96728fb287d60cb266c8ff60a78ea2f30. Evidence204641SHA75a317051b853e852d4016e2c9e25f2a9f73593a79d3bdc20fe9c8ce4b5a5509/bloba4f3eeeb57529f4d22643bfb9e468b8860af0353. Metadata60126c8fb8253c09a809e8d85f238f9ed2de03d6;LATEST6d5865e872c2a4c09c953ed0263ba3fa566ab856. Nextsecondary4preflightmustadapttemporaryprotectedcurrent-equalsraw witnesses into genuine old-version reader coverage plus stronger currentfacts; do not simply delete constraints or gate unrelatedflags. Needactualoldnoncanonicaldefinitioninventorybeforechoosingfixtures. Coreconstant extractiononlyexistingvalues/newacyclicDrencheddata possible;exactarithmetic/historyretained, no balancechange. All9Minorsdeferredincluding16statusone-durationgrammar,notincidentalfix.

Task15secondary cohort BASE5e047d59 preflightactuallegacyinventory145704926444GREEN finds pinnednoncanonicalAirborneironfist.breakfallv5/Blindsideshadehand.backstabv5/Hastechronist.hastev4/Drenchedtidecaller.water-lancev7. Ruling: replace four temporary current-canonical-equals-raw protection witnesses with stronger actual pinned legacy SkillDetails/sourceimmutability coverage, alongside new17currentsecondaryfact/publicreader witnesses — temporaryprotection isfulfilled ratherthandeleted,rawlegacy path unchanged — costifwrong: a current/historyboundary couldregress, coveredbothpaths. First150034 invalidaccuracyfixturesandwronglegacyexplanationadapter;150106 fixesoldreaderexpectationwithactualpreviewEffect, remaininginvalidaccuracy. Correctutility/noaccuracyfixtures yield validRED15012163688710fail33pass;missingfacts/currentnumbers/units reproduce, actualoldlegacyreader30tests pass. Rawdataingroups/privateaccuracyuntouched. Existingvalueswillbesharedbetweenactualauthorityandreader:AirborneJump3/Attackelevation3,Blindsidefront10000basispoints,Hastefloor10AP,Drencheddivisor10 (10%/application) inacyclicdata. Nochangedvalues/formulas/prices/definitionmeaning. PreservelegacyAirborne/Jump/Blindside/elementalpolicies andtypedcustomprofiles/potency. AddexactFactsbeforeplaintext;borrowshared elementalclockgrammar whilepreservingdeferredone-durationpluralMinor. Current9Minorsremainnoincidentalfix. Sourcecoreconstextractionrequirescurrentfocusedcoretests/fullroot andone fresh289replay+allcommandarraycomparison, notnewbalancechoice. Onecombinedreviewlater/oneCIfixwave/norereview. Highsufficient.

Secondary17facts prefreeze: validRED15021651938010fail33pass afterfixtureaccuracy/legacyadaptercorrection;GREEN763/9 150418609953 including13new. Oldfourtemporaryprotectiontests nowgenuinelypinnedlegacySkillDetails immutability/version/completeexplanation, no coverage deletion. Core4136/178GREEN150618926299;webtypes150619566519/coretypes150619565716/weblint150619570791/corelint150619568764/PrettierGREEN. Smallpublicentryprobe150540654201passed(no reproducedcyclicfailure);movedtoownWdiagnosticnotroutinecount. ExistingAirborne3/3,Blindfront10000,Hastefloor10,Drencheddivisor10sharedwithactualauthorityandreaders, no numerical/formulaoutcomechanges. SharedclockpreservesdeferredpluralMinor. Freezeexpected8338+7;onecombinedreview/fresh289exactarrays toprior0cfmatrixbecauseauthoritysourcebyteschanged;originalreleasegatesOPEN.

Workspace interruption 2026-10-16T15:15Z: original .git, most source and dependencies unavailable during review/frozen gates; no parent/source mutation caused it. Verified recovery archive c28844e3 remote/main unchanged; cloned separately and imported all26 preserved incremental bundles, restored missing source files and metadata to last completed5e047d59. Preserved all existing files/W/evidence, 0 existing source differences. Current unbacked420b cohort cannot be claimed restored exactly yet. Prior frozen full/matrix receipts must finish/read before acceptance, and recovered final source needs actual re-verification. Blindside expiry1Important remains ONEwave pending. Highsufficient. No publication/activation/migration/merge/deploy.

Secondary recovery: exact three new files retrieved by original reviewer, copied; restored helper wiring/coreconstant algebra/pinnedlegacywitnesses from recorded diff/contract, new source identity required. Restored43/43GREEN152112646168. Review0C1I0newMinor accepted:Blindsideexpiry; nine earlierMinorsdeferred. Regression152227077559 includes unsupportedduration2fixtureerrors; corrected1turn yields VALID9RED/13GREEN152256034081. Onefixwaveaddsstructuredrecipientturnendvsfullroundexpiry; initial730/8GREEN152317341334, finalsourcepending. Originalmatrix46583 wrapperfailedgetcwdFileNotFoundError,288preservedrows/noacceptance; full74900 oldcwdinterrupted/notaccepted. Rebuild full+289 on restoredfrozenidentity. No rerereview.

# Secondary reader combined-review rulings

Original bounded review5e047d59..420b2423:0Critical/1Important/0newMinor. Parent accepts Important, Blindside expiry. Exact two helpers/13-case test recovered from retained reviewer source; restored sourcefc170382 is independently reverified, not claimed byte-identical420b. No rereview. One C/I correction wave: supported duration1 fixtures nine RED152256034081; final covering772/9 GREEN152433574453. Native unchanged. Nine prior Minors remain deferred.

Final: Ruling: Stale-browser revocation — No authority-path execution; retain authority gate — Cost if wrong: A revoked browser may remain unverified.

Final: Ruling: Alternate selected-character binding — No selected-character authorization exercise — Cost if wrong: Wrong-character authority may remain unverified.

Final: Ruling: Direct RPC expiry — No protected RPC call — Cost if wrong: A direct-call expiry defect may remain.

Final: Ruling: Direct RPC CAS — No concurrency-authority exercise — Cost if wrong: A concurrency defect may remain.

Final: Ruling: Malformed nested definitions — Valid readers do not replace parser rejection tests — Cost if wrong: Malformed definitions may remain unverified.

Final: Ruling: Malformed captures — No new capture rejection evidence — Cost if wrong: Invalid captures may remain unverified.

Final: Ruling: Malformed pending packets — No pending-data rejection evidence — Cost if wrong: Invalid pending data may remain unverified.

Final: Ruling: Malformed summons — No summon validation exercise — Cost if wrong: Malformed summons may remain unverified.

Final: Ruling: Recursive private-accuracy confidentiality — Selected public SSR is narrower than all transports — Cost if wrong: Another transport could expose private data.

Final: Ruling: Every immutable historical consumer — Four pinned witnesses are narrower — Cost if wrong: Another historical consumer may remain wrong.

Final: Ruling: No-input/timeout execution — No scheduler exercise — Cost if wrong: Timeout behavior may remain unverified.

Final: Ruling: Free priming bounds — Instructions are not execution evidence — Cost if wrong: A prime allowance defect may remain.

Final: Ruling: Repeated-event bounds — No event-budget exercise — Cost if wrong: An event loop may remain unverified.

Final: Ruling: Duplicate payment — No complete payment-path acceptance — Cost if wrong: Duplicate payment may remain unverified.

Final: Ruling: Extra-turn prevention — No turn-economy exercise — Cost if wrong: An extra-turn path may remain unverified.

Final: Ruling: Interrupted Move — No reached-origin execution witness — Cost if wrong: An origin defect may remain unverified.

Final: Ruling: Concurrent publication — No publication race or rollback exercise — Cost if wrong: Publication races may remain.

Final: Ruling: Concurrent build writes — No build-write race — Cost if wrong: Concurrent build incoherence may remain.

Final: Ruling: Concurrent claims — No idempotency race — Cost if wrong: Duplicate claims may remain.

Final: Ruling: Concurrent recovery — No late-worker recovery exercise — Cost if wrong: Recovery races may remain.

Final: Ruling: Concurrent settlement — No settlement race — Cost if wrong: Settlement races may remain.

Final: Ruling: Hosted locks/retry/no-contest — No hosted database acceptance — Cost if wrong: Database-only integrity defects may remain.

Final: Ruling: Long-name layout — SSR does not establish geometry — Cost if wrong: Long names may overflow.

Final: Ruling: Missing metadata across every reader — Selected historical cases are narrower — Cost if wrong: Other fallbacks may remain misleading.

Final: Ruling: Native keyboard/focus — No physical focus/dismissal exercise — Cost if wrong: Keyboard usability may remain inadequate.

Final: Ruling: Touch/mobile — No native device interaction — Cost if wrong: Touch controls may remain inaccessible.

Final: Ruling: 200% zoom — No actual zoom geometry — Cost if wrong: Zoom layout may remain inadequate.

Final: Ruling: Contrast/overflow — No physical visual acceptance — Cost if wrong: Visual accessibility may remain inadequate.

Final: Ruling: Native Targeting — Keep original combat integration gate — Cost if wrong: Targeting may remain unfinished.

Final: Ruling: Native Move controls — Keep original movement interaction gate — Cost if wrong: Movement gestures may remain unfinished.

Final: Ruling: Editable five Basics — No complete native edited-Basic acceptance — Cost if wrong: An edited Basic may remain misrepresented.

Final: Ruling: Controlled prime/release/cancel — Retained instructions do not close native acceptance — Cost if wrong: A native release/cancel path may remain wrong.

Final: Ruling: Rewind anchors/history — No complete Rewind interaction proof — Cost if wrong: Anchor/history paths may remain unverified.

Final: Ruling: Every editor/preview/popup — Shared adapters are narrower than all mounted surfaces — Cost if wrong: Another consumer may remain stale.

Final: Ruling: Burn backlash presentation — Separate next secondary-fact cohort — Cost if wrong: Backlash may remain repetitive or incomplete.

Final: Ruling: Poison movement-refresh presentation — Separate next secondary-fact cohort — Cost if wrong: Movement refresh may remain poorly presented.

Final: Ruling: Frozen Ground presentation — Separate next secondary-fact cohort — Cost if wrong: Ground facts may remain repetitive or incomplete.

Final: Ruling: All294 prose quality — Static observation supplements semantic review — Cost if wrong: Other explanations may remain incomplete.

Final: Ruling: Orange references/links — No complete appearance/interaction audit — Cost if wrong: References may remain visually inconsistent.

Final: Ruling: Active lifetime through expiry — Reader review is not elemental expiry execution — Cost if wrong: An expiry defect may remain unverified.

Final: Ruling: Learned-build admission — No complete admission exercise — Cost if wrong: A legal build may remain ineffective.

Final: Ruling: Canonical Requirements — Packet/reader evidence is narrower — Cost if wrong: Prerequisite opportunities may remain unverified.

Final: Ruling: Full distinct legal cycles — Readable facts do not establish gameplay cycles — Cost if wrong: A setup/payoff cycle may remain ineffective.

Final: Ruling: Fresh explicit289 build replay — Require actual final restored-source output; interrupted288 is not accepted — Cost if wrong: Roster regressions could be missed.

Final: Ruling: Exact command-array comparison — Require all289 arrays against prior gold — Cost if wrong: A native outcome change could be missed.

Final: Ruling: AI strategic quality — Deterministic replay is narrower than strategic quality — Cost if wrong: AI planning weakness may remain.

Final: Ruling: Natural pacing — No new balance experiment — Cost if wrong: Sustain stalls may remain.

Final: Ruling: Twelve-round balance — Keep original full benchmark — Cost if wrong: Broader pacing may remain outside target.

Final: Ruling: Current Owner edits — Require fresh release-time reconciliation — Cost if wrong: Publication could overwrite newer edits.

Final: Ruling: Atlas — Keep existing motion bound and acceptance gate — Cost if wrong: Motion acceptance remains unresolved.

Final: Ruling: Human gameplay — Require actual human acceptance — Cost if wrong: Gameplay feel may remain unmet.

Final: Ruling: Frozen full-root check — Require actual completed restored-source receipt — Cost if wrong: Unchecked regressions could be accepted.

Final: Ruling: Publication — None authorized here — Cost if wrong: Premature publication could bypass gates.

Final: Ruling: Activation — None performed — Cost if wrong: Premature activation could bypass gates.

Final: Ruling: Migration application — None performed — Cost if wrong: Hosted data could change before acceptance.

Final: Ruling: Merge — None performed — Cost if wrong: Unaccepted work could enter main.

Final: Ruling: Deployment — None performed — Cost if wrong: Unaccepted work could be released.

Final: Ruling: Broader Master panels — Retain after combat package — Cost if wrong: Broader panel work remains unfinished until that stage.

Final: Ruling: inherited unused non-potency percentage metadata — Current seventeen payloads lack it; parser/native path exists but normal authoring exposure is unestablished, so retain as a bounded follow-up rather than inventing a new cohort regression — Cost if wrong: an edited non-potency status may show an irrelevant percentage.

Deferred Minors, unchanged: Rewind origin witness; Supporting Shot version pin; Ongoing pair identity pin; repeated bounded AI discovery; admission provenance prefix; ranged negative direct-commit witness; defense event/HP reconciliation; Arsenal complete label/exact historical-value hardening; singular elemental duration grammar.


Frozen restoredfc170382: covering772/9GREEN152433574453. All294SSR152450947555GREEN:297groups604effects,17newstatus/341originalchanged263unchanged; rawf44d0d5cde31d7d6fa31c5b77c3fd96a03e6d99ea8dc86814747a88000b32fdc.182numeric/11excludingDamage+Pierce candidates, notprovenviolations. SavedDot/Groundnextpreflight; unchangedmanifest/AI. Original74900 stale-cwdfulljob stoppedwithCtrlC→130, notaccepted. Freshroot73466/fresh28952450 pending. No sourcechangesafterfc170382.

Platform confirmed automated workspace maintenance pruning at15:28UTC. This explains lost source/dependencies/oldcwd; no user deletion assumed. Recovery alreadycompleted from verifiedGitbackup+preservedbundles/reviewerexactsource. No Library retrievalneeded for Git-backed code nowrecovered.

Frozenfc170382 fullroot152433565570exit0 at15:30:39UTC butstdoutroottruncates28069bytes beforecorecomplete. Preservedoriginal+hashedactualpackageTurbooutputs insecondary-fullcheck-audit.json/tar:3965web4136core246other=8347Vitest+7Node,8types2builds pass. Onejustifiedcachedrootreplay91164pending toseekfullsummary, no sourcechange/no furtherrepeatswithoutnewbasis. NextcohortoutsideSRCpreflight153026555857 VALID3RED missingstructuredBurn/Poison/Groundfacts, notcurrentroutinegatefailures. No nextproductioneditsuntilbackup/frozenmatrixfinished.

Cached frozenroot15310793697015:31:07–15:31:44UTCexit0 complete8347Vitest+7Node summary,8types2builds. Originalroottruncatedlogpreserved+packageaudit, no sourcemutation. Rootgateclosedforfc170382only. Matrixpartial149allcomplete rowsidentical tooldgold, awaitingall289. GoldactualRound5meansfourroundsplayed,notactualRound4; correctedanalysisexpectation beforefinal, noactualengine/fixture/testchange.

Read-only editorialpreflight: fourPierce recordsrepeatnon-damageequipmentArmorpercentages althoughdigitmetricexcludesDamage/Pierce. Additional4candidatesretainedseparately; elevennondirectDamageisnotexhaustiveremainingacceptanceclaim. NeedtracecurrentabsentfutureequipmentArmorandlegacyvariants beforelaterdisplayfix, no enginechange.

Newread-onlyparent finding inheritedImportant: actualSkillEffectEditorGuard→Airborneretainsunusedpotency1500,acceptedbycanonicalparser/nativeignores;sharedreader15%false. ValidRED153707157289 outsideSRC. ReviewinitialnormalexposureunestablishednowresolvedbyrealonChange→parse→report. Current17lackit/notnewcohortregression;queue nextboundedreader/editorpassbeforerelease,donot silentlydismissasmalformed. Addedspecificruling/cost tosecondary-review-rulings. No currentproductionchange/frozenverificationstillfc170382.

Secondary boundedcheckpoint final: testedfc17038277d90da29f52483d2e4a8a7bdb7f9b34 complete8347Vitest+7Node cachedroot153107936970;772covering;all294SSR17new/341originalchanged;explicit289/8219commands/complete rows identicalgoldd60cb8110a8ad3f74342c52fbaf368c2c52aa04c6e44f22d0fd1dfcdd6cba280. Review0C1IexpiryfixedsingleREDGREENwave,0newMinor,9priorMinorsdefer.59individualparentrulings(58declines+inheritedmetadatafollowup)retained. Next3REDoutsideSRCpreflight, no newproductionedits. NoallTask15/releaseacceptance. Finaldocs-onlycommit+exactbackupnext.

Exactsecondary backupverified00c81bb9ec28a98054ae0fff3975562d1c4343df root458d90ebfaf3a5b0e817ab9305c39084ad927cfc checkpoints9ce7a0eb2c8b0c1f58ffeb352f09ee6affc20a21.4remoteSHAs+freshgitlsremoteexact/main29506e29unchanged. Source8cdcc9dd testedfc1703828347+7,289exactgold. Bundle17174SHAb72a2374ed1cdd515fc147442e92f9f2fb836c786e54e7478c72bb9afada65b9/blob85ee0331f179feb6d5b50797c35c060786ea8237;Evidence365485SHA4700b6aa3605cf0b6d496bcf53551cb937da35c43a79f4b4dbb020c211d8329c/blobe37c12f30f4d50677a3539d3a108dc20094c5513;metadata7ddab9add77de29873da92883f24cfc5b26cdfb8/LATEST9e37bcaf5135488cc74cd1dcad508c30a3be1b3f. Next actualMasterstatuseditunusedpotencyImportant thenDotGround, originalintegration/native/balance/releaseOPEN.

Newboundedsecondary-facts cohort BASE8cdcc9dd. Ruling: literal-onlyBurn1000/Poison5exports retain exactnativeoperators/values/branches; useactualcore/fullroot plus previous289samegold, no duplicate289 absentmechanical/AI/fixture/outcomechange — avoids duplicatefixedbenchmark withnochangedbehavior — costifwrong: an unrecognized nativechange couldrequirefreshmatrix; inspectdiffandallauthoritytests. Editorfalsepotency andDotGroundfacts share visibleEffectscontract, onecombinedreviewafterbatch/notperrecord. Conditionalprefix/Pierce/orangefollowlater;9Minorsdefer.

Periodic/editorcohort valid13RED/9GREEN154432205172→22GREEN154522992485;794cover/11GREEN154607214438;native79/7GREEN154607218274,types/lintsGREEN. Further actualsharedcompacttracefindsgenericpercentageoverridealso replacesnativeAP/ppunitsinlegacy/directreaders evenwhennativemagnitudeexists (canonicalhelperoverridehidesit). Ruling: removegenericpercentageoverrideentirely andusenativepreviewmagnitude foractualunits; retaincapturedvalues/historymeaning, notlossyabsolutepercentformat — a fixedAPcostmustnotdisplayauthoredirrelevantpercent — costifwrong: oldreadermarkupformatmaychange, checkfulllegacytestsandall294scope. Supersedesourbrief's provisional generic17%formatconstraint;noauthoredhistory/schema/nativechanges. Addedfouractualnativeunitcases beforecompletefix, preserveallothermetadataimmutability.

Nativeunits regression154744703405valid4RED/9GREEN; addedcapturedHealingDownscope2tests plus2experimentalBasicexpectations to1548433015618RED/14GREEN. Aftergenericoverride removal154906049253:801GREEN/5fail; threelegacycompacttests intentionallyassertoldlossyformat (valuesunchanged) updatednativeunits, whiletwoBasicexpectationswereunnecessary:fixednativeBasicreportusesitsownalreadytruthful15%mitigationauthorityandisnotthisgenericoverridepath. Ruling: retainexistingfixedBasicformat/testsunchanged, donotexpandtoBasicrendererredesign — onlyauthored/sharednativeunitsarescopehere — costifwrong: separateBasicprose/formatintegrationremainsinoriginalgate. TwoBasicexperimentalREDnotclaimedruntimebugs. Fulloldtestassertionsretainedwithsamecapturedamounts/newnativeunits;none deleted. CompactMagnitudeconsumesalreadycomputedpreview/options, preservingcapturedHealingDownscopewithoutduplicatepreview.

Periodic/editorcohort prefreeze:806/12GREEN155050300692 incl27new (15edited-status/nativeunits+12DotGround);native79/7GREEN154607218274;web/coretypes/lintGREEN,fullrootexpected8374Vitest+7Node. Main29506e29unchanged. ActualexistingSkillDetailtests nowretaincapturedvalueswithnativeunits, fixedBasic2testsrestoredexact/Basicproductionunchanged. LiteralBurn1000/Poison5only references/nativeopsunchanged;all9priorMinorsdefer. Onefreshcombinedreviewnext/no perrecordreviews/norereview. ReleaseoriginalgatesOPEN.

Frozen7542b6ce all294SSR155223205194GREEN:297groups604effects,10newdescriptions(7Burn2Poison1Ground),594othersunchanged,351totalfromoriginal/253unchanged. Raw3b261230fc8b5f3ae6096273e8bcf294720121515acb3b7875c108dc693bf431;174numeric/3excludingDamage+Pierce plus4PierceArmor candidates, notcompleteeditorialacceptance. AllAI6sourcehashes/manifestb86 unchanged. Root12105andcombinedreviewpending; no sourcechange.

# Periodic/Ground/edited-status combined review and parent rulings

Fresh gpt-6-astra High read-only review8cdcc9dd..7542b6ce:0Critical/0Important/1newMinor. Parent accepts the Minor grade: Burn regular tick boundary is unstated, but the displayed Instant describes valid application and no incorrect tick boundary is promised. This is inherited clarity debt, not a demonstrated native or false-timing regression. Defer as required; no C/I fix wave and no rereview. Total10Minors. Future complete editorial/native acceptance still includes clocks.

Final: minor (deferred): Burn regular ticks lack an explicit affected-turn-end fact; application Instant and percentage sequence/duration remain truthful. Native actions-legacy6013/combat-dots660 provide the actual clock.

Final: Ruling: Retained unused potency after status-ID editing — Preserve stored metadata; native preview now suppresses irrelevant magnitude — Cost if wrong: An unsupported retained value could remain misleading on another consumer.

Final: Ruling: Historical generic percentage formatting — Native units/direction improve accuracy; captured values unchanged — Cost if wrong: A legacy text-layout assumption may need adjustment.

Final: Ruling: Historical Wet/Conductive magnitude — Native legacy Storm bonus is fixed, independently of modern authored potency — Cost if wrong: Wrong history flag could show the wrong magnitude.

Final: Ruling: Haste/Slow retained potency — Native fixed AP overrides unused metadata — Cost if wrong: Another native-unit consumer could remain misleading.

Final: Ruling: Captured Healing Down scope — Already computed preview now receives existing policy flags; both scopes covered — Cost if wrong: Another consumer might omit its policy context.

Final: Ruling: Fixed native Basic formatting — Separate truthful native authority is unchanged — Cost if wrong: Separate Basic prose acceptance remains open.

Final: Ruling: Burn backlash versus tick percentage — Separate facts/captured1875basispoint witness retain distinct values — Cost if wrong: A magnitude mix-up could misstate backlash.

Final: Ruling: Burn multi-hit/miss/friendly/allowance — Prose matches existing aggregation and trigger claims — Cost if wrong: A missing edge could misstate trigger eligibility.

Final: Ruling: Burn reapplication/Copy allowance — Original restriction remains; native behavior unchanged — Cost if wrong: A misleading reset expectation could remain elsewhere.

Final: Ruling: Zero Burn backlash — Nullish default preserves zero — Cost if wrong: A future truthiness substitution could restore the default incorrectly.

Final: Ruling: Poison independent maxima — Prose matches independent percentage/original-duration selection — Cost if wrong: A reader could otherwise expect one winning application.

Final: Ruling: Poison carry/repeated thresholds — Modulo progress and captured full reset remain identical — Cost if wrong: A later movement-clock change could drift.

Final: Ruling: Poison Push/Pull/relocation — Existing traversal semantics retained; no authority change — Cost if wrong: A displacement path could remain unverified.

Final: Ruling: Legacy Burn trigger policy — Complete old explanation remains fallback — Cost if wrong: An uninspected historical consumer could differ.

Final: Ruling: Legacy Poison trigger policies — Both historical trigger/movement combinations preserve full fallback — Cost if wrong: Another captured policy mix may need acceptance.

Final: Ruling: Nonpercentage DoTs/Bleed — Helper returns null; existing presentation retained — Cost if wrong: Another untouched explanation may remain incomplete.

Final: Ruling: Ground authored versus native lifetime — Create-terrain produces Frozen Ground with fixed native lifetime; derive from overlay constants — Cost if wrong: A future versioned terrain rule would need new context.

Final: Ruling: Ground teams policy — Independent current enemy-only/legacy both-team flag retained — Cost if wrong: Wrong context could misstate who pays surcharge.

Final: Ruling: Steam lifetime policy — Modern remaining-life versus legacy configured-life matches authority — Cost if wrong: A wrong flag could misstate lifetime.

Final: Ruling: Ground versus Steam line of sight — No applies to Frozen Ground; prose explicitly identifies Steam blocking both teams — Cost if wrong: A reader could conflate overlay effects.

Final: Ruling: Definition mutation/public leakage — Pure reads/new presentation objects; public projection covered — Cost if wrong: An uninspected transport boundary could still leak.

Final: Ruling: Constant extraction/replay — Identical literals/operators/branches; actual native79/7/fullroot plus prior289gold, no duplicate matrix warranted — Cost if wrong: Unrecognized native change would require a fresh replay.

Final: Ruling: Conditional Requirements duplicates — Queued next; unchanged in this cohort — Cost if wrong: Conditions remain repetitively described.

Final: Ruling: Four Pierce equipment-Armor duplicates — Queued next; unchanged here — Cost if wrong: Bypass values remain repetitive.

Final: Ruling: Orange references/links — No complete appearance/interaction audit — Cost if wrong: References may remain inconsistent.

Final: Ruling: Stale-browser authority — No authority-path change/exercise — Cost if wrong: Revocation acceptance remains unverified.

Final: Ruling: Alternate selected-character authority — No binding-path change/exercise — Cost if wrong: Wrong-character authority remains unverified.

Final: Ruling: Direct RPC expiry — No protected RPC exercise — Cost if wrong: Direct-call expiry may remain unverified.

Final: Ruling: Direct RPC revocation — No protected RPC exercise — Cost if wrong: Direct-call revocation may remain unverified.

Final: Ruling: Direct RPC CAS — No protected concurrency exercise — Cost if wrong: CAS races may remain unverified.

Final: Ruling: Malformed nested data — No parser change; valid readers do not replace rejection evidence — Cost if wrong: Malformed definitions may remain unverified.

Final: Ruling: Malformed captures — No capture-validation change — Cost if wrong: Invalid captures may remain unverified.

Final: Ruling: Malformed pending data — No pending-packet validation change — Cost if wrong: Invalid pending packets may remain unverified.

Final: Ruling: Malformed summons — No summon parser/execution change — Cost if wrong: Malformed summons may remain unverified.

Final: Ruling: No-input/timeout — No scheduler change/exercise — Cost if wrong: Timeout outcomes may remain unverified.

Final: Ruling: Free priming — No native prime-budget exercise — Cost if wrong: Allowance bounds may remain unverified.

Final: Ruling: Repeated events — No native event-budget exercise — Cost if wrong: Unbounded reactions may remain unverified.

Final: Ruling: Interrupted Move/reached-origin attacks — No movement authority change/exercise — Cost if wrong: Origin or interruption defects may remain.

Final: Ruling: Duplicate payment — No complete payment-path acceptance — Cost if wrong: Duplicate costs may remain unverified.

Final: Ruling: Extra turns — No turn-economy acceptance — Cost if wrong: Extra-turn paths may remain unverified.

Final: Ruling: Concurrent publication — No hosted race/rollback exercise — Cost if wrong: Publication coherence may remain unverified.

Final: Ruling: Concurrent build writes — No build race exercise — Cost if wrong: Build coherence may remain unverified.

Final: Ruling: Concurrent claims — No claim/idempotency race — Cost if wrong: Duplicate claims may remain unverified.

Final: Ruling: Concurrent recovery — No late-worker recovery exercise — Cost if wrong: Recovery races may remain unverified.

Final: Ruling: Concurrent settlement — No settlement race exercise — Cost if wrong: Duplicate settlement may remain unverified.

Final: Ruling: Long names — SSR does not establish geometry — Cost if wrong: Names may overflow.

Final: Ruling: 200% zoom — No physical zoom geometry — Cost if wrong: Layout may remain inadequate.

Final: Ruling: Native keyboard/focus — No physical focus/dismissal exercise — Cost if wrong: Keyboard usability may remain inadequate.

Final: Ruling: Mobile/touch — No native device interaction — Cost if wrong: Touch behavior may remain inadequate.

Final: Ruling: Every editor/preview/popup — Shared-path coverage is narrower than all mounted consumers — Cost if wrong: Another surface may remain stale.

Final: Ruling: Missing historical metadata — Selected policy/history fixtures are narrower than every old reader — Cost if wrong: Another fallback may remain misleading.

Final: Ruling: Full legal cycles — Reader facts and literal equivalence are not complete learned cycles — Cost if wrong: A setup/payoff may remain ineffective.

Final: Ruling: AI strategy — Planner unchanged; no new strategic acceptance — Cost if wrong: Planning weaknesses may remain.

Final: Ruling: Natural pacing — No new natural balance experiment — Cost if wrong: Sustain stalls may remain.

Final: Ruling: Twelve-round balance — Original full-roster benchmark remains open — Cost if wrong: Global pacing may remain outside target.

Final: Ruling: Fresh Owner edits — Require current release-time reconciliation — Cost if wrong: Publication could overwrite newer edits.

Final: Ruling: Atlas — Original motion bound/acceptance remains open — Cost if wrong: Motion quality remains unresolved.

Final: Ruling: Human acceptance — Require actual Owner gameplay acceptance — Cost if wrong: Gameplay feel may remain unmet.

Final: Ruling: Broader Master panels — Remain after combat package — Cost if wrong: Broader panel work remains unfinished until its stage.

Final: Ruling: Nine prior Minors — No relevant resolution; individually retain previous9 deferred items — Cost if wrong: Existing test-hardening/grammar debt remains.

Final: Ruling: Frozen full-root result — Parent accepts only actual completed output — Cost if wrong: Unchecked regressions could otherwise be accepted.

Final: Ruling: All294 observation — Parent actual155223205194 passes with10changed594unchanged explanations — Cost if wrong: Static inventory does not prove native/full editorial acceptance.

Final: Ruling: Publication — None authorized/performed — Cost if wrong: Premature content could bypass gates.

Final: Ruling: Activation — None performed — Cost if wrong: Premature activation could bypass gates.

Final: Ruling: Migration application — None performed — Cost if wrong: Hosted state could change before acceptance.

Final: Ruling: Merge — None performed — Cost if wrong: Unaccepted work could enter main.

Final: Ruling: Deployment — None performed — Cost if wrong: Unaccepted work could be released.

Prior9Minors separately retained: (1)Rewind origin witness; (2)SupportingShot version pin; (3)Ongoing pair identity pin; (4)repeated bounded AI discovery; (5)admission provenance prefix; (6)ranged negative direct-commit witness; (7)defense event/HP reconciliation; (8)Arsenal full-label/exact-history-value hardening; (9)singular elemental-duration grammar. New(10)Burn tick-boundary clarity. None incidentally fixed.



## Periodic cohort full-gate correction — 15:59 UTC
Full root155221946742 exited1 with3989/3992 web tests passing: three old snapshot expectations still used generic raw percentages (Drenched42%, Resonance Vulnerable20%, overlapping Drenched35%). Actual native previews and new integration tests correctly expose +42% Storm, +20% incoming and +35% Storm. Changed only those three expected strings, retaining captured values, timing, assertions and coverage. Targeted12/3GREEN155846210254; Prettier and diff check pass. No production change and no review rerequest/fix wave. Reviewed production remains7542b6ce; final tested source is c731bf71f8dd7a933146eb75cb8db012095d2f97. Full frozen root rerun now required; first failed gate preserved. All294 diagnostic remains valid for identical production source.

Frozen root155905876482 exit0, root stdout truncated at web typecheck; actual complete package logs8374Vitest+7Node/all8typechecks/bothbuilds audited and hashed in periodic-fullcheck-audit.json / periodic-turbo-logs.tar.gz. One cached root replay, no source changes, to recover direct complete output.


## Final periodic checkpoint verification
# Native status units and periodic/Ground reader facts — verified checkpoint

This bounded Task15 cohort fixes the reproduced Master status-ID edit path: unused potency no longer invents a percentage for Airborne, Rooted, Covert, Invisible or Chilled. Shared compact readers consume the existing native preview, including actual units, direction and captured Healing Down scope. Stored metadata, schemas and native rules are unchanged. Existing authored/historical compact assertions retain the same captured values and now name native units/direction; fixed native Basic reports retain their separate unchanged format.

Seven current Burn effects expose exact captured/default backlash separately from the DoT sequence, with once-per-turn allowance and unchanged hostile-HP/multi-hit/miss/friendly/reapply/Copy rules. Two Poison effects expose the five-traversed-tile full-duration refresh and absence of extra damage, preserving independent percentage/duration maxima, carry, Push/Pull and relocation restrictions. One Frozen Ground effect derives its two-round-boundary lifetime and10AP surcharge from native overlay data, distinguishes current enemy-only/legacy both-team rules and current remaining-life/legacy reset Steam conversion. Complete old Burn/Poison trigger explanations remain fallbacks; nonpercentage legacy effects remain unchanged.

Two existing native literals become shared exports: Burn default1000basispoints and current Poison refresh5tiles. Native operators, branches, values, fields and formulas are unchanged. Actual DoT authority tests79/7 pass154607218274; accepted manifest and all six planner/fixture hashes remain unchanged. The preceding verified289build/8219command byte-identical benchmark remains evidence of the unchanged fixture; no fresh matrix is claimed for this literal-only presentation cohort. Broader AI quality, natural pacing/twelve-round balance and complete cycles remain open.

TDD: actual editor path/current facts13RED+9GREEN154432205172; initial22GREEN154522992485. Additional native-unit4RED154744703405 and captured Healing Down scopes reproduce the generic override in compact/history consumers. Two exploratory fixed-Basic format expectations were outside that path and are restored unchanged, not claimed as bugs. Three old compact assertions were updated to native direction/units with captured values and coverage preserved. Final focused coverage806/12GREEN155050300692 includes27new cases. The first full gate155221946742 found three further stale expected strings in Technique, Resonance and overlapping elemental-timing contracts (3989/3992webGREEN). Their values/timing/assertions remain; only native unit strings changed. Those12tests pass155846210254. No production change followed review.

Final frozen source `c731bf71f8dd7a933146eb75cb8db012095d2f97` passes the complete root check, receipt `20261016T160349537538Z`, exit0:8,374Vitest plus7Node checks, formatting, lint, all8package typechecks and both builds. Actual receipt window 2026-10-16T16:03:49.537538+00:00–2026-10-16T16:04:22.005732+00:00. Production review covers7542b6cec83bf7f87e7fdbe5c51237af863ce0a9; its descendant changes only three test expectations. Documentation follows without source changes. Original root155905876482 exited0 but its stdout stopped during web typecheck; preserved, hashed package logs reconcile all8types, bothbuilds and8374+7. One cached full-root replay supplies the final complete direct summary; no source changes or speculative repeated gate.

Fresh diagnostic155223205194 renders all294actual records/297groups/604effects through named shared readers:10new explanations (7Burn/2Poison/1Ground), all594others exactly unchanged from the preceding secondary-status checkpoint;351total changed/253unchanged from the original editorial observation. Raw SHA256`3b261230fc8b5f3ae6096273e8bcf294720121515acb3b7875c108dc693bf431`. This is static default-context evidence, not mounted native or complete editorial acceptance. Edited unused potency is independently covered through actual Master handler→canonical parse→report/publicSSR; current payloads do not contain that unused metadata.

One fresh combined review:0Critical/0Important/1newMinor. Ordinary Burn tick boundary is still unstated; Instant describes application. Parent accepts inherited clarity debt as Minor and defers it; ten total Minors remain. No C/I fix wave or rereview. Each of67considered/declined behaviors has a separate reason and cost in the checkpoint evidence/ledger, including current/legacy mechanics, captures, purity, native literal extraction, controls, authority/concurrency, layout, full cycles, balance and release boundaries.

Conditional Requirements prefixes, four Pierce equipment-Armor percentage duplicates and complete orange reference/link interaction remain next work. Original combat Targeting/Move/editable five Basics/Controlled/native controls, complete editors/previews/popups, distinct full cycles/balance, fresh Owner edits, hosted authority/CAS, Atlas motion and human acceptance remain open before release. Broader Master panels follow combat. High remains sufficient for this integration work. No publication, activation, hosted write, migration application, merge or deployment.


Verified remote recovery checkpoint9a561f940ec0b0556f77d24ef2dfe83926af5f8d, root94805617502e8d503a95459c7c5ed9682cfbbf56, checkpointsdf8aed6bd3ada64e2bf07dbb92ae8e84ea1bfb1e. All4entrySHAs and freshgitlsremote verified; main unchanged29506e29. Source0783819c/testedc731bf71, productionreview7542b6ce. No release. Next preflight160416646119 valid9RED1authoredGREEN, actual3conditional/4Pierce+mixednested/Basiccustom33.33. Scope brief saved.

## Conditional/Pierce cohort BASE0783819c — inline
Preflight160416646119 observed9validRED/1authoredGREEN. Implemented generated description-only conditionprefix removal while typed condition/summary remain unchanged; Pierce bypass onlystructurednumeric plus explicit equipment-only/noequipment noadvantage prose, specialized Basic branch same. Ten portable source tests copied from observed preflight; actual3conditional/4Pierce/nested/globalrequirements/authoredescaped/custom33.33Basic. Updated two existing native Basic projection assertions to check condition in typed/Effects rows and bypasspercentage in magnitude, retain strongerPower/immutability/authority coverage. No native/schema/AI/manifest/fixture changes. No orange/fullcycle/balance/release closure.

Task15: Ruling: initial7description assumption was an incomplete inventory from remaining non-damage numeric candidates — generated prefix removal intentionally applies to all29typed conditional effects, preserving the full condition in unchanged structured Effects fields. Fresh all294 data shows33changed (29conditions +4Pierce),571othersidentical. All rows/effects/conditions/limits/maintenance exactprior; each nonPierce explanation equals old string with only exactgeneratedprefix removed. 25status-presence/4resource-state includes EssenceAetherNova75%MP beyond3non-damageResonancecases. No new source change or new bug inferred. Cost if wrong: omittedconditional semantics/misreportedacceptance; bounded exactcomparison provesallactualreports, fullnativeacceptance staysopen. Raw0144a44a91bb54836140aed7d138bedff71d3f156c227537eb109e7b06fe8709,369totalchanged235unchangedoriginal,171digitexplanationsallDamage/Pierce; numericcount is inventory not editorialacceptance. Reviewer informed.


# Parent rulings — conditional/Pierce combined review

Fresh reviewer /root/conditional_pierce_reader_review, gpt-6-astra High, fork none. Read-only0783819c..d47e4120; no suites/mutations/browser/delegation. Parent accepts0Critical/0Important/0newMinor. No C/I wave or rereview. Ten prior Minors remain deferred; none fixed incidentally.

1. Final: Ruling: Native equipment-Armor integration — explicit contribution helper supports wording; no native integration claim. Cost if wrong: unresolved equipment execution could block release.
2. Final: Ruling: Legacy Mature piercing:true execution — separate execution and description paths unchanged. Cost if wrong: historic Pierce could regress if later unified carelessly.
3. Final: Ruling: Every historical metadata combination — inspected fallbacks/capture projection cover bounded contexts. Cost if wrong: an untested old capture could display incorrect semantics.
4. Final: Ruling: Complete orange reference appearance — no styling changed; next bounded reader work. Cost if wrong: inconsistent references remain until completed.
5. Final: Ruling: Orange hover/touch/link interaction — no native browser exercise; original gate remains. Cost if wrong: references could be inaccessible on an untested device.
6. Final: Ruling: Targeting/controller completion — no targeting or controller change; original integration stays open. Cost if wrong: a selection/range/control defect could block combat release.
7. Final: Ruling: Attached Move traversal/interruption — execution unchanged; native path not accepted here. Cost if wrong: an interrupted traversal could violate legal movement.
8. Final: Ruling: Attacks from reached origin — no native interruption/origin acceptance. Cost if wrong: an attack could incorrectly use an unreached tile.
9. Final: Ruling: Editable Move completion — reader correctness does not complete editor/execution acceptance. Cost if wrong: saved Move edits might fail in battle.
10. Final: Ruling: Editable Basic Attack completion — custom projection proves presentation only. Cost if wrong: saved attack edits might diverge during execution.
11. Final: Ruling: Editable Guard completion — no full authoring/runtime workflow exercised. Cost if wrong: saved Guard semantics might diverge.
12. Final: Ruling: Editable HP Recovery completion — captured condition projection is narrower than full workflow. Cost if wrong: HP recovery edits might execute incorrectly.
13. Final: Ruling: Editable MP Recovery completion — no full authoring/runtime acceptance. Cost if wrong: MP recovery edits might execute incorrectly.
14. Final: Ruling: Controlled prime/release/cancel completion — explanation retained; native workflow gate remains. Cost if wrong: prime/release cancellation could violate allowance/payment.
15. Final: Ruling: Full Master editor coverage — relevant adapters inspected, all mounted editors still need acceptance. Cost if wrong: a mounted editor could mis-save or hide a field.
16. Final: Ruling: Every preview/popup — shared report paths checked; all mounted surfaces remain open. Cost if wrong: a surface could hide or mislabel mechanics.
17. Final: Ruling: Long-name geometry — source/SSR cannot prove native layout. Cost if wrong: long text could obscure controls.
18. Final: Ruling: Mobile/touch geometry — no device exercise. Cost if wrong: mobile controls or text could become unusable.
19. Final: Ruling: Native keyboard/focus/dismissal — no physical input exercise. Cost if wrong: keyboard users might lose control/focus.
20. Final: Ruling: 200% zoom — no physical zoom acceptance. Cost if wrong: enlarged controls or prose might clip.
21. Final: Ruling: Stale-browser expiry/revocation — authority paths unchanged; require actual gate. Cost if wrong: stale privileges could remain effective.
22. Final: Ruling: Alternate selected-character authority — binding paths unchanged; independent gate stays open. Cost if wrong: another character could receive unauthorized actions.
23. Final: Ruling: Direct RPC expiry — protected RPC not exercised. Cost if wrong: expired access might bypass a UI-only check.
24. Final: Ruling: Direct RPC revocation — protected RPC not exercised. Cost if wrong: revoked access might remain effective.
25. Final: Ruling: Direct RPC CAS — no concurrency exercise. Cost if wrong: a stale direct write could overwrite newer state.
26. Final: Ruling: Malformed nested definitions — parser unchanged; valid reader tests are not rejection tests. Cost if wrong: invalid definitions could escape validation.
27. Final: Ruling: Malformed captured definitions — capture validation untouched. Cost if wrong: corrupt history could execute or leak fields.
28. Final: Ruling: Malformed pending work — pending validation untouched. Cost if wrong: invalid pending packets could execute.
29. Final: Ruling: Malformed summon data — summon validation untouched. Cost if wrong: invalid summon payloads could execute.
30. Final: Ruling: Complete transport/privacy acceptance — shared public report purity is narrower than every API/RSC/live envelope. Cost if wrong: another envelope could leak private fields.
31. Final: Ruling: No-input/timeout behavior — scheduler/terminal paths unchanged and unexercised here. Cost if wrong: idle turns could terminate or reward incorrectly.
32. Final: Ruling: Free priming bounds — no native prime-budget exercise. Cost if wrong: unbounded priming could become advantageous.
33. Final: Ruling: Repeated-event bounds — event budget unchanged; independent acceptance required. Cost if wrong: repeated events could trigger unbounded output.
34. Final: Ruling: Duplicate payment prevention — no complete payment-path acceptance. Cost if wrong: a release could pay more than once or skip payment.
35. Final: Ruling: Extra-turn prevention — turn economy unchanged; independent acceptance required. Cost if wrong: reactions could create unintended extra turns.
36. Final: Ruling: Concurrent publication — no hosted race/rollback exercise. Cost if wrong: publication could race into an incoherent version.
37. Final: Ruling: Concurrent build writes — no build race exercise. Cost if wrong: simultaneous build writes could lose updates.
38. Final: Ruling: Concurrent claims — claim/idempotency authority untouched. Cost if wrong: repeated claims could duplicate rewards.
39. Final: Ruling: Concurrent recovery — no late-worker recovery exercise. Cost if wrong: recovery could conflict with fresh state.
40. Final: Ruling: Concurrent settlement — no settlement race exercise. Cost if wrong: a battle could settle repeatedly or inconsistently.
41. Final: Ruling: Distinct complete combat cycles — legible requirements do not establish executable setup/payoff cycles. Cost if wrong: a roster cycle could fail or dominate despite readable text.
42. Final: Ruling: AI strategy — planner unchanged and no new strategy acceptance claimed. Cost if wrong: AI may still choose weak legal actions.
43. Final: Ruling: Natural combat pacing — no natural balance experiment in this cohort. Cost if wrong: combat could remain too long or one-sided.
44. Final: Ruling: Twelve-round balance — original benchmark acceptance remains open. Cost if wrong: a nominal test could hide poor intended pacing.
45. Final: Ruling: Fresh Owner edits — main unchanged on refreshed read; release-time content reconciliation still required. Cost if wrong: later Owner changes could be overwritten or omitted.
46. Final: Ruling: Atlas motion — no motion change or acceptance; known .830568 threshold miss stays open. Cost if wrong: motion may remain above the agreed limit.
47. Final: Ruling: Human gameplay acceptance — requires actual Owner gameplay evidence. Cost if wrong: software checks could miss poor play experience.
48. Final: Ruling: Broader Master panels — scheduled after combat package as instructed. Cost if wrong: unrelated Master workflows remain unfinished.
49. Final: Ruling: Exact frozen full root — parent owns actual gate and will read output before acceptance. Cost if wrong: an unobserved failure could invalidate the checkpoint.
50. Final: Ruling: All294 diagnostic — parent executed160709732791 and independently compared all report fields; static scope retained. Cost if wrong: SSR could miss mounted/native or contextual defects.
51. Final: Ruling: Publication — not authorized by this checkpoint; none performed. Cost if wrong: premature roster publication could expose unfinished mechanics.
52. Final: Ruling: Activation — not authorized by this checkpoint; none performed. Cost if wrong: unfinished definitions could become active.
53. Final: Ruling: Hosted writes — none necessary for local presentation work. Cost if wrong: remote state could change without accepted native gates.
54. Final: Ruling: Migration application — no migration necessary or applied. Cost if wrong: hosted authority/schema could change prematurely.
55. Final: Ruling: Merge — no merge authorized or performed. Cost if wrong: unaccepted combat integration could enter main.
56. Final: Ruling: Deployment/release — no release authorized; lock unchanged. Cost if wrong: users could receive unfinished combat behavior.

Deferred minors (existing10; no new findings):

- Final: minor (deferred): Rewind origin witness; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): SupportingShot version pin; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Ongoing pair identity pin; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Repeated bounded AI discovery; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Admission provenance prefix; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Ranged negative direct-commit witness; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Defense event/HP reconciliation; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Arsenal full-label/exact-history-value hardening; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Singular elemental-duration grammar; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Ordinary Burn tick-boundary clarity; inherited, unchanged and not fixed in this bounded cohort.



## Final conditional/Pierce checkpoint verification
# Conditional and Pierce prose — verified checkpoint

This bounded Task15 cohort removes generated condition prefixes from generated explanations. All29actual typed effect conditions and their exact full Effects rows remain unchanged:25status-presence and4resource-state, including Essence Aether Nova’s owner MP≥75% condition. The initial three numeric candidates were non-damage Resonance effects, not the full numeric-condition inventory. Group-level Requirements, recipient, timing, order, maintenance and limits remain separate and unchanged. Full report consumers retain conditions before explanations. Exact aligned authored explanations remain escaped text, including any intentional numeric wording.

Four actual canonical Pierce effects retain exact damage magnitude and equipment-Armor bypass percentage in the structured magnitude. Generated prose explains that the displayed bypass applies only to equipment Armor and offers no advantage without equipment Armor. The specialized Basic Attack branch retains stronger-Power scaling, rounding and tie rules, with the same plain equipment boundary. Legacy Mature piercing:true, native execution, schemas, manifest, all six planner/fixture hashes and values are unchanged. No new289matrix is claimed for presentation-only changes; native equipment-Armor integration/full-cycle acceptance stays separate.

Preflight160416646119:9validRED/1authoredGREEN. Ten new portable cases cover all3actual non-damage conditional Resonance effects, all4actual Pierce effects, nested effect/global Requirements separation, escaped authored explanations and captured33.33% Basic Pierce with Mystic scaling. Covering160602521960 passes35tests across6actual files, including native Basic projection and exact captured reports. A nonexistent requested techniques-manual.test.ts is not counted; actual current-manual.test.ts runs in the full root. Two existing Basic projection assertions check exact condition in typedfields/Effects and exact bypasspercentage in magnitude, retaining stronger-Power/immutability/authority checks.

Frozen source `d47e412015caf3d7dbda0546fad471bbffab0bcc` passes the complete root check, receipt `20261016T160709731530Z`, exit0:8,384Vitest plus7Node checks, formatting, lint, all8package typechecks and both builds. Actual window 2026-10-16T16:07:09.731530+00:00–2026-10-16T16:11:20.742481+00:00. Documentation follows without source changes. Full-root output/package evidence is preserved in the checkpoint; no unobserved pass is inferred.

Fresh diagnostic160709732791 renders all294actual records/297groups/604effects through shared readers. Independent comparison proves every structured report field/row/effect/condition/recipient/timing/limit/maintenance exactly unchanged from the prior frozen checkpoint. All29non-Pierce generated conditions are removed by exact prefix only;4Pierce explanations change independently. Thus33explanations change,571others remain exact;369total changed/235unchanged from original editorial observation. Raw SHA256`0144a44a91bb54836140aed7d138bedff71d3f156c227537eb109e7b06fe8709`. Remaining171numeric explanations are all directDamage/Pierce; this is an inventory, not complete editorial/native acceptance. Authored text is never stripped or normalized.

One fresh combined review0Critical/0Important/0newMinor; parent accepts. No C/I wave or rereview. Fifty-six individually considered/declined behaviors each have a separate parent reason/cost in the checkpoint ledger/rulings. Ten inherited Minors remain deferred, including ordinary Burn tick-boundary clarity; none fixed incidentally. Reviewer inspected all29actual requirement-bearing effects and relevant current/captured/legacy/authored report consumers. The actual manifest has no effect-level prime/nested condition; unchanged generic formatting and the custom nested regression remain narrower evidence than native execution.

Complete orange inline references/link interaction, original combat Targeting/Move/editable five Basics/Controlled/native controls, full editors/previews/popups, distinct complete cycles/balance, fresh Owner edits, hosted authority/CAS, Atlas motion and human acceptance remain open before release. Broader Master panels follow combat. High remains sufficient. No publication, activation, hosted write, migration application, merge or deployment.


Verified conditional/Pierce remote recovery checkpoint4f2f5f72cdacaca82573624674df857251cc499f; root15b6b1d8450cfd07ddd1774851babbc7b42373c1; checkpoints36de32692241663cc50fc77006bd35ce645815d2. FourentrySHAs/freshgitlsremote verified, main29506e29 unchanged. Sourceb0367633/testedd47e4120. No release.


## Typed Ground/Airborne reference foundation — BASEb0367633
Task15 approved inline continuation; desktop/mobile shared PvE/PvP/Spectator readers through same helpers, no geometry/art/control/mechanics changes. Existing written plan/Owner§10 authorizes actual linked terms; no fresh approval stall for routine implementation choices. Scoped coherent foundation:6reference IDs (FrozenGround,Steam,Airborne,Rooted,Slow,Fire), current3actualcanonicalGround/Airborneeffects and Ground Steam-lifetime label. Remaining tags/legacy noncanonical prose/conditions/Manual rich links/live-instance popups/native interaction acceptance remain open; not claimed allorangefinished. No naive keyword replacement or HTML parsing to derive mechanics.
11validRED6GREEN163535488006: missing actualmetadata + secondreaderdismissesparent, not import/type errors. First17GREEN163707444397. Wider340case run1638134859434oldassertionsreject addedSteamlabelParts metadata; exact nativevalues retained and oldSteamrow check now objectContaining with same label/value (newtest asserts semanticmetadata separately). A failed scripted edit led to one unchanged repeat163921216993; preserved, no newbug claimed. Corrected340GREEN163941991096. Additional controls: Delayed/Controlled wrapper appendexactness, unknown/prototypeidentityfallback, pairdismiss reentrancy. Final344/41GREEN164017761110 including16newcases (10newreferencecases,6newsessioncases). Earlier webtypes163845202632GREEN; finalscoped types/lint pending. Accidental import-before-client directive was noticed/restored beforefreeze; no claim unrepairedsourcepassedbuild.
Public plain description contracts unchanged. Explicit tagged templates produce optional safe textparts; resolver derives6genericcompact explanations from existing native/canonicalfunctions using capturedcontext. No invented livepotency/stacks/lifetime, no PHASE4 modern/historical dictionaryguess. Authored overrides removegenerated proseparts even whenidentical; labeldetailreference independent; stale descriptionmetadata and unknownIDs fall back escapedplain text. Wrappers append text without replacing words. Steam conversion remains conditional onaffectedFrozenGround; oldteams/Fire/Airbornehelp stayscaptured. Genericpopupbodyplainstringpreventsrecursivehelp.
Sharedpopupownership becomes oneprimary+oneleaf optin. Parentcontextholdsrootwhileleafopen; siblingreplacement/unmount/rootreplacement/globaldismiss/reentrantcleanup bounded. Parentownsbackdrop/battleconsumption whenleafnotactive; childEscape/outside restoresits owntrigger, clickinsideparentclosesonlychildwithoutconsumingparentinteraction. Hoverchildcancelsparentclose, timeoutchecksownhover/focus/childownership, unmountguardpreventsresume-createdtimerafterparentunmount. Nestedhelpinheritsinspectlayer to stayaboveparent. Nativebrowser unavailable perexisting evidence; noinstall/tunnelretry; pureownership/staticSSR are narrower thanactualkeyboard/hover/touch/mobile/zoomacceptance. All10Minors preserved, ordinaryBurnclockclarityunchanged.


# Parent rulings — linked Ground/Airborne foundation

Reviewer /root/linked_ground_airborne_reference_review, gpt-6-astra High, fork none; read-onlyb0367633..aed2fb53, no suites/services/browser/mutations/delegation/rereview. Parent accepts0Critical/1Important/1newMinor. Keyboard reachability Important enters ONE C/I RED→GREEN wave; Master inline sizing accepted as Minor and deferred (possible tall lines, no established functional obstruction or measured dimensions). Total11Minors; no incidental sizing change.

1. Final: Ruling: Complete orange treatment across every tag — six explicit identities are the bounded foundation. Cost if wrong: other references remain inconsistent until later cohorts.
2. Final: Ruling: Noncanonical/legacy prose links — existing plain fallback generation remains outside this foundation. Cost if wrong: older readers can lack interactive linked terms.
3. Final: Ruling: Condition links — typed condition linking remains next work. Cost if wrong: prerequisite names remain plain text.
4. Final: Ruling: Manual rich links — Manual string consumer unchanged. Cost if wrong: public Manual terms remain noninteractive.
5. Final: Ruling: Authored typed-reference insertion — authored plain explanations are preserved; insertion workflow remains open. Cost if wrong: editors cannot yet deliberately insert typed links.
6. Final: Ruling: Live-instance potency/stacks/expiry — generic help has no instance source and makes no instance claim. Cost if wrong: active-effect popups still require separate complete acceptance.
7. Final: Ruling: Every historical policy combination — relevant old Ground/Fire/Airborne branches tested; not exhaustive. Cost if wrong: an untested historical combination could display wrong help.
8. Final: Ruling: Malformed runtime reference arrays — internally generated typed metadata introduces no external deserializer. Cost if wrong: a future persisted/untrusted reference boundary would need validation.
9. Final: Ruling: Malformed nested definitions — parser unchanged; no rejection-path acceptance here. Cost if wrong: invalid authored structures could escape independent validation.
10. Final: Ruling: Malformed captured definitions — capture validation unchanged. Cost if wrong: corrupt historical definitions could be misread or execute incorrectly.
11. Final: Ruling: Malformed pending work — pending execution unchanged. Cost if wrong: invalid pending packets could survive an unrelated boundary.
12. Final: Ruling: Malformed summon data — summon validation unchanged. Cost if wrong: invalid summon payloads could survive an unrelated boundary.
13. Final: Ruling: Complete transport/privacy — new nodes contain only tag/label/explanation but other envelopes remain unaccepted. Cost if wrong: another transport surface could leak private fields.
14. Final: Ruling: Physical hover traversal — source and ownership tests are narrower than real pointer geometry. Cost if wrong: pointer gaps could dismiss or strand a popup.
15. Final: Ruling: Physical touch dismissal — click ownership inspected; real touch sequencing remains open. Cost if wrong: touch users might struggle to dismiss or switch terms.
16. Final: Ruling: Native focus restoration — appropriate targets retained; no real browser focus acceptance. Cost if wrong: physical focus could be lost or reopen unexpectedly.
17. Final: Ruling: Full keyboard/AT acceptance — reported reachability Important enters one fix wave; native AT/device exercise remains open. Cost if wrong: real keyboard or screen-reader behavior might differ from handler checks.
18. Final: Ruling: Long-name geometry — no physical layout measurements. Cost if wrong: long labels could overflow or obscure controls.
19. Final: Ruling: Mobile viewport geometry — shared code applies to mobile but no device acceptance. Cost if wrong: mobile terms or panels could clip.
20. Final: Ruling: 200% zoom — source/SSR cannot establish enlarged layout. Cost if wrong: zoomed controls or text could become inaccessible.
21. Final: Ruling: Exact Master inline heights — new sizing Minor deferred; no used-height measurement. Cost if wrong: Master inline reference rows may be taller than intended.
22. Final: Ruling: Outer-modal backdrop dismissal — existing close-all modal boundary preserved. Cost if wrong: a modal backdrop can close the broader reader instead of only the leaf.
23. Final: Ruling: Arbitrary open-callback recursion — actual callbacks only close/resume their own hierarchy; broader callback API unchanged. Cost if wrong: a future exotic caller could violate ownership expectations.
24. Final: Ruling: Complete Master editor coverage — relevant shared report adapters inspected only. Cost if wrong: other mounted editors may still mis-save or misdisplay fields.
25. Final: Ruling: Every mounted preview/popup — shared paths traced; full mounted audit remains open. Cost if wrong: a separate surface can miss reference or parameter changes.
26. Final: Ruling: Targeting/controller completion — execution unchanged; original gate remains. Cost if wrong: selection or range defects could block combat release.
27. Final: Ruling: Attached Move traversal/interruption — no movement execution change. Cost if wrong: interrupted movement could violate path or payment rules.
28. Final: Ruling: Attacks from reached origins — native movement/attack acceptance remains separate. Cost if wrong: an attack could use an unreached origin.
29. Final: Ruling: Editable Basic Move completion — no complete editor-to-native workflow exercised. Cost if wrong: saved Move edits may diverge during battle.
30. Final: Ruling: Editable Basic Attack completion — projection/readers are narrower than full workflow. Cost if wrong: saved attack edits may execute differently.
31. Final: Ruling: Editable Guard completion — no complete editor/runtime exercise. Cost if wrong: saved Guard effects may diverge.
32. Final: Ruling: Editable HP Recovery completion — no complete editor/runtime exercise. Cost if wrong: saved HP recovery may execute incorrectly.
33. Final: Ruling: Editable MP Recovery completion — no complete editor/runtime exercise. Cost if wrong: saved MP recovery may execute incorrectly.
34. Final: Ruling: Controlled prime/release/cancel completion — wrapper text remains exact; native gate still required. Cost if wrong: release/cancel could violate allowance or payment.
35. Final: Ruling: Stale-browser expiry/revocation — authority unchanged; independent gate remains. Cost if wrong: stale privileges might remain effective.
36. Final: Ruling: Alternate selected-character authority — selection/binding unchanged. Cost if wrong: operations could affect an unauthorized character.
37. Final: Ruling: Direct RPC expiry — protected RPC not exercised. Cost if wrong: expired direct access might bypass UI-only checks.
38. Final: Ruling: Direct RPC revocation — protected RPC not exercised. Cost if wrong: revoked direct access might remain effective.
39. Final: Ruling: Direct RPC CAS — no concurrency exercise. Cost if wrong: stale direct writes could overwrite newer state.
40. Final: Ruling: No-input/timeout behavior — scheduler/terminal paths unchanged. Cost if wrong: idle handling could settle or reward incorrectly.
41. Final: Ruling: Free priming bounds — no native budget exercise. Cost if wrong: repeated priming could create unintended advantage.
42. Final: Ruling: Repeated-event bounds — event execution unchanged. Cost if wrong: reactions could produce unbounded output.
43. Final: Ruling: Duplicate payment prevention — no complete payment-path exercise. Cost if wrong: release could pay repeatedly or skip costs.
44. Final: Ruling: Extra-turn prevention — turn economy unchanged. Cost if wrong: reactions could create unintended extra turns.
45. Final: Ruling: Concurrent publication — no hosted race/rollback exercise. Cost if wrong: versions could publish inconsistently.
46. Final: Ruling: Concurrent build writes — no write-concurrency exercise. Cost if wrong: simultaneous edits could lose changes.
47. Final: Ruling: Concurrent claims — claim/idempotency paths unchanged. Cost if wrong: repeated claims could duplicate grants/rewards.
48. Final: Ruling: Concurrent recovery — no late-worker exercise. Cost if wrong: recovery could conflict with fresh state.
49. Final: Ruling: Concurrent settlement — no settlement race exercise. Cost if wrong: a battle could settle repeatedly or inconsistently.
50. Final: Ruling: Distinct complete combat cycles — links do not prove playable setup/payoff cycles. Cost if wrong: a roster cycle could fail or dominate despite legible descriptions.
51. Final: Ruling: AI strategy — planner/fixtures unchanged. Cost if wrong: legal AI decisions may remain strategically weak.
52. Final: Ruling: Natural pacing — no balance experiment in this presentation cohort. Cost if wrong: combat could be too long or one-sided.
53. Final: Ruling: Twelve-round balance — original benchmark gate remains open. Cost if wrong: intended pacing could remain unbalanced.
54. Final: Ruling: Fresh Owner content — release-time reconciliation remains required. Cost if wrong: later Owner edits could be overwritten or missed.
55. Final: Ruling: Atlas motion — no motion change or acceptance; known threshold miss stays open. Cost if wrong: motion could remain above the agreed limit.
56. Final: Ruling: Human gameplay acceptance — requires actual Owner play evidence. Cost if wrong: software checks could miss a poor gameplay experience.
57. Final: Ruling: Broader Master panels — scheduled after combat as instructed. Cost if wrong: unrelated Master workflows remain unfinished.
58. Final: Ruling: Frozen full root — parent read actual8400+7 initial gate; post-fix source must pass its own full gate. Cost if wrong: unobserved post-fix failures could invalidate the checkpoint.
59. Final: Ruling: All294 mounted behavior — parent static audit proves exact text/normalized fields only. Cost if wrong: mounted interaction/layout can differ from SSR.
60. Final: Ruling: Publication — none authorized or performed by this cohort. Cost if wrong: unfinished definitions could reach players.
61. Final: Ruling: Activation — none authorized or performed. Cost if wrong: unfinished mechanics could become active.
62. Final: Ruling: Hosted writes — none needed for local reader changes. Cost if wrong: remote state could change before acceptance.
63. Final: Ruling: Migration application — no migration in this cohort or applied. Cost if wrong: hosted schema/authority could change prematurely.
64. Final: Ruling: Merge — not authorized or performed. Cost if wrong: unaccepted work could reach main.
65. Final: Ruling: Deployment/release — original gates remain open; lock retained. Cost if wrong: players could receive unfinished combat behavior.

Final: minor (deferred): Master button min-height/font cascade can enlarge inline reference rows; exact geometry unmeasured. New11thMinor, preserved for later Owner-prioritized work. Ten inheritedMinors remain individually unchanged: Rewindoriginwitness; SupportingShotversionpin; Ongoingpairidentitypin; repeatedboundedAIdiscovery; admissionprovenanceprefix; rangednegativedirectcommit; defenseevent/HPreconciliation; Arsenalfull-label/exacthistoryvaluehardening; singulardurationgrammar; ordinaryBurntickboundaryclarity.

# Fresh combined review verdict and parent disposition
Read-only reviewer /root/linked_ground_airborne_reference_review, gpt-6-astra High/fork none, BASEb036763303a1e34b43f60188ab3b55b591637c54→HEADaed2fb535a5561f48efdeddd67c73f20977e3e1f; all21changedfiles/Owner§10/brief/realconsumers inspected. No suites/services/browser/mutations/delegation/rereview. Verdict0Critical/1Important/1newMinor; parent acceptsgrades. Important: battleplainTab/ShiftTabcapture disables traversal, so initialonFocus referenceopener unreachable from focused reportpanel. Fixonewave scoped referencebutton navigation/discoverableinstructions, preservingpicker/input/nativeactivation/browsermodifiers/custombindings andTabpolicy. Minor: Master .av-master/workspace button minimumheight/font canenlargeinlinereferencebuttons; acceptedMinor/deferred (no measuredfunctionalobstruction). Total11Minors, teninheritedunchanged.
All65declinedbehaviors have separate parentreason/cost in linked-review-rulings.md and progress.md. Initialfrozenroot8400+7passes164320822544; post-fixroot required. Onefixwave testsactualcomponentcallbacks/ARIAinstructionbeforefocuswithcontrolledhook+DOMsurface, plusactualreportSSRtriggerwiring; notrealbrowser/nativeacceptance. Initialtestfixturemissingdocument164912475822 isnotlegitimateRED. Corrected1651035598639validRED9GREEN (6navigation/hint +3actualSSRtriggermarkers);16512538638548GREEN afterfix. Addedmodifierguard regression1651532247591validRED8GREEN; guardappliedsamefixwave. Finalcover/type/lint/root pending. No alltag/native/control/cycle/balance/hosted/Atlas/human/merge/releaseapproval.


Final: fixed keyboardreachabilityImportant — actualpanel callback/hintbeforefocus/realSSRtriggermarker9validRED9GREEN165103559863, modifierguard1validRED8GREEN165153224759, sameONEwave. Final372/43GREEN165221721204, webtypes165220823691/lint165220823959GREEN. Testsusecontrolledhooks/DOMsurface with actualJSXcallbacks, notnativebrowser or actualAT. Missingdocumentfixture164912475822 notvalidRED. Master sizingMinorunchanged/deferred; total11. Finalcodesource3b52fe66e4af6958cde126e38fa36bae0de9bd7b, reviewedinitialaed2fb535a5561f48efdeddd67c73f20977e3e1f; no rereview. All25newcasessincebase, expected8409+7root. Initial8400+7root164320822544 preserved. Pre-reviewall294/rawmetadata snapshots preserved; finalactualobservation+gate nowrun.

Reactcondensedcheck: directimports/nothirdpartydependencies/noasyncwaterfalls; puretypedmetadata/separateclientview/no newfetchorstore; hooksunconditional/primitiveeffectdeps/refsfortransienttimerownership/listenerscleanup; stable explicitnode rendering/plaintextescape/actualbuttonsemantics; scopedkeyboard/ARIAwiredandtested; TypeScriptnocastsinproductiontransport. CSSMaster-sizingMinorstilldeferred/nativeappearanceunaccepted.

Read-onlynextinventorycomplete:82actualstatus-presence nodes across17statusIDs (57groupRequirements,25effectconditions), individuallystoredinlinked-next-requirement-inventory.json. NextbrieftracesbothglobalRequirementsandeffectconditions; no newsourceeditduringgate. Freshmain29506e29 andbackup4f2f5f72 unchanged1656.


## Final linked-reference checkpoint verification
# Ground/Airborne typed reference foundation — verified checkpoint

This bounded Task15 cohort adds six explicit reference identities: Frozen Ground, Steam, Airborne, Rooted, Slow and Fire. Three actual canonical Ground/Airborne effects and the Steam-lifetime detail carry typed text nodes. Existing description strings remain the contract; tagged templates construct references deliberately. The shared definition/report readers and native Basic information consumer render compact explanation triggers. Other terms, noncanonical/legacy prose, condition links, complete Manual/live-instance popup integration and complete orange-reference acceptance remain open.

Compact explanations reuse existing native/canonical functions with captured policy context. They never manufacture an active instance’s potency, stacks or duration. Current/old Ground teams, Fire interaction and Airborne rules stay distinct. Steam conversion remains conditional on affected Frozen Ground. Plain leaf bodies bound recursion. Authored explanations retain escaped text and remove matching generated prose metadata even when wording is identical; null entries retain generated fallback. Stale metadata and unsupported identities fall back to escaped plain text. New optional public nodes contain only tag, label and explanation.

Shared desktop/mobile PvE/PvP/spectator popup ownership permits one primary reader plus one opt-in leaf. Sibling explanations replace the leaf, preserving the parent; root replacement/unmount and existing global dismissal release the pair before callbacks, preserving reentrant replacements. Parent/child hover/focus guard close timers; unmount prevents resumed timers. The leaf inherits the inspection layer. Escape/outside interaction belongs to the active leaf; focus returns to its trigger, and clicks inside the parent dismiss only the leaf. Existing custom bindings, disabled battle Tab/ShiftTab, picker controls and artwork are unchanged. Source, pure ownership and controlled-hook callback tests are narrower than real native hover, touch, focus, assistive technology or geometry acceptance. Browser remains unavailable; no install/tunnel retry.

Initial TDD163535488006:11validRED/6GREEN→17GREEN163707444397. Wider163813485943 found4old Steam detail equality assertions rejecting added metadata, with336otherGREEN; the exact label/value remain in metadata-aware assertions, alongside new exact reference checks. One unchanged repeat163921216993 followed a failed scripted edit, preserved and not called a new bug. Corrected340GREEN163941991096;344/41GREEN164017761110 includes16initial new cases. A misplaced client directive was restored before freeze; no broken client boundary is claimed accepted. Initial frozen sourceaed2fb53 passes8400Vitest+7Node164320822544.

One fresh combined review0Critical/1Important/1newMinor; parent accepts. Important: battle Tab policy made reference buttons unreachable from the focused report. ONE C/I wave adds scoped Up/Down/Home/End traversal from the report itself or an explicit reference trigger, a linked screen-reader instruction set before report focus, and actual SSR trigger markers. Enter/Space activation, Tab policy, picker/input controls and modified browser/selection keys stay with their existing authorities. Corrected fixture165103559863 observes9validRED/9GREEN; missing-document fixture164912475822 is not validRED. Same-wave modifier guard165153224759 observes1validRED/8GREEN. Final372tests/43filesGREEN165221721204, webtypes165220823691 and scopedlint165220823959GREEN. Nine new navigation cases bring the total new cases to25. The tests exercise actual component callback/ARIA wiring with controlled hooks and a DOM surface; they do not mount a native browser. No rereview.

New Minor deferred: Master button minimum-height/font rules can enlarge inline reference rows; exact dimensions and functional obstruction are unmeasured. Ten inherited Minors remain unchanged, including ordinary Burn tick-boundary clarity:11total deferred. Sixty-five individually considered/declined behaviors each have a separate parent reason/cost in the checkpoint ledger/rulings. No incidental sizing change.

Final frozen source `3b52fe66e4af6958cde126e38fa36bae0de9bd7b` passes complete root receipt `20261016T165346259198Z`, exit0:8,409Vitest plus7Node checks, formatting, lint, all8package typechecks and both builds. Actual receipt window 2026-10-16T16:53:46.259198+00:00–2026-10-16T16:57:46.585438+00:00. Documentation follows without source changes. Reviewed productionaed2fb53 differs only by the four-file permitted keyboard fix wave.

Fresh final all294 diagnostic165346260794 renders297groups/604effects through named shared readers. All604plain descriptions, all normalized existing report fields and all static visible reader text remain exactly prior. Only3actual records gain reference markup;291other records’ markup remains exact. Eleven explicit nodes span the six IDs. Raw SHA256`84aaea3581d0a962b06ac0cf2174356cb8479165070592882625289de11e46a1`. Pre-review observation164320824454/raw738fa5be25f4b36d9c15737cb1297becb55bba87490462d744f95161680df91f is preserved independently. Optional reference metadata is deliberately excluded only from the existing-field comparison; every node is checked for exact safe fields and supported identity. This is static default-context evidence, not all-tag/editorial/native acceptance.

Native execution, schemas, accepted manifest and all six planner/fixture hashes are unchanged; no new289matrix is claimed for presentation-only work. Original combat Targeting/Move/editable five Basics/Controlled/native controls, full editors/readers/previews/popups, distinct cycles/balance, fresh Owner edits, hosted authority/CAS, Atlas motion and human acceptance remain open before release. Broader Master panels follow combat. High remains sufficient. No hosted write, publication, activation, migration application, merge or deployment.


Verified durable linked-reference checkpoint825625c88e682b1e69c106f20e1f504c1ee1e120; rootf8bbdf56774413ccaa0a53ccdc9af81a1b655809; checkpointsc4c891119c4f236aebc7aa26421c0a753439ff36. All4localexpectedblobSHAs/uploadSHA/treeentrySHAs andfreshgitlsremote verified; main29506e29 unchanged. Source60b9c4a2/tested3b52fe66/reviewedaed2fb53. Final8409Vitest+7NodecompleteGREEN; all294plaincontracts exact; keyboardImportantfixedonewave; MasterSizingMinordeferred11total. No sourcechangesaftertestsexceptverifiedreportdocs. No release. Next82actualtypedstatusrequirementnodes (57global25effect,17IDs) sourceinventory/brief includedinarchive.

## Task15 bounded prerequisite/condition typed reference cohort — BASE60b9c4a2
Brief task15-linked-requirement-next-brief.md read; cleanbranchverified, main29506e29/backup825625c8 unchanged freshlsremote. Inventory82nodes/17IDs (57global/25effect). Existingowner§10/spec/plan/engineering/concurrent/battleauthorities retained. Inline noimplementers; onefreshcombinedreview planned.
TDD170606595884:22missingfeature assertion failures/2existingguardsGREEN (24cases), noimporterrors. Firstimplementation170641410173:32GREEN/2failures — oneincorrect expected modernDrenchedphrase adjusted to existingcanonicalsemanticwording; one latent gameplayStatusName prototype-map fallback returnsObjectfunction for unknown constructor. Localdisplayboundary now returnsidentityunlessactualstring, preservingtruth for unknownIDs. Bothfirsttypecheckfailures testonly optionalindex and targetfixture corrected; no acceptedtypepass claimed. Nativecockpit hunktemporarilyreverted; freshboundary1707307609853validRED; reapplysameconsumerlinks17075304688856GREEN/5files.
Ruling: typedstatus-presence supports only actual17statusIDs; root maps existingrootedidentity, unknownIDs/rawprime/actiontagwords stayplain — semanticidentitycomesfromtree, notwordmatching — costifwrong: additionalexplicitmappingneededfornewstatus.
Ruling: genericperiodicreferencehelp deliberatelydoesnotidentifyfixedvspercentage/livepotency/lifetimefrompresencealone; explainsDoTandpossiblePoisonmovement, directsactiveeffectforcapturedfacts — bothnativeapplicationtypescoexist — costifwrong: usermustinspectapplicationforexacttrigger.
Ruling: elementalreferencesreuse statusPotencyDescription withunavailablepotency andcapturedpolicyflags; nativefixedInitiativerulesretained, no sampled20%Storm orcontaining-Skilloverlapcondition — statuspresenceisnotaneffectapplication — costifwrong: additionalpolicy-specificgenerichelperrequired.
Ruling: unknownconstructorfallbackfixedonlyatsharedwebgameplayStatusNameboundary (typeoflabelguard), no corecombatresolverchange — a validunknownIDmustremainescapedidentity — costifwrong: othercorecallersretainexistingprototypefallbackandneedseparatework.
Inherited11MinorsdeferredincludingMasterinlinebuttonSizing; noincidentalCSSfix. No native/browser/hosted/releaseclaims. Fullgate/review/diagnostic/backup pending.

Frozen prerequisite source67f657239cf978c65a2e29e09753a3b1c360da4d;9files,27newcases. Focused378/43GREEN170822376227; correctedwebtypes170846035237GREEN. Fullrootandall294observationnowrun; onefreshcombinedreviewpackage requirements-combined-review-package.md. No sourceeditsafterfreezeuntilparentgradesreview.

# Single combined prerequisite/condition review — /root/linked_requirements_combined_review
Model gpt-6-astra High, fresh context/fork none. Read-only all9changedfiles BASE60b9c4a2398c915d8b5492fa3ec803feeed96e40→HEAD67f657239cf978c65a2e29e09753a3b1c360da4d; actual shared/full-definition/modifier/nativecockpit/servercaptured/statushelp/popover consumers, boundedbrief/inventory/Owner§10/Task15/16 and plan focus inspected. No tests/services/browser/network/mutations/delegation.

Verdict:0Critical/0Important/0newactionableMinor. Inherited11Minors remain deferred. No basis to reclassify Master inline button sizing. Ready for bounded change subject to root exact-source verification, not Task15/16/native/release closure.

Strengths: references derive only from typedstatuspresence, retainingallany/subjects/negation/nonstatusbranches/effectbinding. Optionalmetadata preservesplaincontract, staleexacttextfallback andoldreportescaping. SharedAbilityParameters/definitions/modifiers/nativecockpit consume; selectedgroupfilter/multiprefix/mixedoldnewreports intact. Authoredproseoverrides independent. Capturedpolicyflagsflowserver/definitioncontexts; no containing-Skilloverlap or inventedperiodic live magnitude/duration. Webstatusname guard preventsprototypefallthroughwithoutwideningregistry.27newcases coveractualdefinitions/17statuses/nested/history/author/stale/nativecomposition.

Reviewer didnot independently repeat supplied378/43orwebtypes;root8436+7andall294mustbeestablishedbyparent. OutermockexposesclosedAboutreaderonly; realnestedreferencecontrols remainreal; demonstratesrenderingnotnativeinteractions.

Declined to judge (individual behaviors, reason):
1.Native hover/keyboard/touch/dismissal/focus restoration — no browser interaction available or authorized.
2.Mobile/long-textgeometry/200%zoom — source/SSR cannot establish physical acceptance.
3.MasterinlinebuttonSizing — inheritedMinor, no newobservedeffect.
4.Other ten inheritedMinors — not reopened byboundeddiff.
5.PublicManualrichreferences — inspectedmanualsummary remainsplain; separateunfinishedwork.
6.Noncanonicallegacyprose/live-instancepopupcompleteness — outsidecohort.
7.Exactstacks/potency/lifetime/periodictriggersingenericpresencehelp — nodecannotidentifyactiveapplication.
8.OldestlegacyStormwithouteffectStackingPolicyVersion1 — unchangedhelperdescribesperapplicationwhileactions-legacy supportsolderfixed20%; noactualcapturedcanonicalprerequisiteusingoldestcombinationestablished; proposedseparatehistoricalaudit, notdemonstratedregression.
9.Prototypefallthroughincoreothercallers — webboundaryonly, broadercorehardeningnot evaluated.
10.Malformedcapture/pending/summonauthority — optionalfields arepresentation; parsers/serializationnotreaudited.
11.Expiry/revocation/selectedcharacter/directRPC — noauthoritypathchange;Task8/16separate.
12.No-inputdamage/payment/eventrepetition/interruptedMove — noexecutionchange,engineacceptancenotrerunbyreviewer.
13.Concurrentpublication/build/claim/recovery/settlement — notransaction/workerchange,concurrencyacceptancenotrerun.
14.Fullrostercycles/AI/balance — presentationreviewdoesnotestablishgameplayacceptance.
15.Hosted/Atlas/human/publication/release — outsideandopen.
16.Exactheadfullsuite/all294completion — ownedbyrootchecks, noinferredcompletion.

Parent disposition follows requirements-review-rulings.md. Reviewer not asked for rereview.

# Parent rulings for the single prerequisite/condition review

Reviewer0C/0I/0newMinor; parentpromotesoldestlegacyStormtoImportant. OneRED→GREENwave, no rereview. EleveninheritedMinorsunchanged/deferred.

1. Ruling: Native hover/keyboard/touch/dismissal/focus restoration — Keep open: source and controlled callback tests establish integration only; no native browser is available. Cost if wrong: A physical interaction defect can remain until native acceptance.

2. Ruling: Mobile/long-text geometry/200% zoom — Keep open: static rendering is not a physical viewport measurement. Cost if wrong: Obstruction or clipping may require later layout work.

3. Ruling: Master inline button sizing — Inherited Minor remains deferred; no measured functional obstruction supports promotion. Cost if wrong: Inline spacing can remain enlarged.

4. Ruling: Rewind prime witness begins at origin — Inherited Minor deferred; no Rewind test or runtime changed. Cost if wrong: Origin-return coverage remains weaker.

5. Ruling: Supporting Shot version pin — Inherited Minor deferred; no capture fixture changed. Cost if wrong: Version drift may escape that fixture.

6. Ruling: Ongoing pair dynamic ID pin — Inherited Minor deferred; no pairing/capture changed. Cost if wrong: The fixture does not pin exact identity.

7. Ruling: Repeated bounded AI route/target discovery — Inherited Minor deferred; no AI route or target code changed. Cost if wrong: Repeated bounded work remains.

8. Ruling: Admission double-prefix provenance — Inherited Minor deferred; no admission labels changed. Cost if wrong: Provenance wording can be redundant.

9. Ruling: Ranged negative preparation direct commit — Inherited Minor deferred; no ranged execution changed. Cost if wrong: The negative witness is narrower than direct-commit acceptance.

10. Ruling: Defense event independent HP reconciliation — Inherited Minor deferred; no defense payoff changed. Cost if wrong: The positive witness does not separately reconcile HP.

11. Ruling: Arsenal labels/history exact values — Inherited Minor deferred; no Arsenal/history source changed. Cost if wrong: Some reader assertions remain label-focused.

12. Ruling: Singular status clock grammar — Inherited Minor deferred; no status clock changed. Cost if wrong: One-duration grammar remains awkward.

13. Ruling: Burn ordinary tick boundary wording — Inherited Minor deferred; no Burn periodic rule changed. Cost if wrong: The ordinary tick boundary remains less discoverable.

14. Ruling: Public Manual rich references — Keep open: plain Manual summaries are not accepted as rich-reference completion. Cost if wrong: Readers do not yet get the full linked-term behavior there.

15. Ruling: Noncanonical legacy prose — Keep open: typed canonical prerequisite references do not imply arbitrary prose conversion. Cost if wrong: Some older sentences remain plain.

16. Ruling: Live-instance popup completeness — Keep open: generic presence links do not replace actual-instance stack/magnitude/readiness display. Cost if wrong: Specific active-effect facts still need full reader acceptance.

17. Ruling: Generic presence stacks/potency/lifetime/periodic triggers — Stand: a presence predicate does not identify a particular fixed or percentage application, so generic help avoids fabricating those facts. Cost if wrong: Users must inspect the active application for its exact values.

18. Ruling: Oldest legacy Storm fixed-vs-stacking context — PROMOTE TO IMPORTANT: new help could claim per-application scaling while the available legacyElemental context also admits fixed20% history. No need to prove one proposed record already has that capture to keep the public explanation truthful. ONE C/I wave makes generic legacy Wet/Conductive help describe common rules without promising a percentage or stacking model. Cost if wrong: Less detailed legacy help until a context can distinguish those historical policies.

19. Ruling: Prototype fallthrough in other core callers — Stand scoped: web display now returns a string or the original ID; broader core hardening is separate and no combat executor changed. Cost if wrong: Other core callers may retain the inherited prototype-name bug.

20. Ruling: Malformed nested captures — Stand scoped: typed validated requirement trees and optional safe presentation nodes remain the boundary; no new parser or hydration authority was added. Cost if wrong: Malformed authority coverage is not freshly re-audited here.

21. Ruling: Pending effects and summon authority — Stand scoped: no pending/summon schema/runtime changed. Cost if wrong: Their broader acceptance remains open.

22. Ruling: Expiry and revocation — Stand scoped: no capabilities or protected operation changed. Cost if wrong: Task8/16 live freshness acceptance remains open.

23. Ruling: Selected-character/direct-RPC authorization — Stand scoped: rendering strings grants no authority; no authorization path changed. Cost if wrong: Hosted authorization acceptance remains open.

24. Ruling: No-input damage/payment/repeated events/interrupted Move — Stand scoped: no execution source changed; root regression suite is distinct from final gameplay acceptance. Cost if wrong: Full timeout/payment/interruption scenarios remain release gates.

25. Ruling: Concurrent publication/build/claim/recovery/settlement — Stand scoped: no transaction, worker or lifecycle source changed. Cost if wrong: Hosted concurrency acceptance remains a separate gate.

26. Ruling: Full roster cycles/AI/balance — Stand scoped: source hashes and existing regression gates protect presentation-only work; no fresh289 is claimed. Cost if wrong: Natural pacing, distinct/full cycles and twelve-round balance remain open.

27. Ruling: Hosted/Atlas/human/publication/release — Keep open: no hosted write or deployment is authorized for this checkpoint. Cost if wrong: The combat release is not live or accepted.

28. Ruling: Exact-head full suite/all294 audit — Parent owns verification: initial frozen67f65723 passes8436+7 at170921209851 and all294 at170922430596. After the ONE fix wave, repeat both on its frozen source before any final success claim. Cost if wrong: Cannot use pre-fix evidence to certify post-fix source.


Initialfrozenroot8436Vitest+7Node/all8types/lint/format/bothbuildsGREEN17092120985117:09→17:13completeoutput;all294diag170922430596/raw6a730459 verified82newnodes/69records/225othermarkupexact. Pre-fixobservation/audit/package-logarchivespreserved. ParentImportantoldestlegacyStorm2validRED24GREEN171332600788. OneCIfixwaveonlytwofiles (resolver+regression); currentfullsuitepending. No rereview.

ONE C/I wave frozenfb7758fdfe13d17df29def6f18542136ff7e8df9; legacyStormgenerichelpfix2validRED171332600788→380/43GREEN171350452955. 29newcases total, expected8438+7root. Onlyresolver+tests differfromreview67f65723; no rereview; no newMinor. Finalexactsourcegate/diagnostic nowrun.

Finalall294diagnostic171448730313GREEN onfb7758fd; raw8a72a75f569dcabfdbbcf7be40cda912675b8dc21da62c713f94726c4bd011f8. Normalizedpriorfields/plainstrings/staticvisibletext exact,82nodesrecord/group/scope/effect/statusmatch,69markupchanges/225identical. No newsourceeditsafterfinalfreeze. Reactcondensedcheck: no newhooks/effects/listeners/network/dependencies; puremetadataanddirectimports, no server-onlyimport; existing actualbutton/ARIA/session/keyboard authorities reused; safe strings andlimitedbranchmapping, no HTMLorfreeformparser, no newprivacydata. Nativeappearance/AT/physicalacceptanceopen. Freshmain29506e29 andbackup825625c8 unchanged17:16, previousremotecommitroottreef8bbdf56reverified.

## Final prerequisite/condition checkpoint verification
# Typed prerequisite and condition references — verified development checkpoint

This bounded Task15 change links 82 actual status-presence references: 57 global prerequisites and 25 individual effect conditions, across 69 proposed records and 17 status IDs. References come directly from typed requirement nodes. Subjects, presence/absence, nested all/any grouping, resource thresholds, event/action/prime predicates and individual effect binding retain their exact existing text. Unknown status IDs and raw ability IDs stay plain; action tags are not inferred as status references.

Optional public `requirementParts` and `conditionParts` contain only strings or tag/label/explanation nodes. Shared characteristic rows, AbilityParameters, full-definition and manual modifier readers consume them. Native Basic cockpit composition preserves selected-group filtering, multiple-group prefixes and mixed old/new captured reports. Native Move Requirements remain N/A. Authored effect-description overrides do not remove independent prerequisite/condition links. Stale reference metadata falls back to the exact escaped captured string. A shared web status-name guard also prevents an unknown `constructor` identity from becoming JavaScript function text; other core callers are outside this fix.

Generic help reuses canonical/native descriptions and captured elemental options, without manufacturing an active application's potency, stacks or lifetime. Containing-Skill elemental damage does not add an overlap condition to generic help. Burn, Poison and Bleed presence does not identify a fixed or percentage application; the help therefore explains their role and leaves exact application facts to inspection. Current Initiative and Storm consumption rules remain available. For legacy Drenched and Conductive, the public context cannot distinguish oldest fixed-bonus history from later per-application history: generic help describes the common Storm and removal/consumption rules without promising either a percentage or a stacking model.

The existing shared one-primary/one-leaf popover and keyboard navigation are reused. Custom bindings, disabled battle Tab/ShiftTab, picker controls and artwork geometry are unchanged. No additional popup system, runtime, schema, manifest, AI or fixture change is included. Desktop/mobile PvE, PvP and spectators share the same presentation authorities. Static rendering and controlled callback tests are narrower than native interaction and physical layout acceptance; those remain open.

## Verification

- Initial TDD `170606595884`: 22 valid missing-feature failures and two existing guards passed. The first implementation exposed a wrong expected Drenched phrase and the pre-existing prototype-name fallback; both are recorded without claiming that failed run passed.
- Native cockpit consumer was removed before its own boundary test: three valid failures `170730760985`, then shared consumer integration passed. Focused checks reached 378 tests in 43 files; web typecheck passed `170846035237`. Earlier type failures were test-only optional indexing and an invalid target fixture, corrected before freezing.
- Initial reviewed source `67f657239cf978c65a2e29e09753a3b1c360da4d` passed the full root gate `170921209851`: 8,436 Vitest plus seven Node checks, all types/lint/format and both builds, complete output. Its all294 observation and hashed package logs are preserved separately.
- One fresh combined review inspected all nine changed files and actual consumers: reviewer found 0 Critical, 0 Important and 0 new actionable Minor. Parent promoted the oldest-legacy-Storm ambiguity to Important by its possible effect on the reader, rather than requiring a demonstrated proposed-record capture. ONE fix wave: two valid failures `171332600788` → 380 focused tests in 43 files GREEN `171350452955`. Only the resolver and its regression file differ from reviewed source. No rereview.
- Final tested source `fb7758fdfe13d17df29def6f18542136ff7e8df9` passes **8,438 Vitest plus seven Node checks**, all eight workspace typechecks, lint, formatting and both builds. Complete direct root receipt `20261016T171447542392Z`: 2026-10-16T17:14:47.542392+00:00 → 2026-10-16T17:19:03.303394+00:00. No root stdout truncation or cached root replay.
- Final diagnostic observes all 294 records, 297 groups and 604 effects. Every prior structured field, plain description and static visible reader string is unchanged. All 82 added references exactly match typed inventory record/group/scope/effect/status; 69 records have added markup and the other 225 are byte-identical. Raw observation SHA256 `8a72a75f569dcabfdbbcf7be40cda912675b8dc21da62c713f94726c4bd011f8`. This is default-context static reader evidence, not a browser or full editorial acceptance claim.
- Accepted roster manifest and six AI/native fixture source hashes are unchanged. No new 289-case matrix is claimed for this presentation-only change; prior complete matrix evidence remains a separate reference.

## Remaining release gates

The live modular foundation, proposed Skill rebalance and original unfinished combat integration remain distinct. Targeting/Move/five editable Basics/Controlled integration, complete controls/editors/readers/previews and native acceptance still precede combat release. Full distinct roster cycles, natural pacing and twelve-round balance, Owner current edits, hosted SQL/CAS, Atlas motion, human acceptance and release gates remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat. Nothing in this checkpoint publishes, activates, applies migrations, merges or deploys. High remains sufficient for routine integration.

Rich Public Manual references, other generated/noncanonical prose, primary tag-label help and complete live-instance stacks/magnitude/duration/readiness remain unfinished. Native browser remains unavailable; no repeated browser install or tunnel was attempted. Next read-only inventory identifies 42 generated cross-status effect packets (25 displacement, three sensory, 14 status), across 42 records; its 62 semantic tag candidates are not a promise of exact textual occurrence count. No implementation of that next cohort is included.

## Deferred minors

All eleven inherited Minors remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI route/target discovery; admission double-prefix provenance; ranged negative preparation direct-commit witness; independent HP reconciliation in defense-positive events; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick boundary wording; Master inline reference-button minimum height/font sizing. No incidental Minor fix is included.

## Rulings I made

Additional implementation rulings:

- Only actual supported status-presence identities link; unknown IDs and raw prime/action words remain plain. Reason: semantic identity comes from the typed tree. Cost if wrong: a new supported status needs explicit mapping.
- Presence help does not choose fixed versus percentage DoT or assign live values. Reason: both application forms coexist. Cost if wrong: the user needs application inspection for exact triggers.
- Elemental help excludes the containing Skill's overlap context. Reason: presence is not an effect application. Cost if wrong: a separate policy-specific generic helper is required.
- The prototype-name fix is scoped to the shared web string boundary. Reason: truthful unknown labels do not require changing combat execution. Cost if wrong: other core callers retain the inherited fallback issue.

Every reviewer set-aside behavior has a separate parent reason/cost disposition below. Eleven inherited findings remain deferred Minors; they are listed individually to avoid dropping one inside the reviewer's grouped carry-forward.

1. Ruling: Native hover/keyboard/touch/dismissal/focus restoration — Keep open: source and controlled callback tests establish integration only; no native browser is available. Cost if wrong: A physical interaction defect can remain until native acceptance.

2. Ruling: Mobile/long-text geometry/200% zoom — Keep open: static rendering is not a physical viewport measurement. Cost if wrong: Obstruction or clipping may require later layout work.

3. Ruling: Master inline button sizing — Inherited Minor remains deferred; no measured functional obstruction supports promotion. Cost if wrong: Inline spacing can remain enlarged.

4. Ruling: Rewind prime witness begins at origin — Inherited Minor deferred; no Rewind test or runtime changed. Cost if wrong: Origin-return coverage remains weaker.

5. Ruling: Supporting Shot version pin — Inherited Minor deferred; no capture fixture changed. Cost if wrong: Version drift may escape that fixture.

6. Ruling: Ongoing pair dynamic ID pin — Inherited Minor deferred; no pairing/capture changed. Cost if wrong: The fixture does not pin exact identity.

7. Ruling: Repeated bounded AI route/target discovery — Inherited Minor deferred; no AI route or target code changed. Cost if wrong: Repeated bounded work remains.

8. Ruling: Admission double-prefix provenance — Inherited Minor deferred; no admission labels changed. Cost if wrong: Provenance wording can be redundant.

9. Ruling: Ranged negative preparation direct commit — Inherited Minor deferred; no ranged execution changed. Cost if wrong: The negative witness is narrower than direct-commit acceptance.

10. Ruling: Defense event independent HP reconciliation — Inherited Minor deferred; no defense payoff changed. Cost if wrong: The positive witness does not separately reconcile HP.

11. Ruling: Arsenal labels/history exact values — Inherited Minor deferred; no Arsenal/history source changed. Cost if wrong: Some reader assertions remain label-focused.

12. Ruling: Singular status clock grammar — Inherited Minor deferred; no status clock changed. Cost if wrong: One-duration grammar remains awkward.

13. Ruling: Burn ordinary tick boundary wording — Inherited Minor deferred; no Burn periodic rule changed. Cost if wrong: The ordinary tick boundary remains less discoverable.

14. Ruling: Public Manual rich references — Keep open: plain Manual summaries are not accepted as rich-reference completion. Cost if wrong: Readers do not yet get the full linked-term behavior there.

15. Ruling: Noncanonical legacy prose — Keep open: typed canonical prerequisite references do not imply arbitrary prose conversion. Cost if wrong: Some older sentences remain plain.

16. Ruling: Live-instance popup completeness — Keep open: generic presence links do not replace actual-instance stack/magnitude/readiness display. Cost if wrong: Specific active-effect facts still need full reader acceptance.

17. Ruling: Generic presence stacks/potency/lifetime/periodic triggers — Stand: a presence predicate does not identify a particular fixed or percentage application, so generic help avoids fabricating those facts. Cost if wrong: Users must inspect the active application for its exact values.

18. Ruling: Oldest legacy Storm fixed-vs-stacking context — PROMOTE TO IMPORTANT: new help could claim per-application scaling while the available legacyElemental context also admits fixed20% history. No need to prove one proposed record already has that capture to keep the public explanation truthful. ONE C/I wave makes generic legacy Wet/Conductive help describe common rules without promising a percentage or stacking model. Cost if wrong: Less detailed legacy help until a context can distinguish those historical policies.

19. Ruling: Prototype fallthrough in other core callers — Stand scoped: web display now returns a string or the original ID; broader core hardening is separate and no combat executor changed. Cost if wrong: Other core callers may retain the inherited prototype-name bug.

20. Ruling: Malformed nested captures — Stand scoped: typed validated requirement trees and optional safe presentation nodes remain the boundary; no new parser or hydration authority was added. Cost if wrong: Malformed authority coverage is not freshly re-audited here.

21. Ruling: Pending effects and summon authority — Stand scoped: no pending/summon schema/runtime changed. Cost if wrong: Their broader acceptance remains open.

22. Ruling: Expiry and revocation — Stand scoped: no capabilities or protected operation changed. Cost if wrong: Task8/16 live freshness acceptance remains open.

23. Ruling: Selected-character/direct-RPC authorization — Stand scoped: rendering strings grants no authority; no authorization path changed. Cost if wrong: Hosted authorization acceptance remains open.

24. Ruling: No-input damage/payment/repeated events/interrupted Move — Stand scoped: no execution source changed; root regression suite is distinct from final gameplay acceptance. Cost if wrong: Full timeout/payment/interruption scenarios remain release gates.

25. Ruling: Concurrent publication/build/claim/recovery/settlement — Stand scoped: no transaction, worker or lifecycle source changed. Cost if wrong: Hosted concurrency acceptance remains a separate gate.

26. Ruling: Full roster cycles/AI/balance — Stand scoped: source hashes and existing regression gates protect presentation-only work; no fresh289 is claimed. Cost if wrong: Natural pacing, distinct/full cycles and twelve-round balance remain open.

27. Ruling: Hosted/Atlas/human/publication/release — Keep open: no hosted write or deployment is authorized for this checkpoint. Cost if wrong: The combat release is not live or accepted.

28. Ruling: Exact-head full suite/all294 audit — Parent owns verification: initial frozen67f65723 passes8436+7 at170921209851 and all294 at170922430596. After the ONE fix wave, repeat both on its frozen source before any final success claim. Cost if wrong: Cannot use pre-fix evidence to certify post-fix source.




Durable prerequisite/condition checkpoint0b81f2d0ac53f6d508e3a0f467192250a4cc7a6d; root5c0b1706bc735b86709c0b20567d5202695da154; checkpoints4e992f16a0bd181aa57e8ea39568d34cd922660a. All4localexpectedblobSHA/uploadSHA/remoteentrySHA plusfreshlsremote verified; main29506e29 unchanged. Source5d4dd27125a69d76dff0d2f0c522fb10b106eaf3/testedfb7758fdfe13d17df29def6f18542136ff7e8df9/reviewed67f657239cf978c65a2e29e09753a3b1c360da4d. Final8438Vitest+7Node/all8types/lint/format/bothbuilds completeGREEN171447542392. All294plaincontracts preserved,82nodesexacttypedbinding. OneparentImportantfixedonewave/no rereview;11inheritedMinorsdeferred. No newlive release. Nextcrossstatusinventory42effects/42records andbrief preserved; no nextsourceeditsyet.

## Task15 bounded generated cross-status references — BASE5d4dd271
User17:21UTCasks ETA/continue. Provisionalcombat/rebalance testingrelease16–30activeworkinghours/roughly2–4fullworkingdays reiterated withoriginalcombat/nativeacceptance beforelaunch; broaderMasterfollows; Highsufficient. Cleanbranch/previousfull8438+7/durable0b81f2d0 verified; main29506e29/backup0b81f2d0 freshlsremote unchanged. Exactnextbriefread, inventory42effectpackets/42records:25displace,3sensory,10Suppress,4BurnWard. Semantic62candidates become65textualnodes because3Revealparagraphs eachmentionCovert twice. No newreferenceIDs/popups/components/native/AI/schema/manifest/fixtures.
TDD172325770225:9validRED/2existingguardsGREEN; missingtypedmetadata8failures pluscanonicaldescriptiondictionaryconstructorprototypefallthrough1failure; noimporterrors. Minimalimplementation2sourcefiles: displaceRooted/RevealCovert×2 andSuppressBurnPoisonBleed/BurnWardBurn explicitmechanicText templates; exactplainstringsfromfrozenpreceding294observation. Mixedplain/richdescriptionentry keepssingletextsource; own-keyguard preventsinheritedentries.47/3GREEN172401710626 (11newcases); broadfocused/typespending.
Ruling: linkonlyactual supportedcross-statusidentities in knownpayloadbranches, notallwords/capitalizedterms — explicittypedtemplatespreservemeaningandcapture — costifwrong:newunsupportedtermneedsseparateidentity/helpwork.
Ruling: RevealparagraphcontainsCovert twice; annotatebothactualoccurrences, keepReveal/Revealedplainbecauseoutsideexistingregistry — inventorysemanticcountisnottextoccurrencecount — costifwrong:someothertermsremainplainuntilsupported.
Ruling: canonicalstatusdescriptionmapacceptsplainstringsortypedtemplateentries; requireownkeybeforeentryselection — typedentrymustnotacceptObjectprototypefunctionasvalidexplanation — costifwrong:othercorefallbacksretaininheritedprototypeissuesoutsidethiswebhelper.
Ruling: genericleafexplanationsremainplaintext anduseexistingstatusreferencehelpers; donotrecursivelyrendernewdescriptionPartsinsideleaf — preservefinitehelpdepth/capturedfacts — costifwrong:readerscannotfollowthird-levelreferences.
11inheritedMinorsremainunchanged/deferred,includingMasterinlinebuttonSizing. No hostedwrite/publication/activation/migration/merge/deploy. Originalcombat/Task15/16/native/fullcycles/balance/Ownerhosted/Atlas/human/releasegatesOPEN. Sameonecombinedfreshreview/parentreason-costeachdecline/ONECIfixwave/no rereview.

Cross-statusfrozen3b6cd9a84597c40fb48890a903c05dd1445182f0;3files/11newcases.377/42GREEN172409509035/webtypes172409509008GREEN. Wholecohortcombinedreviewandroot8449+7/all294nowrun; no sourceeditsuntilparentdisposition.

# Single combined cross-status review — /root/cross_status_combined_review
Freshgpt-6-astraHigh/forknone; read-only complete3-file BASE5d4dd27125a69d76dff0d2f0c522fb10b106eaf3→HEAD3b6cd9a84597c40fb48890a903c05dd1445182f0. Boundedbrief/inventory/Owner§10/planfocus/ledger andactualreport/reader/capture/resolver/popoverpaths inspected. No suites/services/browser/network/mutations/delegation.

Verdict0Critical/0Important/1newMinor. Existing11Minorsdeferred. NoCIfixrequested. Parentexactheadroot8449+7/all294notestablishedbyreviewer. Readyforboundedimplementationonlysubjecttorootverification, notTask15/16/native/merge/deploy/releaseauthorization.

Strengths: typedpayloadtemplates preserveexactsentence/recipient/value/timing/conditionmetadata. Inventory42packets/42records→65nodes Rooted25/Covert6/Burn14/Poison10/Bleed10; sensoryCovertbothoccurrencescovered. Existingreport→resolver→view→popover reused; no newidentity/popup/clientinteraction/schema/native/AI. Capturedcontextsremainfromimmutableencounterpolicy. Genericperiodichelpdoesnotinventvalues/durations/stacking. Authoredoverride/staleescapedfallback/plainleafdepth intact. Ownpropertyguardrejectsprototypeconstructor. Testscoverfourbranches/wrappers/neighbors/history/authored/stale/prototype.

NewMinor: linked-cross-status-references.test.tsx54–56,72 capturesdefinitionbefore butreportFor(id)parsesanotherdefinition; finalcomparisondoesnotobservedirectreportinputmutation. No demonstratedruntime mutation orcurrentreaderdefect. Suggestedlater sameobjectpassedtoabilityBehaviorInformation. ParentacceptsMinor/deferred; no incidentalfix. Total12Minors.

Declined to judge (separate behaviors/reasons):
1.Nativehover/keyboard/touch/dismissal/focusrestoration — source/SSRnotnativeacceptance.
2.Longtext/mobile/200%zoom — no physicalviewport/layoutsourcechange.
3.MasterinlinebuttonSizing — inheritedMinor/no new measuredobstruction.
4.Singularelementalclockgrammar — inheritedunchangedclockissue.
5.Burnordinarytickboundarydiscoverability — inheritedgenericapplication-neutralwording.
6.Reveal/Revealed/Cleanse/Dispel/unsupportedtermlinks — outsideexistingregistryaddition, plainnotcalledcomplete.
7.Noncanonicalhistory/plainnativeBasic/summonwording — branchesunchanged.
8.PublicManualrichcompleteness — existingplain-summarynotconvertedbythischange.
9.Exactliveinstancestacks/magnitude/duration/readiness — genericreferencesdon'tidentifyapplication.
10.Thirdlevellinksinsideleaf — existingplaintextleafpolicyintentionallyboundsnesting.
11.Othercoreprototypecallers — webdictionaryguardonly; broadercallersnotreaudited.
12.Malformedcapture/pending/summonauthority/privateaccuracy — safeoptionalpresentationmetadata,noparser/capture/serializationchange.
13.Expiry/revocation/selectedcharacter/directRPC — nocapability/protectedpathchange.
14.Noinputdamage/freeprime/duplicatepayment/events/interruptedMove — textinspected,executionunchanged/notindependentlyreplayed.
15.Concurrentpublication/build/claim/recovery/settlement — notransaction/worker/lifecyclechange.
16.Fullcycles/AI/naturalpacing/twelveroundbalance — presentationnotgameplayacceptance.
17.HostedOwner/Atlas/human/release — nohosted/nativeevidence,open.
18.Exactheadroot/all294success — ownedbyparent, noinference.

Parentdispositions in cross-status-review-rulings.md. No rereview.

# Parent rulings for the single cross-status review

Reviewer0C/0I/1newMinor; parentacceptsgrades. NoCIfixwaveor rereview. NewtestinputimmutabilityMinorjoins11inherited, total12deferred.

1. Ruling: Native interaction — Keep open: unchanged shared interaction code and controlled callbacks do not establish browser hover, focus, touch or dismissal acceptance. Cost if wrong: An interaction defect can remain until native acceptance.

2. Ruling: Long-text/mobile/200% zoom geometry — Keep open: static SSR does not measure physical geometry; layout source is unchanged. Cost if wrong: Clipping or obstruction may require later work.

3. Ruling: Master inline reference-button sizing — Inherited Minor remains deferred; no measured obstruction supports promotion. Cost if wrong: Enlarged inline spacing can remain.

4. Ruling: Singular elemental clock grammar — Inherited Minor remains deferred; no clock source changed. Cost if wrong: One-duration grammar stays awkward.

5. Ruling: Burn ordinary tick-boundary wording — Inherited Minor remains deferred; adding links does not resolve that application-neutral wording. Cost if wrong: The exact ordinary tick boundary remains less discoverable.

6. Ruling: Unsupported Reveal/Revealed/Cleanse/Dispel and other terms — Stand scoped: only five existing identities are newly referenced; plain unsupported terms are not advertised as linked. Cost if wrong: Separate explicit identity/help integration is still needed.

7. Ruling: Noncanonical historical prose — Keep open: existing noncanonical branches remain plain and are not inferred from words. Cost if wrong: Older sentences may lack linked terms.

8. Ruling: Plain native Basic and summon wording — Keep open: this bounded canonical template addition does not certify every native fallback. Cost if wrong: Those readers still need separate review.

9. Ruling: Public Manual rich references — Keep open: an existing plain-summary reader is not converted by metadata alone. Cost if wrong: Manual readers still lack complete linked behavior.

10. Ruling: Live-instance stacks/magnitude/lifetime/readiness — Keep open: generic references cannot identify a specific active application. Read-only next notes prioritize actual-instance reader integration. Cost if wrong: Specific combined values and remaining lifetimes remain acceptance work.

11. Ruling: Third-level references inside compact help — Stand: leaf bodies stay plain to preserve finite nesting and usable dismissal. Cost if wrong: A reader cannot follow another link inside the leaf.

12. Ruling: Prototype-name behavior in other core callers — Stand scoped: the canonical web dictionary now rejects inherited entries; no broader core-hardening claim. Cost if wrong: Other callers may retain inherited fallthrough.

13. Ruling: Malformed nested/captured/pending/summon authority — Stand scoped: source adds optional public strings/tag nodes, without replacing validation/capture/serialization. Cost if wrong: Broader malformed-data acceptance remains open.

14. Ruling: Private-accuracy enforcement — Stand scoped: no private state or accuracy is added to nodes; existing viewer projection remains authority. Cost if wrong: Full privacy acceptance is not re-audited by this presentation change.

15. Ruling: Expiry/revocation and selected-character/direct-RPC authorization — Stand scoped: no capability or protected operation changes. Cost if wrong: Task8/16 hosted authorization acceptance remains open.

16. Ruling: No-input/free-prime/duplicate-payment/events/interrupted Move execution — Stand scoped: timing text is verified, execution source is unchanged; root regressions are distinct from final gameplay acceptance. Cost if wrong: Full timeout/payment/interruption scenarios remain release gates.

17. Ruling: Concurrent publication/build/claim/recovery/settlement — Stand scoped: no lifecycle, transaction or worker change. Cost if wrong: Hosted concurrency acceptance remains separate.

18. Ruling: Full roster cycles/AI/natural pacing/twelve-round balance — Stand scoped: six source-hash guards and root regressions protect presentation-only work; no new289 is claimed. Cost if wrong: Natural pacing and distinct/full cycles/balance remain open.

19. Ruling: Hosted Owner reconciliation/Atlas motion/human/release — Keep open: no hosted write, migration, publication, activation, merge or deploy is included. Cost if wrong: The combat update remains unreleased.

20. Ruling: Exact-head root suite/all294 completion — Parent owns verification: all294 already passes172516171916 with65nodes/42packets/252othermarkup unchanged; exact-source full8449+7 still must complete before final claim. Cost if wrong: Static evidence alone cannot certify all checks.


Final: minor (deferred): cross-status immutability assertion compares a different parsed definition from directreportgenerationinput; no proven runtime mutation. Future regressionguard weaker, no current reader defect. Total12Minors; noCIfix/norereview.

## Final generated cross-status checkpoint verification
# Generated cross-status references — verified development checkpoint

This bounded Task15 change adds **65 explicit references in 42 effect packets across 42 proposed records**: Rooted 25, Covert 6, Burn 14, Poison 10 and Bleed 10. Displacement links Rooted; Reveal links both actual Covert mentions; Suppress links Burn/Poison/Bleed; Burn Ward links Burn. Known typed payload branches author the reference templates. There is no keyword replacement or new reference identity.

Existing English, recipients, values, meaningful conditions and timing remain unchanged. Plain descriptions and typed parts come from one template source. The canonical status description table now supports plain strings and typed templates, with an own-property guard so a status named `constructor` cannot become a JavaScript function description. This guard applies to this web dictionary, without claiming broader core fallback hardening.

The existing report → resolver → text view → shared popover path carries the metadata through full definitions, shared readers, manual modifiers and native Basic information. Existing captured policy context, selected-group binding, authored overrides and stale escaped-text fallback remain intact. Delayed and Controlled appendages retain their exact text. Generic referenced explanations stay plain leaf bodies, preserving finite help depth and avoiding invented active-application magnitudes or durations. No client interaction, CSS, geometry, popup system, combat runtime, schema, manifest, AI or native fixture change is included.

## Verification

- TDD `172325770225`: nine valid failures (eight missing-reference assertions and the inherited prototype-entry fallthrough) plus two existing guards GREEN; no import failure. Corrected implementation passes 47 tests in three files `172401710626`, then 377 focused tests in 42 files `172409509035`. Web typecheck GREEN `172409509008`. Eleven new cases.
- One fresh read-only combined review inspected all three changed files and actual consumers/capture helpers: **0 Critical, 0 Important, 1 new Minor**. Parent accepts those grades. No C/I repair wave and no rereview. The new Minor is a test weakness: the direct report call parses a second definition, so one immutability assertion does not observe that direct input. No runtime mutation or reader defect was demonstrated. It joins eleven inherited deferred Minors; total twelve.
- Reviewed and tested source `3b6cd9a84597c40fb48890a903c05dd1445182f0` passes **8,449 Vitest plus seven Node checks**, all eight workspace typechecks, lint, formatting and both builds. Complete direct root receipt `20261016T172514961761Z`: 2026-10-16T17:25:14.961761+00:00 → 2026-10-16T17:29:11.625716+00:00. No root stdout truncation or cached root replay.
- Diagnostic `172516171916` observes all 294 records, 297 groups and 604 effects. Every prior structured field, plain description, static visible reader string and existing reference field is exact. Only the 42 intended packets gain explanation metadata; all 65 nodes match exact inventory record/group/effect/occurrence expectations. Forty-two records gain markup; the other 252 are byte-identical. Raw observation SHA256 `08b4ee8401a5c53e855eeb4209ff2feaab29950bb6f86055225569ffeb5a5f4b`. This is default-context static named-reader evidence, not native interaction or full editorial acceptance.
- Accepted manifest and six AI/native fixture source hashes remain unchanged. No new 289-case matrix is claimed for presentation-only work; prior complete gameplay evidence remains a separate reference.

## Release scope and next work

The live modular foundation, proposed Skill rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled integration, complete controls/editors/readers/previews and native acceptance must finish before combat release. Full distinct roster cycles, natural pacing and twelve-round balance, Owner current edits, hosted SQL/CAS, Atlas motion, human and release gates remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat. This checkpoint publishes, activates, applies migrations, merges and deploys nothing. High remains sufficient for routine integration.

Next is actual active-effect reader integration, with captured stacks, current combined strength, remaining lifetime and readiness. Read-only notes trace the shared `BattleCombatantEffects`/`describeBattleEffect` path and the separately mounted legacy `BattleStatusEffectAssist`; its actual trigger coverage and captured facts must be traced before a fix is designed. Existing native popovers are not accepted merely because a legacy assist exists. No next-cohort source edits are included here. Public Manual rich references, other generated/noncanonical prose, remaining elemental/removal references and complete native acceptance remain unfinished. No repeated browser install or tunnel attempt was made.

The provisional combat/rebalance testing-release estimate remains 16–30 active working hours, roughly 2–4 full working days, subject to final integration/acceptance findings; this is not a calendar launch promise.

## Deferred minors

All eleven inherited Minors remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI route/target discovery; admission double-prefix provenance; ranged negative preparation direct-commit witness; independent HP reconciliation in defense-positive events; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button minimum height/font sizing. New twelfth Minor: one cross-status immutability assertion compares a different parsed definition from the direct report-generation input. No incidental Minor fix is included.

## Rulings I made

Implementation rulings:

- Only supported identities in actual payload branches gain links. Reason: words and capitalization do not establish semantic identity. Cost if wrong: a newly supported term needs separate explicit identity/help work.
- Both Covert occurrences link; Reveal/Revealed remain plain. Reason: the inventory's 62 semantic candidates represent 65 actual textual occurrences, and unsupported identities must not be invented. Cost if wrong: other terms remain plain until supported.
- The mixed plain/rich status dictionary requires an own key. Reason: Object prototype functions are not descriptions. Cost if wrong: untouched core fallbacks may retain their inherited prototype issues.
- Generic compact help remains a plain leaf. Reason: nesting depth and touch dismissal must stay usable. Cost if wrong: readers cannot follow third-level references.

Every reviewer set-aside behavior receives a separate parent disposition with reason and cost below.

1. Ruling: Native interaction — Keep open: unchanged shared interaction code and controlled callbacks do not establish browser hover, focus, touch or dismissal acceptance. Cost if wrong: An interaction defect can remain until native acceptance.

2. Ruling: Long-text/mobile/200% zoom geometry — Keep open: static SSR does not measure physical geometry; layout source is unchanged. Cost if wrong: Clipping or obstruction may require later work.

3. Ruling: Master inline reference-button sizing — Inherited Minor remains deferred; no measured obstruction supports promotion. Cost if wrong: Enlarged inline spacing can remain.

4. Ruling: Singular elemental clock grammar — Inherited Minor remains deferred; no clock source changed. Cost if wrong: One-duration grammar stays awkward.

5. Ruling: Burn ordinary tick-boundary wording — Inherited Minor remains deferred; adding links does not resolve that application-neutral wording. Cost if wrong: The exact ordinary tick boundary remains less discoverable.

6. Ruling: Unsupported Reveal/Revealed/Cleanse/Dispel and other terms — Stand scoped: only five existing identities are newly referenced; plain unsupported terms are not advertised as linked. Cost if wrong: Separate explicit identity/help integration is still needed.

7. Ruling: Noncanonical historical prose — Keep open: existing noncanonical branches remain plain and are not inferred from words. Cost if wrong: Older sentences may lack linked terms.

8. Ruling: Plain native Basic and summon wording — Keep open: this bounded canonical template addition does not certify every native fallback. Cost if wrong: Those readers still need separate review.

9. Ruling: Public Manual rich references — Keep open: an existing plain-summary reader is not converted by metadata alone. Cost if wrong: Manual readers still lack complete linked behavior.

10. Ruling: Live-instance stacks/magnitude/lifetime/readiness — Keep open: generic references cannot identify a specific active application. Read-only next notes prioritize actual-instance reader integration. Cost if wrong: Specific combined values and remaining lifetimes remain acceptance work.

11. Ruling: Third-level references inside compact help — Stand: leaf bodies stay plain to preserve finite nesting and usable dismissal. Cost if wrong: A reader cannot follow another link inside the leaf.

12. Ruling: Prototype-name behavior in other core callers — Stand scoped: the canonical web dictionary now rejects inherited entries; no broader core-hardening claim. Cost if wrong: Other callers may retain inherited fallthrough.

13. Ruling: Malformed nested/captured/pending/summon authority — Stand scoped: source adds optional public strings/tag nodes, without replacing validation/capture/serialization. Cost if wrong: Broader malformed-data acceptance remains open.

14. Ruling: Private-accuracy enforcement — Stand scoped: no private state or accuracy is added to nodes; existing viewer projection remains authority. Cost if wrong: Full privacy acceptance is not re-audited by this presentation change.

15. Ruling: Expiry/revocation and selected-character/direct-RPC authorization — Stand scoped: no capability or protected operation changes. Cost if wrong: Task8/16 hosted authorization acceptance remains open.

16. Ruling: No-input/free-prime/duplicate-payment/events/interrupted Move execution — Stand scoped: timing text is verified, execution source is unchanged; root regressions are distinct from final gameplay acceptance. Cost if wrong: Full timeout/payment/interruption scenarios remain release gates.

17. Ruling: Concurrent publication/build/claim/recovery/settlement — Stand scoped: no lifecycle, transaction or worker change. Cost if wrong: Hosted concurrency acceptance remains separate.

18. Ruling: Full roster cycles/AI/natural pacing/twelve-round balance — Stand scoped: six source-hash guards and root regressions protect presentation-only work; no new289 is claimed. Cost if wrong: Natural pacing and distinct/full cycles/balance remain open.

19. Ruling: Hosted Owner reconciliation/Atlas motion/human/release — Keep open: no hosted write, migration, publication, activation, merge or deploy is included. Cost if wrong: The combat update remains unreleased.

20. Ruling: Exact-head root suite/all294 completion — Parent owns verification: all294 already passes172516171916 with65nodes/42packets/252othermarkup unchanged; exact-source full8449+7 still must complete before final claim. Cost if wrong: Static evidence alone cannot certify all checks.




Durable cross-status checkpoint3736ca45b386cc995d2f0dc9b82812c788b1bf94; rootb4e4db3561f417d77fc632df0ddc42c726ee2253; checkpoints1174fe47d417e3fbdeb4e4ad197fb06043e06f56. All4local/upload/remoteentryblobSHAs andfreshlsremote verified; main29506e29 unchanged. Source54a1ab343cac44d7d346c2c1fee052551e0679a1/testedreviewed3b6cd9a84597c40fb48890a903c05dd1445182f0; final8449Vitest+7NodecompleteGREEN172514961761. All294plainfields/oldreferences/text exact;65newnodes/42packets; onecombinedreview0C0I1newMinordeferred,12total,20parentdispositions. No release. Nextoriginalcombatliveeffectreaderread-onlytrace, no nextsourceedit.

Read-only actualsurface trace afterdurablecheckpoint: desktop-battle-combatant-inspect activeeffects renders plainbuttons with capturedlabels/stacks/duration; mobile-battle-combatant-popup andpvp-battle-inspect-popup renderli withstrong/small; pvp-desktop-parity renders plainstatusbuttons; pvp-battle-combatant-panels renders b withstaticDefenseless2.5×title. These matchlegacyassistselectors, unlike newerBattleCombatantEffects which usesnativeBattleInfoPopover+describeBattleEffect. BattleLogFeed isseparatehistoricalsegmentmetadata withtext-derivedeffectnames/duration; do nottreatthat asfullinstanceorborrowcurrentdictionaryrules. All5livelegacy surfaces canaccessBattleSessionView snapshotstatuses (localCombatStatus aliasesarenativepublicsnapshotrows), ratherthanneedingDOMtextinference. Fullprojection/privatefacts/policyfieldsstillmustbetracedbeforeimplementation.
ExistingdescribeBattleEffect alreadyhas terrainwhile-elevated, percentageDotcapturedHP/nexttick, blindside/airborne/elemental/healingpolicy, pendingactivationround, recoveryapplications andround/battle/instant/until-spent/until-removed/historicalturnlifetimes. ExistingaggregateBattleStatusStacksgroupkeypreservesstatus/version/timing/activation/duration/potency/applicationModifiers/DoTfacts andsource-scopedMarksource; preserveit. ExistingEffectModifierscontainsperapplicationdamagemodifierdisplayontrigger, notbyitselfcurrentcombinedmagnitudepopupacceptance. Existingpublicsummaryhelpershaveactualcombinedincomingdamagearithmetic; tracealignmentwithnativeoperatorsbeforeusingforothercategories. No codechanged duringtrace; no broadpopupcompletion/nativeacceptanceclaim.

# Live-effect implementation and verification notes
BASE54a1ab343cac44d7d346c2c1fee052551e0679a1. Initial frozen10adca11d86a3e02cda989857199f92680199225.16source/test/stylefiles;24newcases. Onefreshcombinedreview/parentindividualreason-costdeclines/ONECIfixwave/no rereview;12inheritedMinorsdeferred.

Originalcombat/Owner§10/Task15inline. Previous8449+7/full294/durable3736ca45 verified; main29506e29/backup3736ca45 unchanged17:33. Brief task15-live-effect-reader-brief.md written before edits. Sharedactualinstance report/content/popover; compact/full/Allrail plus5legacydesktop/mobilePvE/PvP/spectatorsurfaces. Preservetriggercontents/tones/art;2stylesheetscarryoldchipdeclarationstobutton/transparentinnerrowcontrol. Nativeassistownershipguard; historicalChroniclefallbacknotconverted. Existingnativepopupsession/hover/focus/outside/Escape/noX reused. New referenceTrigger marker follows existing scoped parent navigation; deliberately assess reachability under disabled battleTab and existing inspection modal behavior.

Viewer-onlyeffectStackingPolicyVersion1 nowcarriesimmutableencountercontext, notpersistedstate/engineauthority. OrdinaryoldlegacyignoresheterogeneousapplicationModifiers like engine; currentflag1usesindividualstrengths. ModernWet/Conductive retainindependentelementalpolicy. OldestlegacyStormcommonhelpdoesnotpromiseunsupportedstacking/percentage. Realprojection→reader givescurrent−28% vslegacy−19%; originalinputsameobjectimmutabilityassert. Pendingnotactive; unsupportedcapturedversion/unknownpositional/prototypeidentitytruthfulunavailable. SourceIDs/provenancenotshown; Covert/privacyprojectionstillauthority.
Incoming summary reusesexisting bounded presentation arithmetic; labelled fromthiseffect, notallstatuses/forecastHP. Mixedgroupsdisplayactualapplicationfactswithoutinventedrootdefaultnarrative. Nativepending/recovery/depletion/roundlifetimes retained. VisiblemagnitudeusesexistingorangeCompactEffectSummary. Fullcombinedoutgoing/conditional/othercategories andControlledreadinessnotpresentinstatusrowarenotclaimedfinished.

TDD:
-173645145534 initial5validRED2existingguardsGREEN→34/3GREEN173740111292.
-173842835511 includes2validunknownidentity/terrainRED plusintegrationfixtureerrors.
-173925558144 fourvalidsurfaceRED+3nativeownershipcallbackRED/1legacyguardGREEN+1mobileassetfixtureerror. Do not callall8failuresvalid.
-17401691984544GREEN/1mobileassetfixtureerror. MobilehunkrestoredtoHEAD; validassetfixture;1741215677861validmissingnativecontrolRED4skipped; reapplysamehunk. Testassertions scrubirrelevantembeddedimageURLsonly; noartsourcechange.
-1741057118332validRED scoping/mixeddefault→47/5GREEN174200382890.
-Typefailures174256177267/174335548959 missingcharacterLevelfixture fixedasrealfield; firstnexttypegenexit2withoutdetail174200857678 notclaimedpass. 3unusedimportwarnings removed; cleanlint174356876508.
-825/79GREEN174355643933/types174356857877.
-1746029969002validRED capturedlegacy/profileprojectionflag.174639542750additionaloldestStormRED withsameearlierlegacyfailure.
-174704486617 twofixture-contextfailures: globalcurrentflagkeptlegacyfixturescurrent; correctedflagonlycurrentcases.828/79GREEN174733493913/types174734094615/cleanlint174734082095.
-1748415069911validvisiblemagnitudeRED13GREEN; wireexistingCompactEffectSummary→829/79GREEN174908456606,types174908817005.
24newcases:14reader,5actualcontrolled-stateSSRsurfaces,4actualcallbackownership,1realprojection→reader. Notnative/browser/AT/physicalacceptance.
Reactcondensedcheck: no new fetch/dependencies/waterfalls/statehooks; pureboundedcalculation/directimports/existingclientpopoverboundary; actualbuttons/ARIA-describedbysafeplaintext; finitecontent; existinglistener/observercleanup. TypeScriptclean; originalnativecontrols/custombindings/art retained. Fullgate/all294nowrunning.
No core/native/schema/manifest/AI/fixturechanges; sixhashguardsunchanged; nonew289claimed. No hostedwrite/publication/activation/migration/merge/deploy.

Ruling: incoming summary is scoped to this effect and uses existing summary arithmetic — other statuses/conditions/per-step HP rounding are not a forecast — cost if wrong: other strength categories need their own native operator projection.
Ruling: mixed application groups use actual individual strengths, with no invented aggregate base potency — most recent/root potency cannot describe every application — cost if wrong: long groups need physical geometry inspection.
Ruling: add viewer-only captured stacking context because history otherwise cannot choose the correct existing application handling — never persist or apply a rule change — cost if wrong: other categories may need additional captured policy context.
Ruling: unavailable versions retain recorded identity/counters but do not borrow current rules — supported native versions and verified transient/terrain families only — cost if wrong: future known versions need explicit presentation support.
Ruling: preserve unmigrated historical message fallback, yielding to native owners — log segment names are not actual live-instance capture — cost if wrong: old historical modal/dictionary remains unfinished work.
Ruling: migrate both desktop/mobile PvE/PvP/spectators through shared authority and preserve geometry declarations — native physical acceptance unavailable — cost if wrong: later physical inspection may reveal CSS obstruction.
Fullcontrols/native/allcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. Highsufficient.


## Captured live-effect single combined review and parent repair wave

# Single combined review — frozen 10adca11d86a3e02cda989857199f92680199225
Reviewer /root/live_effect_combined_review, read-only, all16changedfiles and callers. No tests/services/browser/network/mutations/subagents. Verdict: with fixes. 0Critical,5Important,1newMinor. Supplied829/79/typechecks green; final root not established by review. Parent later observed root175035629955 exit1:10percentage-dot fixture comparisons omit new public stacking flag,4081webtests pass.

I1 Important: live effect buttons have no reachable keyboard entry under globally blocked Tab. referenceTrigger only participates within an already open information panel; rails and legacy inspection have no owning panel/focus/navigation. Need discoverable entry, scoped navigation, modal focus and return, actual registered guard/handlers tests, custom combat bindings preserved.
I2 Important: three inspection sections declare aria-modal but child effects portal to document.body outside their subtree. layer changes position only; nested finds no reader context. Need modal-owned portal host, topmost Escape and trigger return, actual portal target/control tests. Native/AT remains open.
I3 Important: {...effect,...application} inherits root latest potency when application omitted optional property. Native defaultGuard then20% leaves root20%,firstapplicationpotencyabsent; firstdescriptionwrong20%, correctcombined−32%. Explicitly overwrite optional potency/blindside modifiers, actual capture→publicprojection→reader/immutability test.
I4 Important: pending/current captured DoT profile says displayed percentage but omits available percentage/decay progression. PendingBurn30%/10pointdecay/3ticks lacks30→20→10; active addsHP but not profile. Show capturedprofile/stage/remainingsequence, no guessedpendingHP, realpending/activeBurn/Poison/Bleed/historytests.
I5 Important: migrated surrounding summaries/raw EffectModifiers ignore captured stacking policy, reportinglegacy−28% vs popup−19%. Mobile/PvP duration helper reportsBarrier1turn instead ofUntildepleted; round/recoverylabels similarlywrong. Share captured policy/lifetime interpretation for visible chips/summaries; actual visiblemarkup tests acrosssurfaces.
M1 Minor: legacy keys statusId:version or statusId:source collide for separately captured same-status groups, now owning popupstate. Static collision established; mounted reconciliation failure not executed. Ledger,13totalMinors; no incidental fix.

Reviewer strengths: shared realreport and fivelegacysurfaces, viewer-only capturedflag, pending summary suppression, unknownversiontruthfulness, privacy, nativeassistownershipguard, actualcontrolledcomponents/callbacks/projection tests. No new execution/persistence/schema mutation found.
Reviewer declined behaviors are individually dispositioned in live-effect-review-rulings.md. Full raw finding descriptions remain in the reviewer final conversation message; this durable record preserves every issue, reproduction, impact and required repair boundary.


# Parent disposition — one repair wave, no rereview
Accept I1–I5 Important as concrete user defects, not deferred native acceptance. Accept parent I6: root fixture equality failure caused by new viewerflag. Repair all six in one RED→GREEN wave. M1 remainsMinor/deferred,13total. No implementer or secondreview. Source frozen10ad untilthisdisposition.

I1 design: shared information-only Ctrl+Alt+E entry (combat custom bindings support code+Shift only), visible discoverable Effects heading help plus main accessible instruction, scoped arrows/Home/End among actual instance controls, Escape returns to origin. Install with existing shared battle Tab guard used playable/spectator, before combat listeners; leave textentry/unrelateddialogs/modifiers/pickers/nativeEnterSpace untouched. Inspection owns initial focus and returns it. No combat command or configured binding replaced.
I2 design: shared inspection section owns portal host context and focus boundary; effect portal renders inside actual modal section. Existing session and topmost Escape retained, no second popup framework.
I3 design: overwrite optional application potency/blindside fields even when absent; captured defaults remain defaults rather than latest root fields.
I4 design: captured profile percentage/progression from actual stage/remainingticks, public pending profile retained; unknown futureHP unavailable. No roster defaults.
I5 design: shared policy normalization for summaries plus existing full lifetime reader for visible duration labels; preserve geometry/classes.
I6 design: bring independent percentageDot presentation fixture into parity with public viewer-only stacking context, retain equality guard and kernelauthority immutability. No engine fixture behavior change.

## Every declined behavior: parent ruling, reason and cost
1. Incoming rate versus exactHP forecast: stand scoped; reuses bounded rate, notperhitrounding/pierce/otherstatuses. Cost: exact forecasts remain separate.
2. Combinedoutgoing: open; isolatedstatusincomingonly. Cost: outgoingoperatorprojection unfinished.
3. Combinedconditionaldamage: open; attacker/recipientconditionsabsent. Cost: contextualstrengthrequiresseparateprojection.
4. Combinednondamagecategories: open; categoryoperatorsdiffer. Cost: completecategorysummariesunfinished.
5. Controlledreadiness: open; wholeactioncontractnotinstatusrow. Cost: Controlledreaderacceptanceremains.
6. RecoveryHP/MPamount: open; countsavailablebutamountnotprojected. Cost: safeamountprojectionrequired.
7. Barrierremainingamount: open; aggregatecombatantbarriernotinstanceauthority. Cost: safeperinstanceprojectionrequired.
8. HistoricalChroniclefallback: retain; lognamesarenotlivecapture. Cost: historicalmodal/dictionaryintegrationunfinished.
9. OldestfixedStormexactpercentage: retainconservativecommonrules; avoidsfalsemodernstacking. Cost: oldestexactmagnitudeunshown.
10. Nativemouse/touch/keyboardacceptance: open; unavailablebrowserisnotpermissiontodeferI1. Cost: actualdeviceverificationstillrequired.
11. ATacceptance: open; repairI2structuralownershipnow. Cost: actualATbehaviorunverified.
12. Longmixedreports/mobile/200%zoom: open; staticCSSnotphysicalproof. Cost: clipping/overflowmayremain.
13. ButtonCSSinheritance: stand; noadditionaldefiniteregressioninreview,geometrytokenspreserved. Cost: physicalsizingunverified.
14. Inspectbackdropdismissesinspection: retainexistingexplicitoutsidecardbehavior. Cost: outsideinspectioncloseswholeinspection,notnewleaf-onlycontract.
15. Unknown/malformedpersistedvalidation: standscoped; existingparserauthorityunchanged. Cost: reader testsdonotreauditmalformedpersistence.
16. Expiry/revocation/CAS/directRPC: openindependentTask8/16authoritygates; nosecuritypathchange. Cost: hostedacceptanceremains.
17. Noinput/duplicatepayment/interruptedMove/origin: open; executionunchanged. Cost: finalgameplayacceptancecannotbeinferred.
18. Publication/build/claim/recovery/settlementconcurrency: open; transactions/workersunchanged. Cost: hostedconcurrencygateremains.
19. Rewindoriginwitness: deferinheritedMinor; noexecutionchange. Cost: witnessdoesnotstartbeforeorigin.
20. SupportingShotversionpin: deferinheritedMinor; unrelatedcaptureassertion. Cost: exactversionpincoverageincomplete.
21. Ongoingpairdynamicidentity: deferinheritedMinor; unrelatedtest. Cost: weakeridentitypin.
22. RepeatedboundedAIroute/targetdiscovery: deferinheritedMinor; noAIchanges. Cost: redundantboundedworkremains.
23. Admissiondoubleprefixprovenance: deferinheritedMinor; presentationcohortunrelated. Cost: duplicateprefixremains.
24. Rangednegativepreparationdirectcommit: deferinheritedMinor; sixAIhashesguarded. Cost: negativewitnessnotdirectcommit.
25. DefensepositiveHPreconciliation: deferinheritedMinor; executionunchanged. Cost: eventassertionsnotindependentHPproof.
26. Arsenalhistoryexactvalues: deferinheritedMinor; historycohortunchanged. Cost: exactlabel/valuecoverageincomplete.
27. Singularstatusclockgrammar: deferinheritedMinor; do notbundleeditorialcleanup. Cost: grammarremains.
28. Burnordinarytickboundarywording: deferinheritedMinor; distinctfromI4availableprofile. Cost: boundarywordingremainsimprecise.
29. Masterinlinereferencebuttonsizing: deferinheritedMinor; otherstylescope. Cost: inlinegeometryacceptanceopen.
30. Cross-statusdirectinputimmutability: deferinheritedMinor; differenttestcohort. Cost: weakerdirectinputwitness.
31. FullTask15/16,balance,Ownerhosted,Atlas/human/release: open; boundedreaderreviewcannotclose. Cost: combatupdateunreleased.
32. NewM1duplicatelegacykeys: deferMinor; staticcollisionwithoutmountedfailure,oneImportantrepairwaveonly. Cost: statefulreconciliationcanmisassociatehistoricalsame-statusinstancesuntilseparatefix.


# Parent ONE Critical/Important repair wave
Reviewed10adca11d86a3e02cda989857199f92680199225→tested20038c54c80f97a4a192dfcd128009759ded77c3. Parent accepts5Important and addsI6rootfixturefailure. Onewave/no rereview/noimplementer. NewM1duplicatelegacyinstancekeysdeferred,13Minorstotal. Fullrulings32separateindividualreason/costentries live-effect-review-rulings.md.

I1: shared information-only Ctrl+Alt+E entry registered alongside Tab guard, existing hook mounted by playablePvE/PvP andspectatorroots. No code+Shift combatbinding is replaced. Nativebuttonfocus, Up/Down/Home/End traversal, existingEnter/Space, topmostpopupEscape thenoriginreturn. Documentbody/disconnectedoriginfallbacktobattlefocusroot. Consumeownedchordevenempty/repeated; no commandfallthrough. Inputs/unrelatedmodals/pickers/browsermodifierspreserved. Mainaccessibleinstructions/nativearia-keyshortcuts andvisibleControlssettingshelp. Inspectorinitialfocusonmodalroot andopenerreturn. No globalskill/command action added.
I2: actualthreeinspectionsectionrefs pass explicitly throughsharedBattleEffectPopover intoexistingBattleInfoPopover portalHost. Optionalhostinheritsforopt-inchildren. RealcreatePortal receivesactualinspectionref, soeffectdialogiswithinthedeclaredmodalsubtree. ExistingdocumentEscape preventDefault/triggerreturn preserveswindowinspectionguard. Oversizedmodal-ownedreportstayinexistingmodalscrollflow, ratherthanabsoluteviewportcoordinatesinsidearelativescrollbox; no newinnerpopupscrollbar. Native/AT/physicaloverflowacceptanceopen.
I3: applicationoptionalpotencyandBlindsideoverrideexplicitlyreplace rootfieldsevenwhenundefined. Realnative defaultGuard→explicit20%capture→viewer→readernow15%/20%/−32%, directoriginalstateimmutable. OmittedBlindsidefieldguardusespublicoptionalshape; currentnativeBlindsidecaptureitselfusuallywritesdefaults, notclaimednativeomissionwitness.
I4: existingidentityhelpernowshowsactualcapturedprofilepercentage andBurnremainingsequencefromstage/lifetime; actualpendingprofilesdonotguessfutureHP. Existingpercentagehelpervalidatessequence; actualactivecapturedHP/nexttickretained. Realpending/activeBurn/Poison/Bleedthroughnativeexecutionandpublicprojection; actualaffected-turnBurntickadvancesstage1andshows20→10/next4HP; currentandhistoricaltriggerruleskept.
I5: sharedcapturedpolicyhelperusedbyreportandallincomingstatussummaries; oldordinaryrowsignorelaterheterogeneousmetadata. Sharedlifetimehelperextractedunchangedfromidentity, usedbyvisibledurationlabels; recoveryapplications/roundboundaries/depletiontruthfularoundexistingchipgeometry. Existingcurrent-summarytestfixtureexplicitlypinscurrentflaginstead ofsilentlyusingcurrentrulesforlegacyshape.
I6: independentpercentageDoTbrowserpresentationfixtureaddsviewer-onlystackingflaglikeproduction;10existingexactprojectionequalitycasespass. No nativecorefixture/kernel/execution/schema/persistence/AI/manifestchange.

## Evidence and honest failure provenance
-175035629955 initialfullrootexit1:10percentage-dotprojectionfixtureequalityfailures,4081otherwebpass. NotGREEN.
-17585416807018failures/15pass includes10existingI6cases plusapplication/DoT/visiblepolicyRED; initialBlindsideexpectationwronglyused20%instead ofactual160%default. Correctedexpectationandseparatedsixpending/activecasesbeforeproductionrepair.
-18001492663811validdatareaderRED/15GREEN: actualnativeGuardinheritance,sixactualDoTphasecases,optionalBlindsideinheritance,elapsed/historicalBurnprofile,legacyvisibleincoming.
-1759125826517validactualsurfaceRED/5GREEN: sixmobile/PvPlifetimecases, desktopincominglegacy.
-18005717394867/5GREEN afterdatarepair,including10fixtureequalitycases.
-1802269477558validinteractionRED/19GREEN: threeidenticallyparametrizedsharedentrylabels,inspectionnavigation,actualportalargument,threeactualinspectionSSRfocusattributes. Thethreeentrylabelsarenotthreeindependentmountedmodeacceptances; sharedhookwiringinbothrootcomponentsisstatictrace.
-180304909867threefocus-testfixtureerrors(useContextdispatcher), notvalidRED. Correctedcontrolledhooks→180339305502threevalidactualinspectionfocusRED.
-18035693424836GREEN/1testcleanupfailure: NodeEventTargetboolean-captureremovalrequiredmatchingoptionsobject, changedtothesamepatternasexistingTabguard.
-18044165400321/3GREEN: sharedregisterednavigationguard, actualthreeinspectionlayoutcallbacks/openerreturn, actualthreecomponent→wrapper→realcreatePortalcontainerInfohost, genericportalargument. RealportalobjectspluscontrolledrefsarenotmountedDOMornative/ATacceptance.
-180529930481operatorcommanderror: nonexistentcheck:typesscript, nottestfailure; correctedtypecheckcommand.
-180603762372webtypesGREEN;180605093752871/83GREEN;180613888205lintcaughtfakeElementthisalias, repairedfixturefocussetter.
-1807546424521validbodyoriginfallbackRED/5GREEN, repaired.
-180828614984872GREEN/1addednativeelapsedBurnfixtureerror: usedtickswithoutdurationTurns;180828615418typecheckcaughtticksnotBurnfield. CorrecteddurationTurns3; thiswasnotnewproductiondefect.
-180828645553lint9refreturn-objectaccesserrorsinthreeinspectcomponents; changedhooktotakeexistingnativeinspectionRefandreturnplaininstructionID. No ref-rule suppression.
-1809000774012validempty/repeatedchordfallthroughRED/6GREEN; sharedentrynowconsumesownedchordbeforeearlyempty/repeatreturns.
-Finalfocused875/83GREEN180937773476;webtypes180937770373GREEN;all23changedTS/TSXfileszero-warninglint180937813314GREEN.60newcasesoverall(24initial+36repair), source34filesoverall. Initialreview16files;repair24fileswithoverlap. Frozen20038c54; full8509Vitest+7Nodeexpected, notclaimedcompleteuntilreceipt.

Reactcondensedcheckafterrepair: singleexistingpopupsession, no clientfetch/dependency/newcommand, hooksunconditionalwithcleanup/directrefprops, actualbuttons/aria-safeplaintext, topmostEscape, finiteleafcontent, bothplayableandspectatorsharedhook, sharedpolicy/lifetimeauthority. Nativekeyboard/AT/physicalgeometryremainopen; no nativeinstallation/tunnelretry.
Fullroot/all294anddurablebackupstillrequired. No hostedwrite/publication/activation/migration/merge/deploy. Highsufficient. Originalcombatcontrols/editors/readers/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN.


## Final captured live-effect checkpoint verification
# Captured live-effect readers — verified development checkpoint

Actual captured effect details now share one report and popup across compact/full/All battle rails and five migrated desktop/mobile PvE, PvP and spectator surfaces. Supported current incoming strength is explicitly scoped to this effect, with actual stacks, captured application strengths and remaining lifetime. Pending effects do not claim active incoming modification. Unsupported versions retain identity and counters with rules unavailable rather than borrowing current rules. No private source identity or execution metadata is shown.

The public viewer adds the encounter's captured stacking-policy flag without changing persistence or execution. Current applications retain their individual strengths; ordinary historical rows retain native whole-row semantics. Default Guard followed by authored 20% now explains 15% and 20%, matching the combined −32% incoming rate. Omitted application-specific fields do not inherit the latest root override. Visible incoming summaries and lifetime labels use the same interpretation as the popup, including recovery applications, round boundaries and Barrier depletion.

Captured DoT profiles now expose actual percentages and Burn's remaining progression from its captured stage and lifetime. Pending Burn 30% with 10-point decay and three ticks shows 30% → 20% → 10% without inventing future HP damage. Active captures retain actual captured HP and next-tick HP; an actual affected-turn tick advances the reader to 20% → 10%. Historical and current special-trigger wording remain distinct.

Keyboard-only information entry uses **Ctrl+Alt+E**, shared by playable and spectator battle roots. Up/Down/Home/End choose actual effect buttons; Enter/Space and the existing popup own opening. Escape closes the report and returns to its trigger, then returns to the prior focus or the battle root. Plain Tab/Shift+Tab stay disabled. Code+Shift custom combat bindings, text fields, pickers and unrelated modal input remain under their existing owners. The information chord is consumed even when repeated or no effect exists. Accessible instructions and visible Controls-settings help describe it.

Three inspection dialogs establish initial focus and restore their opener. Their effect readers portal into the actual inspection section, inside its declared modal boundary. Oversized modal-owned readers use the inspection's existing scroll flow rather than viewport-relative absolute positioning within a relative scroll box. Existing popup ownership, outside dismissal, topmost Escape and no-X effect readers remain shared. Legacy dictionary assist yields to actual native readers; historical Chronicle fallback remains separate unfinished work. Existing chip/art/card geometry tokens are preserved; physical layout acceptance is not claimed.

## Verification and review

- Initial frozen source `10adca11d86a3e02cda989857199f92680199225`: 24 new cases, 829 focused tests in 79 files and web types pass. The first full root check `175035629955` failed ten independent percentage-DoT presentation-fixture equality assertions because that fixture omitted the new public flag; 4,081 other web tests passed. This run is not reported as GREEN.
- One fresh read-only combined review examined all 16 initial changed files and their real consumers: **0 Critical, 5 Important, 1 new Minor**. Parent accepts all five Important findings, adds the fixture mismatch as I6, and repairs them in **one RED→GREEN wave**, without rereview or implementers. The new duplicate-key Minor joins 12 inherited deferred Minors; 13 total.
- The repair covers inaccessible keyboard entry, detached modal portal ownership, root-value inheritance, missing available DoT strength/progression, contradictory visible summaries/lifetimes, and the fixture mismatch. TDD provenance, including invalid fixture attempts and corrected type/lint failures, is retained in `live-effect-repair-notes.md` in the recovery evidence. No failing command is relabelled as passing.
- Final tested source `20038c54c80f97a4a192dfcd128009759ded77c3`: **875 focused tests in 83 files GREEN** (`180937773476`), web typecheck GREEN (`180937770373`), zero-warning scoped lint GREEN (`180937813314`). **60 new cases overall**:24 initial plus 36 repair. The cohort changes 34 web source/test/style files; no core execution or schema file changes.
- Exact tested source passes **8,509 Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds. The fresh full run `181018586167` passed from18:10:18 to18:14:18UTC; its combined stdout omitted the completed build tail, while the preserved web package log contained the full route table. One cached root replay `20261016T181508741424Z` provides the complete final receipt: 2026-10-16T18:15:08.741424+00:00 → 2026-10-16T18:15:40.722466+00:00. No source changed between them. Both audits preserve package log hashes and test summaries.
- Final all 294 diagnostic `181018588403`:294 records, 297 groups, 604 effects. Every named Skill-reader report and HTML string is byte-identical to the previous cross-status checkpoint. Raw observation SHA256 `530f38dcaba1bef3445a017f74d54474e8d7c6845ab9f078c99111151fee5d6c`. Manifest and six AI/native source hashes are unchanged. No fresh 289-case gameplay matrix is claimed for viewer/presentation-only changes.

The automated evidence includes real native capture→viewer→reader cases, actual inspection component trees and layout callbacks, actual registered EventTarget handlers alongside the Tab guard, actual popup Escape callbacks, and real React portal objects with the supplied modal container. Controlled refs, fake elements and SSR are **not mounted DOM, native browser, assistive-technology or physical geometry acceptance**. Three keyboard entry labels invoke the same shared handler; they are not three independently mounted mode flows. Both actual root components use the shared hook. Native acceptance remains required; no repeated browser installation or tunnel attempt was made.

## Remaining release work

The modular foundation already live, proposed Skill rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance must finish before combat release. Other live strength categories, safe recovery/Barrier per-instance amount projection, Controlled whole-action readiness, historical Chronicle readers, public Manual rich references and remaining prose/reference coverage remain open. Distinct/full roster cycles, natural pacing/twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion, human and release gates remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

This development checkpoint publishes, activates, applies migrations, merges and deploys nothing. High remains sufficient for routine integration. The provisional 16–30 active working hour estimate (roughly 2–4 full working days) has not become a calendar launch promise or been mechanically reduced by this checkpoint.

## Deferred Minors

Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status direct-input immutability witness; and new legacy duplicate keys around stateful same-status popup instances. No incidental Minor fix is included.

## Every parent set-aside ruling


1. Incoming rate versus exact HP forecast: retain the scoped rate. Reason: per-hit rounding, Pierce and other effects require the actual forecast. Cost: this summary cannot predict exact HP loss.

2. Combined outgoing damage: leave open. Reason: this cohort implements supported incoming rates only. Cost: outgoing summaries still need their native operator projection.

3. Combined conditional damage: leave open. Reason: attacker and recipient conditions are absent from an isolated status row. Cost: contextual strength needs separate projection.

4. Combined non-damage categories: leave open. Reason: each category has different native operators. Cost: complete category summaries remain unfinished.

5. Controlled readiness: leave open. Reason: readiness belongs to the whole captured action. Cost: Controlled reader acceptance remains required.

6. Recovery HP/MP amounts: leave open. Reason: the public row has counts without its captured amount. Cost: safe amount projection remains necessary.

7. Barrier remaining amount: leave open. Reason: the combatant total does not identify one Barrier instance. Cost: safe per-instance projection remains necessary.

8. Historical Chronicle fallback: retain for now. Reason: a log name does not identify a live capture. Cost: the historical modal and dictionary integration remain unfinished.

9. Oldest fixed Storm percentage: retain conservative common rules. Reason: modern stacking cannot be assumed. Cost: the exact oldest magnitude remains undisplayed.

10. Native mouse/touch/keyboard acceptance: leave open, while fixing I1 now. Reason: native browser access is unavailable. Cost: actual device verification remains required.

11. Assistive-technology acceptance: leave open, while fixing I2 now. Reason: structural ownership can be corrected without claiming AT execution. Cost: actual AT behavior remains unverified.

12. Long mixed reports, mobile geometry and 200% zoom: leave open. Reason: static CSS is not physical evidence. Cost: overflow and clipping still require inspection.

13. Button CSS inheritance: retain the reviewed styles. Reason: review found no additional definite regression and geometry tokens are preserved. Cost: physical sizing remains unverified.

14. Inspection backdrop dismissal: retain the existing outside-card behavior. Reason: this cohort does not redefine inspection dismissal. Cost: clicking outside inspection closes the whole inspection.

15. Unknown or malformed persisted validation: retain the existing parser authority. Reason: this presentation change does not replace validation. Cost: reader tests do not re-audit malformed persistence.

16. Expiry/revocation/CAS and direct RPC access: retain the separate Task8/16 gate. Reason: no security path changes here. Cost: hosted authority acceptance remains required.

17. No input, duplicate payment, interrupted Move and attack origin: retain the gameplay gate. Reason: execution paths are unchanged. Cost: reader tests cannot establish fresh gameplay acceptance.

18. Publication/build/claim/recovery/settlement concurrency: retain its separate gate. Reason: transactions and workers are unchanged. Cost: hosted concurrency acceptance remains required.

19. Rewind witness origin: defer the inherited Minor. Reason: no related execution change belongs in this reader repair. Cost: the witness still starts at the origin.

20. Supporting Shot version pin: defer the inherited Minor. Reason: the unrelated capture assertion is unchanged. Cost: exact version-pin coverage remains incomplete.

21. Ongoing pair dynamic identity: defer the inherited Minor. Reason: the unrelated test is unchanged. Cost: its identity pin remains weaker.

22. Repeated bounded AI discovery: defer the inherited Minor. Reason: no AI code changes here. Cost: redundant bounded discovery remains.

23. Admission double-prefix provenance: defer the inherited Minor. Reason: the admission path is unchanged. Cost: duplicate prefix wording remains.

24. Ranged negative direct-commit witness: defer the inherited Minor. Reason: six guarded AI/native sources are unchanged. Cost: the negative witness remains a preparation check.

25. Defense-positive HP reconciliation: defer the inherited Minor. Reason: execution is unchanged. Cost: event assertions do not independently reconcile HP.

26. Exact Arsenal history values: defer the inherited Minor. Reason: the history cohort is unchanged. Cost: exact label/value coverage remains incomplete.

27. Singular status-clock grammar: defer the inherited Minor. Reason: unrelated editorial cleanup is excluded. Cost: the grammar defect remains.

28. Burn ordinary tick-boundary wording: defer the inherited Minor. Reason: it is distinct from I4’s missing captured profile. Cost: boundary wording remains imprecise.

29. Master inline reference-button sizing: defer the inherited Minor. Reason: these battle styles do not own it. Cost: inline geometry acceptance remains open.

30. Cross-status direct-input immutability: defer the inherited Minor. Reason: it is a different test cohort. Cost: that direct-input witness remains weaker.

31. Full Task15/16, balance, Owner hosted, Atlas, human acceptance and release: leave open. Reason: a bounded reader review cannot close them. Cost: the combat update remains unreleased.

32. New duplicate legacy keys: defer M1 as Minor. Reason: review established a static collision without executing a mounted failure. Cost: same-status expiry/replacement may misassociate popup state until a separate fix.



Durable captured live-effect checkpoint 4533a1f6969a13ab76ec0fa9f7bf28fca14332e5; root 38fabd140b85eb6ea9010ce57f67dde4eabb040b; checkpoints 080acacc21a3ae5df8689c279584d12732390f16. All4 local/upload/remote blob SHAs and fresh ls-remote verified; main29506e29 unchanged. Sourcef9367ece1880896f09ebc20c1818fe7c41823c8b/tested20038c54c80f97a4a192dfcd128009759ded77c3/reviewed10adca11d86a3e02cda989857199f92680199225 (parentONEImportantwave/no rereview). Final8509Vitest+7Node/alltypes/lint/format/bothbuilds GREEN; initialroot181018586167 build-tailstdoutloss and completepackageaudit preserved; ONEcachedcompletefinalroot181508741424. All294reports/HTMLexact;60newcases;13Minorsdeferred;32individualreason/costrulings. Native/AT/geometry/originalcombat/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. Next read-only amount-projection notes; no next source edit yet. No publication/activation/migration/merge/deploy. Highsufficient.

## Task15 live recovery/Barrier amount cohort start
# Task15 live recovery and Barrier amount readers
BASE f9367ece1880896f09ebc20c1818fe7c41823c8b. Previous tested20038c54/full8509+7/all294/review/ONECIwave/durable4533a1f6 verified. Approved originalcombat/Owner§10 reader design, inlinecontinuation; no new subsystem/designapproval needed. Existing isolated agent/overhaul-resume-20261016 branch verifiedclean. Keep13Minorsdeferred includinglegacyduplicatekeys; no implementers/per-recordreviewers. Onefreshcombinedreview at end/parentindividualreason-costdeclines/ONECIfixwave/no rereview.

Bounded design: extend existing ephemeral CombatEffectPresentationStatus in combat-effect-timing.ts with optional typed recovery facts and Barrier facts, populated while the actual native pending/active instance is already in hand. Do not join by index in the web server after filters. No persisted CombatStatusInstance/schema/operator/timing-mode/command/cost/AI/manifest change. BattlePresentedStatus inherits optional fields; production privacy/Covert filtering remains authority.
Recovery facts: resource hp/mp, basis flat or percentage. Flat amountPerApplication is the recorded base before applicable dynamic modifiers. Percentage contains actual percent and optional captured {maximumAtCast,amountPerApplication}, projected field-by-field from the exact recipient capture; never recalculate using current maxHP/statuses. Pending percentage capture missing remains amount-unavailable, actual percent discoverable. Active percentage amount follows native scheduled amountPerTick, with original maximum/percent basis from its capture. All pending/active recovery rows carry actual remaining application counts, including flat schedules. Expose true skip-current-owner-turn-end marker; do not claim next application at an already skipped boundary. Zero captured amount is valid, never treated as absent.
Barrier facts: pending grant requests vs active per-instance remaining pool, never combatant aggregate/current default. Native grant only supports positive amount; no new removal behavior. Current unlimited stacking promises requested gain, historical cap wording says up to requested amount and retains maxHP cap; no future-state forecast. Actual active pools contain their current remaining amount.
Use existing CompactEffectSummary for visible amount and percent/maximum basis rows, same safe plaintext in accessible report; all shared consumers inherit it without changing geometry/session/controls/art. Keep unknown versions unavailable and absent metadata truthful. For equal grouped rows display total plus per-stack value; duration/application count explicitly per stack if grouped. Add recovery/Barrier/skip facts to aggregation key so unlike values and clocks never merge. Existing duplicate component keys remain deferred separately.

RED actual native capture→public projector→visible/shared/accessibility reader: hp/mp percentage pending/active under25%HealingDown gives75HP/15MP from10%ofmax1000/200, unchanged if max/status later differs; flat40base versus actual30modified; Barriergrant35, two unlike independent pools35/12, actual partial absorption leaves17, legacy pending cap; zeroMPmaximum gives0; two recipients independentamounts; missinghistoricalcaptureunavailable; unknownversiondoesnotborrowamount; no mutation/privacy leak; equal/different amounts and skipclocks preserve correct groups; amber magnitude body. Keep actual captures/values hand-derived, no mocks except server-only marker.
Focused core recovery/barrier/timing, web battle/projection/privacy/readers and types/lint; final whole root/all294/hashguards. No fresh289 for pure presentation: sourceoperator/timingmode unchanged; nativecapture tests exercise actual amounts. All294 Skill reports/HTML expected exact. Native/AT/geometry/currentControls/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. No hostedwrite/publication/activation/migration/merge/deploy. Highsufficient.

Ruling: use the existing core presentation projection for optional amount facts — it holds the native instance before recipient/visibility filtering, avoiding an unsafe index join — cost if wrong: broader consumers must tolerate additive ephemeral fields, covered by full root and fixture equality.
Ruling: percentage recovery has a frozen effective amount, flat recovery has a dynamic base — native execution bypasses later modifiers only for captured percentage recovery — cost if wrong: base text cannot promise exact future restoration.
Ruling: group equal facts with totals/per-stack amounts and per-stack application counts; separate unlike values/skip clocks — existing grouping must not silently erase newly exposed facts — cost if wrong: native physical long-list/key-expiry acceptance remains required.

Initial182414565382:15 valid missing-amount/grouping failures,1 unsupported-version guard GREEN,1 Covert fixture error (pending Covert was not concealment). Set explicit instant Covert and valid ally HP before the second RED run. No production source edits yet.

Correction to initial RED count after tracing all errors:182414565382 had14validmissing-amount/grouping failures,2fixture errors (Covertpending and illegalselfdamage),1guardGREEN.182507043887 had18validRED/1illegalselfdamagefixtureerror/2guardsGREEN.182619886524 afterinitialimplementation20GREEN/1samefixtureerror. Fixed partialdepletion fixture by ending actor turn and executing an actual enemy attack; removed only own new Barrier aggregation-key hunk, then182712985512 valid missing-separation RED/20skipped. Restored the same hunk. No selfdamage behavior changed.

Frozen live-amount sourcefec7710a7fc3964b62186ce72085ff1b19beec19;6files/21newcases. Focusedweb896/84GREEN182800332756;core69/3GREEN182800338608;webtypesGREEN182800333707. Rootlintcommand182800339417ignored5webfilesandfailedwarnings(notclean); correctedweb182911224551/core182911228279bothzero-warningGREEN. Reactcondensedcheck: nohooks/fetch/state/dependencies/globalcontrols, directpurehelpers, ephemeral numericwhitelist, existingCompactEffectSummary/onepopup/ARIAplaintext; nativegeometryopen. Brief3initialreason-costrulingsretained. No newnativeexecution/schema/AI/manifestfixturechange. Full8530+7/all294andonecombinedreviewrequired.

# Combined live amount review
Reviewer: /root/live_amount_combined_review, gpt-6-astra High, fresh read-only context.
BASE f9367ece1880896f09ebc20c1818fe7c41823c8b → reviewed fec7710a7fc3964b62186ce72085ff1b19beec19, all six files and actual native/projection/shared/legacy consumers. No tests, mutations, browser or native acceptance by reviewer.
0 Critical, 2 Important, 0 new Minor. Thirteen inherited Minors remain deferred.

I1 Important: aggregateBattleStatusStacks omits recoveryApplications. Two actual pending flat effects amount10/durationTurns0/ticks1 versus3 have equal compatibility counters and amount facts, so merge and retain the first application count. Native execution uses ticks; reverse order overstates the shorter schedule. Include application count in grouping identity; test actual native pending capture→public projection→aggregation→reader.
I2 Important: application counts replace old lifetime text, but affected-turn cadence is only shown for skip-true schedules. Ally recovery outside its turn and self recovery after the skipped boundary show no future tick time; pending schedules omit subsequent cadence. State ordinary affected-turn-end cadence, pending first activation/subsequent cadence and keep skip qualification. Test visible/accessibility with actual native schedules.
Strengths: exact recipient/instance capture, frozen percentage maxima/effective amounts, flat dynamic base, per-instance Barrier depletion/capped historical requests, explicit public field copies, Covert/privacy retained, zero valid, unknown-version unavailable, visible/accessibility sharing.
Parent independently traced pending retained duration/ticks and resolveEndOfTurnRecovery. Both findings accepted Important by player-visible false/incomplete schedule impact. One joint repair wave authorized; no rereview; no gameplay/schema/timing-policy edits.

# Parent review disposition

I1 and I2 accepted Important, one repair wave. No new Minor.

## Every declined behavior: parent ruling, reason and cost

1. Final: Ruling: Exact future HP/MP after caps — Keep recorded base/capture plus missing-resource qualification; future state is not available. Cost if wrong: Actual future restoration is not forecast.

2. Final: Ruling: Combined outgoing damage — Leave the unchanged damage reader for its own bounded cohort. Cost if wrong: Combined outgoing strength remains open.

3. Final: Ruling: Conditional damage — Do not invent absent attacker/recipient context. Cost if wrong: Conditional combined strength remains open.

4. Final: Ruling: Other non-damage strength — Leave separate native categories for subsequent integration. Cost if wrong: Those category readers remain incomplete.

5. Final: Ruling: Controlled readiness — Keep unchanged captured-action ownership. Cost if wrong: Controlled readiness still needs its own acceptance.

6. Final: Ruling: Manual modifiers and controls — Keep unchanged behavior and separate integration gate. Cost if wrong: No fresh control acceptance.

7. Final: Ruling: Historical Chronicle/modal redesign — Keep existing historical caller; current amount extension is additive. Cost if wrong: Historical readers remain unfinished.

8. Final: Ruling: Old fixed Storm magnitude — Retain inherited conservative unavailable handling. Cost if wrong: Old Storm does not gain an invented magnitude.

9. Final: Ruling: Native mouse — Leave acceptance open; browser is unavailable. Cost if wrong: Mouse behavior remains unverified.

10. Final: Ruling: Native touch — Leave acceptance open; browser is unavailable. Cost if wrong: Touch behavior remains unverified.

11. Final: Ruling: Native keyboard/focus — Source tracing is insufficient for mounted acceptance. Cost if wrong: Keyboard/focus still needs native verification.

12. Final: Ruling: Assistive technology — Keep shared accessible strings; no actual AT execution. Cost if wrong: AT acceptance remains open.

13. Final: Ruling: Long reports/small screens/200% zoom — Reuse existing layout and defer physical inspection. Cost if wrong: Clipping and overflow remain unverified.

14. Final: Ruling: Button CSS geometry — No geometry changes in this amount cohort. Cost if wrong: Physical sizing remains unverified.

15. Final: Ruling: Inspection backdrop dismissal — Retain existing outside-card behavior. Cost if wrong: Outside inspection still closes the whole inspection.

16. Final: Ruling: Broader malformed persisted/pending/summon validation — Retain existing parser authority; relevant captures traced. Cost if wrong: No whole-parser re-audit.

17. Final: Ruling: Expiry/revocation/character authority/CAS/direct RPC — Keep separate Task8/16 authority gate. Cost if wrong: Hosted security acceptance remains required.

18. Final: Ruling: No input/duplicate payment/interrupted Move/attack origin — Native execution unchanged. Cost if wrong: Fresh gameplay acceptance remains required.

19. Final: Ruling: Publication/build/claim/recovery/settlement concurrency — Transactions/workers unchanged. Cost if wrong: Hosted concurrency acceptance remains required.

20. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated witness. Cost if wrong: Witness still begins at origin.

21. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; unrelated capture test. Cost if wrong: Version-pin coverage remains incomplete.

22. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Identity witness remains weaker.

23. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

24. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission unchanged. Cost if wrong: Duplicate prefix wording remains.

25. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; guarded native files unchanged. Cost if wrong: Negative witness remains preparation-only.

26. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; execution unchanged. Cost if wrong: Events lack independent HP reconciliation.

27. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact history label/value coverage incomplete.

28. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; unrelated editorial work. Cost if wrong: Grammar defect remains.

29. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; distinct from recovery cadence. Cost if wrong: Burn boundary wording remains imprecise.

30. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry acceptance remains open.

31. Final: Ruling: Cross-status input immutability witness — Keep inherited Minor deferred; different test cohort. Cost if wrong: Its direct-input witness remains weaker.

32. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: static collision but no demonstrated mounted failure; no incidental repair. Cost if wrong: More separate same-status rows may misassociate popup state at expiry/replacement.

33. Final: Ruling: Full roster balance/gameplay cycles — Keep separate complete-cycle/balance gate. Cost if wrong: Roster balance remains unaccepted.

34. Final: Ruling: Whole Task15/16 — Bounded readers cannot close original combat integration. Cost if wrong: Original combat integration remains unfinished.

35. Final: Ruling: Owner-hosted/Atlas/human acceptance — No hosted/native evidence establishes these. Cost if wrong: Acceptance gates remain open.

36. Final: Ruling: Merge/deploy/release readiness — No release authorized by this checkpoint. Cost if wrong: Combat update remains unreleased.

Initial frozen root8530Vitest+7NodeGREEN183019306300, completebothbuildtail/no replay; initialpackageaudit preserved. BeginONEjointI1/I2repairwave with14newnativecases, productionfixnotyetedited.

# ONE Important repair wave
I1: two actual pending flat HP/MP native schedules use equal amount10/durationTurns0, ticks1/3. RED183514594355 merges each pair (expected2 groups/actual1); add recoveryApplications to existing grouping key.
I2: twelve actual native schedules HP/MP × flat/percentage × pending/ally/after-self-skip. RED183514594355 lacks ordinary/subsequent cadence in both actual SSR body and accessible report. Native after-self case executes endCombatTurn and confirms skipfalse/remaining2; ally case targets actual all-allies outside ally turn. Add affected-turn-end cadence to shared lifetime text, preserve first-on-activation and existing skiptrue qualification.
RED183514594355:14validmissing-group/cadencefailures/21existingGREEN. GREEN183528282543:35/35. Focused183537280194:910tests/84filesGREEN. Types183537273307GREEN;zero-warninglint183537270966GREEN;gitdiffcheckGREEN. No engine operator/schema/timingpolicy/AI/manifest edits. Singlewave/no rereview; no Minor repaired.

## Final live amount checkpoint verification
# Recovery and Barrier amount readers — verified development checkpoint

Live HP/MP recovery now shows the native recorded flat base or captured percentage amount, the original percentage and resource maximum, and the remaining application count. Percentage amounts retain the modifiers captured when used; later maximum-resource or status changes do not recalculate history. Flat amounts remain explicitly before applicable recovery modifiers. Both retain the missing-resource cap. Zero is a valid captured amount; unavailable historical captures remain unavailable.

Pending recovery retains its exact recipient-specific capture. Its first application occurs on activation; subsequent applications occur at affected-turn ends. Active schedules state one application per affected-turn end and preserve the skipped-current-turn qualification. Equal amount schedules with different remaining application counts remain separate; genuinely equal rows show total and per-stack strength with per-stack counts.

Barrier shows the pending grant request or each actual remaining native pool. Partial absorption changes the displayed individual pool rather than substituting the character's aggregate Barrier. Historical pending grants say up to the requested amount and retain their maximum-HP cap. Unlike remaining pools stay separate; equal pools show total and per-stack amounts.

The existing shared reader renders these values with its gold/orange summary component and equivalent accessible text. Compact/full/All and the five previously migrated legacy battle surfaces inherit the same facts. Unsupported versions do not borrow current rules. The optional ephemeral projection copies public numeric fields individually before the existing recipient/Covert privacy boundary; no persisted schema, native operator, timing-mode function, command, cost, AI, manifest, controls, art or geometry changes.

## Evidence and review

- BASE f9367ece1880896f09ebc20c1818fe7c41823c8b → initial frozen/reviewed `fec7710a7fc3964b62186ce72085ff1b19beec19` → final tested `37455c988d89852125f08cdab0678977d8b6fe3b`. Six production/test files, **35 new cases overall**:21 initial plus14 review repairs. Core changes are confined to additive presentation facts in combat-effect-timing.ts.
- Initial TDD182414565382:14 valid missing-fact failures, two fixture errors and one guard pass. The Covert fixture incorrectly used pending concealment; a partial-depletion fixture attempted illegal self damage. Corrected182507043887:18 valid RED, one remaining self-damage fixture error and two guard passes. Initial implementation182619886524:20 pass/one same fixture error. Corrected partial depletion uses actual actor end turn and native enemy attack; temporarily removing only the new Barrier aggregation key produces valid missing-separation RED182712985512. Restored hunk passes. No gameplay was changed to accommodate fixtures.
- Initial focused896/84 GREEN182800332756, core recovery/Barrier/timing69/3 GREEN182800338608, web types182800333707 GREEN. Initial wrong-root lint182800339417 ignored web files and is not clean evidence; corrected web182911224551 and core182911228279 are zero-warning GREEN. Initial complete full check183019306300 passes **8,530 Vitest plus seven Node checks**, both builds included; no stdout-loss replay needed.
- One fresh read-only combined review: **0 Critical, 2 Important, 0 new Minor**. Parent independently accepts I1 (different application counts merged) and I2 (ordinary/subsequent recovery cadence omitted). One joint repair wave adds14 actual native cases; all14 reproduce the missing grouping/cadence at183514594355 while21 existing cases pass. All35 GREEN183528282543. Final focused **910 tests/84 files GREEN183537280194**, web types183537273307 and zero-warning lint183537270966 GREEN. No rereview, implementer agents or incidental Minor repair.
- Final exact-source full check **8,544 Vitest plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN: `20261016T183559983689Z`, 2026-10-16T18:35:59.983689+00:00 → 2026-10-16T18:39:54.079521+00:00. Package counts: realtime 3, validation 106, worker 2, audio 17, db 118, game-core 4136, web 4162. Complete root build tail and package-log hash audit preserved.
- Final all294 diagnostic183559984745:294 records,297 groups,604 effects. Every named Skill report and HTML string is exactly unchanged from the preceding captured live-effect checkpoint. Observation SHA256 `01819601b8350a5968f5d38d6bf5996db1ad56ce5d79eae4387c4834df1f6007`. Manifest and six AI/native source hashes unchanged. No new289-case gameplay-matrix claim for this presentation-only change.

The new tests execute native HP/MP capture, actual pending and active recovery, actor end turns, native enemy damage/Barrier absorption, and public server projection before invoking the real shared report and SSR body. They verify exact recipient captures, frozen amounts, flat bases, zero, caps, independent pools, grouping, application counts, ordinary/skip cadence, Covert and input immutability. SSR is not mounted DOM, native browser, assistive-technology or physical geometry acceptance. More separate same-status rows increase exposure to the inherited duplicate-key Minor; no mounted reconciliation failure was established here.

## Open work and release boundary

The modular foundation is already live. The proposed Skill rebalance and original unfinished combat integration remain separate. Original Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance must finish before combat release. Other live strength categories and whole-action readiness, historical Chronicle readers, public Manual references and remaining prose coverage remain open. Distinct/full roster cycles, natural pacing/twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion and human acceptance remain open. Broader Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is made by this checkpoint. High remains sufficient for routine integration. The provisional16–30 active working hours/roughly2–4 full working days remains an uncertain working estimate, not a calendar launch promise or mechanically reduced count.

## Deferred Minors

Thirteen retained: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status direct-input immutability witness; legacy duplicate component keys. None is incidentally repaired.

## Initial implementation rulings

1. Use the existing core presentation projection for optional facts: the native instance is available before recipient/visibility filtering, avoiding an index join. Cost if wrong: broader consumers must tolerate additive ephemeral fields; full-root and fixture equality guard them.
2. Percentage recovery exposes frozen effective amounts; flat recovery exposes dynamic base amounts, matching native modifier handling. Cost if wrong: base text cannot promise future restoration.
3. Group equal facts with total/per-stack values and per-stack counts, separating unlike strength/counts/skip clocks. Cost if wrong: native long-list/key-expiry acceptance remains required.

## Every parent set-aside ruling


1. Final: Ruling: Exact future HP/MP after caps — Keep recorded base/capture plus missing-resource qualification; future state is not available. Cost if wrong: Actual future restoration is not forecast.

2. Final: Ruling: Combined outgoing damage — Leave the unchanged damage reader for its own bounded cohort. Cost if wrong: Combined outgoing strength remains open.

3. Final: Ruling: Conditional damage — Do not invent absent attacker/recipient context. Cost if wrong: Conditional combined strength remains open.

4. Final: Ruling: Other non-damage strength — Leave separate native categories for subsequent integration. Cost if wrong: Those category readers remain incomplete.

5. Final: Ruling: Controlled readiness — Keep unchanged captured-action ownership. Cost if wrong: Controlled readiness still needs its own acceptance.

6. Final: Ruling: Manual modifiers and controls — Keep unchanged behavior and separate integration gate. Cost if wrong: No fresh control acceptance.

7. Final: Ruling: Historical Chronicle/modal redesign — Keep existing historical caller; current amount extension is additive. Cost if wrong: Historical readers remain unfinished.

8. Final: Ruling: Old fixed Storm magnitude — Retain inherited conservative unavailable handling. Cost if wrong: Old Storm does not gain an invented magnitude.

9. Final: Ruling: Native mouse — Leave acceptance open; browser is unavailable. Cost if wrong: Mouse behavior remains unverified.

10. Final: Ruling: Native touch — Leave acceptance open; browser is unavailable. Cost if wrong: Touch behavior remains unverified.

11. Final: Ruling: Native keyboard/focus — Source tracing is insufficient for mounted acceptance. Cost if wrong: Keyboard/focus still needs native verification.

12. Final: Ruling: Assistive technology — Keep shared accessible strings; no actual AT execution. Cost if wrong: AT acceptance remains open.

13. Final: Ruling: Long reports/small screens/200% zoom — Reuse existing layout and defer physical inspection. Cost if wrong: Clipping and overflow remain unverified.

14. Final: Ruling: Button CSS geometry — No geometry changes in this amount cohort. Cost if wrong: Physical sizing remains unverified.

15. Final: Ruling: Inspection backdrop dismissal — Retain existing outside-card behavior. Cost if wrong: Outside inspection still closes the whole inspection.

16. Final: Ruling: Broader malformed persisted/pending/summon validation — Retain existing parser authority; relevant captures traced. Cost if wrong: No whole-parser re-audit.

17. Final: Ruling: Expiry/revocation/character authority/CAS/direct RPC — Keep separate Task8/16 authority gate. Cost if wrong: Hosted security acceptance remains required.

18. Final: Ruling: No input/duplicate payment/interrupted Move/attack origin — Native execution unchanged. Cost if wrong: Fresh gameplay acceptance remains required.

19. Final: Ruling: Publication/build/claim/recovery/settlement concurrency — Transactions/workers unchanged. Cost if wrong: Hosted concurrency acceptance remains required.

20. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated witness. Cost if wrong: Witness still begins at origin.

21. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; unrelated capture test. Cost if wrong: Version-pin coverage remains incomplete.

22. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Identity witness remains weaker.

23. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

24. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission unchanged. Cost if wrong: Duplicate prefix wording remains.

25. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; guarded native files unchanged. Cost if wrong: Negative witness remains preparation-only.

26. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; execution unchanged. Cost if wrong: Events lack independent HP reconciliation.

27. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact history label/value coverage incomplete.

28. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; unrelated editorial work. Cost if wrong: Grammar defect remains.

29. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; distinct from recovery cadence. Cost if wrong: Burn boundary wording remains imprecise.

30. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry acceptance remains open.

31. Final: Ruling: Cross-status input immutability witness — Keep inherited Minor deferred; different test cohort. Cost if wrong: Its direct-input witness remains weaker.

32. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: static collision but no demonstrated mounted failure; no incidental repair. Cost if wrong: More separate same-status rows may misassociate popup state at expiry/replacement.

33. Final: Ruling: Full roster balance/gameplay cycles — Keep separate complete-cycle/balance gate. Cost if wrong: Roster balance remains unaccepted.

34. Final: Ruling: Whole Task15/16 — Bounded readers cannot close original combat integration. Cost if wrong: Original combat integration remains unfinished.

35. Final: Ruling: Owner-hosted/Atlas/human acceptance — No hosted/native evidence establishes these. Cost if wrong: Acceptance gates remain open.

36. Final: Ruling: Merge/deploy/release readiness — No release authorized by this checkpoint. Cost if wrong: Combat update remains unreleased.



Final: fixed I1 recovery application identity — nativependingflatHP/MPcounts1vs3 RED183514594355→GREEN183528282543, focused910/910/full8544+7GREEN183559983689.
Final: fixed I2 ordinary/subsequent recovery cadence —12nativeHP/MPflat/percentagepending/ally/postskipcases RED183514594355→GREEN183528282543, focused910/910/full8544+7GREEN183559983689. ONEjointImportantwave/no rereview. All294exact183559984745;manifest/sixAIhashguardsunchanged;completefullroottail/no replay.

Durable live-amount checkpoint cf6de8a1258daea1dae03a7ea09e0ff480cbf41f;root707835f421d9d16950212e721a32c8d6b3dee9c5;checkpointsf6ef34fa689bf418b138aeb81212296f8483ca87. All4local/upload/remoteSHAs+freshlsremoteverified;main29506e29unchanged. Source505b00cc253fdeeff966edffd152b7b19750cb84/tested37455c988d89852125f08cdab0678977d8b6fe3b/reviewedfec7710a7fc3964b62186ce72085ff1b19beec19;ONEImportantwaveI1/I2/no rereview. Final8544Vitest+7Node/fulltypes/lint/format/bothbuildsGREEN183559983689;completebuildtail/no replay;all294reports/HTMLexact183559984745/hashguardsunchanged.35newcases/13Minorsdeferred/36individualdeclinedreason-costrulings+3initialscope-rulings. Sourceworktreeclean/docs-onlydescendant. Native/AT/geometry/originalcombat/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. Nextread-onlystrength/readinesshandoffpreserved;no nextsourceedityet. No publication/activation/migration/merge/deploy. Highsufficient.

## Task15 unconditional live damage strength cohort
# Task15 unconditional live damage strength readers
BASE505b00cc253fdeeff966edffd152b7b19750cb84; previous8544+7/all294/durablecf6de8a1 verified. Original approvedOwner§10 design/Task15 inline continuation, existingisolatedagentbranchclean; no newsubsystem/designapproval. Bothbreakpoints/allsharedPvE/PvP/spectator consumers inherit existingreader.13Minorsdeferred/noincidentalfix. Onefreshcombinedreview/parentregrade+individualdeclinedreason-cost/ONECIfixwave/no rereview.

Scope: show combined outgoing damage multiplier from this effect for Inspired(DamageUp), Suppress, Reckless, Fortified; include separate incoming multiplier for Reckless/Fortified (ordinarydamageTaken summary already coversGuard/etc). Use exact supported version definition, captured application potencies/defaults and current-vs-legacy encounter stacking. New pure web helper fed actual public projection; existingCompactEffectSummary rows/accessibility sharecontent. No new projection/schema/nativeoperator/control/style/art changes. Pending rows explicitly say on activation, nevercurrentactive modifier. Existing perapplicationdescription/lifetime retained.
Native authority: damage-modifiers.ts conditionalDamageMultiplier currentInspired iteratescombatStatusApplications/stacks and floors basispointnumerator aftereach; historicalfirststatusonce. Reckless/Fortified always damageModifiers compose exactBigIntratios then finalinteger division; currentallapplications/stacks, historicalrowonce. Currentnative overflowaboveMAX_SAFE_INTEGER throws; reader shows unavailable ratherthancrashes/Veryhighfakeexact. Legacyconditionalbudgetclamp50..200 isglobal; isolatedsupportedlegacyrowonce/defaultorpotencywithinrange. Suppress usesoutgoingSuppressionBasisPoints strongestpotency once regardlessstackandoutsideconditionalbudget; scaleSuppressedDirectDamage performscheckedfinalrounding. Do not multiplySuppressionbystacks. No conditionalnativebranches/opponent/source/facingreadinessjudgment from isolatedrow.

TDD: actual native selfcasts→publicspectatorprojection→sharedreaderSSR/accessibility/nativekernel references. Currentvslegacy default+explicit10/20Inspired132%current/120%legacy; multiplecurrentequalstacks121%; Recklessdefaulttwo196%out/156.25%in; Fortifieddefaulttwo64%out/49%in; authoredmixed10/20Reckless132%out/132%in andFortified72%out/72%in; legacyone140/125and80/70; Suppress25then40staysone60% (and100%zero); pendingnotactive labels; differentpotencies preserveactualdefaultapplicationvalues; unknownversion/conditionalstatus getsnospeculativesummary; Covertprivacyunchanged/inputimmutable; finite/safebounds withrealprojectedrow controls.
ExpectedREDmissingnewstrengthrows, not fixture/importerrors. Focusedrealbattle/projection/captured/amountfixtures+coreconditional/suppress/tests/types/lint, thenfullroot/all294exact/hashguards. No fresh289forpresentation-only. Rootbaseline8544+7; newcountfromactualtestreceipt. Native/AT/geometry/fullTask15/16/originalcombat/editor/control/readiness/conditions/Manual/Chronicle/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. No hostedwrite/publication/activation/migration/merge/deploy. Highsufficient.

Ruling: expose multipliers scoped to this effect, not finaldamage — actual actor/recipient/othermodifiers areabsent from an isolatedrow — costifwrong: conditional/fullcombined damage remains explicitfuturework.
Ruling: preserve native perapplication integer arithmetic forInspired and exactratioarithmetic foralwaysmodifiers; don'tuse genericMath.round — nativeoperators differ — costifwrong: no exactHPforecast andactualnativekernelcomparisonneeded.
Ruling: legacyrow appliesonce andSuppress neverstacks — currentpubliccountdoesnotreplacecapturedmechanics — costifwrong: historical readerdoesnotclaimstackmultiplier.


TDDprovenance:184715734384 importerrorexportcombat-suppress(nocasestested);fixedtestimportrelative,no exportchange.18473289033119validmissingstrengthRED+2invalidSuppressstacksfixtures+6guardsGREEN. CorrectedSuppressnativeoneapplication;18481537498821validmissingstrengthRED/6guardsGREEN. Initialimplementation18484165547727GREEN. Strengthenedzeroassertiontoactualrow(notgeneric100%substring),addedactual100damage→72HPcombinationandnative20kInspired/capacity1Mguards; temporarilyremovedonlynewhelperintegrationfornewtestsRED before restoringit. Nativepurepresentationunchanged. Ruling: cap synchronousInspiredreaderwork16384stepsandmarkunavailableforlargervalidcounts — perstepnativefloorrequiresiteration; donotfreezeUIorpretend0 — costifwrong: someextremevalidtotalsremainunavailableevenwhennativecancomputethem.

184922453937 integration-offstrengthguardRED:23validmissingrows/2invalidpotency1fixtures/5guardsGREEN;184938570314 restoredimplementation28GREEN/2sameinvalidfixtures. AuthoredANDpersistedpotencyminimumis100basispoints, not1; correctedlargecapturefixtures100, nativeoverflowsafe/capacitytruth. Previousreaderbudgetrulingcostqualificationwithdrawn: validInspiredpotency>=100 overflowsnativeMAXSAFE before16384steps, so no valid computabletotalisdiscarded bythisguard. Guardisdefensive; actualsafemax/nativecapacityunavailablequalificationremains. Two correctedlargecases testedwithonlynewintegrationoffbefore restoringit.

185012292738correctedlargecasesvalidRED2/28skipped;18502600287129GREEN/1testorderassumptionfailure and185035335286939GREEN/1sameorderassertionfailure. Fortifiednativeauthoreddefinitionordersincomingthenoutgoing; preserveit. Correcttesttoasserttwodirectionswithoutinventedoutgoingfirstrequirement;nosourcefix. Webtypes185035334144GREEN/lint185035334221GREEN.

Initialfinalfocused940tests/85filesGREEN185101256902;core58/2GREEN185101777557 (thirdrequestedconditional-modifiers.test.tsdoesnotexist,notclaimedtested). Types185035334144/lint185035334221GREEN. Nativeconditionaltestsactuallyphase4-effects/interactions/unlimited-dots;runseparately. Reactcondensedcheck: directpurehelper/existingCompactEffectSummary, nohooks/fetch/state/globalcontrols/dependencies/CSS/artchange; sharedaccessibleplaintext, exactboundedBigIntarithmetic, capturedfactsnoaddedprivacyfields. Bothbreakpoints inheritallsharedconsumers; nativegeometry/ATopen.

# Single combined live-strength review
Fresh reviewer /root/live_strength_combined_review, gpt-6-astra High; read-only BASE505b00cc253fdeeff966edffd152b7b19750cb84→HEAD2fdb2f36d9e2dc97dfce177075f91c1c7e056223. All3files, brief/Owner§10/Task15/ledger, actual native arithmetic/copy/validation/capture/publicprivacy/grouping/sharedconsumers inspected. No tests/services/network/browser/native/mutations/subagents; supplied test results remain parent evidence.
Result:0Critical/0Important/0newMinor. Thirteen inherited Minors stay deferred. Parent independently agrees by actual player effect; no repair wave/no rereview.
Strengths: helper50–80 preserves current applications vs historicalonce, Inspiredperapplicationfloor, Reckless/Fortifiedexactratios/finaldivision;65,536bitcapacity+safeoverflowunavailable. Minimumvalidatedpotency100bps meansInspiredoverflowbefore16,384guard.96–105Suppressone/zeroanddualdirections. ExactID/versiongate, pendingonactivation, no private source reconstruction. Sharedreport78–103uses samefactsforactualCompactEffectSummarygold/amberrows/accessibility. Activeidentitypreventsduplicateactivefourstatusrows; pendingpotency/count/timinggroupcorrect. SharedPvE/PvP/spectatorconsumersinheritonehelper; no breakpoint-specific arithmetic. Testsactualnativecasts/projector/kernels/100→72HP; fixtureerrorshonestlyexcludedfromRED.
Assessment: ready for bounded checkpoint, notfullTask15/native/AT/geometry/balance/releaseapproval. All39declinedbehaviors are retained individually in parentrulingsbelow.

1. Final: Ruling: Final actor/recipient HP forecast — Retain per-effect multipliers because other modifiers and combat state are absent. Cost if wrong: These rows do not establish final HP.

2. Final: Ruling: Conditional opponent/source/facing/HP damage — Leave unchanged conditions for their own context-aware integration. Cost if wrong: Conditional combined magnitude remains open.

3. Final: Ruling: Legacy global damage-budget presentation — Do not attribute a global clamp to one effect; isolated supported legacy values stay within it. Cost if wrong: Per-effect rows are not the complete legacy damage budget.

4. Final: Ruling: Other non-damage strength — Keep separate from the four selected damage effects. Cost if wrong: Other category readers remain incomplete.

5. Final: Ruling: Controlled and other readiness — Keep action-state ownership and separate integration. Cost if wrong: Readiness acceptance remains open.

6. Final: Ruling: Noncompact EffectModifiers trigger summaries — Retain existing individual deltas; this cohort changes popup/report strength. Cost if wrong: Trigger summaries are not fully audited or combined.

7. Final: Ruling: Manual/authored-content reader acceptance — Leave separate public Manual/content gate. Cost if wrong: No full content-reader acceptance.

8. Final: Ruling: Historical Chronicle/modal redesign — Keep unchanged historical fallback for later work. Cost if wrong: Historical readers remain unfinished.

9. Final: Ruling: Existing ordinary incoming-damage summary arithmetic — Keep unchanged helper; new arithmetic is limited to its applicable native operators. Cost if wrong: This cohort does not reverify all ordinary summary rounding.

10. Final: Ruling: Mounted mouse — Leave native acceptance open; no browser execution. Cost if wrong: Mouse interaction remains unverified.

11. Final: Ruling: Mounted touch — Leave native acceptance open; no browser execution. Cost if wrong: Touch interaction remains unverified.

12. Final: Ruling: Mounted keyboard/focus — Source parity is insufficient for physical acceptance. Cost if wrong: Keyboard/focus acceptance remains open.

13. Final: Ruling: Assistive technology — Keep shared accessible strings without claiming actual AT execution. Cost if wrong: AT output remains unverified.

14. Final: Ruling: Long reports/small screens/200%zoom — Keep existing layout and physical acceptance gate. Cost if wrong: Added content may expose clipping/overflow.

15. Final: Ruling: Button/popup CSS geometry — No geometry changed; no physical evidence to close gate. Cost if wrong: Physical sizing remains unverified.

16. Final: Ruling: Inspection backdrop dismissal — Keep existing outside-click ownership. Cost if wrong: Outside inspection still closes the whole inspection.

17. Final: Ruling: Whole persisted/pending/summon malformed-data validation — Keep parser authority; relevant constraints traced, not whole parser. Cost if wrong: Broader parser audit remains open.

18. Final: Ruling: Expiry/revocation/character authority/CAS/direct RPC — Keep separate Task8/16 gate; authority unchanged. Cost if wrong: Hosted security acceptance remains required.

19. Final: Ruling: No input/duplicate payment/extra turns/interrupted Move origins — Native execution unchanged; keep gameplay gate. Cost if wrong: Fresh gameplay acceptance remains required.

20. Final: Ruling: Publication/build/claim/recovery/settlement concurrency — Transactions and workers unchanged. Cost if wrong: Hosted concurrency acceptance remains required.

21. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated witness. Cost if wrong: Witness still starts at origin.

22. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; unrelated capture test. Cost if wrong: Exact version coverage remains incomplete.

23. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Identity witness remains weaker.

24. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

25. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission unchanged. Cost if wrong: Duplicate prefix wording remains.

26. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; no relevant execution change. Cost if wrong: Negative witness remains preparation-only.

27. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; unrelated event test. Cost if wrong: Events lack independent HP reconciliation.

28. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact history value/label coverage incomplete.

29. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; unrelated wording. Cost if wrong: Grammar defect remains.

30. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; Burn unchanged. Cost if wrong: Burn boundary wording remains imprecise.

31. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry remains unverified.

32. Final: Ruling: Cross-status input-immutability witness — Keep inherited Minor deferred; different cohort. Cost if wrong: That direct-input witness remains weaker.

33. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: no new status rows or demonstrated mounted failure. Cost if wrong: Expiry/replacement may still misassociate popup state.

34. Final: Ruling: Whole-roster balance/full cycles — Keep separate natural/full-cycle/balance gate. Cost if wrong: Roster balance remains unaccepted.

35. Final: Ruling: Full Task15/16 — Bounded readers cannot close original combat integration. Cost if wrong: Task15/16 remain unfinished.

36. Final: Ruling: Owner-hosted acceptance — No hosted execution establishes acceptance. Cost if wrong: Hosted gate remains open.

37. Final: Ruling: Atlas acceptance — Unchanged and outside this reader check. Cost if wrong: Atlas motion/acceptance remains open.

38. Final: Ruling: Human gameplay acceptance — Source review/tests cannot establish human acceptance. Cost if wrong: Human gate remains open.

39. Final: Ruling: Merge/deployment/activation/release readiness — Review supplies no operational authorization; preserve no-release boundary. Cost if wrong: Combat update remains unreleased.

## Final combined damage strength checkpoint
# Captured combined damage multipliers — verified development checkpoint

The shared live-effect reader now shows the combined damage multiplier for Damage Up, Suppress, Reckless and Fortified. Reckless and Fortified show incoming and outgoing values separately. Values use the existing gold/orange summary rows and equivalent accessible descriptions. Current encounters retain each recorded application/default magnitude; historical encounters apply their recorded row once. Pending values explicitly say on activation. These are multipliers from this effect; other damage modifiers and combat rules still apply, so the reader does not claim final HP damage.

Damage Up follows native integer flooring after each application. Reckless and Fortified follow native exact-ratio composition with the final basis-point rounding. A three-application1.99% case yields106.07% for Damage Up and106.08% for Reckless, matching their different operators. Suppress uses its strongest recorded percentage once, including a genuine0% outgoing multiplier at full suppression. Default then20% Damage Up shows132% under current application stacking and120% under historical whole-row rules. Two default Reckless applications show196% outgoing/156.25% incoming; two default Fortified applications show64% outgoing/49% incoming.

Unsafe or unsupported exact totals are unavailable without crashing the reader. Integer formatting preserves hundredths without floating-point percentage drift. Current minimum authored/persisted potency is100basispoints; native safe-total overflow occurs before the defensive16,384-step Damage Up rendering limit. Exact-ratio arithmetic uses the native65,536-bit capacity ceiling and bounded exponentiation. Native execution and validation are unchanged.

Condition-dependent damage, Healing Down/recovery rates, other non-damage strength and whole-action readiness remain separate work. The reader does not invent missing attacker/recipient/source/facing context. Existing per-application descriptions, lifetime, unknown-version behavior and Covert privacy remain shared. No projection, persistence, schema, native operator, command, control, AI, manifest, CSS, artwork or geometry file changes.

## Verification and review

- BASE505b00cc253fdeeff966edffd152b7b19750cb84 → initial reviewed `2fdb2f36d9e2dc97dfce177075f91c1c7e056223` → final tested `2fdb2f36d9e2dc97dfce177075f91c1c7e056223`. Three initial web source/test files; **30 new cases overall**. The report is a docs-only descendant of tested production source.
- TDD184715734384 failed before tests because combat-suppress is not a package subpath export; the test now imports that native source directly without changing exports.184732890331 had19 valid missing-row failures, two invalid multiple-application Suppress fixtures and six guards passing. Corrected184815374988 had21 valid missing-row failures and six guards passing; initial implementation184841655477 passed27cases.
- A zero assertion was strengthened to inspect the actual summary row rather than matching0% inside100% dictionary prose. Added an actual native100-damage attack after120% Damage Up and60% Suppress, which deals72HP, plus large-count/capacity cases. Temporarily removing only the new reader integration produced184922453937:23 valid missing-row failures, two invalid potency1 fixtures and five passing guards. Authored and persisted potency minimum is100basispoints, so the fixtures were corrected.185012292738 then reproduced both corrected large cases as missing-row RED. The earlier ruling about discarding a valid low-potency total was explicitly withdrawn; such potency is invalid.
- Restored185026002871 had29 cases pass and one test-only row-order assertion fail; focused185035335286 had939 pass/one same assertion fail. Fortified's native definition orders incoming before outgoing; the test now checks both directions without an invented ordering requirement. No production ordering change was made. Final initial focused **940tests/85files GREEN185101256902**; web types185035334144 and zero-warning lint185035334221 GREEN. Core58/2 GREEN185101777557; the third requested conditional-modifiers filename does not exist and is not counted. Actual native conditional suites **722tests/3files GREEN185155843703**.
- Final exact-source full check: **8,574Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds GREEN. Receipt `20261016T185155842818Z`, 2026-10-16T18:51:55.842818+00:00 → 2026-10-16T18:55:45.898170+00:00. Package counts: worker 2, audio 17, validation 106, realtime 3, db 118, game-core 4136, web 4192. Complete root build tail and package-log hash audit preserved.
- All294 named Skill reports and HTML strings remain exactly unchanged against the preceding amount-reader checkpoint:294records,297groups,604effects; observation SHA256 `8ed95936c035ece0fae96fba4d104696ece0cfd07b94dc87e3db3979c22345d0`. Manifest and six AI/native source hashes unchanged. No fresh289-case gameplay-matrix claim for this presentation-only change.

## Combined review disposition

One fresh combined read-only review finds **0Critical,0Important,0newMinor**. Parent accepts the assessment after tracing the reported native rules and public/shared consumers. No repair wave is needed; no rereview. Thirteen inherited Minors remain deferred. All39 individually declined behaviors receive the reason/cost rulings below.


Tests use real native casts, conditional kernels, actual public spectator projection and the real shared report/SSR body, with only the server-only import marker mocked. They check current/legacy captured defaults and mixed strengths, native rounding, pending labels, zero, unsafe totals, source input immutability, conditions/unknown versions, Covert, and an actual direct-damage outcome. SSR and source parity are not mounted DOM, native browser, assistive-technology or physical geometry acceptance. Both desktop/mobile PvE/PvP/spectators inherit the existing shared reader path; their native acceptance remains open.

## Remaining release work

The modular foundation already live, proposed rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance remain pre-release requirements. Further strength categories, conditional/readiness context, historical Chronicle, public Manual references, full roster cycles, natural pacing/twelve-round balance, current Owner edits, hosted authority/CAS, Atlas motion and human acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is made here. High remains sufficient for routine integration. The provisional16–30activehours/roughly2–4fullworkingdays is an uncertain working estimate, not a calendar launch promise or mechanically reduced count.

## Deferred Minors

Thirteen inherited items remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status input immutability witness; legacy duplicate component keys. Any new reviewed Minor is listed in the review outcome above.

## Initial implementation decisions

1. Scope multipliers to this effect, preserving conditional/full-damage context for separate work. Reason: isolated public rows lack actual attacker/recipient/other modifiers. Cost if wrong: a per-effect reader cannot replace the full damage forecast.
2. Preserve native per-application flooring for Damage Up and exact-ratio arithmetic for always modifiers. Reason: these operators differ. Cost if wrong: kernel comparisons and native final-damage tests remain necessary.
3. Historical rows apply once; Suppress never multiplies by stacks. Reason: captured native policies govern strength. Cost if wrong: visible counts do not independently establish multiplier count.
4. Defensive rendering limits show unavailable rather than freeze or pretend zero. The initial low-potency computable-total concern was withdrawn after inspecting both validation boundaries. Cost if wrong: malformed/unsupported arithmetic remains unavailable rather than receiving invented values.

## Every parent set-aside ruling

1. Final: Ruling: Final actor/recipient HP forecast — Retain per-effect multipliers because other modifiers and combat state are absent. Cost if wrong: These rows do not establish final HP.

2. Final: Ruling: Conditional opponent/source/facing/HP damage — Leave unchanged conditions for their own context-aware integration. Cost if wrong: Conditional combined magnitude remains open.

3. Final: Ruling: Legacy global damage-budget presentation — Do not attribute a global clamp to one effect; isolated supported legacy values stay within it. Cost if wrong: Per-effect rows are not the complete legacy damage budget.

4. Final: Ruling: Other non-damage strength — Keep separate from the four selected damage effects. Cost if wrong: Other category readers remain incomplete.

5. Final: Ruling: Controlled and other readiness — Keep action-state ownership and separate integration. Cost if wrong: Readiness acceptance remains open.

6. Final: Ruling: Noncompact EffectModifiers trigger summaries — Retain existing individual deltas; this cohort changes popup/report strength. Cost if wrong: Trigger summaries are not fully audited or combined.

7. Final: Ruling: Manual/authored-content reader acceptance — Leave separate public Manual/content gate. Cost if wrong: No full content-reader acceptance.

8. Final: Ruling: Historical Chronicle/modal redesign — Keep unchanged historical fallback for later work. Cost if wrong: Historical readers remain unfinished.

9. Final: Ruling: Existing ordinary incoming-damage summary arithmetic — Keep unchanged helper; new arithmetic is limited to its applicable native operators. Cost if wrong: This cohort does not reverify all ordinary summary rounding.

10. Final: Ruling: Mounted mouse — Leave native acceptance open; no browser execution. Cost if wrong: Mouse interaction remains unverified.

11. Final: Ruling: Mounted touch — Leave native acceptance open; no browser execution. Cost if wrong: Touch interaction remains unverified.

12. Final: Ruling: Mounted keyboard/focus — Source parity is insufficient for physical acceptance. Cost if wrong: Keyboard/focus acceptance remains open.

13. Final: Ruling: Assistive technology — Keep shared accessible strings without claiming actual AT execution. Cost if wrong: AT output remains unverified.

14. Final: Ruling: Long reports/small screens/200%zoom — Keep existing layout and physical acceptance gate. Cost if wrong: Added content may expose clipping/overflow.

15. Final: Ruling: Button/popup CSS geometry — No geometry changed; no physical evidence to close gate. Cost if wrong: Physical sizing remains unverified.

16. Final: Ruling: Inspection backdrop dismissal — Keep existing outside-click ownership. Cost if wrong: Outside inspection still closes the whole inspection.

17. Final: Ruling: Whole persisted/pending/summon malformed-data validation — Keep parser authority; relevant constraints traced, not whole parser. Cost if wrong: Broader parser audit remains open.

18. Final: Ruling: Expiry/revocation/character authority/CAS/direct RPC — Keep separate Task8/16 gate; authority unchanged. Cost if wrong: Hosted security acceptance remains required.

19. Final: Ruling: No input/duplicate payment/extra turns/interrupted Move origins — Native execution unchanged; keep gameplay gate. Cost if wrong: Fresh gameplay acceptance remains required.

20. Final: Ruling: Publication/build/claim/recovery/settlement concurrency — Transactions and workers unchanged. Cost if wrong: Hosted concurrency acceptance remains required.

21. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated witness. Cost if wrong: Witness still starts at origin.

22. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; unrelated capture test. Cost if wrong: Exact version coverage remains incomplete.

23. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Identity witness remains weaker.

24. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

25. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission unchanged. Cost if wrong: Duplicate prefix wording remains.

26. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; no relevant execution change. Cost if wrong: Negative witness remains preparation-only.

27. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; unrelated event test. Cost if wrong: Events lack independent HP reconciliation.

28. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact history value/label coverage incomplete.

29. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; unrelated wording. Cost if wrong: Grammar defect remains.

30. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; Burn unchanged. Cost if wrong: Burn boundary wording remains imprecise.

31. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry remains unverified.

32. Final: Ruling: Cross-status input-immutability witness — Keep inherited Minor deferred; different cohort. Cost if wrong: That direct-input witness remains weaker.

33. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: no new status rows or demonstrated mounted failure. Cost if wrong: Expiry/replacement may still misassociate popup state.

34. Final: Ruling: Whole-roster balance/full cycles — Keep separate natural/full-cycle/balance gate. Cost if wrong: Roster balance remains unaccepted.

35. Final: Ruling: Full Task15/16 — Bounded readers cannot close original combat integration. Cost if wrong: Task15/16 remain unfinished.

36. Final: Ruling: Owner-hosted acceptance — No hosted execution establishes acceptance. Cost if wrong: Hosted gate remains open.

37. Final: Ruling: Atlas acceptance — Unchanged and outside this reader check. Cost if wrong: Atlas motion/acceptance remains open.

38. Final: Ruling: Human gameplay acceptance — Source review/tests cannot establish human acceptance. Cost if wrong: Human gate remains open.

39. Final: Ruling: Merge/deployment/activation/release readiness — Review supplies no operational authorization; preserve no-release boundary. Cost if wrong: Combat update remains unreleased.



Durable live-strength checkpoint 88aa0c7a07fc1f03b3577b9b992b510d5ddf65e6;rootb8fb035a75f7903a17b7ce490c1e2617c3f835fa;checkpoints9c8b4e443d8b0c24d839a99b13418d7f94e01f80. All4local/upload/remoteSHAs+freshlsremoteverified;main29506e29unchanged. Sourceb4e3e537d01817b78e75ecb6810500009e8a3120/tested2fdb2f36d9e2dc97dfce177075f91c1c7e056223/reviewed2fdb2f36d9e2dc97dfce177075f91c1c7e056223;onecombinedreview0C/0I/0newM/no repair/no rereview. Final8574Vitest+7Node/fulltypes/lint/format/bothbuildsGREEN185155842818;completebuildtail/no replay;all294reports/HTMLexact185155845887/hashguardsunchanged.30newcases/13inheritedMinorsdeferred/39individualdeclinedreason-costrulings+initialscope/arithmeticrulings. Sourceworktreeclean/docs-onlydescendant. Native/AT/geometry/originalcombat/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. Nextread-onlystrength/readiness/trigger-summaryhandoffpreserved;no nextsourceedityet. No publication/activation/migration/merge/deploy. Highsufficient.

## Task15 Healing Down live combined-rate cohort
# Task15 Healing Down live combined recovery rate
BASEb4e3e537d01817b78e75ecb6810500009e8a3120. Previous8574+7/all294/sourceanddurable88aa0c7averified. ExistingapprovedOwner§10/Task15inlinecontinuation; no newsubsystem/designapproval. Existingisolatedagentbranchclean. Bothbreakpoints/sharedPvE/PvP/spectatorreader;13Minorsdeferred/no incidentalfix. Onefreshcombinedreview/parentindividualdeclinedreason-cost/ONECIfixwaveifneeded/no rereview.

Scope: one new shared HealingDown report helper, actual public recorded applications/current-vs-historicalstacking, capturedhealingDownPolicyVersion governsMPandAbsorb. ShowHP/MPmultiplier fromthiseffect; pendingonactivation, neveractive. Nominalcombinedrate explicitly beforepermodifierintegerrounding, roundedtohundredthpercentwithapproximationmarkerwhenneeded; strictlypositivebelowprecisionnotdisplayed0. Nativepermodifierfloor/order/amountcappingmeansnominalrateisnotexactHPforecast. Previouslycapturedpercentageamountsnotreducedagain; keepthissecondaryrulevisible. HistoricalMPandAbsorbunchangednote. Unknownversionsunavailable; no privatecontext/recomputefromcurrentdefaults.
Nativeauthority: combat-recovery-modifiers.ts healingDownAdjustedRecovery currentiteratesallapplications/stacks/integerflooraftereach, historicalfirstrowonce. actions-legacy.ts applyImmediateRecovery HPall, MPonlyhealingDownPolicyVersion1; capturePercentageRecovery usesHPallorcurrentMP, thenalreadyCapturedfutureticksbypasslatermodifiers. combat-absorb-recovery.ts reduceRecoveryonlyhealingDownPolicyVersion1forbothresources. Existingprojector alreadyaddsflagtoHexedpending/active; no newDTO/schema/operator/controls/styles/art. ExtractexistingpureBigIntpercent/ratiofunctionsfromdamage-strengthhelperintoonewebsharedmathmodule; preserveold30damagecasesunchanged. No newframework/dependency.

TDDactualnativecasts→publicspectatorprojection→sharedreportSSR/accessibility. Crosscurrent/legacyapplicationpolicywithcurrent/legacyhealingpolicy; default25%twice56.25%currentor75%legacy, defaultthen20%60%currentor80%legacy. FlatHP/MP9currenttwo25%modifiersrestore4(notnominal5); legacyMP9unchanged. PercentageHP/MP10%captures frommax1000/200 modifiedonceandfrozen, laterHealingDownchangesdon'trereduce. MPdrainunaffected/capsactual; pendingunapplied; visibleorangevaluesandnominalroundingnote; smallfractionapprox; largesupportedstackcountunderprecisionpositive; unsafeexactcapacityunavailablewithoutblocking; unknownversion/nontarget/Covertprivacy/actualinputimmutability. ActualAbsorbpolicytestedviaexistingnativecorecoverageandnewnativecaseifneeded; donotclaimallotherstrength/readiness.
ExpectedREDmissingratefacts, notimport/fixtureerrors. Focusedsharedbattle/projection/captured/amount/strength/ratefixtures+coreRecovery/percentage/Absorb+types/lint; finalrootexpectedbaseline8574+newactualcount, all294reports/HTMLexact/hashguards. No fresh289forpurepresentation. Native/AT/geometry/fullTask15/16/originalcombat/editors/controls/readiness/conditional/Manual/Chronicle/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. No hostedwrite/publication/activation/migration/merge/deploy. Highsufficient.

Ruling: display nominal combined rate before integer rounding, not an exactfutureamount — native recovery floors after each applied modifier and caps bymissingresources — costifwrong: usersstillneedactualcapturedamount/outcome for exactHP/MP.
Ruling: legacyMPandAbsorbretaintheir ownpolicy; stackingflagcannotstandinforhealingpolicy — nativepathscheckthemseparately — costifwrong: policycross-producttestsrequired.
Ruling: extractexistingratio/percentutilitiesunchangedratherthanduplicatingthem — olddamagesemanticsmuststayidentical — costifwrong: existing30damagecases/fullrootmustguardsharedrefactor.


Initial190903562217:32validmissingrate/rounding/capture-noteRED,1incorrectCovertfixtureexpectation,1unknownversionguardGREEN. Covertprotectspositivefacts;Hexednegativeintentionallyvisible. CorrectfixtureassertsactualInspiredhidden/Hexedvisiblewithratebeforeproduction. No privacy/operatorchange. SecondREDcorrectedfixturebeforeproduction. Extractedexistingratio/percentfunctionsunchangedtosinglewebmodule; old30damagecasesmustremainexact.

SecondRED19094989769533validmissingrate/notesRED+1unsupportedguardGREEN aftercorrectCovertfixture. Initialcombinednew+old64/2GREEN191017896193. Strengthenedactualvisible/accessibleHPandMPtablevalues; noadditionalbehavior. Ruling: bound nominalexactratioarithmetic atshared65,536bits andshowunavailable — recoverykernelcanstopafterintegerzero,butaformalpositivefractioncanrequireunboundedprecision — costifwrong: extremevalidstackcounts mayhaveunavailable nominalrateevenwhennativerecoveryiszero;neverinventzero nominalrate. Nativeoperatorsunchanged.

Initialfinalfocused974tests/86filesGREEN191122445549;actualnativeRecovery/percentage/Absorb125tests/5filesGREEN191122446669;webtypes191122448673GREEN/zero-warninglint191122445251GREEN.34newcases,5websource/testfiles;no native/projection/schema/AI/manifest/control/style/artchanges. Reactcondensedcheck: nohooks/fetch/state/listeners/dependencies,existingCompactEffectSummarygold/amberrows andidenticalplaintext, allsharedbothbreakpointsmodepaths, boundedpureBigInthelpers; native/AT/geometryopen. Freezeandonecombinedreview/full8608+7/all294required.

# Single combined recovery-rate review
Fresh reviewer /root/live_recovery_rate_combined_review, gpt-6-astra High, read-only BASEb4e3e537d01817b78e75ecb6810500009e8a3120→HEADdf53d50ba49ea70094fceb7945927018d9a031fb. All5files/brief/Owner§10/Task15/ledger/native/public/sharedconsumers reviewed; no tests/services/network/browser/native/mutations/subagents.
Result0Critical/0Important/0newMinor. Parent agrees after independent native/consumer tracing; no repair/no rereview. Existing13Minorsdeferred.
Helper18–34 matchesnative currentapplications/stacks vslegacyrootonce andnative25%defaultnotlatestroot.17,45–54 separateshealingDownPolicyVersion fromstacking: HPalways,MPandbothAbsorbresourcesonlycurrenthealingpolicy.35–54 truthfullystatesnominalrate/rounding/caps/previouscapture; approximation/subprecision/nominalcapacityunavailablehonest.9–16exactID/versionandpendingwording. Sharedpercent/ratioextractionpreservesoperations/constants/order/failureboundary;nochangedDamageUp/Suppress/Reckless/Fortifiedarithmetic. Existingpublicprojection/grouping/sharedmodeandbreakpointpathsretainflags. Covertpositivehidden/negativeHexedpublic.34newactualnative/public/SSRcases; parentownsalltestreceipts.
Extremevalidnominalrateunavailableisdocumentedprecisionlimit, notanewdefect; integerrecoveryzero≠nominalfractionzero. Assessmentreadyforboundedcheckpointonly,notnative/AT/geometry/balance/fullTask15/16/releaseapproval. All52declinedbehaviorsretainedindividuallyinparentrulings.

1. Final: Ruling: Final HP/MP forecasts — Keep nominal rates with rounding/cap/capture qualifications; final state is absent. Cost if wrong: Exact restoration still needs actual capture/outcome.

2. Final: Ruling: Conditional opponent/source/facing/HP damage — Leave unchanged context-aware damage integration for later. Cost if wrong: Conditional combined magnitude remains open.

3. Final: Ruling: Other non-damage strength — Keep separate from Healing Down. Cost if wrong: Other categories remain unfinished.

4. Final: Ruling: Controlled readiness — Keep captured action-state ownership. Cost if wrong: Controlled readiness acceptance remains open.

5. Final: Ruling: Other whole-action readiness — Keep separate state-aware integration. Cost if wrong: Other readiness remains open.

6. Final: Ruling: Noncompact EffectModifiers triggers — Retain unchanged individual deltas; popup/report only here. Cost if wrong: Trigger summary audit remains open.

7. Final: Ruling: Manual/authored-content acceptance — Keep separate public content reader gate. Cost if wrong: No full Manual/content acceptance.

8. Final: Ruling: Historical Chronicle/modal redesign — Keep unchanged historical fallback for later integration. Cost if wrong: Historical readers remain unfinished.

9. Final: Ruling: Ordinary incoming-damage summary arithmetic — Keep unchanged summary; extracted ratio module is separate. Cost if wrong: No fresh ordinary-summary arithmetic audit.

10. Final: Ruling: Legacy global damage budget — Do not infer a global clamp from an isolated rate. Cost if wrong: Full legacy damage-budget presentation remains open.

11. Final: Ruling: Mounted mouse — Leave native acceptance open; no browser session. Cost if wrong: Mouse behavior unverified.

12. Final: Ruling: Mounted touch — Leave native acceptance open; no browser session. Cost if wrong: Touch behavior unverified.

13. Final: Ruling: Mounted keyboard/focus — Source parity and SSR are insufficient. Cost if wrong: Native keyboard/focus acceptance remains open.

14. Final: Ruling: Assistive technology — Keep shared strings without claiming actual AT execution. Cost if wrong: AT output remains unverified.

15. Final: Ruling: Long-report layout — Reuse existing layout with physical gate open. Cost if wrong: Added text may expose overflow.

16. Final: Ruling: Small-screen geometry — No mounted viewport evidence closes this gate. Cost if wrong: Small-screen clipping remains unverified.

17. Final: Ruling: 200%zoom geometry — No physical zoom evidence closes this gate. Cost if wrong: Zoom clipping remains unverified.

18. Final: Ruling: Button/popup CSS sizing — No geometry changes or physical evidence. Cost if wrong: Physical sizing remains unverified.

19. Final: Ruling: Inspection backdrop dismissal — Retain unchanged outside-click ownership. Cost if wrong: Outside inspection still closes the whole inspection.

20. Final: Ruling: Whole malformed persisted validation — Keep parser authority; relevant constraints traced only. Cost if wrong: Whole-parser audit remains open.

21. Final: Ruling: Whole malformed pending validation — Keep pending parser authority; relevant projection traced. Cost if wrong: Full pending malformed-state acceptance remains open.

22. Final: Ruling: Whole summon validation — Summon behavior unchanged and separate. Cost if wrong: No fresh summon-parser audit.

23. Final: Ruling: Live expiry/revocation — Keep unchanged authority under Task8/16 gate. Cost if wrong: Hosted expiry/revocation acceptance required.

24. Final: Ruling: Alternate selected-character authority — Keep unchanged selected-character enforcement gate. Cost if wrong: No fresh alternate-character authority evidence.

25. Final: Ruling: Direct RPC/CAS bypass — Keep unchanged hosted authority gate. Cost if wrong: Hosted direct-RPC/CAS verification remains required.

26. Final: Ruling: No-input bounded gameplay — Execution unchanged; keep gameplay gate. Cost if wrong: No fresh complete no-input acceptance.

27. Final: Ruling: Duplicate payment/extra turns — Native payment/turn authority unchanged. Cost if wrong: Fresh complete payment/turn acceptance remains open.

28. Final: Ruling: Interrupted Move origins — Movement execution unchanged. Cost if wrong: Reached-origin gameplay acceptance remains open.

29. Final: Ruling: Publication/build/claim concurrency — Transactions/workers unchanged. Cost if wrong: Hosted concurrent operations remain unaccepted.

30. Final: Ruling: Recovery/settlement concurrency — Settlement authority unchanged. Cost if wrong: Reader tests do not establish concurrency safety.

31. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Witness still starts at origin.

32. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; capture test unchanged. Cost if wrong: Exact version coverage remains incomplete.

33. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; identity test unchanged. Cost if wrong: Identity witness remains weaker.

34. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

35. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission wording unchanged. Cost if wrong: Duplicate prefix wording remains.

36. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; no native change. Cost if wrong: Negative witness remains preparation-only.

37. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; event test unchanged. Cost if wrong: Events lack independent HP reconciliation.

38. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact historical value/label coverage incomplete.

39. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; no incidental editorial repair. Cost if wrong: Grammar defect remains.

40. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; Burn unchanged. Cost if wrong: Burn boundary wording remains imprecise.

41. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry remains unverified.

42. Final: Ruling: Cross-status input-immutability witness — Keep inherited Minor deferred; separate cohort. Cost if wrong: Its direct-input witness remains weaker.

43. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: no new status rows or demonstrated mounted failure. Cost if wrong: Expiry/replacement may misassociate popup state.

44. Final: Ruling: Whole-roster balance — Keep separate balance gate. Cost if wrong: Roster balance remains unaccepted.

45. Final: Ruling: Full natural combat cycles — Representative native fixtures cannot establish exhaustive cycles. Cost if wrong: Natural/full-cycle acceptance remains open.

46. Final: Ruling: Original combat/editor/control completion — A bounded reader does not complete those systems. Cost if wrong: Original combat integration remains unfinished.

47. Final: Ruling: Full Task15/16 — Keep whole-task acceptance separate. Cost if wrong: Task15/16 remain unfinished.

48. Final: Ruling: Owner-hosted acceptance — No hosted execution establishes acceptance. Cost if wrong: Hosted gate remains open.

49. Final: Ruling: Atlas motion/acceptance — Unchanged and outside reader checks. Cost if wrong: Atlas gate remains open.

50. Final: Ruling: Human gameplay acceptance — Source review and fixtures cannot establish human acceptance. Cost if wrong: Human gate remains open.

51. Final: Ruling: Publication/activation/migration readiness — Review supplies no operational approval. Cost if wrong: No content activation or hosted migration is authorized here.

52. Final: Ruling: Merge/deployment/release readiness — Keep final integration and release gates open. Cost if wrong: Combat update remains unreleased.

Initialroot191248136192exit0/8608Vitest+7NodeGREEN,butcombinedstdoutfileomitscompletedbuildtaildespitetoolcompletiontailshowingit;actualwebpackagebuildlogcomplete/preservedinitialhashaudit+tar. Finalizerblockedonmissingrootbuildsummary,notsourcefailure. ONEcachedrootreplayrequiredforcompletefinalreceipt;no sourcechange/noadditionaltestloop.

## Final Healing Down combined-rate checkpoint
# Healing Down combined recovery rates — verified development checkpoint

The shared live-effect reader now shows Healing Down's combined HP and MP recovery rates from its recorded applications. Values explicitly say **before rounding**, because native recovery rounds down after each applied modifier and caps restoration by missing resources. Two25% modifiers show56.25% before rounding; an actual9-point recovery restores4, rather than a nominal5.0625. Default then20% shows60% under current application stacking and80% under historical whole-row rules.

The captured recovery policy is independent of stacking policy. Current recovery rules apply Healing Down to HP, MP and Absorb. Historical rules leave MP recovery and Absorb unchanged; the reader explicitly retains that exception and shows MP100%. Previously captured percentage recovery keeps its recorded amount despite later status changes. Actual future ticks after cleansing and replacing Healing Down verify the existing captured56HP/MP (or100legacyMP), without recalculation or a second reduction.

Exact nominal rates use the existing shared BigInt ratio utilities. The damage helper now imports the same extracted functions with no arithmetic changes. Rates requiring more than two decimal places carry an approximation marker: two33.33% reductions show≈44.45% before rounding, while native10,000-point recovery is4444 after per-modifier truncation. A positive rate below displayed precision is never called zero. Extreme nominal precision beyond the shared65,536-bit capacity is unavailable, even when native integer recovery has already reached zero; the reader does not invent an exact nominal value or run an unbounded calculation.

The existing gold/orange summary rows and accessible report share the same HP/MP facts and qualifications. Pending rows say on activation. Exact known ID/version checks retain unavailable rules for unsupported captures. Covert retains its existing polarity rule: positive Damage Up is hidden from a spectator, while negative Healing Down remains public. No new public metadata, native operator, validation, persistence, schema, command, AI, manifest, control, CSS, artwork or geometry change.

## Verification and review

- BASEb4e3e537d01817b78e75ecb6810500009e8a3120 → initial reviewed `df53d50ba49ea70094fceb7945927018d9a031fb` → final tested `df53d50ba49ea70094fceb7945927018d9a031fb`. Five initial web source/test files; **34new cases overall**. The final report is a docs-only descendant of tested production source.
- Initial190903562217 had32 valid missing-rate/qualification failures, one incorrect Covert fixture expectation and one unsupported-version guard passing. The unchanged production filter intentionally retains negative debuffs under Covert. The corrected fixture checks positive Damage Up hidden and Healing Down visible with its rate. Corrected190949897695:33 valid missing-fact RED plus one guard GREEN. No privacy behavior was changed to fit a test.
- First implementation191017896193 passes64tests in two files:34new recovery-rate cases plus all30 previous damage-strength cases after extracting their arithmetic unchanged. Final initial focused **974tests/86files GREEN191122445549**, native Recovery/percentage/Absorb **125tests/5files GREEN191122446669**, web types191122448673 GREEN and zero-warning scoped lint191122445251 GREEN. Exact body and accessible HP/MP values, approximation/precision, pending, unknown rules, input immutability, capture freeze and Covert are covered.
- Native command cases cover flat HP/MP rounding across the full stacking/recovery-policy cross-product; actualMPDrain remains unmodified; actual restoration is capped by missingHP/MP. A real100damage command under25%Absorb and two25%HealingDown modifiers recovers13HP/MP under current recovery policy and25 under historical policy, matching the reader's explicit exception.
- Final exact-source full check: **8,608Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds GREEN. Receipt `20261016T191706229103Z`, 2026-10-16T19:17:06.229103+00:00 → 2026-10-16T19:17:37.031997+00:00. Package counts: worker 2, game-core 4136, db 118, audio 17, validation 106, realtime 3, web 4226. Complete final root build tail and package-log hash audit preserved. The initial fresh root191248136192 exited0 with all test counts and complete web package build log, but its combined saved stdout omitted the final build-summary lines. Initial audit/package logs are preserved; ONE cached root replay supplies this complete final receipt. No production source changed between them.
- All294 named Skill reports and HTML strings remain exactly unchanged from the preceding damage-strength checkpoint:294records,297groups,604effects; raw observation SHA256 `84defd352e91da4396a97663c24d346e553524fa5b7b6f8ce8ed4a2207c5f95c`. Manifest and six AI/native source hashes are unchanged. No new289-case gameplay matrix is claimed for this presentation-only cohort.

## Combined review disposition

One fresh read-only combined review finds **0Critical,0Important,0newMinor**. Parent accepts the assessment against actual native semantics and public/shared consumers. No repair wave or rereview. The extreme nominal-rate precision fallback is an explicit truthful limitation. Thirteen inherited Minors stay deferred. All52 separately declined behaviors receive individual parent reason/cost rulings below.


The new tests execute real native casts, turns, public spectator projection, shared report and actual SSR body. Only the server-only import marker is mocked. Source parity and SSR are not mounted DOM, native browser, assistive-technology or physical geometry acceptance. Both breakpoints and shared PvE/PvP/spectator readers inherit the same facts; native acceptance remains required.

## Remaining release work

The modular foundation already live, proposed Skill rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance remain pre-release requirements. Other non-damage/conditional strength and whole-action readiness, noncompact trigger summaries, historical Chronicle and public Manual references remain open. Full roster cycles, natural pacing/twelve-round balance, current Owner edits, hosted authority/CAS, Atlas motion and human acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is made here. High remains sufficient for routine integration. The provisional16–30activehours/roughly2–4fullworkingdays is an uncertain working estimate, not a calendar launch promise or a mechanically reduced count.

## Deferred Minors

Thirteen inherited items remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status input-immutability witness; legacy duplicate component keys. Any new reviewed Minor is listed in the review outcome above.

## Initial implementation decisions

1. Show nominal combined rate before integer rounding, with actual caps and frozen-capture qualifications. Reason: a rate alone cannot represent per-step truncation or missing resources. Cost if wrong: actual captures/outcomes remain necessary for exactHP/MP.
2. Keep recovery policy independent of stacking policy. Reason: native MP and Absorb paths check their own captured flag. Cost if wrong: cross-product coverage is required to prevent historical changes.
3. Extract and reuse the existing web ratio and percentage functions. Reason: damage and recovery nominal rates should not duplicate exact arithmetic. Cost if wrong: old30damage cases and full-root checks must guard the refactor.
4. Bound nominal exact precision and show unavailable at the existing shared capacity. Reason: native integer recovery can stop at zero while a positive formal fraction requires arbitrarily large precision. Cost if wrong: extreme valid nominal rates may be unavailable even when actual recovery is zero; no invented zero nominal value is shown.

## Every parent set-aside ruling

1. Final: Ruling: Final HP/MP forecasts — Keep nominal rates with rounding/cap/capture qualifications; final state is absent. Cost if wrong: Exact restoration still needs actual capture/outcome.

2. Final: Ruling: Conditional opponent/source/facing/HP damage — Leave unchanged context-aware damage integration for later. Cost if wrong: Conditional combined magnitude remains open.

3. Final: Ruling: Other non-damage strength — Keep separate from Healing Down. Cost if wrong: Other categories remain unfinished.

4. Final: Ruling: Controlled readiness — Keep captured action-state ownership. Cost if wrong: Controlled readiness acceptance remains open.

5. Final: Ruling: Other whole-action readiness — Keep separate state-aware integration. Cost if wrong: Other readiness remains open.

6. Final: Ruling: Noncompact EffectModifiers triggers — Retain unchanged individual deltas; popup/report only here. Cost if wrong: Trigger summary audit remains open.

7. Final: Ruling: Manual/authored-content acceptance — Keep separate public content reader gate. Cost if wrong: No full Manual/content acceptance.

8. Final: Ruling: Historical Chronicle/modal redesign — Keep unchanged historical fallback for later integration. Cost if wrong: Historical readers remain unfinished.

9. Final: Ruling: Ordinary incoming-damage summary arithmetic — Keep unchanged summary; extracted ratio module is separate. Cost if wrong: No fresh ordinary-summary arithmetic audit.

10. Final: Ruling: Legacy global damage budget — Do not infer a global clamp from an isolated rate. Cost if wrong: Full legacy damage-budget presentation remains open.

11. Final: Ruling: Mounted mouse — Leave native acceptance open; no browser session. Cost if wrong: Mouse behavior unverified.

12. Final: Ruling: Mounted touch — Leave native acceptance open; no browser session. Cost if wrong: Touch behavior unverified.

13. Final: Ruling: Mounted keyboard/focus — Source parity and SSR are insufficient. Cost if wrong: Native keyboard/focus acceptance remains open.

14. Final: Ruling: Assistive technology — Keep shared strings without claiming actual AT execution. Cost if wrong: AT output remains unverified.

15. Final: Ruling: Long-report layout — Reuse existing layout with physical gate open. Cost if wrong: Added text may expose overflow.

16. Final: Ruling: Small-screen geometry — No mounted viewport evidence closes this gate. Cost if wrong: Small-screen clipping remains unverified.

17. Final: Ruling: 200%zoom geometry — No physical zoom evidence closes this gate. Cost if wrong: Zoom clipping remains unverified.

18. Final: Ruling: Button/popup CSS sizing — No geometry changes or physical evidence. Cost if wrong: Physical sizing remains unverified.

19. Final: Ruling: Inspection backdrop dismissal — Retain unchanged outside-click ownership. Cost if wrong: Outside inspection still closes the whole inspection.

20. Final: Ruling: Whole malformed persisted validation — Keep parser authority; relevant constraints traced only. Cost if wrong: Whole-parser audit remains open.

21. Final: Ruling: Whole malformed pending validation — Keep pending parser authority; relevant projection traced. Cost if wrong: Full pending malformed-state acceptance remains open.

22. Final: Ruling: Whole summon validation — Summon behavior unchanged and separate. Cost if wrong: No fresh summon-parser audit.

23. Final: Ruling: Live expiry/revocation — Keep unchanged authority under Task8/16 gate. Cost if wrong: Hosted expiry/revocation acceptance required.

24. Final: Ruling: Alternate selected-character authority — Keep unchanged selected-character enforcement gate. Cost if wrong: No fresh alternate-character authority evidence.

25. Final: Ruling: Direct RPC/CAS bypass — Keep unchanged hosted authority gate. Cost if wrong: Hosted direct-RPC/CAS verification remains required.

26. Final: Ruling: No-input bounded gameplay — Execution unchanged; keep gameplay gate. Cost if wrong: No fresh complete no-input acceptance.

27. Final: Ruling: Duplicate payment/extra turns — Native payment/turn authority unchanged. Cost if wrong: Fresh complete payment/turn acceptance remains open.

28. Final: Ruling: Interrupted Move origins — Movement execution unchanged. Cost if wrong: Reached-origin gameplay acceptance remains open.

29. Final: Ruling: Publication/build/claim concurrency — Transactions/workers unchanged. Cost if wrong: Hosted concurrent operations remain unaccepted.

30. Final: Ruling: Recovery/settlement concurrency — Settlement authority unchanged. Cost if wrong: Reader tests do not establish concurrency safety.

31. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Witness still starts at origin.

32. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; capture test unchanged. Cost if wrong: Exact version coverage remains incomplete.

33. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; identity test unchanged. Cost if wrong: Identity witness remains weaker.

34. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

35. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission wording unchanged. Cost if wrong: Duplicate prefix wording remains.

36. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; no native change. Cost if wrong: Negative witness remains preparation-only.

37. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; event test unchanged. Cost if wrong: Events lack independent HP reconciliation.

38. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact historical value/label coverage incomplete.

39. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; no incidental editorial repair. Cost if wrong: Grammar defect remains.

40. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; Burn unchanged. Cost if wrong: Burn boundary wording remains imprecise.

41. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry remains unverified.

42. Final: Ruling: Cross-status input-immutability witness — Keep inherited Minor deferred; separate cohort. Cost if wrong: Its direct-input witness remains weaker.

43. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: no new status rows or demonstrated mounted failure. Cost if wrong: Expiry/replacement may misassociate popup state.

44. Final: Ruling: Whole-roster balance — Keep separate balance gate. Cost if wrong: Roster balance remains unaccepted.

45. Final: Ruling: Full natural combat cycles — Representative native fixtures cannot establish exhaustive cycles. Cost if wrong: Natural/full-cycle acceptance remains open.

46. Final: Ruling: Original combat/editor/control completion — A bounded reader does not complete those systems. Cost if wrong: Original combat integration remains unfinished.

47. Final: Ruling: Full Task15/16 — Keep whole-task acceptance separate. Cost if wrong: Task15/16 remain unfinished.

48. Final: Ruling: Owner-hosted acceptance — No hosted execution establishes acceptance. Cost if wrong: Hosted gate remains open.

49. Final: Ruling: Atlas motion/acceptance — Unchanged and outside reader checks. Cost if wrong: Atlas gate remains open.

50. Final: Ruling: Human gameplay acceptance — Source review and fixtures cannot establish human acceptance. Cost if wrong: Human gate remains open.

51. Final: Ruling: Publication/activation/migration readiness — Review supplies no operational approval. Cost if wrong: No content activation or hosted migration is authorized here.

52. Final: Ruling: Merge/deployment/release readiness — Keep final integration and release gates open. Cost if wrong: Combat update remains unreleased.



Finalcompletecachedroot1917062291038608+7/alltypes/lint/format/bothbuildsGREEN; initial191248136192stdoutbuild-summarygap andpackageauditpreserved. Docs92cdee2ecommitted. Firstbackupscriptguardretainedpreviouscohortreportbasenameandcorrectlystoppedbeforebundle/APIwrites;correctedonlyWallowedreportpathtoactualsix-filecohort. No sourcechange/noretestneeded.

Durable live-recovery-rate checkpoint 8c6271ebdca51a1b9f1c06569e0fcee678ce537a;root86035533ef9f2a999a801fbf3b7002f386cf3d26;checkpointsdf03d26cad2e807e48d16c67fc7ffc5bfce5e4e3. All4local/upload/remoteSHAs+freshlsremoteverified;main29506e29unchanged. Source92cdee2eb60a68db728666c956c8aa00f521934b/testeddf53d50ba49ea70094fceb7945927018d9a031fb/revieweddf53d50ba49ea70094fceb7945927018d9a031fb;onecombinedreview0C/0I/0newM/no repair/no rereview. Final8608Vitest+7Node/fulltypes/lint/format/bothbuildsGREEN191706229103;initial191248136192build-summarystdoutlossandpackageauditpreserved;ONEcachedcompletefinalreplay. All294reports/HTMLexact191248141373/hashguardsunchanged.34newcases/13inheritedMinorsdeferred/52individualdeclinedreason-costrulings+4initialimplementationrulings. Sourceworktreeclean/docs-onlydescendant. Native/AT/geometry/originalcombat/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. Nextread-onlytrigger-summary/conditional/readiness/Manual/Chronicle/editor/nativehandoffpreserved;no nextsourceedityet. No publication/activation/migration/merge/deploy. Highsufficient.

## Task15 conditional live strength cohort
# Task15 conditional Burn Ward and source-aware Taunt readers
BASE92cdee2eb60a68db728666c956c8aa00f521934b;previous8608+7/all294/durable8c6271ebverified. ExistingapprovedOwner§10/Task15inlinecontinuation;no newsubsystem/designapproval. Existingisolatedagentbranchclean. Bothbreakpoints/allsharedcompact/full/AllpopupPvE/PvP/spectatorsinheritonehelper.13Minorsdeferred/noincidentalfix. Onefreshcombinedreview/parentindividualdeclinedreason-cost/ONECIfixwaveifneeded/no rereview.

Read-onlycandidatecorrection: allactualBattleCombatantCardliveconsumershardcodecompact; noncompactEffectModifiersbranchhasnoactualproductioncaller. Leaveunusedbranchunchangedratherthanbuildnewreadoutthere. ActualsharedBattleEffectInformation/BattleEffectPopoverremainliveandownthisnextcohort.
Scope: extendexistingbattle-effect-strength-information.ts for knownversion1BurnWard(warded) andTaunt(challenged), unchangednativeoperators/DTO/schema/publicprivacy/controller/art/styles. Ward'sincomingmultiplierconditionalonburningopponents; actualsameconditionappliesacrossallrecordedapplications, exactratio/currentstackingvslegacyonce. Taunt'soutgoingmultiplierconditionalontargetotherthanthesource; combineonlyifallcurrentapplicationsshareoneknownsource. Currentmixedsources: no inventedcombinedrate; noteCombined damage depends on which source is attacked, preserveexistingexactperapplicationdescriptions. Legacyrootappliesonceusingroot source, ignorescurrentapplicationgroups. NeverdisplayrawsourceIDs. Pendinglabelsqualifyonactivation; neverimplyconditioncurrentlymet. KeepOtherdamage modifiersstillapplyplusconditionqualification. Unsupportedversionsunavailable; no outgoing/incomingHPforecast.
Nativeauthority damage-modifiers.ts conditionalDamageMultiplier/matchesCondition andcombatStatusApplications; exactsamearithmeticutilityaspriorunconditionals. Branchconditionsopponent-status burnandopponent-is-source matchesfalse; nativecurrentallapplications/per-sourceconditions,legacyrootonce. Actualnativeapply-statussourcesandprojectionreviewneededbeforecombining.

TDDrealnativecasts→publicspectatorprojection→sharedreportSSR/nativekernel/actualcommand. Wardcurrent/legacydefaulttwice64/80%;defaultthen30%=56/70%; oppositeBurnabsent100%/Burnpresentnativeexactvalue, actualenemy100damageafterBurnhitsactor64(current)or80(legacy). Tauntsourceactor vsnonsourceally:100%vstwo25%56.25(current)/75%(legacy), defaultthen20%60/80%; currentmixedsourcesactor+allynoonecombinedrate andactualnativeper-source7500vsboth5625;legacy latestrootone. Actualsourcechangesviaendturns/currentallycast,no fabricatednativeappidentity. Pendinglabels,unknownversion,zero/sourceprivacy/inputimmutability andexisting64damage/recoverycasesunchanged. Extremeexactcapacityfallbackexistingtruthfulunavailable; no newglobalclamp/orientation/otherconditionalcontextinvention.
ExpectedREDnewconditionalrows/qualificationsmissing,notimport/fixtureerrors. Focusedsharedbattle/projector+captured/amount/strength/recovery/conditionalfixtures+actualnativeconditionalcore/types/lint; finalroot8608+actualnewcount/all294reportsHTMLexact/hashguards. No fresh289forpurepresentation. Native/AT/geometry/fullTask15/16/originalcombat/editors/controls/readiness/Manual/Chronicle/cycles/balance/Ownerhosted/Atlas/human/releaseOPEN. No hostedwrite/publication/activation/migration/merge/deploy. Highsufficient.

Ruling: leaveunusednoncompacttriggerbranchunchanged — actuallivecardsusecompacticons/sharedpopup — costifwrong: retainednoncompactbranchdoesnotgaincombinedreadouts; no newdead-pathwork.
Ruling: combineWardunderitsoneexplicitBurnconditionandTauntonlywithonesourcecondition — allapplicationsmustqualifytogetherforoneconditionalrate — costifwrong: mixed-sourceTauntrequirescontextandretainsnoinventedaggregate.
Ruling: usepublicrecordedsourceidentityonlyforequality,neverdisplayit — sourcebindingisnecessarymechanicsbutnamingacastermayviolateconcealed-sourceprivacy — costifwrong: source-specificfulltargetforecastremainsseparatework.


Initialconditional192519385233:16validmissingconditionalrows/qualificationsRED,3unknown/CovertguardsGREEN,19cases; allnativeconditional/outcomechecksreachedexpectedbrancheswithoutfixtureerrors. Updatedoldunconditionalguardtorejectanexactunqualifiedrowlabelinsteadofsubstringthatwouldalsoexcludeproperlyqualifiedconditionalrows;contractpreserved/30casecountunchanged. No native/policy/projectionchange.

Initialconditional+oldstrength/recovery83tests/3GREEN192601771810. AddedtwoactualnativeignoreIncomingMitigationcontextcasesfortheWardprotectionbypasssecondaryrule;watchedmissingqualificationREDbeforeaddingnote. Existingoperatorsunchanged;thisdoesnotclaimallcurrentPierceignoreprotection(currentPierceequipmentArmorsemanticsremainseparate). Finalnewcasecount21,expectedwhole8629+7.

Finalinitial995focused/87filesGREEN192726288973;actualnativeconditional722/3GREEN192726308944;webtypes192726303535GREEN/zero-warninglint192726300094GREEN.21newcases/3websource-testfiles. Wardbypasssecondaryrule2validRED192643076992beforeitsnote→focusedGREEN. No native/projection/schema/AI/manifest/controller/style/artchanges;allsharedbothbreakpointspopupsinherithelper. Reactcondensed: no newhooks/fetch/state/listeners/dependencies/markupframework,existingCompactEffectSummaryandplaintext,sourceequalityonlynoIDdisplay. Unknown/current/legacy/pendingscopepreserved. Sourcefreeze/full8629+7/all294/onecombinedreviewrequired.

Onefreshcombinedreview7b6f813e:0C/1I/0newM; I1accepted: actualcompactgroupinglosespendingTauntsourceidentity. NativeRED193316620357twoexpectedgroupingfailures/23GREEN→ONEsharedgroupingrepair7262d0f0800da87914bcb8419bf2eda3ff30c3d1→25nativeGREEN193335309415. Fouraddedcasescurrent/legacydistinctsourcesandsamesourcepending,actualactivationnativeper-targetcomparison. Finalfocused999/87GREEN193349867191Z-e3d63ebd/types193349872727Z-6a8b9ada/lint193349862354Z-9b5c2c53.55individualdeclinedrulingssaved;13inheritedMinorsunchanged;no rereview. Finalsourcefrozen/all294exact193501475530Z-3007cba7/raw935d142977fea59f266c03a75931176df9939e2c22c434c77a5030b5f3c042e3/hashguardsunchanged. Initialroot8629+7exit0butcombinedsavedlogmissedbuildtail/rootdiagnosticsharedtimestampcollision;rawaudit/package-logspreserved. Ignoredrun.pyUUIDsuffixpreventslogfilenamecollision;freshrepairedroot8633+7required. No hostedwrite/publication/activation/migration/merge/deploy. Highsufficient.

## Final conditional live-strength checkpoint
# Conditional Burn Ward and source-aware Taunt — verified development checkpoint

Shared compact-card inspection now describes Burn Ward's combined incoming-damage factor only **against burning opponents**, and Taunt's outgoing factor only **against targets other than the source**. Pending rows explicitly say **on activation**. The report retains the condition qualification and “Other damage modifiers still apply.” Burn Ward also retains its secondary rule: damage that bypasses incoming protection is unaffected. This does not claim every current Pierce action bypasses protection.

Ward combines recorded applications under its common Burn condition. Two default 20% reductions show 64% under current application stacking and 80% under historical whole-row rules; default then 30% shows56% or 70%. Native damage is unchanged: without Burn the conditional kernel is 100%; with Burn the exact displayed factors apply, and actual 100-damage enemy attacks cause 64 or 80 HP damage under the respective rules.

Taunt combines current applications only when every application records the same known source. Two default 25% reductions show 56.25% current or 75% historical; default then 20% shows60% or 80%. Current mixed sources show no invented combined rate; the explanation says combined damage depends on which source is attacked and retains the recorded per-application descriptions. Historical rules apply the root potency/latest native source once. Source identity is used internally for equality and is never printed as a raw caster ID. This is an isolated conditional effect fact, not a selected-target forecast, command-readiness claim or final HP prediction.

The combined review exposed one real shared-path defect: public pending Taunt rows have a root source but no applicationModifiers; the existing card grouper merged two sources and retained the first. That made a false common-source factor possible. The ONE Important repair preserves Taunt source distinctions in the shared grouping key, as the existing source-scoped Mark path already does. Separate pending casters now retain separate 75% rows; same-source pending casts still combine. No application set is reconstructed from lost data. On actual activation current sources yield 75% against either caster and 56.25% against a third target. Historical activation uses the latest caster, yielding 75% against the first and 100% against the latest.

## Scope and live consumers

Actual BattleCombatantCard consumers hardcode compact, across the shared playable PvE/PvP cockpit and spectator surface. Compact icons open the shared BattleEffectPopover/BattleEffectInformation report, which inherits these facts on both breakpoints. Source tracing found no production caller of the retained noncompact EffectModifiers branch; that unused branch is unchanged. Its individual-delta design is not a reason to add dead-path UI. If a future Master/other consumer mounts it, revisit its readouts then.

Four source/test files changed from BASE92cdee2eb60a68db728666c956c8aa00f521934b; this report is a fifth, docs-only file. No native operator, policy, DTO, schema, validation, AI, manifest, command, control, CSS, artwork or geometry change. Grouping separates Taunt source conditions without exposing new public data. Unknown ID/version rules remain unavailable; positive Ward remains hidden from a spectator under actual Covert. Input state remains unchanged by reading.

## Verification and review

- Initially reviewed source: 7b6f813e03c4b946836c69a006a3354dc8ea8a0f. Final tested repaired source: 7262d0f0800da87914bcb8419bf2eda3ff30c3d1. Final report is a docs-only descendant.
- Initial RED192519385233:16 valid missing conditional-row/qualification failures, three unknown/Covert guards passing. Native checks passed before reader failures. The old negative guard now rejects an exact unqualified label, preserving its intent while allowing explicit conditional labels. Existing 30 unconditional cases are retained.
- Initial 83 cases GREEN192601771810. Two actual native protection-bypass cases then failed for the missing Ward secondary-rule note in RED192643076992 before that note was added. Initial focused995/87files, native conditional 722/3 files, webtypes and zero-warning lint passed.
- Important repair RED193316620357: two valid distinct-source grouping failures;23 cases already passed. GREEN193335309415:25/25. Four added cases run real pending casts, public spectator projection, actual live grouping, shared report/SSR, then actual native round activation and target comparisons; same-source current/historical aggregation also remains correct.
- Repaired focused **999tests/87files GREEN193349867191Z-e3d63ebd**; webtypes193349872727Z-6a8b9ada and zero-warning scopedlint193349862354Z-9b5c2c53 GREEN. **25 new cases overall** from the previous8608-case baseline.
- Final exact-source root: **8,633Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds GREEN. Receipt 20261016T193500220138Z-78b64a70, 2026-10-16T19:35:00.220138+00:00 → 2026-10-16T19:38:54.880250+00:00. Package counts: realtime 3, audio 17, validation 106, db 118, worker 2, game-core 4136, web 4251. Complete root build tail/package-log hash audit preserved.
- Initial reviewed-source root192842001155 exited0 with8629+7; its saved combined stdout omitted the final build-summary lines, and initial root/diagnostic timestamp collision interleaved their logs. Initial audit/package logs and raw data are preserved. Ignored evidence runner now adds a UUID suffix to prevent filename collisions. Repaired production source required the fresh final root above; the initial incomplete stdout is not used as final proof.
- All 294 named Skill reports and HTML strings remain exactly unchanged from the preceding recovery-rate checkpoint:294 records, 297 groups, 604 effects, observation SHA256 935d142977fea59f266c03a75931176df9939e2c22c434c77a5030b5f3c042e3. Repaired-source diagnostic193501475530Z-3007cba7 GREEN. Manifest and six AI/native source hashes remain unchanged. No fresh289-case gameplay matrix is claimed for this presentation-only work.

# Combined review outcome

One fresh combined review at7b6f813e03c4b946836c69a006a3354dc8ea8a0f: 0Critical,1Important(I1),0newMinor. Parent accepts I1 for player-visible target-dependent misinformation; ONE repair wave only and no rereview. Grouping retains source identity for Taunt. Four native regression cases cover current/historical different-source pending casts and same-source aggregation. RED193316620357: two expected grouping failures,23cases GREEN; GREEN193335309415:25cases including actual next-round activation and native target comparisons. Fifty-five declined behaviors each have an individual parent reason/cost in live-conditional-strength-review-rulings.md. Thirteen inherited Minors remain deferred; no incidental fixes. Final broader verification and backup follow separately.



Actual native casts/turns/kernel/commands, public spectator projection, shared grouping/report and SSR are exercised. Only the server-only import marker is mocked. Source parity and SSR do not establish mounted DOM, native mouse/touch/keyboard, AT, focus restoration, physical overflow/clipping or 200% zoom acceptance. No new browser installation/tunnel attempt was made.

## Remaining release work

The modular foundation already live, proposed Skill rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled, full controls/editors/readers/previews and native acceptance remain pre-release requirements. Whole-action readiness, public Manual rich references, historical Chronicle fallback and complete editor previews remain open. Other conditional/non-damage values require actual context and must not infer target/source/facing from an isolated status.

Full Task 15/16, natural roster cycles, twelve-round pacing/balance, current Owner edits, hosted authority/CAS, Atlas motion (.830568 versus<.75), human acceptance and final release gates remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat. No publication, activation, hosted migration, merge or deployment is performed. The deployment lock is retained. High remains sufficient for routine integration.

## Deferred Minors

Thirteen inherited items remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing-pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal historical values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status input-immutability witness; legacy duplicate component keys. No new Minor was found and no incidental repair was made.

## Initial implementation decisions

1. Leave unused noncompact trigger summaries unchanged. Reason: all actual cards use compact icons/shared popups. Cost: that retained branch has no new combined readouts if mounted later.
2. Combine Ward under one Burn condition and Taunt only under one known source condition. Reason: one conditional aggregate requires every included application to qualify together. Cost: mixed-source Taunt retains per-application facts without a single aggregate.
3. Compare public recorded source identity internally without naming the caster. Reason: mechanics need equality while source naming requires a separate privacy-aware presentation contract. Cost: no full source-named target forecast.
4. Preserve Taunt source distinctions in grouping. Reason: pending rows have no captured application set to reconstruct. Cost: separate pending casters occupy separate existing rows, and future legacy duplicate-key mounted acceptance remains open.

## Every parent set-aside ruling

# Parent review rulings

I1 accepted as Important: the live compact-card path can present a false source-bound conditional rate before activation. Repair the grouping authority, retaining source IDs for challenged rows exactly as existing source-scoped Mark retains them. Do not synthesize application data. Reason: each pending source must retain its condition through projection → grouping → reader; actual native activation differs by target. Cost: different pending casters occupy separate existing rows; this avoids inventing a merged target forecast and does not display raw source IDs. Current/legacy and same-source preservation must pass actual native tests.

ONE Critical/Important repair wave only; no new reviewer or rereview. No new Minor. Thirteen inherited Minors remain deferred.

1. **Mounted mouse interaction** — Ruling/reason: Keep native gate open; no browser execution was permitted. Cost if wrong: Click/dismiss behavior remains physically unaccepted.

2. **Mounted touch interaction** — Ruling/reason: Keep device gate open; no touch/browser execution was permitted. Cost if wrong: Touch behavior remains physically unaccepted.

3. **Mounted keyboard navigation and focus restoration** — Ruling/reason: SSR/source tracing cannot establish mounted physical behavior. Cost if wrong: Keyboard/focus restoration remains unaccepted.

4. **Assistive-technology output** — Ruling/reason: No AT execution; plain accessible text coverage is narrower. Cost if wrong: Actual spoken output remains unaccepted.

5. **Long-report physical overflow** — Ruling/reason: SSR has no layout measurements. Cost if wrong: Long reports still need mounted overflow checks.

6. **Small-screen clipping and geometry** — Ruling/reason: No viewport execution. Cost if wrong: Small-screen layout remains unaccepted.

7. **200% zoom geometry** — Ruling/reason: No physical zoom execution. Cost if wrong: Zoom layout remains unaccepted.

8. **Popup/button CSS sizing** — Ruling/reason: CSS unchanged; no physical inspection. Cost if wrong: Sizing remains unaccepted.

9. **Inspection-backdrop dismissal behavior** — Ruling/reason: Interaction owner unchanged; this cohort changes values/grouping. Cost if wrong: Backdrop dismissal still needs native acceptance.

10. **Unused noncompact EffectModifiers trigger summaries** — Ruling/reason: Actual cards hardcode compact; no production caller was found. Cost if wrong: Retained unused branch gains no combined summary.

11. **Source-specific forecasts or caster naming** — Ruling/reason: Conditional facts use private source equality; naming needs its own privacy-aware contract. Cost if wrong: No full source-named target forecast is supplied.

12. **Other conditional modifier families** — Ruling/reason: Known Ward/Taunt scope is bounded; other conditions require their own real context. Cost if wrong: Other conditional readers remain unfinished.

13. **Whole-action readiness** — Ruling/reason: Effect helper does not own command legality or eligibility. Cost if wrong: Whole-action readiness remains unfinished.

14. **Legacy whole-attack global min/max** — Ruling/reason: Isolated effect factors cannot represent the whole attack budget. Cost if wrong: Combined attack forecast remains separate.

15. **Ordinary incoming-summary arithmetic** — Ruling/reason: Separate implementation unchanged; do not mix unrelated arithmetic repair. Cost if wrong: Existing incoming-summary behavior remains.

16. **Extreme native arithmetic capacity policy** — Ruling/reason: Preserve truthful bounded unavailable fallback; no numeric-policy redesign. Cost if wrong: Extreme nominal rates may be unavailable.

17. **Full malformed persisted-state validation** — Ruling/reason: Relevant capture constraints traced; no comprehensive parser audit. Cost if wrong: Malformed-state audit remains open.

18. **Full malformed pending-payload validation** — Ruling/reason: Projection traced; no comprehensive pending-schema audit. Cost if wrong: Malformed pending-state audit remains open.

19. **Summon serialization/validation** — Ruling/reason: Unchanged and unrelated to Ward/Taunt. Cost if wrong: Summon validation remains outside this checkpoint.

20. **Live expiry/revocation enforcement** — Ruling/reason: Authority unchanged; no hosted execution. Cost if wrong: Live authority acceptance remains open.

21. **Alternate selected-character enforcement** — Ruling/reason: Authority unchanged. Cost if wrong: Selected-character enforcement acceptance remains open.

22. **Direct RPC/CAS bypass resistance** — Ruling/reason: No hosted/RPC checks authorized here. Cost if wrong: Hosted bypass-resistance acceptance remains open.

23. **No-input/free-priming bounds** — Ruling/reason: Native command execution unchanged. Cost if wrong: Priming gameplay acceptance remains open.

24. **Duplicate payment behavior** — Ruling/reason: Payment authority unchanged. Cost if wrong: Payment acceptance remains open.

25. **Extra-turn behavior** — Ruling/reason: Turn authority unchanged. Cost if wrong: Extra-turn acceptance remains open.

26. **Interrupted Move reached-origin legality** — Ruling/reason: Movement execution unchanged; preserve original required integration. Cost if wrong: Movement acceptance remains open.

27. **Concurrent publication** — Ruling/reason: Transactions unchanged; no publication performed. Cost if wrong: Publication race acceptance remains open.

28. **Concurrent build and claim** — Ruling/reason: Transactions unchanged. Cost if wrong: Build/claim race acceptance remains open.

29. **Concurrent recovery and settlement** — Ruling/reason: Worker/settlement unchanged. Cost if wrong: Settlement race acceptance remains open.

30. **Manual/public authored-content completeness** — Ruling/reason: Separate content acceptance; not inferred from effect readers. Cost if wrong: Manual/public content remains unfinished.

31. **Historical Chronicle/modal redesign** — Ruling/reason: Historical reader owner unchanged. Cost if wrong: Chronicle integration remains unfinished.

32. **Rewind witness origin** — Ruling/reason: Keep inherited Minor deferred; unrelated fixture. Cost if wrong: Witness still starts at origin.

33. **Supporting Shot version pin** — Ruling/reason: Keep inherited Minor deferred; unrelated capture coverage. Cost if wrong: Explicit version witness remains absent.

34. **Ongoing-pair dynamic identity pin** — Ruling/reason: Keep inherited Minor deferred; unrelated identity witness. Cost if wrong: Dynamic identity witness remains incomplete.

35. **Repeated bounded AI discovery** — Ruling/reason: Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

36. **Admission double-prefix provenance** — Ruling/reason: Keep inherited Minor deferred; wording unchanged. Cost if wrong: Duplicate-prefix wording remains.

37. **Ranged negative direct-commit witness** — Ruling/reason: Keep inherited Minor deferred; native preparation/commit unchanged. Cost if wrong: Negative witness remains preparation-only.

38. **Independent defense-positive HP reconciliation** — Ruling/reason: Keep inherited Minor deferred; event witness unchanged. Cost if wrong: Events lack independent HP reconciliation.

39. **Exact Arsenal historical values** — Ruling/reason: Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact historical values/labels remain incompletely pinned.

40. **Singular status-clock grammar** — Ruling/reason: Keep inherited Minor deferred; no incidental editorial repair. Cost if wrong: Grammar defect remains.

41. **Burn ordinary tick-boundary wording** — Ruling/reason: Keep inherited Minor deferred; ordinary Burn unchanged. Cost if wrong: Boundary wording remains imprecise.

42. **Master inline reference-button sizing** — Ruling/reason: Keep inherited Minor deferred; different surface. Cost if wrong: Master geometry remains unaccepted.

43. **Cross-status direct-input immutability witness** — Ruling/reason: Keep inherited Minor deferred; separate cohort. Cost if wrong: That witness remains weaker.

44. **Legacy duplicate component keys** — Ruling/reason: Keep inherited Minor deferred; no demonstrated mounted failure; source separation fixes the reviewed Taunt loss only. Cost if wrong: Legacy expiry/replacement state reuse still needs mounted acceptance.

45. **Complete original combat/editor/control integration** — Ruling/reason: This bounded reader cohort cannot establish full integration. Cost if wrong: Original pre-release work remains unfinished.

46. **Full roster natural combat cycles** — Ruling/reason: Representative native fixtures are not exhaustive cycles. Cost if wrong: Full natural cycles remain unaccepted.

47. **Whole-roster balance and twelve-round pacing** — Ruling/reason: No balance evaluation in a reader cohort. Cost if wrong: Balance/pacing remains unaccepted.

48. **Full Task15 acceptance** — Ruling/reason: Bounded implementation is part of the larger task. Cost if wrong: Task15 remains unfinished.

49. **Full Task16 acceptance** — Ruling/reason: Final integrated gate not performed. Cost if wrong: Task16 remains unfinished.

50. **Current Owner-hosted content acceptance** — Ruling/reason: No hosted access or changes. Cost if wrong: Current Owner edits remain to reconcile.

51. **Atlas motion acceptance** — Ruling/reason: No animation/runtime inspection; existing .830568 versus <.75 gap remains. Cost if wrong: Atlas motion remains unaccepted.

52. **Human gameplay acceptance** — Ruling/reason: Source/fixtures cannot establish human acceptance. Cost if wrong: Human acceptance remains open.

53. **Publication/activation/migration readiness** — Ruling/reason: No operational review/authorization in this checkpoint. Cost if wrong: No publication, activation or hosted migration is authorized.

54. **Merge/deployment/release readiness** — Ruling/reason: Keep final integration/release gates open. Cost if wrong: Combat overhaul remains unreleased.

55. **Independent reviewer test-total verification** — Ruling/reason: Reviewer was prohibited from executing tests; parent must verify receipts directly. Cost if wrong: Totals depend on parent-run evidence, not independent rerun.




Finalrepairedroot193500220138Z-78b64a70GREEN8633Vitest+7Node/allformatlinttypes/bothbuilds;completebuildtail/no replayneeded. All294exact935d142977fea59f266c03a75931176df9939e2c22c434c77a5030b5f3c042e3/hashguardsunchanged. Finaldocsonly93de5d82bbdbf3bfe871cbe204f4567626d20d9a/source-tested7262d0f0/reviewed7b6f813e. Four source/testfiles+report;25newcases;ONEI1repair/norereview/55individualreasoncostdeclines/13deferredMinors. Durablebackupnext. No hostedwrite/publication/activation/migration/merge/deploy.

Finalreportreadabilitycorrectionbeforeupload: localunsharedownlatestdocscommitamendedf8ff229b28245151cb22399c3c59f452f167df97;stilldocsonlydescendant7262d0f0/no productionchange/noretestneeded. Prior93de5d82wasneveruploaded. Finalreportcontainsall55individualrulingsandactualfreshverificationreceipts.

Durable conditional Ward/Taunt checkpoint 509cc491712c4a22fd2909a1ce333903343bff61;root5e8f5e085aa4363795c98cb14836184a28bf9957;checkpointsaab17a10c024438547b001e52eb93f74435dcc23. All4local/upload/remoteSHAs+freshAPIrefs verified;main29506e29unchanged. Source/docsf8ff229b28245151cb22399c3c59f452f167df97/tested7262d0f0800da87914bcb8419bf2eda3ff30c3d1/reviewed7b6f813e03c4b946836c69a006a3354dc8ea8a0f. Final8633Vitest+7Node/fullformatlinttypes/bothbuildsGREEN193500220138Z-78b64a70/completebuildtail/no replay. All294reports/HTMLexact/raw935d142977fea59f266c03a75931176df9939e2c22c434c77a5030b5f3c042e3/hashguardsunchanged.25newnativecases/onecombinedreview0C1I0newM/ONEI1groupingrepair/no rereview/55individualreasoncostdeclines/13inheritedMinorsdeferred. Sourceworktreeclean/docs-onlydescendant. Native/AT/geometry/originalcombat/fullTask15/16/readiness/Manual/Chronicle/editor/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. No hostedwrite/publication/activation/migration/merge/deploy. Highsufficient.

## Captured Controlled command availability
# Task15 captured Controlled command availability

BASE f8ff229b28245151cb22399c3c59f452f167df97; previous full8633+7 and durable509cc491 verified. Continue approved Owner§7/§10 and accepted Manual picker design, inline/High. Existing isolated branch/workspace/plan; no new subsystem. Higher-priority persistent approved scope permits finishing the specified integration without asking again. Personal Context search skipped: visible state/current source suffice.

Source finding: native Controlled availability reports spent after cancellation or committed release; once-per-character/ability/battle admission remains used. Shared captured descriptor and cockpit payment presentation do not consume this terminal phase. Skill/Essence/Manual Resonance and Basic artwork can remain enabled (even stale readyID), while server rejects release. Fix the actual consumer path, not native rules.

Ruling: phase spent disables only that captured Controlled action/group, preserving ordinary Manual groups, historical absent metadata and information access — native semantics own availability — cost if wrong: consumed Controlled artwork cannot be selected, but readable details and unrelated supported Manual choices remain available.
Ruling: retain definition costs independent of availability — an unavailable action is not free — cost if wrong: UI needs an additional availability flag rather than changing numeric affordability.
Ruling: no new primed decoration or Release button — approved cockpit contract — cost if wrong: readiness still needs a complete legal current-intent forecast and real native acceptance.

Tests first: real prime→release/cancel→owner projection→descriptor/intent factories and actual Skill/Essence/Resonance/Basic SSR. Reject stale ready flags after spend. Preserve before/primed current captures, exact modifiers, different ordinary group, actual costs/no-pay cancel, owner privacy and historical metadata behavior. Use server-only marker mock only. Basic tests all five editable records where capture supports Controlled; correct real fixture errors without changing product rules. Expected RED is enabled spent command or nonnull spent intent, not import/schema errors. Focused shared battle/projector + native Controlled/bundle/composition + webtypes/lint; final root8633+actualnewcases and294staticreport/HTML exact/hashguards. Do not repeat existing mechanics or change AI/core/schema/public metadata/CSS/art.

One fresh combined reviewer for bounded cohort at frozen source; parent individual declined reason/cost; ONE C/I RED→GREEN repair/no rereview;13 inherited Minors deferred. Final report/docs-only commit and authorized recovery branch backup with exact blob/ref verification. No publication/activation/hostedmigration/merge/deploy. Original combat/fullTask15/16/browser/AT/geometry/fullcycles/balance/Ownerhosted/Atlas/human/release remain OPEN; broader unrelated panel follows combat. High sufficient.



# Combined Controlled command availability review
BASE f8ff229b28245151cb22399c3c59f452f167df97
HEAD 465020f2c89f38691b7ad596932e36f14701ee1e
Review all six changed source/test files, including the new346-line fixture. Use the actual code-reviewer.md template at /root/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/requesting-code-review/code-reviewer.md.

Requirements: task15-controlled-command-availability-brief.md; Owner§7/§10 and later ready-only correction; approved docs/superpowers/specs/2026-10-16-manual-modifier-picker-design.md and root/scopedAGENTS. Native controlled phase spent after release/cancel cannot invite a new action. Preserve same-source ordinaryManualgroups/historical absentmetadata/costs/infoaccess/freeprime/primedlegalrelease/lockedmodifiercontracts/customkeys/boardlayout. Shared PvE/PvP/bothbreakpoints. No core/schema/publicprojection/nativecost/control/CSS/art change.

Current checks: initial195400566375 eight real spent descriptor/artwork RED, threeguardsGREEN. Basic fixtures first incorrectly changed unsupported Move timing, then incorrectly attached follow-up effects to per-terrain-point Move; parser correctly rejected. Corrected fixtures use explicit flat overall Move price + one supported Controlled damage payload. Basic gating temporarily removed and corrected195612060404 five valid enabled-spent-commands RED,11skipped, then restored. Final876focused/82filesGREEN195646317858; webtypes195713495744,lint195713495745,native73/4files195713491291GREEN;format/diffcheckGREEN.19newcases, full8652+7 and294staticcomparisonrunning separately. Only server-onlymarker mocked; realnativeprime/release/cancel→ownerprojection→intentfactories/SSR. Do not infer mounted/native/AT/geometry acceptance.

Trace actual source-to-consumer spent gating, everyBasic/Skill/Essence/Resonance, selected/ambiguous groups, cooldown/cost distinction, explicit lockedmodifiers and actualsharedBattleExperience forwarding. Look for a reasonable user's impact, not spec silence. One fresh combined read-only reviewer. No tests, service/browser/native/network, mutations or subagents. Do not independently rerun suites; parent owns receiptverification. Report actual Critical/Important/Minor withfilelines and every considered-but-declined behavior individually withreason; no pooleddeclines. Parent gradesactualimpact, ONECIfix/no rereview.13inheritedMinors remain deferred (see latest verificationreport/progressledger); do not silently close or fix them. No releaseapproval.

## Review Focus (verbatim)

- A stale browser, alternate selected character or direct RPC must not bypass live expiry/revocation/CAS. Task8 exercises these actual authority paths; Task16 verifies them with the finished workspaces.
- Malformed nested/captured/pending/summon data must fail closed without leaking private accuracy or replacing old definitions with current content. Tasks1/5/7 exercise wrong types, recursive serialization and immutable capture.
- No input, free priming, repeated events and interrupted Move must not produce unbounded damage, duplicate payment, extra turns or attacks from an unreached tile. Tasks2/3A/4 and14–16 exercise those paths.
- Concurrent publication/build/claim/recovery/settlement must either commit a coherent result once or return a specific retry/no-contest outcome. Tasks5/6/9/12/16 test actual rollback, locks and late/repeated workers.
- Long names, missing historical metadata, mobile/native keyboard and 200% zoom must retain truthful mechanics and accessible primary controls. Tasks7–13/16 inspect actual components/screens and distinguish fixtures from hosted/human evidence.


Reactcondensedcheck: derivedbooleansduringrender/no newstate/effects/listeners/fetch;type-onlyprop/no runtimebarrel/newdeps;disabledartworkkeepsinfoi accessible;sharedsamebothbreakpoints/nogeometrychange. Productfrozen465020f2.

Combinedreview465020f2:0C/2I/0newM. ParentacceptsI1pointer/touchgroupselectionlockoutandI2Basicallspentambiguouscaptureloss. ONErepair: sharedavailabilityhelperindependentofprice/selecteddescriptor;actualartworkretainschooseanotheractionwithoutautocast/groupdrafttargetsreset;armingcooldown/costgatesallowchooseronly;allspentBasicartdisabledbyactualownercaptures. RED20024412448711validfailures/19passes;Basicmixedchoicefalsification2004269976525validfailures/30skipped;repaired1034focused/88filesGREEN200454694110/types200454709745/lint200454688617.35newcases/finalsource97d4b3d0da7d6135d740da446276e1ffab92b353.65individualdeclinedreason-costrulings/13inheritedMinorsdeferred/no rereview. Initialroot8652+7exit0butsavedbuildsummarygap/packageauditpreserved. Finalrepairedroot8668+7/all294running. No hostedwrite/publication/activation/migration/merge/deploy. Highsufficient.

## Final spent Controlled command checkpoint
# Spent Controlled commands — verified development checkpoint

After a Controlled action has been released or its prime cancelled, its captured group can no longer arm an executable command. The shared cockpit disables the artwork when every group is spent. Its information button stays accessible. When another ordinary Manual group remains, artwork instead offers an explicit group chooser. Opening it clears the old group, attachments and targets without selecting or casting a replacement. A stale ready signal or prime hint cannot override the captured spent state or turn a chooser into a ready action. The accessible command label explains “already used this battle”; no new primed decoration, Release button, artwork change or command slot is introduced.

Native once-per-character/ability/battle admission already rejected another prime or release. The defect was in the consumers: captured descriptor resolution and cockpit cost presentation did not consume the terminal phase. The shared descriptor now becomes unavailable for a selected spent Controlled group, so existing target/initial/directional/range factories and the executeIntent guard reject it. The payment adapter separately reports controlledSpent without changing affordability or definition costs. Skill, Essence and active Manual Resonance buttons use that flag; actual BattleExperience forwards availability aggregated from the Basic's owner captures even when no group is resolved to Move, Basic Attack and the current Support artwork.

This applies through the shared playable PvE/PvP cockpit on both breakpoints. Other ordinary Manual groups in the same source remain selectable and legal. Unprimed/free-prime and legally primed release behavior remain unchanged. Historical absence of Controlled metadata retains existing behavior. Private source identity, capture fields, payment, cooldowns, limits, effect execution and prime reconciliation remain native authority.

## Verification

BASE f8ff229b28245151cb22399c3c59f452f167df97 → reviewed 465020f2c89f38691b7ad596932e36f14701ee1e → final tested 97d4b3d0da7d6135d740da446276e1ffab92b353. Six source/test files changed initially; this report is a docs-only descendant. No game-core, schema, public projection, persistence, AI, manifest, control bindings, CSS, artwork or geometry changes.

- Initial RED195400566375Z-893bf67b reproduced eight real failures: spent descriptor intent creation plus enabled Skill/Essence/Resonance artwork after native release/cancel. Three guards passed. The native state already reported spent and rejected reuse.
- Basic fixtures initially attempted unsupported Controlled timing on Move, then attached extra effects to per-terrain-point walking. Both parser rejections were correct. Fixtures were corrected to an explicit flat overall Move price and a supported Controlled damage payload alongside the other effects. No native legality or cost rule changed to fit a test.
- With Basic spent gating removed, corrected RED195612060404Z-1c7abfd1 showed five actual enabled-spent Basic commands, with no fixture error. Restoring that guard made them pass. Default per-terrain-point native walking remains unchanged.
- **35 new native lifecycle cases overall (19 initial plus 16 review regressions)** cover prime/release/cancel, owner projection, descriptor/intent factories and actual shared SSR for Skill/Essence/Manual Resonance and all five editable Basics. Basic coverage includes the current equipped Guard/HP Recovery/MP Recovery choices. Ordinary Manual groups remain legal after the same ability's Controlled action is consumed. Cancel spends no HP/MP; the displayed captured 11 AP / 2 MP / 1 HP price remains intact; spectators receive no owner action choices. Before prime there is no readiness glow; a legally primed action remains available with its existing ready signal.
- Final initial focused **876 tests /82 files GREEN**195646317858Z-33b41d99; web types195713495744Z-efd5f02a and zero-warning scoped lint195713495745Z-ce7d94ed GREEN. Correct native Controlled/configured/bundle/composition suite **73 tests /4 files GREEN**195713491291Z-e91fd0bd. An earlier command used a nonexistent bundle filename and therefore ran only the other two matching files (72 tests); the later correctly named four-file run is the evidence for73.
- The combined review found two Important multi-group gaps. ONE correction wave adds a deliberate chooser for a spent selected group with another ordinary group, and independent all-spent Basic aggregation. Review RED200244124487:11 valid failures/19 passing; additional Basic mixed-choice falsification200426997652:five valid failures/30 skipped. Final repaired focused **1,034 tests /88 files GREEN**200454694110Z-7e5f6f2c;types200454709745Z-36739318 and zero-warninglint200454688617Z-0ccff72c GREEN. No rereview.
- Initial reviewed-source full check195801168899 exited0 with8652+7, but saved stdout lacked its final build summary despite the tool completion tail. Initial audit/package logs are preserved. The changed repaired source required the fresh full check below, not a redundant cached replay.
- Final exact-source root: **8,668 Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds GREEN. Receipt 20261016T200529920491Z-9af33b15, 2026-10-16T20:05:29.920491+00:00 → 2026-10-16T20:09:24.752071+00:00. Counts: realtime 3, audio 17, validation 106, db 118, worker 2, game-core 4136, web 4286. Complete root build tail and package-log hash audit are preserved.
- All 294 named Skill reports and HTML are exactly unchanged from the preceding conditional Ward/Taunt checkpoint:294 records,297 groups,604 effects. Observation SHA256 53993a97d7b856591c63d22cf08ddae50dd6d48f4b9d6297ef6e1e3d9e65ab39. Manifest and six AI/native source hashes remain unchanged. This does not claim a fresh 289-case gameplay matrix.

## Combined review and parent decisions

One fresh combined review of465020f2: **0 Critical,2 Important,0 new Minor**. Parent accepted I1 (pointer/touch access to another ordinary group) and I2 (ambiguous all-spent Basic aggregation). Both addressed in ONE test-first repair wave, final tested97d4b3d0da7d6135d740da446276e1ffab92b353. Eleven valid review regressions RED200244124487 plus five Basic mixed-choice falsification failures200426997652 →1034focused/88files GREEN200454694110;types/lintGREEN.35newnativecasesoverall. No rereview;13inheritedMinorsdeferred. Every reviewer-declined behavior has an individual parent reason/cost below (65rulings; expanded grouped review lines). Native/AT/geometry/fullTask 15/16/release remain open.


## Evidence limits and next work

Only the server-only import marker is mocked in the new fixture. Actual native lifecycle, projection and shared SSR are tested; this is not mounted browser, physical keyboard/touch, assistive-technology, focus or geometry acceptance. No repeat browser installation or tunnel attempt was made.

The existing Manual picker already carries exact selected references through prime, locked release, preview and direct commit. This checkpoint fixes spent-command availability; it does not replace that implementation or claim every readiness flow accepted. Whole-action current-intent readiness, complete Manual/public references, Chronicle fallback and full editor previews still need final integration/acceptance.

The live modular foundation, proposed rebalance and original unfinished combat integration remain separate. Original Targeting/Move/five editable Basics/Controlled and controls/editors/readers/previews remain pre-release requirements until their complete chains and native acceptance pass. Full Task 15/16, full natural cycles, twelve-round pacing/balance, current Owner edits, hosted SQL/CAS, Atlas motion and human acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is performed. Deployment lock retained. High remains sufficient for routine integration. The provisional 16–30 active-hour estimate remains uncertain and is not a calendar launch promise.

## Deferred Minors

Thirteen inherited Minors remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing-pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal historical values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status direct-input immutability witness; legacy duplicate component keys. Any new reviewer Minor is listed in the review outcome.

## Initial rulings

1. Disable only the selected spent Controlled group, preserving ordinary Manual groups and information access. Reason: native phase owns availability. Cost if wrong: consumed Controlled artwork cannot arm a command; unrelated Manual groups must remain available.
2. Keep definition price/affordability independent of spent availability. Reason: unavailable does not mean free. Cost if wrong: consumers must read the new derived spent flag as well as affordability.
3. Preserve no primed decoration/no extra Release button. Reason: approved cockpit contract. Cost if wrong: readiness still depends on a complete legal current-intent forecast and native acceptance.
4. Correct Basic fixtures to supported flat-price Move composition. Reason: per-terrain-point walking is pure native movement; follow-up effects require a flat overall Skill price. Cost if wrong: this lifecycle test does not claim a new per-tile composition mechanic.

## Every parent set-aside ruling

# Parent rulings

I1 accepted Important: a legal ordinary group must remain reachable from artwork with pointer/touch after consuming selected Controlled group. Repair provides an explicit choose-another-action route, clears group/draft/targets and arms only the group selector, never silently chooses/casts replacement. UI affordability/cooldown no longer prevents opening that chooser; legal execution keeps server/payment guards. Reason: preserving a legal group in data is insufficient if its only selection path disappears. Cost: artwork may remain enabled solely to choose another group, without readiness or a current action claim.

I2 accepted Important: Basic all-spent aggregation must consume actual owner captures independently of group resolution. Shared battleCapturedControlledAvailability serves both cost adapter and actualBasicforwarding. All-Controlled/spent groups disable artwork even with no selected group; mixedordinary groups retain choice. Reason: an ambiguous descriptor intentionally has no selectedcontrolledrecord, which is insufficient evidence ofavailability. Cost: Basicforwardingnowtakesderivedaggregateavailability;selectedgroupstillownsmechanics.

ONE Critical/Important repair wave. InitialnewrepairRED20024412448711validfailures/19passes. AdditionalBasicmixedchoicefalsification200426997652fivevalidfailures/30skippedbeforecorrectbranchrestored. GREEN repairedfocused1034/88files200454694110/types200454709745/lint200454688617.35newnativecasesoverall(19initial+16repair). No rereview;13inheritedMinorsremain;no newMinor.

1. **Changing once-per-group admission** — Ruling/reason: Native ownership is once per battle/character/ability; consume that authority. Cost if wrong: Native once-per-ability admission remains; no per-group reprime.

2. **Making spent costs zero** — Ruling/reason: Availability and payment remain separate. Cost if wrong: Price still shows the captured activation cost.

3. **Allowing stale ready to override spent** — Ruling/reason: Component gates suppress readiness; actual readiness also checks descriptor availability. Cost if wrong: Readiness is not accepted without a legal current intent.

4. **Changing free-prime affordability** — Ruling/reason: Structural admission and paid release are intentionally different. Cost if wrong: Free admission still differs from paid release.

5. **Adding primed decoration or Release button** — Ruling/reason: Approved interaction contract excludes both. Cost if wrong: No primed decoration/extra Release control is added.

6. **Disabling every group when one is spent** — Ruling/reason: Ordinary Manual groups remain native-legal; I1 identifies access regression. Cost if wrong: Ordinary-group access must be preserved by I1 repair.

7. **Automatically choosing another Manual group** — Ruling/reason: Ambiguity requires deliberate selection. Cost if wrong: The player must choose the group explicitly.

8. **Historical captures without Controlled metadata** — Ruling/reason: Optional metadata does not infer spend; historical envelope/cost fallback remains. Cost if wrong: Historical metadata remains weaker but is not invented.

9. **Replacing missing canonical captures with current definitions** — Ruling/reason: Missing/ambiguous canonical references fail closed. Cost if wrong: Missing canonical captures remain unavailable.

10. **Changing native/Manual attachment selection** — Ruling/reason: References remain bound through intent metadata; primed metadata exclusively owns captured refs/empty set. Cost if wrong: Exact attachment ownership/locked set remains required.

11. **Reopening spent attachments for editing** — Ruling/reason: Primed/spent resolution stays locked; spent intents blocked. Cost if wrong: Captured attachment editing remains forbidden.

12. **Keyboard command bypass** — Ruling/reason: Unavailable descriptors still guard executeIntent; no native authority change. Cost if wrong: Actual mounted keyboard acceptance remains open.

13. **Directional/target/range bypass** — Ruling/reason: Existing factories consume descriptor unavailability. Cost if wrong: Physical input and full targeting acceptance remain open.

14. **Rearm notice** — Ruling/reason: Not an independent Important; corrected chooser branch explains deliberate selection. Cost if wrong: Other rejected hotkey notices may remain generic.

15. **Per-terrain-point Move follow-up damage** — Ruling/reason: Unsupported by native parser; preserve pure walking. Cost if wrong: Controlled composed Move must use a flat overall Skill price.

16. **Attached Move price** — Ruling/reason: Unchanged included-cost contract. Cost if wrong: No new per-tile fee is authorized.

17. **Reached-origin mechanics** — Ruling/reason: Execution unchanged. Cost if wrong: Interrupted Move acceptance remains open.

18. **Guided Practice Guard** — Ruling/reason: No real exposure established; do not change hypothetical practice content. Cost if wrong: If edited Controlled practice Guard becomes reachable, it needs an explicit gate.

19. **Stale browser** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

20. **Alternate selected actor** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

21. **Direct RPC bypass** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

22. **Live expiry** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

23. **Revocation** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

24. **Authority CAS** — Ruling/reason: No authority change; keep actual Tasks8/16 verification separate. Cost if wrong: Live authority acceptance remains open.

25. **Malformed nested state** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

26. **Malformed captured data** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

27. **Malformed pending data** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

28. **Malformed summon data** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

29. **Private accuracy serialization** — Ruling/reason: Parser/serialization/projection unchanged; no full audit in this review. Cost if wrong: The dedicated validation/privacy acceptance remains required.

30. **Duplicate payment** — Ruling/reason: Native execution unchanged; representative reader tests are narrower. Cost if wrong: Broader execution acceptance remains required.

31. **Repeated events** — Ruling/reason: Native execution unchanged; representative reader tests are narrower. Cost if wrong: Broader execution acceptance remains required.

32. **No-input/extra-turn bounds** — Ruling/reason: Native execution unchanged; representative reader tests are narrower. Cost if wrong: Broader execution acceptance remains required.

33. **Interrupted movement** — Ruling/reason: Native execution unchanged; representative reader tests are narrower. Cost if wrong: Broader execution acceptance remains required.

34. **Concurrent publication** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

35. **Concurrent build** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

36. **Concurrent claim** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

37. **Concurrent recovery** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

38. **Concurrent settlement** — Ruling/reason: Transaction/worker authority unchanged. Cost if wrong: The corresponding concurrency gate remains open.

39. **Mounted keyboard** — Ruling/reason: Source/SSR does not establish physical interaction. Cost if wrong: Actual interaction acceptance remains open.

40. **Mounted touch** — Ruling/reason: Source/SSR does not establish physical interaction. Cost if wrong: Actual interaction acceptance remains open.

41. **Native browser** — Ruling/reason: Source/SSR does not establish physical interaction. Cost if wrong: Actual interaction acceptance remains open.

42. **Assistive technology** — Ruling/reason: No physical/AT execution. Cost if wrong: Physical/accessibility acceptance remains open.

43. **Long-name layout** — Ruling/reason: No physical/AT execution. Cost if wrong: Physical/accessibility acceptance remains open.

44. **Narrow-screen geometry** — Ruling/reason: No physical/AT execution. Cost if wrong: Physical/accessibility acceptance remains open.

45. **200%zoom** — Ruling/reason: No physical/AT execution. Cost if wrong: Physical/accessibility acceptance remains open.

46. **Full roster natural cycles** — Ruling/reason: Bounded availability cases do not establish whole-roster acceptance. Cost if wrong: Gameplay/balance acceptance remains open.

47. **Natural pacing** — Ruling/reason: Bounded availability cases do not establish whole-roster acceptance. Cost if wrong: Gameplay/balance acceptance remains open.

48. **Twelve-round balance** — Ruling/reason: Bounded availability cases do not establish whole-roster acceptance. Cost if wrong: Gameplay/balance acceptance remains open.

49. **Current hosted Owner edits** — Ruling/reason: Outside this source-only cohort; no hosted changes. Cost if wrong: The named final acceptance gate remains open.

50. **Hosted SQL/CAS reconciliation** — Ruling/reason: Outside this source-only cohort; no hosted changes. Cost if wrong: The named final acceptance gate remains open.

51. **Atlas motion** — Ruling/reason: Outside this source-only cohort; no hosted changes. Cost if wrong: The named final acceptance gate remains open.

52. **Human acceptance** — Ruling/reason: Outside this source-only cohort; no hosted changes. Cost if wrong: The named final acceptance gate remains open.

53. **Rewind witness origin** — Ruling/reason: Inherited Minor retained; unrelated witness. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

54. **Supporting Shot version pin** — Ruling/reason: Inherited Minor retained; capture hardening unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

55. **Ongoing pair dynamic identity pin** — Ruling/reason: Inherited Minor retained; identity witness unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

56. **Repeated bounded AI discovery** — Ruling/reason: Inherited Minor retained; AI unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

57. **Admission double-prefix provenance** — Ruling/reason: Inherited Minor retained; wording unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

58. **Ranged negative direct-commit witness** — Ruling/reason: Inherited Minor retained; witness remains preparation-only. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

59. **Independent defense-positive HP reconciliation** — Ruling/reason: Inherited Minor retained; event witness unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

60. **Exact Arsenal history values** — Ruling/reason: Inherited Minor retained; historical coverage unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

61. **Singular status-clock grammar** — Ruling/reason: Inherited Minor retained; unrelated wording. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

62. **Burn ordinary tick-boundary wording** — Ruling/reason: Inherited Minor retained; timing description unchanged. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

63. **Master inline reference-button sizing** — Ruling/reason: Inherited Minor retained; separate geometry surface. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

64. **Cross-status direct-input immutability witness** — Ruling/reason: Inherited Minor retained; separate cohort. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.

65. **Legacy duplicate component keys** — Ruling/reason: Inherited Minor retained; no mounted reconciliation claim. Cost if wrong: The inherited Minor remains deferred; no incidental repair in this cohort.




Durable Controlled command availability checkpoint cc887a44c5f16c556062e8995bce4156c2e254b1;root71a467bd294e874a22cf7bda2512ea49ce33aa9e;checkpoints970cde01c74bfe93f743a7024a6474299f674a12. All4local/upload/remoteSHAs+freshAPIrefs/lsremoteverified;main29506e29unchanged. Source/docs62aaebb264bfec2e130868aad6a2fdd1f6b3427a/tested97d4b3d0da7d6135d740da446276e1ffab92b353/reviewed465020f2c89f38691b7ad596932e36f14701ee1e. Final8668Vitest+7Node/fullformatlinttypes/bothbuildsGREEN200529920491Z-9af33b15/completebuildtail/no replay.35newcases(19initial+16repair)/onefreshreview0C2I0newM/ONEI1/I2repair/no rereview/65individualdeclinedreasoncostrulings/13inheritedMinorsdeferred. All294namedreports/HTMLexact/raw53993a97d7b856591c63d22cf08ddae50dd6d48f4b9d6297ef6e1e3d9e65ab39/hashguardsunchanged. Sourceclean/docs-onlydescendant. ActualManualpicker/exactrefs/lockedprimeimplementationexists;spentavailabilitynowintegratedinclmixedexplicitchooserandallspentBasics. Nextread-onlywholecurrentreadiness/nativeacceptance/Manualrichreferences/Chronicle/editorinventory;donotrebuildcompletedpaths. Fulloriginalcombat/Task15/16/native/AT/geometry/cycles/balance/Ownerhosted/Atlas/human/releaseOPEN. No publication/activation/hostedmigration/merge/deploy. Highsufficient.

## Public Manual typed mechanics
# Task15 public Manual typed mechanics

BASE62aaebb264bfec2e130868aad6a2fdd1f6b3427a; prior8668+7/durablecc887a44verified. ExistingapprovedOwner§10/Task15 continuation, inline/High; no new subsystem. CurrentpublicManualroute alreadydoesonecoherent currentcatalogue read and correctpublicprojection. Its canonicalSkill/Basic summaryproducer discards typed condition/requirement/explanation references and compact effectparts into plainstrings. ManualArticle rendersdisclosurebulletsasplaintext. Scopefinishthisexistingchainwithoutchangingarticlewordingor publication authority.

Ruling: add optional typed inline metadata only togeneratedcanonicalSkill/Basic catalogue disclosurebullets — preserve existingstringbullets as authoritative fallback and shared CompactEffectSummary/MechanicTextView — costifwrong: nativelegacySkillrows, statusdictionarytableandstaticarticleprose remainplain; no naiveautolinking.
Ruling: validate metadata plain output against exactbullet before rendering — stale/missing/unsupporteddatafallsbacktoescapedtext, never today’sdictionary replacingwords — costifwrong: mismatch loses styling/links ratherthan changingmechanics.
Ruling: do not change Chronicle without a concretecurrent-sourcegap — existingpinnedcontextalreadycompletedandunrelatedreaderworkmustnotrebuildit — costifwrong: remaininghistoricalChronicleacceptance staysopen.
Ruling: maintain repeatedgroup boundaries/limits/maintenance/recipients/conditionalwording; do not replacecompactcataloguewithhundredsoffullparametercards — actualarticleflowalreadyexists — costifwrong: completeinteractivepreview/nativegeometryacceptance remainsseparate.

Beforeproductedit: saveprechangeManualbodyplainbaselineforactualbuiltinandproposed136regularSkills+5Basics. Shiptests actualcanonicaldefinitions→articlebuilder→actualManualArticleSSR. Literalnativeconditions/referencecounts/plaintext/inheritedtiming/mixedgroups/conditions/directdamageorange/Basicpertraversal/missingstalemalformedmetadata/escaping/disabledfilter/matchingmetadataunknown/immutability. Onlymock unavoidableboundary ifobserved; no service/network/browser. ExpectedREDmissingtypedreference/colorbodymarkup with nativeparser/reportplainalreadycorrect. Addpureinlinepresentationpartsandguard,producertransportandsharedrenderer; no core/schema/API/persistence/AI/manifest/control/CSS/art changes. StaticpublicManualonly; no gameplayclaim.
FinalfocusedManual/content/publicroute/characterreferencespluswebtypeslint/full8668+newcases;exactManualplainbaseline/native+proposedandall294namedreports/HTML/hashguards. Onefreshcombinedreview/frozenrange,parentindividualreasoncost/ONECIfix/no rereview/13inheritedMinorsdeferred. Guardedreport/docs-onlycommit/durableauthorizedrecoverybranchbackup. No hostedwrite/publication/activation/migration/merge/deploy;originalcombat/fullTask15/16/native/AT/geometry/editor/cycles/balance/Ownerhosted/Atlas/human/releaseOPEN. Highsufficient.


Preproductplainbaseline201607524291Z-a576fa86GREEN: actualbuiltin136Skills/5Basics andproposed136Skills/5Basics;fullarticleplaintextsaved. ExistingChroniclepinnedcontextreviewedread-only;no concretegapchosen. CurrentpublicManualcoherentcatalogueroutealreadycomplete;finishplainflatteningseamonly.

ManualTDD: first201709fixtureinvalidFiremissingrequiredpolicy2companion; correctedfixtureaddedexplicitselfChilledremoval,notproductionrulechange.201742fivevalidmissingrichfailures+oneincorrectescapedSkillnameexpectation(nativeskilltitlesderiveID); useactualBasicnameescapingguard instead. Corrected201808fivevalidmissingmarkup/linkfailures+10guardsGREEN. Initialimplementation20191713/15GREEN: fixtureFiredescriptionhastypedreferenceonlyinactualFrozenGroundreport,sochangedtesttorealproposedFrostweaverGrounddefinitionratherthannaiveautolinking. BasicMoveexactrowTargetdisplaydiffersfromtypedselfrecipient;202050nativeMoveone missingcompactrow plusmalformedtimingcoercionRED. Pureproducerusesactualcanonicaltargetkindself;strictstringtimingguard;20210616/16GREEN. Exactplainarticlebaselineforboth136Skills+5Basicsunchanged202123. Broaderroute202122oldrawHTMLassertMove[2]failsnowspanssplittext;updatedtovisibletextassertionplusactualcompactmarkup,privacy/exactcataloguereadguardsretained. No mechanics/wordingchange.

# Public Manual mechanics combined review
BASE62aaebb264bfec2e130868aad6a2fdd1f6b3427a
HEAD1ead4e9351b28bd57159eeb9acfe736a225566aa
All7changedsource/testfiles including3newfiles. Actual /root/.codex/plugins/cache/openai-curated-remote/superpowers/6.4.2/skills/requesting-code-review/code-reviewer.md template. Requirements: task15-public-manual-mechanics-brief.md, existingapprovedOwner§10/Task15/currentManualcatalogue contract/rootAGENTS.
CurrentManualroute coherentcatalogue/publicprojection alreadyexists and isunchanged. Generator adds optionalbulletParts only tocanonicalSkills/Basicdisclosures. Existingstringbullet remains authoritative; renderer validates shape+exact visibleplaintext before sharedMechanicTextView/CompactEffectSummary. Actualcanonicaltargetkind self controlsrecipientomission; noprosetextinference. NativelegacySkillbullets/statusdictionarytable/staticproseremainplain. Noarticlewording/gameplay/core/schema/API/persistence/AI/manifest/control/CSS/artchanges.
Tests: firstFirefixturemissingpolicy2companion correctlyrejected; correctedexplicitselfChilledremoval. InitialvalidRED5missingreferences/colors+10guards201808 afterfixingincorrectnativeSkillnameescapingfixture(useactualBasicname). FrozenGround/Firetypedrefsverifiedfromactualproposal ratherthannaivetextlinking. BasicMovetargetdisplayvsrealselfkindgate andstrictmalformedtimingcoercion RED202050→16GREEN202106. Exactallplaintextbothbuiltin/proposed136Skills+5Basics baseline/observationequal202123. Focused391/44filesGREEN202207234834,webtypes202122638652,zero-warninglint202207231933,format/diffcheckGREEN. RouteoldrawHTMLMove[2]assertfailedduespanmarkup; nowassertactualvisibletextplusmarkup;privacy/coherentcataloguechecksretained. Newfixtureusesactualparser/builder/ManualArticle/sharedSSR/NextImagewithNOmocks.16newcases/fullroot8684+7/all294running.
Reviewactualproductionreach currentroute→publiccatalogue→generator→bodymetadata→ManualArticle→sharedrenderer, type/shape guards/plainpreservation/stalemetadata/unknownnestedparts/noautolinks/conditions/recipients/groups/costs/limits/maintenance/context/privatefieldavoidance/performance/accessibility. Popoverparentlessnestedfallback is existing sharedbehavior; source/SSR notmounted/native/AT/geometry. No tests/services/network/browser/native/mutations/subagents. Onefreshcombinedreviewonly;reportC/I/Minorwithfilelines andeveryindividuallydeclinedbehaviorwithreason. Parentgradesbyrealplayerimpact,ONECIfix/no rereview.13inheritedMinorsdeferred; no releaseorfullTask15/16acceptance.

## Review Focus (verbatim)

- A stale browser, alternate selected character or direct RPC must not bypass live expiry/revocation/CAS. Task8 exercises these actual authority paths; Task16 verifies them with the finished workspaces.
- Malformed nested/captured/pending/summon data must fail closed without leaking private accuracy or replacing old definitions with current content. Tasks1/5/7 exercise wrong types, recursive serialization and immutable capture.
- No input, free priming, repeated events and interrupted Move must not produce unbounded damage, duplicate payment, extra turns or attacks from an unreached tile. Tasks2/3A/4 and14–16 exercise those paths.
- Concurrent publication/build/claim/recovery/settlement must either commit a coherent result once or return a specific retry/no-contest outcome. Tasks5/6/9/12/16 test actual rollback, locks and late/repeated workers.
- Long names, missing historical metadata, mobile/native keyboard and 200% zoom must retain truthful mechanics and accessible primary controls. Tasks7–13/16 inspect actual components/screens and distinguish fixtures from hosted/human evidence.


Reactcondensed:no newhooks/state/effects/fetch/listeners/dependencies;plainservermetadata/typedclientreferenceleafprops;reuseexistingpopovers/colors;nocss/art/geometrychange;source/SSRonlynotnativeacceptance. Frozen1ead4e9351b28bd57159eeb9acfe736a225566aa

## Public Manual mechanics final checkpoint
# Public Manual mechanics — verified development checkpoint

Canonical Skill and Basic summaries in the public Manual now retain the shared typed mechanic presentation. Requirements, effect conditions and explicitly authored reference terms use the existing explanation controls. Effect names, values, durations and timing use the existing compact renderer. The exact original bullet remains authoritative: missing, stale or unsupported annotations fall back to that escaped text.

The route already reads one coherent current catalogue and applies the public projection. This checkpoint completes the presentation seam between its report generator and ManualArticle; it does not change publication or catalogue authority. Repeated action groups, conditions, recipients, limits, maintenance and native Basic traversal pricing keep their previous wording. Canonical targeting determines self omission; the displayed “Empty Ground” label does not infer a recipient.

Native legacy Skill bullets, the status dictionary table and static article prose remain plain. No arbitrary word linking is introduced. No concrete current-source Chronicle gap was found, so that existing pinned context was not rebuilt.

## Reviewed source and correction

BASE 62aaebb264bfec2e130868aad6a2fdd1f6b3427a → reviewed 1ead4e9351b28bd57159eeb9acfe736a225566aa → final tested 4b05948226468f4b53a97042e1d4e0b211ed219f. Seven initial source/test files plus one Manual CSS correction; this report is a docs-only descendant.

The fresh combined review found no Critical issue, one Important issue and one new Minor. The Important issue was a real integration regression: shared pale gold and teal labels lost contrast on the Manual's parchment surface. ONE repair wave adds scoped dark orange and teal colors for these markers. Names and magnitudes retain the same color. Existing reference underlines and focus-visible currentColor outlines remain; shared dark readers are unchanged. The original no-CSS ruling has this bounded exception.

The source contrast calculation reproduced the defect in RED202810589220Z-e1fc1089. The first candidate202819028546Z-94e4326d remained below 4.5:1 at the darkest overlay. Final GREEN202826122264Z-73f31ff6 calculates minimum contrast 4.7317:1 for orange and4.6595:1 for teal across source gradient endpoints and overlay combinations. This is source-derived numerical evidence, not a mounted-browser measurement or native/AT/geometry acceptance.

M1 remains deferred: the unknown-reference fixture also has mismatching visible text, so it does not isolate matching-text rejection. Production validation correctly rejects unknown nodes. Thirteen inherited Minors plus this new coverage weakness remain deferred, fourteen total. No incidental Minor repair and no rereview.

## Verification

- Sixteen new native-definition → actual report builder → actual ManualArticle/shared SSR cases use no mocks. They cover typed requirements/conditions, actual proposed Frozen Ground references, separate Manual/Ongoing groups, compact values, all five Basics, traversal prices, input immutability, escaping and missing/stale/unsupported metadata.
- Initial valid RED201808960527Z-5588879b reproduced five missing reference/markup failures with ten guards already passing. Actual Move self-recipient rendering and coercible malformed timing produced two valid failures in RED202050785034Z-2ccc0da6; all sixteen passed202106740835Z-ec4f9806.
- Fixture corrections preserved native legality: Fire required its supported companion; actual Skill titles derive identity so escaping uses a real Basic name; typed Ground references come from the real proposed Frozen Ground report rather than inferred Fire prose. Route assertions now compare visible text where spans split raw HTML, while retaining actual shared markup and privacy/coherent-read guards.
- Focused **391 tests /44 files GREEN**, both initial202207234834Z-0511f4c4 and repaired202826122263Z-38a7503b. Initial web types202122638652Z-1be24831 and zero-warning scoped lint202207231933Z-a197755f GREEN; final root repeats these gates.
- Final exact-source root **8,684 Vitest plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN. Receipt 20261016T203114900254Z-40abffbf, 2026-10-16T20:31:14.900254+00:00 → 2026-10-16T20:35:12.831679+00:00. Package counts: worker 2, realtime 3, validation 106, audio 17, db 118, game-core 4136, web 4302. Complete root build tail and package-log hash audit are preserved.
- Reviewed-source initial root202314170422Z-74743f23 also passed 8684+7 with complete build tail. The first repaired-source attempt202842928832Z-d891069d was interrupted during lint and has no completed receipt; its partial log is retained. The fresh completed final receipt above is the claimed evidence.
- Full plain article data exactly match the preproduct baseline for both builtins and proposals: **136 regular Skills plus five Basics each**. SHA256 1bd2b9ef74551bc2e0b36322958180630454aeb056e9b5af1755f9f749b3203c.
- Actual complete rich-versus-plain ManualArticle SSR also retains exactly the same visible text for both catalogues, receipt202937069049Z-81382d86. Builtins keep their 136 legacy Skill rows plain and render five compact Basics; proposals render 249 compact effects and 43 explicit reference controls. Rendering counts do not certify opening or operating a control.
- All **294 named Skill reports and HTML** remain exactly unchanged from the previous reader checkpoint (297 groups,604 effects). Observation SHA256 fbc16c5c24ca3eaa132246265a585f91d2c7a602f2dc5b05a2794718c26bd7c2. The proposal manifest and six AI/native hashes are unchanged. No fresh 289-case gameplay matrix is claimed.

## Evidence boundaries and launch work

This slice adds no hooks, effects, event listeners, service reads, dependencies, private authoring fields, execution math, schema, persistence, control binding or artwork changes. The only CSS change is the scoped readability correction. The existing parentless shared popover fallback is reused.

SSR and source calculations are not mounted interaction, physical keyboard/touch, screen-reader, focus, mobile geometry, zoom or browser performance acceptance. Existing browser limitations remain; no repeated installation or tunnel attempt was made.

The modular foundation is already live. Proposed rebalance and the original unfinished combat integration remain separate. Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance remain pre-release requirements. Full Task 15/16, whole-action current-intent readiness, full equipped natural cycles, twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion and human/release acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is performed. Git auto-deployment lock remains in place. High remains sufficient for routine integration. The earlier 16–30 active-working-hour estimate remains provisional and is not a calendar promise.

## Parent review decisions

# Parent decisions

I1 accepted Important: actual public learning text loses contrast on parchment. ONE repair wave applies Manual-scoped marker colors as a bounded exception to the no-CSS ruling. Dark-reader styles, label/value equality and currentColor focus outline remain. Cost if wrong: numerical source evidence does not replace native/AT/geometry acceptance.

M1 deferred Minor: production rejects unknown tags correctly; the matching-text fixture is weaker than intended. Reason: a coverage weakness without observed reader failure. Cost if wrong: isolated matching-text unknown-tag rejection lacks a direct regression witness. Thirteen inherited plus one new Minor = fourteen deferred. No incidental Minor repair; no rereview.

## Every declined behavior

1. **Native legacy Skill linking** — Ruling/reason: Its unchanged plain path is deliberately outside this typed canonical catalogue cohort. Cost if wrong: Legacy Skill bullets remain plain.

2. **Status dictionary linking** — Ruling/reason: This table has no typed transport in the approved cohort. Cost if wrong: Dictionary rows retain plain rendering.

3. **Static article prose linking** — Ruling/reason: Typed provenance is absent; automatic word matching could invent a reference. Cost if wrong: Static prose remains plain.

4. **Replacing compact disclosures with full cards** — Ruling/reason: The approved catalogue retains compact summaries. Cost if wrong: Full parameter-card interactions remain separate.

5. **Chronicle changes** — Ruling/reason: No concrete current-source gap was found here. Cost if wrong: Historical reader acceptance remains separate.

6. **Reworking current catalogue publication** — Ruling/reason: The actual route already reads one coherent snapshot. Cost if wrong: Existing catalogue authority is reused.

7. **Fallback to builtins after catalogue failure** — Ruling/reason: Silently resurrecting stale content would violate catalogue authority. Cost if wrong: Catalogue errors keep their existing failure path.

8. **Disabled content resurrection** — Ruling/reason: Existing public filtering and route guards remain in place. Cost if wrong: No additional disabled-content behavior is certified.

9. **Additional private-data projection** — Ruling/reason: The recursive public projection precedes generation and metadata contains presentation fields. Cost if wrong: Future private fields still require projection review.

10. **Executable getters, proxies or prototypes** — Ruling/reason: This server-generated JSON presentation boundary adds no external runtime metadata ingestion. Cost if wrong: Arbitrary executable objects are not certified as inputs.

11. **Unknown nested reference nodes** — Ruling/reason: The guard checks supported nested identities; production behavior is correct. Cost if wrong: The matching-text regression weakness is deferred as M1.

12. **Stale nested label text** — Ruling/reason: The shared renderer retains its exact-label fallback. Cost if wrong: Stale annotations lose their link instead of rewriting words.

13. **Absent explanation strings** — Ruling/reason: The existing renderer returns a plain label rather than inventing dictionary content. Cost if wrong: Missing explanations are unavailable.

14. **Malformed timing coercion** — Ruling/reason: Strict string validation and the isolated matching-text fixture reject it. Cost if wrong: Unsupported timing metadata falls back to plain text.

15. **Recipient inference from Empty Ground text** — Ruling/reason: Canonical targeting kind owns self omission. Cost if wrong: Display wording does not determine recipients.

16. **Conditional Fire claims** — Ruling/reason: Only actual typed report references are transported. Cost if wrong: Ordinary prose is not automatically linked.

17. **Ground condition claims** — Ruling/reason: Only actual typed report references are transported. Cost if wrong: Ordinary prose is not automatically linked.

18. **Repeated group merging** — Ruling/reason: Groups retain their numbering, boundaries and own values. Cost if wrong: No collapsed or combined execution is introduced.

19. **Overall Skill cost** — Ruling/reason: This presentation change leaves native costs and wording intact. Cost if wrong: Existing included-cost and native walking rules retain authority.

20. **Attached Move included cost** — Ruling/reason: This presentation change leaves native costs and wording intact. Cost if wrong: Existing included-cost and native walking rules retain authority.

21. **Native Basic walking cost** — Ruling/reason: This presentation change leaves native costs and wording intact. Cost if wrong: Existing included-cost and native walking rules retain authority.

22. **Parentless nested popovers** — Ruling/reason: The existing shared fallback supports a root reader without a parent. Cost if wrong: Mounted ownership acceptance remains open.

23. **Outside-click consumption** — Ruling/reason: The shared dismissal behavior is intentionally reused. Cost if wrong: This cohort does not certify new dismissal semantics.

24. **Opened explanation escaping evidence** — Ruling/reason: Closed SSR does not include the explanation; JSX already renders it as text. Cost if wrong: The new SSR test is not proof of an opened explanation.

25. **Mounted keyboard** — Ruling/reason: Source and SSR cannot establish physical interaction. Cost if wrong: Mounted/native interaction acceptance remains open.

26. **Mounted touch** — Ruling/reason: Source and SSR cannot establish physical interaction. Cost if wrong: Mounted/native interaction acceptance remains open.

27. **Mounted focus** — Ruling/reason: Source and SSR cannot establish physical interaction. Cost if wrong: Mounted/native interaction acceptance remains open.

28. **Screen-reader acceptance** — Ruling/reason: SSR attributes do not establish assistive-technology behavior. Cost if wrong: AT acceptance remains open.

29. **Long-name wrapping** — Ruling/reason: The existing layout is retained without mounted measurement. Cost if wrong: Actual layout acceptance remains open.

30. **Mobile geometry** — Ruling/reason: The existing layout is retained without mounted measurement. Cost if wrong: Actual layout acceptance remains open.

31. **200% zoom** — Ruling/reason: The existing layout is retained without mounted measurement. Cost if wrong: Actual layout acceptance remains open.

32. **Catalogue-scale browser performance** — Ruling/reason: Generation remains linear and adds no per-reference network calls. Cost if wrong: Hydration and browser performance remain unmeasured.

33. **Live expiry** — Ruling/reason: The underlying authority paths are unchanged. Cost if wrong: Dedicated final authority acceptance remains required.

34. **Live revocation** — Ruling/reason: The underlying authority paths are unchanged. Cost if wrong: Dedicated final authority acceptance remains required.

35. **Alternate selected character** — Ruling/reason: The underlying authority paths are unchanged. Cost if wrong: Dedicated final authority acceptance remains required.

36. **Direct RPC authority** — Ruling/reason: The underlying authority paths are unchanged. Cost if wrong: Dedicated final authority acceptance remains required.

37. **Captured execution** — Ruling/reason: Engine and persistence paths are unchanged. Cost if wrong: No new execution certification is claimed.

38. **Pending execution** — Ruling/reason: Engine and persistence paths are unchanged. Cost if wrong: No new execution certification is claimed.

39. **Summon execution** — Ruling/reason: Engine and persistence paths are unchanged. Cost if wrong: No new execution certification is claimed.

40. **No-input execution** — Ruling/reason: The cohort changes presentation only. Cost if wrong: Broader native execution acceptance remains required.

41. **Free priming** — Ruling/reason: The cohort changes presentation only. Cost if wrong: Broader native execution acceptance remains required.

42. **Repeated execution events** — Ruling/reason: The cohort changes presentation only. Cost if wrong: Broader native execution acceptance remains required.

43. **Interrupted Move** — Ruling/reason: The cohort changes presentation only. Cost if wrong: Broader native execution acceptance remains required.

44. **Concurrent publication** — Ruling/reason: Transaction paths are unchanged. Cost if wrong: Concurrency acceptance remains open.

45. **Concurrent claim** — Ruling/reason: Transaction paths are unchanged. Cost if wrong: Concurrency acceptance remains open.

46. **Concurrent recovery** — Ruling/reason: Transaction paths are unchanged. Cost if wrong: Concurrency acceptance remains open.

47. **Concurrent settlement** — Ruling/reason: Transaction paths are unchanged. Cost if wrong: Concurrency acceptance remains open.

48. **AI behavior** — Ruling/reason: Hash-preserving presentation checks are narrower than gameplay acceptance. Cost if wrong: Natural cycles and balance remain open.

49. **Rebalance manifest** — Ruling/reason: Hash-preserving presentation checks are narrower than gameplay acceptance. Cost if wrong: Natural cycles and balance remain open.

50. **Full equipped cycles** — Ruling/reason: Hash-preserving presentation checks are narrower than gameplay acceptance. Cost if wrong: Natural cycles and balance remain open.

51. **Natural twelve-round balance** — Ruling/reason: Hash-preserving presentation checks are narrower than gameplay acceptance. Cost if wrong: Natural cycles and balance remain open.

52. **Hosted acceptance** — Ruling/reason: These were neither performed nor implied. Cost if wrong: Launch readiness remains open.

53. **Atlas motion** — Ruling/reason: These were neither performed nor implied. Cost if wrong: Launch readiness remains open.

54. **Human acceptance** — Ruling/reason: These were neither performed nor implied. Cost if wrong: Launch readiness remains open.

55. **Release readiness** — Ruling/reason: These were neither performed nor implied. Cost if wrong: Launch readiness remains open.




## Public Manual durable recovery verified
Source 1f216f216eea2681b478f0f6ea57d4e25004ad16;tested 4b05948226468f4b53a97042e1d4e0b211ed219f;reviewed 1ead4e9351b28bd57159eeb9acfe736a225566aa. Recovery commit 49884069d358ebd1ad0dfd5f5731e9c64aa48f4c;root d7c09a1926c40899d678b5071c66b89ad523b5bc;checkpoints c5d8bf4623deda5e1292025f724c2074999eea9a. Four local/remote blob SHA values exactly match (bundle/evidence/metadata/LATEST), expected-parent nonforce update; API refs and fresh ls-remote agree. Main remains 29506e293e81abef1b0b8a46099618ab3ae3f0ae. Bundle13895bytesSHA2566dc673d625ff4e7996996813521f70a78530a652617a12b36d929c4d0435e7ec; evidence584431bytesSHA256f55635a6adda8c8bcf6e059ddee68e81f6ad4a2339fb3d9648ab54bd24c2dee1. Root8684Vitest+7Node/allquality/buildsGREEN203114900254Z-40abffbf, source exact and onlydocs descendant. Both fullManualvisibletexts unchanged;all294readers/hashguards exact. FourteendeferredMinors. No publication/activation/hostedmigration/merge/deploy. Originalcombat/Task15/16/native/AT/geometry/editors/previews/naturalcycles/balance/Owneredits/hostedSQLCAS/Atlas/human/releaseOPEN. Highsufficient.

## Captured preview feedback cohort
Task15 captured preview feedback and readiness. BASE1f216f216eea2681b478f0f6ea57d4e25004ad16;8684+7/durable49884069verified;main29506e29unchanged. ExistingapprovedTask15inlineHigh. ActualControlledready path alreadychecks currentversion/localturn/execution/pending/descriptoravailability/exactintent;nativepreparedbundleownslegality. Do not rewrite withoutconcretefailure.
Concretegap actualrequestPreview notices hardcodeGuard30AP/2turns andHP/MPRecovery50AP/10%, ignoringeditedcapturedBasics. GenericactionnoticehardcodesWASD. Noticebar alwaysrenders these claims.
Ruling: onlyaction-readyfeedback usescapturedpublicname and forecastready/readytorelease fromserver;nonumeric/effectduplication/fixedkeys. Reason: authoritativeparameterreaders/quote/recipientforecastalreadyexist. Costifwrong:noticeconcise;valuesstayexistingreaders. NativeMovecurrentcostnoticestays. HistoricalabsentBasicmetadata mayusenativename;missingcurrentmetadata fallsbackAction,notcurrentcatalogue.
Test actualBattleExperiencecallbacks→actualpreviewtransport→realpreviewservice/nativecapture/projector→rerendernotice/artworkprops. Reacthooklifecycle/Nextnavigation/server-onlymarkermocked becausemountedbrowserunavailable;core/controllerfactories/evaluationnotmocked. CoverPvE/PvPeditedGuard/HP/MPnames/costs/numericclaimabsence,nonmutation/noCommit,currentreadywhereactualpathsupports. No native/AT/geometryclaim.
Focused/types/lint/full8684+actualnewcases/all294exact/hashguards. Onefreshcombinedreviewfrozenrange,parentindividualdeclinereasoncost,ONECIfix/no rereview,14inheritedMinorsdeferred. Guardedreport/docs-onlycommit/exactauthorizedrecoverybackup. No hostedwrite/publication/activation/migration/merge/deploy. FullTask15/16/originalcombat/native/AT/geometry/editors/fullcycles/balance/Ownerhosted/Atlas/human/releaseOPEN. Highsufficient.


Initialhookfixture204455didnotinvokepublicwrapperchild; correctedactualinternalchildviareturnedJSXfunctionreference.204508twoactualGuardnoticeRED/fourRecoveryfull-resourcefixtureblocks. Correctedactualactorresourceheadroom204522sixvalidincorrectnoticeRED. Minimalcontrollername/forecastreadyfeedback204536sixGREEN. ExtendedControlledfixture initiallyviolatedBasiccaptureconsistency/in-placeimmutability;nativecorrectlyrejected. Newseparateinitialcapturepreservesdefinition/basicidentity;noenginechange. Onefetchoptionsshadowingfixturebug corrected. Typesreadonlyannotationcorrected.20480316GREEN;postfinal903/84focused204839308527/types204839310196/lint204839313065GREEN. Frozen6e14078cb1dea3bfd94ff923adc5a27fe037eb59. No productionreadinessrewrite;realnativeprime/projection/preview/currentcontrollerreadypropsverified,stale/abortedlateforecastnoReady. Reacthooklifecycle/Nextnavigation/server-onlymarkertransportboundarymocked;nomounted/native/AT/geometryclaim.14Minorsdeferred.

Reviewed-source full204911880191Z-5960210b exit0;rootstdoutstopsduringlint. Actualsevenpackagetestlogs8700plusNode7andcompletedwebbuildretainedininitialaudit/tar. ONEcachedexact-source replayrequiredforcompletefinalrootreceipt;notnewproductchange. Review0C0I0newM/14inheritedMinor;44individualparentrulings.

## Captured preview feedback final checkpoint
# Captured preview feedback — verified development checkpoint

Edited Guard, HP Recovery and MP Recovery now announce their captured names after a legal preview. The previous notices always claimed stock costs and effects (30/50 AP, two turns or 10% recovery), even when the real captured action and forecast said otherwise. Basic Attack and named Skill/Essence/Resonance actions use the same existing pinned public name list. Ordinary legal previews say “forecast ready”; a current legal Controlled release says “ready to release.”

The existing parameter readers, complete quote inside Modifiers and recipient forecasts retain all numeric facts. The notice no longer duplicates stock effect claims or a fixed WASD instruction. Native walking retains its existing actual route-cost notice. Historical snapshots without Basic metadata may use the known native Basic name; missing current metadata falls back to “Action,” not a current catalogue lookup.

The actual Controlled readiness path already checks local turn, available descriptor, planning/execution/preview status, current battle version, exact pending intent and the server's whole-action readiness. The native preview prepares the exact command bundle and evaluates its legality without committing it. No readiness, prime, release, payment or controller-selection rewrite was justified or introduced.

## Source and verification

BASE 1f216f216eea2681b478f0f6ea57d4e25004ad16 → reviewed 6e14078cb1dea3bfd94ff923adc5a27fe037eb59 → final tested 6e14078cb1dea3bfd94ff923adc5a27fe037eb59. Two source/test files; this report is a docs-only descendant. The shared controller serves both playable PvE and PvP at both breakpoints. No CSS, artwork, bounds, command slots, bindings, schema, projection, core, AI or proposal change.

- **Sixteen new callback cases** traverse the actual public BattleExperience wrapper/content, command callbacks, preview request transport, native preview service, captured sources and public projection, then inspect the re-evaluated notice and readiness props. They cover renamed Guard/HP Recovery/MP Recovery and Basic Attack in PvE/PvP, exact 47 AP/3 MP/2 HP native quotes, legal Controlled readiness, stale-version rejection, blocked-response copy and aborted late forecasts after leaving the action.
- RED204522973805Z-c1efefee reproduced all six stock support-notice failures after the actual native preview was already legal. GREEN204536992332Z-829f05da passed those six with the small controller change. Extended sixteen-case GREEN204803324233Z-d6580b62; final focused suite below repeats them.
- Fixture errors were corrected without changing native rules: first invoke the actual content returned by the public wrapper; give recovery targets real resource headroom; preserve Basic capture/definition consistency and create a separate initial Controlled capture instead of editing a saved source. The native parser/immutability guards correctly rejected the invalid attempts. A transport options-name shadow and readonly fixture type were also corrected.
- **903 tests / 84 files GREEN**, receipt204839308527Z-f3fa283e, covering the shared battle components, native preview and captured targeting controller services and spent Controlled integration. Web types204839310196Z-3d53eb11 and zero-warning scoped lint204839313065Z-4b7744bb GREEN.
- Initial full check204911880191Z-5960210b exited0, with8,700+7 verified from complete package logs and finished web build. Its saved root stdout stopped during lint; initial audit and package-log archive are retained. Direct full web lint205320888175Z-cb041008 also passed while investigating that missing output. ONE cached exact-source replay supplies the final complete root receipt below.
- Final exact-source root: **8,700 Vitest plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN. Receipt 20261016T205357474326Z-a42bbf72; 2026-10-16T20:53:57.474326+00:00 → 2026-10-16T20:54:28.190444+00:00. Package counts: realtime 3, audio 17, validation 106, worker 2, db 118, game-core 4136, web 4318. Full build tail and package-log hash audit retained.
- All **294 named Skill reports and HTML** remain exactly unchanged from the public Manual checkpoint: 297 groups and 604 effects. Observation SHA256 93be88d22b88a53a0d47673c89752b9d6c9b2f5f756302707abcac82404545e9. Manifest and six AI/native hashes are unchanged. No fresh 289-case gameplay matrix is claimed.
- Forecasting leaves the tested native encounter unchanged and does not call the repository commit boundary. The Controlled readiness assertion checks the actual controller's forwarded artwork prop; existing shared component tests cover its rendering.

## Review and parent decision

Fresh combined review: **0 Critical, 0 Important, 0 new Minor findings**. Parent accepts the bounded verdict after tracing the actual native preview and controller consumers. No unresolved Critical or Important findings; no corrective code wave or rereview was needed. Fourteen inherited Minors remain deferred. The reviewer performed source inspection only; actual test receipts are the executor's evidence.



## Evidence limits and next work

React hook state/ref plumbing is controlled by the fixture; effects and layouts are not mounted. Next navigation and the server-only import marker are mocked. The transport uses a local repository and real native evaluation; the blocked and stale responses are explicit transport faults. No browser, authenticated request, physical key/touch input, assistive technology, focus or geometry was exercised. A forwarded readiness prop is not native artwork acceptance. The late-response case also verifies abort at the actual transport signal and resolves the held response before its final assertions.

This closes the observed stock-notice regression and adds bounded readiness evidence. It does not certify complete editor publication, every target/modifier/Move scenario or native controls. The already live modular foundation, proposed rebalance and original unfinished combat integration remain distinct. Full Task 15/16, editor/preview completion, whole equipped natural cycles, twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion and human/release acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment. Deployment lock retained. High remains sufficient. The earlier 16–30 active-hour estimate remains provisional and is not a calendar launch promise.

## Initial rulings

1. Use existing captured public names for action feedback, with no stock numeric/effect claims. Reason: existing readers and forecasts own the exact mechanics. Cost if wrong: notice copy stays concise, requiring the existing detailed reader for parameters.
2. Preserve native movement's actual route-cost notice. Reason: no mismatch was found in that branch. Cost if wrong: this slice does not independently certify all movement feedback.
3. Preserve the existing whole-action readiness chain. Reason: current source and native callback tests support it; no new defect was demonstrated. Cost if wrong: native interaction and complete target/bundle acceptance remain required.
4. Correct test fixtures to native capture and resource contracts. Reason: legal recovery needs headroom and immutable captures cannot change in place. Cost if wrong: these fixtures do not establish arbitrary source-replacement behavior.

## Every parent set-aside decision

1. **Numeric cost/effect claims in notices** — Ruling/reason: Duplicating the existing authoritative readers would restore the demonstrated drift. Cost if wrong: The short notice does not repeat detailed parameters.

2. **WASD execution instructions** — Ruling/reason: Fixed keys misrepresent customized controls. Cost if wrong: The notice does not repeat execution shortcuts.

3. **Rewriting readiness** — Ruling/reason: The inspected client and server already bind readiness to native legality/current intent. Cost if wrong: Full native interaction acceptance still remains required.

4. **Contradictory ready=true and legal=false payloads** — Ruling/reason: Production server construction excludes this combination, and this notice branch already requires legality. Cost if wrong: An arbitrary contradictory transport is not independently certified.

5. **New native blocked-Controlled fixture coverage** — Ruling/reason: The blocked case deliberately modifies an ordinary support response and proves copy handling. Cost if wrong: It does not certify native blocked-release legality.

6. **New Skill callback coverage** — Ruling/reason: Its existing public name enters the same inspected lookup; the reproduced defect is Basic feedback. Cost if wrong: The new callback fixture is not a new Skill certification.

7. **New Essence callback coverage** — Ruling/reason: Its existing public name enters the same inspected lookup; the reproduced defect is Basic feedback. Cost if wrong: The new callback fixture is not a new Essence certification.

8. **New Resonance callback coverage** — Ruling/reason: Its existing public name enters the same inspected lookup; the reproduced defect is Basic feedback. Cost if wrong: The new callback fixture is not a new Resonance certification.

9. **Historical fallback callback coverage** — Ruling/reason: The narrow historical native-name branch is inspected directly and uses no current catalogue. Cost if wrong: That fallback has no dedicated new callback case.

10. **Missing-name callback coverage** — Ruling/reason: Current missing names fall back to Action without guessing catalogue content. Cost if wrong: That fallback has no dedicated new callback case.

11. **Multiple-owner name-isolation fixtures** — Ruling/reason: The existing Basic names filter to the local owner and runtime uses that participant's build. Cost if wrong: No new multiple-owner fixture is claimed.

12. **Mounted React lifecycle** — Ruling/reason: Mocked effects and directly invoked callbacks do not establish native scheduling. Cost if wrong: Mount/update/unmount acceptance remains open.

13. **Native keyboard** — Ruling/reason: Callbacks are invoked without native dispatch. Cost if wrong: Physical keyboard acceptance remains open.

14. **Native touch** — Ruling/reason: Callbacks are invoked without native dispatch. Cost if wrong: Physical touch acceptance remains open.

15. **Assistive technology** — Ruling/reason: No real accessibility interaction was exercised. Cost if wrong: AT acceptance remains open.

16. **Focus behavior** — Ruling/reason: No real DOM focus was exercised. Cost if wrong: Focus acceptance remains open.

17. **Long-name geometry** — Ruling/reason: No rendered layout measurement was made, and source changes no geometry. Cost if wrong: Long-name layout acceptance remains open.

18. **Mobile geometry** — Ruling/reason: No rendered layout measurement was made, and source changes no geometry. Cost if wrong: Mobile layout acceptance remains open.

19. **200% zoom geometry** — Ruling/reason: No rendered layout measurement was made, and source changes no geometry. Cost if wrong: Zoom acceptance remains open.

20. **Hosted PvP** — Ruling/reason: Both tested modes use a local repository and transport. Cost if wrong: Hosted PvP acceptance remains open.

21. **Real network acceptance** — Ruling/reason: Transport boundaries are controlled locally. Cost if wrong: Real network acceptance remains open.

22. **Live expiry** — Ruling/reason: Authorization and storage implementations are unchanged and not exercised by this callback fixture. Cost if wrong: The corresponding final authority gate remains open.

23. **Live revocation** — Ruling/reason: Authorization and storage implementations are unchanged and not exercised by this callback fixture. Cost if wrong: The corresponding final authority gate remains open.

24. **Authority CAS** — Ruling/reason: Authorization and storage implementations are unchanged and not exercised by this callback fixture. Cost if wrong: The corresponding final authority gate remains open.

25. **Direct-RPC security** — Ruling/reason: Authorization and storage implementations are unchanged and not exercised by this callback fixture. Cost if wrong: The corresponding final authority gate remains open.

26. **Malformed nested captures** — Ruling/reason: The authority validation boundaries are unchanged. Cost if wrong: Dedicated validation acceptance remains required.

27. **Malformed pending data** — Ruling/reason: The authority validation boundaries are unchanged. Cost if wrong: Dedicated validation acceptance remains required.

28. **Malformed summon data** — Ruling/reason: The authority validation boundaries are unchanged. Cost if wrong: Dedicated validation acceptance remains required.

29. **No-input execution** — Ruling/reason: No execution transition changes here; preview nonpayment is narrower evidence. Cost if wrong: The corresponding native execution acceptance remains open.

30. **Repeated events** — Ruling/reason: No execution transition changes here; preview nonpayment is narrower evidence. Cost if wrong: The corresponding native execution acceptance remains open.

31. **Interrupted Move** — Ruling/reason: No execution transition changes here; preview nonpayment is narrower evidence. Cost if wrong: The corresponding native execution acceptance remains open.

32. **Full combat cycles** — Ruling/reason: No execution transition changes here; preview nonpayment is narrower evidence. Cost if wrong: The corresponding native execution acceptance remains open.

33. **Concurrent publication** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

34. **Concurrent build** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

35. **Concurrent claim** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

36. **Concurrent recovery** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

37. **Concurrent settlement** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

38. **Full Task15** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

39. **Full Task16** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

40. **Complete editors** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

41. **Balance** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

42. **Atlas motion** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

43. **Human playtest** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

44. **Release completion** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

Fourteen inherited Minors remain deferred, without incidental repair: Rewind witness origin; Supporting Shot version pin; Ongoing-pair identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal historical labels/values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline-reference sizing; cross-status direct-input immutability witness; legacy duplicate component keys; unknown-reference matching-text witness.




## Captured preview feedback durable recovery verified
Source 578f755487da3727268498681040f6cffd6a1769;tested/reviewed 6e14078cb1dea3bfd94ff923adc5a27fe037eb59. Recovery bcc046e25534c82a12c6eb1ac32043891fd592e5;root c20b9688c6bf7f1355441ed1bf19622680125103;checkpoints 843f4176e1af9529018544bc315e61d56f243d4a. Fourlocal/remoteblobSHAs exactlymatch;expected-parent/nonforceupdate;freshAPIrefsandls-remoteagree. Mainunchanged29506e293e81abef1b0b8a46099618ab3ae3f0ae. Bundle10816bytesSHA2569aa1cfcf458adc7c7b13e6e8b1d9bae2b0f654db9b94bc15fdde80568906ab4c; evidence451888bytesSHA2564ea34d119c00581a78276782caf07c8d89433cae53c7625c56765dbfb401cf8e. Finalroot8700Vitest+7Node/allquality/bothbuildsGREEN205357474326Z-a42bbf72;initialexit0packagelogsretainedafterrootstdoutgap/ONEcachedreplay. All294readers/hashguardsexact. Review0C0I0newM;14inheritedMinorsdeferred;44individualrulings. Worktreeclean;onlydocsaftertestedsource. No publication/activation/hostedmigration/merge/deploy. FullTask15/16/originalcombat/native/AT/geometry/editors/fullcycles/balance/Ownerhosted/SQLCAS/Atlas/human/releaseOPEN. Highsufficient.

## Canonical Master targeting preview cohort
Task15 canonical Master targeting preview. BASE578f755487da3727268498681040f6cffd6a1769;8700+7/durablebcc046verified;main29506e29unchanged. ExistingapprovedTask15/targeting/editorintegration inlineHigh. ActualMastersharedpreview fixture previewSelection/previewDistance onlytreatgeometry2areas;geometry3Line/Circle/All producewrongselectionkind. OrdinaryindependentcategoriesstillinferprimaryfromlegacyteamPolicy, rejectingfriendlySelf/Ally e.gRally. Pluralacceptedmax2/3 previewonlyoneunit despiteactualmultitargetnativepath. No livepublication.
Ruling: usealreadyexistingnative target enumerator and resolveCombatTargeting fordeterministicgeometry3Singlefixturecandidates (prefercurrentfixturetarget,normalizeSelf/unitduplicates,capauthoredmaximum), notanotherlegalityengine/clientguess. UsecanonicaltargetshapeLine/Circle/Allcontracts forversions2and3;legacyFireGroundflagonlyitsoldgeometry2path,geometry3authoredcategoriesownGround. Preservehistoricaluncapturednative,Area2,rawdefinitions/costs/selectionmaximum/timing/Move/release. Costifwrong:fixturechoosesboundedavailabletargets,notpromisedmaximumifnotenougheligibleunits;nativefullbattleacceptance remainsopen.
Testsfirst actualacceptedrosterSkilldefinitions→realMastervalidation/previewservice→nativepreparation→actualReviewPanelSSR;canonicalLine/Circle,hostileplural2/3 andfriendlyself+ally,geometry3All/customBasic variantsifnativevalid. Actualshape/recipients/outcomes/nonmutation/determinism/noRNG/privatefieldguards;legacyfixtureunchangedwhereintended. Onlyserver-onlymarker mocked. No arbitrarynewroster/creativebalance/engine/API/schema/CSS/control/AI/manifest changes. FulleditorAutomatic/OngoingeventpreviewandManualResonancepreviewstillopen.
FocusedMastereditor/service/nativegeometrycases/types/lint/full8700+actualcases/all294readerexact/hashguards. Onefreshcombinedreview/frozenrange,parentindividualreasoncost,ONECIfix/no rereview,14Minorsdeferred. Guardedreport/docs-onlycommit/authorizedGitobjectrecoverybackup. No hostedwrite/publication/activation/migration/merge/deploy. FullTask15/16/originalcombat/native/AT/geometry/editor/fullcycles/balance/Owneredits/hostedSQLCAS/Atlas/human/releaseOPEN. Highsufficient.


Actual10validRED210253693405;8GREEN2Rallyorderonlymismatches210326007732. Keepfixturepreferredallythenselforder;testexpectationcorrected. ExtraGroundonly/rawSelfindependentfixturesvalidparsebutnativefixturetargetmissing/cooccupancyRED210427031949;categoriesownfixtureplacement/selection. First13+17existing30GREEN210451036397. AdditionalBasicarea/Controlled/Move/zero-rangeguards20new;twozero-rangetestparametersincorrectVitesttupleunpackingfixedwithoutnativechange.135/3GREEN210556270311. AlliedGroundSingle/CirclevalidmissingrecipientRED210754020781(twofail/20pass)→fixtureallyplacementsmallfix→276/20focusedGREEN210806116155/types210806113634/lint210806113148. Native59/4GREEN210642839797. Legacy136nativeexactpre-freeze210710698585 SHA02c15403a64ddfa66a2e259123c1348a9b0a88c7638924bbd7e8846c14c005b0;finalrepeatonfrozen452161cd9e1e9be7b92ceb30fbddff1acaf639a0.22newcases8722+7expected. No core/API/schema/roster/control/art/AIchange;onlyMasterfixtureselectionusesnativecategory/targetingauthority.14Minorsdeferred.

## Canonical Master targeting preview final checkpoint
# Canonical Master targeting previews — verified development checkpoint

The Master Panel now previews canonical Line, Circle, All and plural target selections through the existing native targeting authority. Previously its fixture recognized only the older area-target format, so a valid canonical Line or Circle was sent a selected unit instead of a direction or activation. Independent friendly categories could also be replaced by an enemy inferred from the legacy envelope. Plural previews showed only one target.

The fixture now respects authored categories, prefers its existing intended target, and asks the native enumerator and target resolver for eligible selections. It stops at the authored selection limit and never invents extra units to fill that limit. The fixture contains two enemies, so a three-target Volley demonstrates two available recipients. Self and a unit reference to the actor count as one selection. Zero-range drafts leave other units on distinct tiles and retain native legality failures when they cannot reach a target.

Line uses a cardinal direction; Circle and All use activation. Explicit geometry3 categories own Ground delivery. The older geometry2 Fire/Ground intent flag remains on its historical path. Friendly Ground previews place an actual allied recipient within the fixture instead of showing an empty-effect failure. The native command still decides full legality, Requirements, costs and outcomes.

Selection uses the planned Move destination without moving or executing the fixture. The normal preparation path retains the included overall Move price and free one-time Controlled prime. It performs the existing native command preparation once; target enumeration is a pure geometry step, not a second command preparation or another effect evaluator.

## Source and tests

BASE 578f755487da3727268498681040f6cffd6a1769 → reviewed 452161cd9e1e9be7b92ceb30fbddff1acaf639a0 → final tested 452161cd9e1e9be7b92ceb30fbddff1acaf639a0. Two source/test files, with this report as a docs-only descendant. No game-core, schema, API, publication authority, combat execution, AI, proposal, control, artwork or layout change.

- **22 new root-suite cases** use actual accepted Cleave, Piercing Barrage, Chain Spark, Volley and Rally definitions, plus supported edited definitions. The real Master validation/preview service, native capture/preparation, local repository and actual review-panel SSR are used. Only the server-only import marker is mocked.
- Ten valid RED failures210253693405Z-2e31cfbb establish wrong area forms, incomplete plural demonstration and wrong friendly selection. Initial eight passed210326007732Z-aa5b0da9; two remaining assertions imposed an unrequired Self-first order and were corrected to the fixture's intended-target-first order.
- Independent Ground and raw legacy-Self-envelope definitions validate natively but reproduced missing recipients and duplicate fixture occupancy in RED210427031949Z-7dd1b7b2. Categories now own their fixture positions and candidate selection. All first thirteen plus seventeen existing preview cases passed210451036397Z-d9fc688a.
- Additional guards cover edited Basic Line/Circle/All, geometry3 All, Ground, independent categories, Controlled area preparation, attached Move, zero-range Self deduplication and native limits. A Vitest table-unpacking mistake initially produced invalid category strings and was corrected without changing the parser.
- Allied Ground Single/Circle reproduced two real missing-recipient failures with twenty guards passing in RED210754020781Z-8c2a12a8. The category-aware allied fixture placement made both pass.
- Final focused **276 tests / 20 files GREEN**, receipt210806116155Z-1933877e. Native targeting/Controlled **59 tests / 4 files GREEN**, receipt210642839797Z-88daaf0a. Web types210806113634Z-09c04489 and zero-warning scoped lint210806113148Z-5eacabe3 GREEN.
- All **136 built-in native Master previews** exactly match the prerequisite's full JSON results, including seed, costs, targets, outcomes and projections. All 136 evaluate successfully. Final frozen diagnostic210930400781Z-fc64e877; SHA256 02c15403a64ddfa66a2e259123c1348a9b0a88c7638924bbd7e8846c14c005b0. The exact old module was extracted from BASE and its one relative import was rebased for the isolated diagnostic; module SHA256 1806a9251de5a151d91ba40c7053d48682f2e79b63b9080dd668c4971702fc41. This is latest built-in coverage, not every historical version.
- All **294 named Skill reports and HTML** remain exactly unchanged: 297 groups and 604 effects. Final frozen diagnostic210930392222Z-1e004e7f; observation SHA256 988fa25602cab93011de1bd4a39d74958840338939983617625096bf147694e4. The proposal manifest and six AI/native hashes remain unchanged. No fresh 289-case gameplay matrix is claimed.
- Final exact-source root: **8,722 Vitest plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN. Receipt 20261016T211330154760Z-d5304156; 2026-10-16T21:13:30.154760+00:00 → 2026-10-16T21:14:01.508539+00:00. Counts: game-core 4136, worker 2, audio 17, realtime 3, validation 106, db 118, web 4340. Complete build tail and package-log hash audit retained. Initial root output was incomplete despite its exit status. Its audit and package logs are preserved; ONE cached exact-source replay supplies the complete final receipt. Details are in the implementation notes.

## Review

Fresh combined source review: **0 Critical, 0 Important, 0 new Minor**. Parent inspected the two-file diff and actual native selection/preparation call chain and accepts this bounded source assessment. **No unresolved Critical or Important** in this cohort; no repair wave or rereview was needed. The fourteen inherited Minors remain deferred. Source review does not establish hosted, browser, native, balance or release acceptance. Individual exclusions and costs are recorded below.


## Evidence limits and remaining work

These are deterministic local authoring fixtures and SSR checks. The Publish control becomes reviewable for a valid current preview, but no publication action is performed. This does not exercise a signed-in browser, physical keyboard/touch, assistive technology, focus, geometry, authenticated storage or human acceptance.

The fix does not promise that every valid definition will be legal in this fixture. Native Requirements, resource, target and other restrictions remain truthful. It does not add a Manual Resonance editor simulation or Automatic/Ongoing event previews; those remain distinct unfinished integration work. No balance rule or current roster version was changed.

The modular foundation is already live. Proposed rebalance and original unfinished combat integration remain separate. Targeting/Move/five editable Basics/Controlled and complete controls/editors/readers/previews/native acceptance remain pre-release requirements. Full Task 15/16, equipped natural cycles, twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion and human/release acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No hosted write, publication, activation, migration, merge or deployment. Deployment lock retained. High remains sufficient. The prior 16–30 active-hour estimate remains provisional rather than a calendar promise.

## Initial rulings

1. Reuse native target enumeration and resolveCombatTargeting for fixture selection. Reason: a preview must follow the same category/spatial rules as a real command. Cost if wrong: the fixture still needs full native command evaluation; selecting a geometric candidate is not a legality certificate.
2. Preview up to the actual available target count, bounded by the authored maximum. Reason: the fixture must demonstrate plural behavior without inventing actors. Cost if wrong: a three-target cap may be demonstrated with only two eligible fixture units.
3. Preserve the intended target before additional native candidates, and normalize actor identity. Reason: stable preview composition and no duplicate Self. Cost if wrong: candidate order is a fixture choice, not a player's forced target order.
4. Restrict the legacy Fire Ground flag to its prior geometry path. Reason: geometry3 uses authored categories. Cost if wrong: legacy snapshots and independent-category drafts continue to use different established delivery contracts.
5. Keep current execution, pricing, versioning and roster definitions unchanged. Reason: the defect is in the authoring fixture. Cost if wrong: this checkpoint cannot certify unrelated gameplay, history or release behavior.

## Every parent set-aside decision

# Parent individual review rulings

1. **Every valid definition legal** — Ruling/reason: Native Requirements and resource failures must remain visible. Cost if wrong: Some authored definitions legitimately fail this demonstration fixture.

2. **Target-status Requirements satisfied automatically** — Ruling/reason: Would invent target state beyond this fixture correction. Cost if wrong: Status-dependent previews require dedicated event/state fixtures.

3. **Actor-status Requirements satisfied automatically** — Ruling/reason: Would invent actor state beyond this correction. Cost if wrong: Actor-status previews remain conditional.

4. **Fill every plural cap** — Ruling/reason: The fixture demonstrates available targets, bounded by the cap. Cost if wrong: A three-target cap currently demonstrates two enemies.

5. **Failed conditional Move succeeds** — Ruling/reason: Native Requirements retain authority. Cost if wrong: A conditional Move can correctly leave an action illegal.

6. **Automatic preview** — Ruling/reason: No event setup or event execution is added here. Cost if wrong: Automatic authoring preview remains unfinished.

7. **Ongoing preview** — Ruling/reason: No recurring event setup is added here. Cost if wrong: Ongoing authoring preview remains unfinished.

8. **Event preview** — Ruling/reason: This slice prepares manual commands only. Cost if wrong: Event-driven simulation remains unfinished.

9. **Manual Resonance editor** — Ruling/reason: This editor has previewRequired=false and lacks its simulation flow. Cost if wrong: Manual Resonance preview remains an explicit next integration gap.

10. **Native targeting rules** — Ruling/reason: Existing enumerator/resolver are consumed unchanged. Cost if wrong: This checkpoint cannot establish a new geometry rule.

11. **Creative balance** — Ruling/reason: No roster definition or balance change exists. Cost if wrong: Balance still requires distinct acceptance.

12. **Live expiry** — Ruling/reason: Auth chain unchanged; no hosted expiry witness. Cost if wrong: Expiry acceptance remains open.

13. **Live revocation** — Ruling/reason: Auth chain unchanged; no hosted revocation witness. Cost if wrong: Revocation acceptance remains open.

14. **Authority CAS** — Ruling/reason: No persistence mutation or CAS implementation changed. Cost if wrong: CAS acceptance remains open.

15. **Alternate-character RPC** — Ruling/reason: Authenticated handler is traced but alternate-character requests are not executed. Cost if wrong: Authority acceptance remains open.

16. **Concurrent publication** — Ruling/reason: Preview does not publish. Cost if wrong: Publication concurrency remains open.

17. **Concurrent build** — Ruling/reason: No build transaction is changed. Cost if wrong: Build concurrency remains open.

18. **Concurrent claim** — Ruling/reason: No claim transaction is changed. Cost if wrong: Claim concurrency remains open.

19. **Concurrent recovery** — Ruling/reason: No recovery transaction is changed. Cost if wrong: Recovery concurrency remains open.

20. **Concurrent settlement** — Ruling/reason: No settlement transaction is changed. Cost if wrong: Settlement concurrency remains open.

21. **Malformed historical captures** — Ruling/reason: No capture parser/storage change is present. Cost if wrong: Historical validation acceptance remains separate.

22. **Malformed pending persistence** — Ruling/reason: No pending persistence change is present. Cost if wrong: Pending restore acceptance remains open.

23. **Malformed summon persistence** — Ruling/reason: No summon persistence change is present. Cost if wrong: Summon restore acceptance remains open.

24. **No-input execution** — Ruling/reason: Command preparation does not execute full battle lifecycles. Cost if wrong: No-input runtime acceptance remains open.

25. **Repeated-event execution** — Ruling/reason: No event loop transition changes here. Cost if wrong: Repeated-event runtime acceptance remains open.

26. **Interrupted Move execution** — Ruling/reason: Selection uses planned origin while native preparation retains actual eligibility; no interruption lifecycle executes. Cost if wrong: Interrupted execution acceptance remains open.

27. **Native keyboard** — Ruling/reason: SSR cannot exercise physical keyboard input. Cost if wrong: Native keyboard acceptance remains open.

28. **Assistive technology** — Ruling/reason: SSR cannot establish accessibility interaction. Cost if wrong: AT acceptance remains open.

29. **Responsive geometry** — Ruling/reason: No mounted layout or measurement exists. Cost if wrong: Responsive acceptance remains open.

30. **200% zoom** — Ruling/reason: No mounted zoom measurement exists. Cost if wrong: Zoom acceptance remains open.

31. **Inherited14 Minors** — Ruling/reason: Approved deferred backlog is unchanged; no incidental repair. Cost if wrong: All fourteen listed in progress remain unresolved.

32. **Hosted SQL** — Ruling/reason: No hosted SQL executed. Cost if wrong: Hosted data acceptance remains open.

33. **Migration** — Ruling/reason: No migration applied. Cost if wrong: Migration readiness remains separate.

34. **Activation** — Ruling/reason: No activation executed. Cost if wrong: Activation remains gated by full acceptance.

35. **Publication readiness** — Ruling/reason: A local legal preview does not establish current Owner/live publication acceptance. Cost if wrong: Publication remains open.

36. **Deployment** — Ruling/reason: Deployment lock is retained and no deploy occurs. Cost if wrong: No launch claim follows.

37. **Release** — Ruling/reason: This is a bounded fixture correction. Cost if wrong: Original combat/native/balance/human release gates remain open.

38. **Full Task15** — Ruling/reason: Remaining editors/previews and native acceptance exceed this slice. Cost if wrong: Task15 remains unfinished.

39. **Full Task16** — Ruling/reason: Final acceptance and hosted verification exceed this slice. Cost if wrong: Task16 remains unfinished.

40. **Long-name geometry** — Ruling/reason: Fixture/test changes do not measure actual rendered layout. Cost if wrong: Long-name acceptance remains open.

41. **Full combat cycles** — Ruling/reason: Local preview preparation is narrower than equipped battle execution. Cost if wrong: Full-cycle and natural twelve-round acceptance remain open.

42. **Atlas motion** — Ruling/reason: No Atlas render or metric changes here. Cost if wrong: Recorded .830568 versus <.75 threshold remains open.

43. **Human playtest** — Ruling/reason: Automated preparation/SSR does not constitute a human playtest. Cost if wrong: Human acceptance remains open.



