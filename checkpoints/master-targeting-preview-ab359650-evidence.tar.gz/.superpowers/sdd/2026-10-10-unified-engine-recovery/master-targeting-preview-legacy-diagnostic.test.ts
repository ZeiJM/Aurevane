import { readFileSync, writeFileSync } from 'node:fs'
import { expect,it,vi } from 'vitest'
import { latestEnabledMatureSkills } from '@aurevane/game-core/combat/mature-skills'
import { previewCombatContentDefinition as before } from './master-targeting-preview-legacy-baseline-module'
import { previewCombatContentDefinition as after } from '@/server/master/combat-content-preview'
vi.mock('server-only',()=>({}))
const w='/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery'
it('retains exact builtin native preview results, including existing errors',()=>{
 const definitions=latestEnabledMatureSkills().filter(row=>!Object.hasOwn(row,'ability'))
 expect(definitions).toHaveLength(136)
 const previous=[];const current=[]
 for(const definition of definitions){
  const original=JSON.stringify(definition)
  const evaluate=(fn:typeof before)=>{
   try{return {id:definition.id,result:fn(definition)}}
   catch(error){return {id:definition.id,error:error instanceof Error?{name:error.name,message:error.message}:String(error)}}
  }
  const old=evaluate(before);const next=evaluate(after)
  expect(next,definition.id).toEqual(old)
  expect(JSON.stringify(definition)).toBe(original)
  previous.push(old);current.push(next)
 }
 writeFileSync(w+'/master-targeting-preview-legacy-baseline.json',JSON.stringify(previous,null,2)+'\n')
 writeFileSync(w+'/master-targeting-preview-legacy-observation.json',JSON.stringify(current,null,2)+'\n')
})
