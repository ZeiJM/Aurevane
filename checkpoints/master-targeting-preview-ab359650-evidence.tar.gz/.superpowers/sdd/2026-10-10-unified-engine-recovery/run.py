import datetime
import json
import pathlib
import subprocess
import sys
import uuid

workspace = pathlib.Path(__file__).resolve().parent
args = sys.argv[1:]
if args and args[0] == '--':
    args = args[1:]
if not args:
    raise SystemExit('Provide a command after --')
started = datetime.datetime.now(datetime.timezone.utc)
name = started.strftime('%Y%m%dT%H%M%S%fZ') + '-' + uuid.uuid4().hex[:8]
log = workspace / 'evidence' / (name + '.log')
log.parent.mkdir(parents=True, exist_ok=True)
with log.open('w') as stream:
    result = subprocess.run(args, stdout=stream, stderr=subprocess.STDOUT)
finished = datetime.datetime.now(datetime.timezone.utc)
record = {'argv': args, 'cwd': str(pathlib.Path.cwd()), 'started_utc': started.isoformat(), 'completed_utc': finished.isoformat(), 'exit_code': result.returncode, 'log': str(log)}
with (workspace / 'verification.jsonl').open('a') as stream:
    stream.write(json.dumps(record) + '\n')
print(json.dumps(record), flush=True)
print('\n'.join(log.read_text(errors='replace').splitlines()[-35:]), flush=True)
raise SystemExit(result.returncode)
