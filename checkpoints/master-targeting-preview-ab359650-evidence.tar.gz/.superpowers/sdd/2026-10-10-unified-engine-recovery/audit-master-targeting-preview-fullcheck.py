import pathlib,json,hashlib,tarfile,re
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
r=next(x for x in reversed(receipts) if x['argv']==['pnpm','--reporter=append-only','check'])
s=pathlib.Path(r['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',s)
assert r['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==int((w/'master-targeting-preview-test-count.txt').read_text()),counts
assert 'ℹ pass 7' in s and 'ℹ fail 0' in s
logs=[]
with tarfile.open(w/'master-targeting-preview-turbo-logs.tar.gz','w:gz') as archive:
 for folder in [root/'apps',root/'packages']:
  for p in sorted(folder.glob('*/.turbo/turbo-*.log')):
   data=p.read_bytes();logs.append({'path':str(p.relative_to(root)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});archive.add(p,arcname=str(p.relative_to(root)))
d={'source':(w/'master-targeting-preview-tested-source.txt').read_text().strip(),'receipt':r,'rootStdoutIssue':('Root stdout omits the completed build tail; preserved web package build log contains complete route table. One cached root replay required for final receipt.' if '2 successful, 2 total' not in s.rsplit('$ turbo run build',1)[-1] else 'Complete root build tail; no replay needed for this receipt.'),'counts':[(name,int(n)) for name,n in counts],'logs':logs}
(w/'master-targeting-preview-fullcheck-audit.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in d.items() if k!='logs'}))
