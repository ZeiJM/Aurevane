from pathlib import Path
import datetime,json,re,subprocess,hashlib
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='master-targeting-preview'
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
source=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip()
assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
assert reviewed=='452161cd9e1e9be7b92ceb30fbddff1acaf639a0'
subprocess.run(['git','merge-base','--is-ancestor',reviewed,source],check=True)
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
log=Path(gate['log']).read_text();expected=int((w/(prefix+'-test-count.txt')).read_text())
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert datetime.datetime.fromisoformat(gate['started_utc'])>=datetime.datetime.fromisoformat(git('show','-s','--format=%cI',source))
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
a=json.loads((w/(prefix+'-reader-analysis.json')).read_text())
assert a['source']==source and a['records']==294 and a['effects']==604 and a['allReportsAndHtmlExactlyUnchanged'] and a['manifestAndSixAiSourceHashesUnchanged']
assert a['rawSha256']==hashlib.sha256((w/(prefix+'-reader-observation.json')).read_bytes()).hexdigest()
legacy=json.loads((w/(prefix+'-legacy-analysis.json')).read_text())
assert legacy['source']==source and legacy['records']==136 and legacy['allLegacyNativePreviewsExactlyUnchanged'] and legacy['rawSha256']==legacy['baselineSha256']
outcome=(w/(prefix+'-review-outcome.md')).read_text();rulings=(w/(prefix+'-review-rulings.md')).read_text()
assert 'No unresolved Critical or Important' in outcome and 'Cost if wrong:' in rulings
initial=''
if (w/(prefix+'-initial-fullcheck-audit.json')).exists():
 initial='Initial root output was incomplete despite its exit status. Its audit and package logs are preserved; ONE cached exact-source replay supplies the complete final receipt. Details are in the implementation notes.'
report=f'''# Canonical Master targeting previews — verified development checkpoint

The Master Panel now previews canonical Line, Circle, All and plural target selections through the existing native targeting authority. Previously its fixture recognized only the older area-target format, so a valid canonical Line or Circle was sent a selected unit instead of a direction or activation. Independent friendly categories could also be replaced by an enemy inferred from the legacy envelope. Plural previews showed only one target.

The fixture now respects authored categories, prefers its existing intended target, and asks the native enumerator and target resolver for eligible selections. It stops at the authored selection limit and never invents extra units to fill that limit. The fixture contains two enemies, so a three-target Volley demonstrates two available recipients. Self and a unit reference to the actor count as one selection. Zero-range drafts leave other units on distinct tiles and retain native legality failures when they cannot reach a target.

Line uses a cardinal direction; Circle and All use activation. Explicit geometry3 categories own Ground delivery. The older geometry2 Fire/Ground intent flag remains on its historical path. Friendly Ground previews place an actual allied recipient within the fixture instead of showing an empty-effect failure. The native command still decides full legality, Requirements, costs and outcomes.

Selection uses the planned Move destination without moving or executing the fixture. The normal preparation path retains the included overall Move price and free one-time Controlled prime. It performs the existing native command preparation once; target enumeration is a pure geometry step, not a second command preparation or another effect evaluator.

## Source and tests

BASE578f755487da3727268498681040f6cffd6a1769 → reviewed {reviewed} → final tested {source}. Two source/test files, with this report as a docs-only descendant. No game-core, schema, API, publication authority, combat execution, AI, proposal, control, artwork or layout change.

- **{expected-8700} new root-suite cases** use actual accepted Cleave, Piercing Barrage, Chain Spark, Volley and Rally definitions, plus supported edited definitions. The real Master validation/preview service, native capture/preparation, local repository and actual review-panel SSR are used. Only the server-only import marker is mocked.
- Ten valid RED failures210253693405Z-2e31cfbb establish wrong area forms, incomplete plural demonstration and wrong friendly selection. Initial eight passed210326007732Z-aa5b0da9; two remaining assertions imposed an unrequired Self-first order and were corrected to the fixture's intended-target-first order.
- Independent Ground and raw legacy-Self-envelope definitions validate natively but reproduced missing recipients and duplicate fixture occupancy in RED210427031949Z-7dd1b7b2. Categories now own their fixture positions and candidate selection. All first thirteen plus seventeen existing preview cases passed210451036397Z-d9fc688a.
- Additional guards cover edited Basic Line/Circle/All, geometry3 All, Ground, independent categories, Controlled area preparation, attached Move, zero-range Self deduplication and native limits. A Vitest table-unpacking mistake initially produced invalid category strings and was corrected without changing the parser.
- Allied Ground Single/Circle reproduced two real missing-recipient failures with twenty guards passing in RED210754020781Z-8c2a12a8. The category-aware allied fixture placement made both pass.
- Final focused **276 tests /20 files GREEN**, receipt210806116155Z-1933877e. Native targeting/Controlled **59 tests /4 files GREEN**, receipt210642839797Z-88daaf0a. Web types210806113634Z-09c04489 and zero-warning scoped lint210806113148Z-5eacabe3 GREEN.
- All **136 built-in native Master previews** exactly match the prerequisite's full JSON results, including seed, costs, targets, outcomes and projections. All136 evaluate successfully. Final frozen diagnostic210930400781Z-fc64e877; SHA256 {legacy['rawSha256']}. The exact old module was extracted from BASE and its one relative import was rebased for the isolated diagnostic; module SHA256 {legacy['baselineModuleSha256']}. This is latest built-in coverage, not every historical version.
- All **294 named Skill reports and HTML** remain exactly unchanged:297 groups and604 effects. Final frozen diagnostic210930392222Z-1e004e7f; observation SHA256 {a['rawSha256']}. The proposal manifest and six AI/native hashes remain unchanged. No fresh289-case gameplay matrix is claimed.
- Final exact-source root: **{expected:,} Vitest plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN. Receipt {Path(gate['log']).stem}; {gate['started_utc']} → {gate['completed_utc']}. Counts: {', '.join(name+' '+n for name,n in counts)}. Complete build tail and package-log hash audit retained. {initial}

## Review

{outcome}

## Evidence limits and remaining work

These are deterministic local authoring fixtures and SSR checks. The Publish control becomes reviewable for a valid current preview, but no publication action is performed. This does not exercise a signed-in browser, physical keyboard/touch, assistive technology, focus, geometry, authenticated storage or human acceptance.

The fix does not promise that every valid definition will be legal in this fixture. Native Requirements, resource, target and other restrictions remain truthful. It does not add a Manual Resonance editor simulation or Automatic/Ongoing event previews; those remain distinct unfinished integration work. No balance rule or current roster version was changed.

The modular foundation is already live. Proposed rebalance and original unfinished combat integration remain separate. Targeting/Move/five editable Basics/Controlled and complete controls/editors/readers/previews/native acceptance remain pre-release requirements. Full Task15/16, equipped natural cycles, twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion and human/release acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No hosted write, publication, activation, migration, merge or deployment. Deployment lock retained. High remains sufficient. The prior16–30active-hour estimate remains provisional rather than a calendar promise.

## Initial rulings

1. Reuse native target enumeration and resolveCombatTargeting for fixture selection. Reason: a preview must follow the same category/spatial rules as a real command. Cost if wrong: the fixture still needs full native command evaluation; selecting a geometric candidate is not a legality certificate.
2. Preview up to the actual available target count, bounded by the authored maximum. Reason: the fixture must demonstrate plural behavior without inventing actors. Cost if wrong: a three-target cap may be demonstrated with only two eligible fixture units.
3. Preserve the intended target before additional native candidates, and normalize actor identity. Reason: stable preview composition and no duplicate Self. Cost if wrong: candidate order is a fixture choice, not a player's forced target order.
4. Restrict the legacy Fire Ground flag to its prior geometry path. Reason: geometry3 uses authored categories. Cost if wrong: legacy snapshots and independent-category drafts continue to use different established delivery contracts.
5. Keep current execution, pricing, versioning and roster definitions unchanged. Reason: the defect is in the authoring fixture. Cost if wrong: this checkpoint cannot certify unrelated gameplay, history or release behavior.

## Every parent set-aside decision

{rulings}
'''
for a0,b0 in [('BASE578','BASE 578'),(' /20',' / 20'),(' /4',' / 4'),('All136','All 136'),(':297',': 297'),('and604','and 604'),('fresh289','fresh 289'),('Task15/16','Task 15/16'),('prior16–30active-hour','prior 16–30 active-hour')]:report=report.replace(a0,b0)
(root/'docs/verification/2026-10-16-master-targeting-preview.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Canonical Master targeting preview final checkpoint\n'+report+'\n')
print('Guarded report and ledger written.')

