# Parent individual review rulings

1. **Every valid definition legal** — Ruling/reason: Native Requirements and resource failures must remain visible. Cost if wrong: Some authored definitions legitimately fail this demonstration fixture.

2. **Target-status Requirements satisfied automatically** — Ruling/reason: Would invent target state beyond this fixture correction. Cost if wrong: Status-dependent previews require dedicated event/state fixtures.

3. **Actor-status Requirements satisfied automatically** — Ruling/reason: Would invent actor state beyond this correction. Cost if wrong: Actor-status previews remain conditional.

4. **Fill every plural cap** — Ruling/reason: The fixture demonstrates available targets, bounded by the cap. Cost if wrong: A three-target cap currently demonstrates two enemies.

5. **Failed conditional Move succeeds** — Ruling/reason: Native Requirements retain authority. Cost if wrong: A conditional Move can correctly leave an action illegal.

6. **Automatic preview** — Ruling/reason: No event setup or event execution is added here. Cost if wrong: Automatic authoring preview remains unfinished.

7. **Ongoing preview** — Ruling/reason: No recurring event setup is added here. Cost if wrong: Ongoing authoring preview remains unfinished.

8. **Event preview** — Ruling/reason: This slice prepares manual commands only. Cost if wrong: Event-driven simulation remains unfinished.

9. **Manual Resonance editor** — Ruling/reason: This editor has previewRequired=false and lacks its simulation flow. Cost if wrong: Manual Resonance preview remains an explicit next integration gap.

10. **Native targeting rules** — Ruling/reason: Existing enumerator/resolver are consumed unchanged. Cost if wrong: This checkpoint cannot establish a new geometry rule.

11. **Creative balance** — Ruling/reason: No roster definition or balance change exists. Cost if wrong: Balance still requires distinct acceptance.

12. **Live expiry** — Ruling/reason: Auth chain unchanged; no hosted expiry witness. Cost if wrong: Expiry acceptance remains open.

13. **Live revocation** — Ruling/reason: Auth chain unchanged; no hosted revocation witness. Cost if wrong: Revocation acceptance remains open.

14. **Authority CAS** — Ruling/reason: No persistence mutation or CAS implementation changed. Cost if wrong: CAS acceptance remains open.

15. **Alternate-character RPC** — Ruling/reason: Authenticated handler is traced but alternate-character requests are not executed. Cost if wrong: Authority acceptance remains open.

16. **Concurrent publication** — Ruling/reason: Preview does not publish. Cost if wrong: Publication concurrency remains open.

17. **Concurrent build** — Ruling/reason: No build transaction is changed. Cost if wrong: Build concurrency remains open.

18. **Concurrent claim** — Ruling/reason: No claim transaction is changed. Cost if wrong: Claim concurrency remains open.

19. **Concurrent recovery** — Ruling/reason: No recovery transaction is changed. Cost if wrong: Recovery concurrency remains open.

20. **Concurrent settlement** — Ruling/reason: No settlement transaction is changed. Cost if wrong: Settlement concurrency remains open.

21. **Malformed historical captures** — Ruling/reason: No capture parser/storage change is present. Cost if wrong: Historical validation acceptance remains separate.

22. **Malformed pending persistence** — Ruling/reason: No pending persistence change is present. Cost if wrong: Pending restore acceptance remains open.

23. **Malformed summon persistence** — Ruling/reason: No summon persistence change is present. Cost if wrong: Summon restore acceptance remains open.

24. **No-input execution** — Ruling/reason: Command preparation does not execute full battle lifecycles. Cost if wrong: No-input runtime acceptance remains open.

25. **Repeated-event execution** — Ruling/reason: No event loop transition changes here. Cost if wrong: Repeated-event runtime acceptance remains open.

26. **Interrupted Move execution** — Ruling/reason: Selection uses planned origin while native preparation retains actual eligibility; no interruption lifecycle executes. Cost if wrong: Interrupted execution acceptance remains open.

27. **Native keyboard** — Ruling/reason: SSR cannot exercise physical keyboard input. Cost if wrong: Native keyboard acceptance remains open.

28. **Assistive technology** — Ruling/reason: SSR cannot establish accessibility interaction. Cost if wrong: AT acceptance remains open.

29. **Responsive geometry** — Ruling/reason: No mounted layout or measurement exists. Cost if wrong: Responsive acceptance remains open.

30. **200% zoom** — Ruling/reason: No mounted zoom measurement exists. Cost if wrong: Zoom acceptance remains open.

31. **Inherited14 Minors** — Ruling/reason: Approved deferred backlog is unchanged; no incidental repair. Cost if wrong: All fourteen listed in progress remain unresolved.

32. **Hosted SQL** — Ruling/reason: No hosted SQL executed. Cost if wrong: Hosted data acceptance remains open.

33. **Migration** — Ruling/reason: No migration applied. Cost if wrong: Migration readiness remains separate.

34. **Activation** — Ruling/reason: No activation executed. Cost if wrong: Activation remains gated by full acceptance.

35. **Publication readiness** — Ruling/reason: A local legal preview does not establish current Owner/live publication acceptance. Cost if wrong: Publication remains open.

36. **Deployment** — Ruling/reason: Deployment lock is retained and no deploy occurs. Cost if wrong: No launch claim follows.

37. **Release** — Ruling/reason: This is a bounded fixture correction. Cost if wrong: Original combat/native/balance/human release gates remain open.

38. **Full Task15** — Ruling/reason: Remaining editors/previews and native acceptance exceed this slice. Cost if wrong: Task15 remains unfinished.

39. **Full Task16** — Ruling/reason: Final acceptance and hosted verification exceed this slice. Cost if wrong: Task16 remains unfinished.

40. **Long-name geometry** — Ruling/reason: Fixture/test changes do not measure actual rendered layout. Cost if wrong: Long-name acceptance remains open.

41. **Full combat cycles** — Ruling/reason: Local preview preparation is narrower than equipped battle execution. Cost if wrong: Full-cycle and natural twelve-round acceptance remain open.

42. **Atlas motion** — Ruling/reason: No Atlas render or metric changes here. Cost if wrong: Recorded .830568 versus <.75 threshold remains open.

43. **Human playtest** — Ruling/reason: Automated preparation/SSR does not constitute a human playtest. Cost if wrong: Human acceptance remains open.

