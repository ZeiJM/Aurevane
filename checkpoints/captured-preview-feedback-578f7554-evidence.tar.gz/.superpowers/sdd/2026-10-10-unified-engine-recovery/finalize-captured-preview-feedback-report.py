from pathlib import Path
import datetime,json,re,subprocess,hashlib
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='captured-preview-feedback'
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
source=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip()
assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
assert reviewed=='6e14078cb1dea3bfd94ff923adc5a27fe037eb59'
subprocess.run(['git','merge-base','--is-ancestor',reviewed,source],check=True)
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
log=Path(gate['log']).read_text();expected=int((w/(prefix+'-test-count.txt')).read_text())
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert datetime.datetime.fromisoformat(gate['started_utc'])>=datetime.datetime.fromisoformat(git('show','-s','--format=%cI',source))
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
a=json.loads((w/(prefix+'-reader-analysis.json')).read_text())
assert a['source']==source and a['records']==294 and a['effects']==604 and a['allReportsAndHtmlExactlyUnchanged'] and a['manifestAndSixAiSourceHashesUnchanged']
assert a['rawSha256']==hashlib.sha256((w/(prefix+'-reader-observation.json')).read_bytes()).hexdigest()
outcome=(w/(prefix+'-review-outcome.md')).read_text();rulings=(w/(prefix+'-review-rulings.md')).read_text()
assert 'No unresolved Critical or Important' in outcome and 'Cost if wrong:' in rulings
report=f'''# Captured preview feedback — verified development checkpoint

Edited Guard, HP Recovery and MP Recovery now announce their captured names after a legal preview. The previous notices always claimed stock costs and effects (30/50 AP, two turns or10% recovery), even when the real captured action and forecast said otherwise. Basic Attack and named Skill/Essence/Resonance actions use the same existing pinned public name list. Ordinary legal previews say “forecast ready”; a current legal Controlled release says “ready to release.”

The existing parameter readers, complete quote inside Modifiers and recipient forecasts retain all numeric facts. The notice no longer duplicates stock effect claims or a fixed WASD instruction. Native walking retains its existing actual route-cost notice. Historical snapshots without Basic metadata may use the known native Basic name; missing current metadata falls back to “Action,” not a current catalogue lookup.

The actual Controlled readiness path already checks local turn, available descriptor, planning/execution/preview status, current battle version, exact pending intent and the server's whole-action readiness. The native preview prepares the exact command bundle and evaluates its legality without committing it. No readiness, prime, release, payment or controller-selection rewrite was justified or introduced.

## Source and verification

BASE1f216f216eea2681b478f0f6ea57d4e25004ad16 → reviewed {reviewed} → final tested {source}. Two source/test files; this report is a docs-only descendant. The shared controller serves both playable PvE and PvP at both breakpoints. No CSS, artwork, bounds, command slots, bindings, schema, projection, core, AI or proposal change.

- **Sixteen new callback cases** traverse the actual public BattleExperience wrapper/content, command callbacks, preview request transport, native preview service, captured sources and public projection, then inspect the re-evaluated notice and readiness props. They cover renamed Guard/HP Recovery/MP Recovery and Basic Attack in PvE/PvP, exact47 AP/3 MP/2 HP native quotes, legal Controlled readiness, stale-version rejection, blocked-response copy and aborted late forecasts after leaving the action.
- RED204522973805Z-c1efefee reproduced all six stock support-notice failures after the actual native preview was already legal. GREEN204536992332Z-829f05da passed those six with the small controller change. Extended sixteen-case GREEN204803324233Z-d6580b62; final focused suite below repeats them.
- Fixture errors were corrected without changing native rules: first invoke the actual content returned by the public wrapper; give recovery targets real resource headroom; preserve Basic capture/definition consistency and create a separate initial Controlled capture instead of editing a saved source. The native parser/immutability guards correctly rejected the invalid attempts. A transport options-name shadow and readonly fixture type were also corrected.
- **903 tests /84 files GREEN**, receipt204839308527Z-f3fa283e, covering the shared battle components, native preview and captured targeting controller services and spent Controlled integration. Web types204839310196Z-3d53eb11 and zero-warning scoped lint204839313065Z-4b7744bb GREEN.
- Initial full check204911880191Z-5960210b exited0, with8,700+7 verified from complete package logs and finished web build. Its saved root stdout stopped during lint; initial audit and package-log archive are retained. Direct full web lint205320888175Z-cb041008 also passed while investigating that missing output. ONE cached exact-source replay supplies the final complete root receipt below.
- Final exact-source root: **{expected:,} Vitest plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN. Receipt {Path(gate['log']).stem}; {gate['started_utc']} → {gate['completed_utc']}. Package counts: {', '.join(name+' '+n for name,n in counts)}. Full build tail and package-log hash audit retained.
- All **294 named Skill reports and HTML** remain exactly unchanged from the public Manual checkpoint:297 groups and604 effects. Observation SHA256 {a['rawSha256']}. Manifest and six AI/native hashes are unchanged. No fresh289-case gameplay matrix is claimed.
- Forecasting leaves the tested native encounter unchanged and does not call the repository commit boundary. The Controlled readiness assertion checks the actual controller's forwarded artwork prop; existing shared component tests cover its rendering.

## Review and parent decision

{outcome}

## Evidence limits and next work

React hook state/ref plumbing is controlled by the fixture; effects and layouts are not mounted. Next navigation and the server-only import marker are mocked. The transport uses a local repository and real native evaluation; the blocked and stale responses are explicit transport faults. No browser, authenticated request, physical key/touch input, assistive technology, focus or geometry was exercised. A forwarded readiness prop is not native artwork acceptance. The late-response case also verifies abort at the actual transport signal and resolves the held response before its final assertions.

This closes the observed stock-notice regression and adds bounded readiness evidence. It does not certify complete editor publication, every target/modifier/Move scenario or native controls. The already live modular foundation, proposed rebalance and original unfinished combat integration remain distinct. Full Task15/16, editor/preview completion, whole equipped natural cycles, twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion and human/release acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment. Deployment lock retained. High remains sufficient. The earlier16–30active-hour estimate remains provisional and is not a calendar launch promise.

## Initial rulings

1. Use existing captured public names for action feedback, with no stock numeric/effect claims. Reason: existing readers and forecasts own the exact mechanics. Cost if wrong: notice copy stays concise, requiring the existing detailed reader for parameters.
2. Preserve native movement's actual route-cost notice. Reason: no mismatch was found in that branch. Cost if wrong: this slice does not independently certify all movement feedback.
3. Preserve the existing whole-action readiness chain. Reason: current source and native callback tests support it; no new defect was demonstrated. Cost if wrong: native interaction and complete target/bundle acceptance remain required.
4. Correct test fixtures to native capture and resource contracts. Reason: legal recovery needs headroom and immutable captures cannot change in place. Cost if wrong: these fixtures do not establish arbitrary source-replacement behavior.

## Every parent set-aside decision

{rulings}
'''
for a0,b0 in [('BASE1f','BASE 1f'),('or10%','or 10%'),('exact47','exact 47'),(' /84',' / 84'),(':297',': 297'),('and604','and 604'),('fresh289','fresh 289'),('Task15/16','Task 15/16'),('earlier16–30active-hour','earlier 16–30 active-hour')]:report=report.replace(a0,b0)
(root/'docs/verification/2026-10-16-captured-preview-feedback.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Captured preview feedback final checkpoint\n'+report+'\n')
print('Guarded report and ledger written.')

