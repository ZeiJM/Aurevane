1. **Numeric cost/effect claims in notices** — Ruling/reason: Duplicating the existing authoritative readers would restore the demonstrated drift. Cost if wrong: The short notice does not repeat detailed parameters.

2. **WASD execution instructions** — Ruling/reason: Fixed keys misrepresent customized controls. Cost if wrong: The notice does not repeat execution shortcuts.

3. **Rewriting readiness** — Ruling/reason: The inspected client and server already bind readiness to native legality/current intent. Cost if wrong: Full native interaction acceptance still remains required.

4. **Contradictory ready=true and legal=false payloads** — Ruling/reason: Production server construction excludes this combination, and this notice branch already requires legality. Cost if wrong: An arbitrary contradictory transport is not independently certified.

5. **New native blocked-Controlled fixture coverage** — Ruling/reason: The blocked case deliberately modifies an ordinary support response and proves copy handling. Cost if wrong: It does not certify native blocked-release legality.

6. **New Skill callback coverage** — Ruling/reason: Its existing public name enters the same inspected lookup; the reproduced defect is Basic feedback. Cost if wrong: The new callback fixture is not a new Skill certification.

7. **New Essence callback coverage** — Ruling/reason: Its existing public name enters the same inspected lookup; the reproduced defect is Basic feedback. Cost if wrong: The new callback fixture is not a new Essence certification.

8. **New Resonance callback coverage** — Ruling/reason: Its existing public name enters the same inspected lookup; the reproduced defect is Basic feedback. Cost if wrong: The new callback fixture is not a new Resonance certification.

9. **Historical fallback callback coverage** — Ruling/reason: The narrow historical native-name branch is inspected directly and uses no current catalogue. Cost if wrong: That fallback has no dedicated new callback case.

10. **Missing-name callback coverage** — Ruling/reason: Current missing names fall back to Action without guessing catalogue content. Cost if wrong: That fallback has no dedicated new callback case.

11. **Multiple-owner name-isolation fixtures** — Ruling/reason: The existing Basic names filter to the local owner and runtime uses that participant's build. Cost if wrong: No new multiple-owner fixture is claimed.

12. **Mounted React lifecycle** — Ruling/reason: Mocked effects and directly invoked callbacks do not establish native scheduling. Cost if wrong: Mount/update/unmount acceptance remains open.

13. **Native keyboard** — Ruling/reason: Callbacks are invoked without native dispatch. Cost if wrong: Physical keyboard acceptance remains open.

14. **Native touch** — Ruling/reason: Callbacks are invoked without native dispatch. Cost if wrong: Physical touch acceptance remains open.

15. **Assistive technology** — Ruling/reason: No real accessibility interaction was exercised. Cost if wrong: AT acceptance remains open.

16. **Focus behavior** — Ruling/reason: No real DOM focus was exercised. Cost if wrong: Focus acceptance remains open.

17. **Long-name geometry** — Ruling/reason: No rendered layout measurement was made, and source changes no geometry. Cost if wrong: Long-name layout acceptance remains open.

18. **Mobile geometry** — Ruling/reason: No rendered layout measurement was made, and source changes no geometry. Cost if wrong: Mobile layout acceptance remains open.

19. **200% zoom geometry** — Ruling/reason: No rendered layout measurement was made, and source changes no geometry. Cost if wrong: Zoom acceptance remains open.

20. **Hosted PvP** — Ruling/reason: Both tested modes use a local repository and transport. Cost if wrong: Hosted PvP acceptance remains open.

21. **Real network acceptance** — Ruling/reason: Transport boundaries are controlled locally. Cost if wrong: Real network acceptance remains open.

22. **Live expiry** — Ruling/reason: Authorization and storage implementations are unchanged and not exercised by this callback fixture. Cost if wrong: The corresponding final authority gate remains open.

23. **Live revocation** — Ruling/reason: Authorization and storage implementations are unchanged and not exercised by this callback fixture. Cost if wrong: The corresponding final authority gate remains open.

24. **Authority CAS** — Ruling/reason: Authorization and storage implementations are unchanged and not exercised by this callback fixture. Cost if wrong: The corresponding final authority gate remains open.

25. **Direct-RPC security** — Ruling/reason: Authorization and storage implementations are unchanged and not exercised by this callback fixture. Cost if wrong: The corresponding final authority gate remains open.

26. **Malformed nested captures** — Ruling/reason: The authority validation boundaries are unchanged. Cost if wrong: Dedicated validation acceptance remains required.

27. **Malformed pending data** — Ruling/reason: The authority validation boundaries are unchanged. Cost if wrong: Dedicated validation acceptance remains required.

28. **Malformed summon data** — Ruling/reason: The authority validation boundaries are unchanged. Cost if wrong: Dedicated validation acceptance remains required.

29. **No-input execution** — Ruling/reason: No execution transition changes here; preview nonpayment is narrower evidence. Cost if wrong: The corresponding native execution acceptance remains open.

30. **Repeated events** — Ruling/reason: No execution transition changes here; preview nonpayment is narrower evidence. Cost if wrong: The corresponding native execution acceptance remains open.

31. **Interrupted Move** — Ruling/reason: No execution transition changes here; preview nonpayment is narrower evidence. Cost if wrong: The corresponding native execution acceptance remains open.

32. **Full combat cycles** — Ruling/reason: No execution transition changes here; preview nonpayment is narrower evidence. Cost if wrong: The corresponding native execution acceptance remains open.

33. **Concurrent publication** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

34. **Concurrent build** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

35. **Concurrent claim** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

36. **Concurrent recovery** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

37. **Concurrent settlement** — Ruling/reason: There is no corresponding implementation change or concurrency evidence in this source range. Cost if wrong: The corresponding concurrency acceptance remains open.

38. **Full Task15** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

39. **Full Task16** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

40. **Complete editors** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

41. **Balance** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

42. **Atlas motion** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

43. **Human playtest** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

44. **Release completion** — Ruling/reason: This bounded captured-feedback correction is narrower than the remaining overall work. Cost if wrong: The corresponding completion/acceptance gate remains open.

Fourteen inherited Minors remain deferred, without incidental repair: Rewind witness origin; Supporting Shot version pin; Ongoing-pair identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal historical labels/values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline-reference sizing; cross-status direct-input immutability witness; legacy duplicate component keys; unknown-reference matching-text witness.

