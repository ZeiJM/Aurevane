# Task15 historical Resonance backend — combined review

BASE: `df1ac65868dd8ce833b8327f7303cd1ab00e22b6`
HEAD: `9efdf7d4b6289a2e79a786a2bd3eb632655f538b`

Verdict: **With fixes. 0 Critical / 2 Important / 0 new Minor.** The inherited 16 Minors remain deferred and are not recounted as new findings. This is the single combined spec/quality review, not acceptance of the broader Task15 or release.

## Scope and evidence

Reviewed all four changed files in the exact bounded diff, the historical preview brief, earlier Resonance preview brief, relevant Task15 plan and original approved preview/privacy requirements, and the supplied reviewer template. Followed native evaluation/execution, Resonance forecast/target constraint/hit-dependent execution, current resolver, fixture selection, and Summon removal/stat bridge paths where relevant. No production source, test file, checkout, index, HEAD, or branch mutation; no subagents.

The added 21 cases were read. Parent reports 369/9 focused tests before the last two cases, 21 new cases passing, and preservation of 141 native previews / 284 Manual quotes / 294 readers. These were not independently rerun by this reviewer. Full quality was still running in the parent at report time. Independent focused probes loaded the actual TypeScript modules through an in-memory Vite SSR server (configFile:false, middlewareMode:true, watch:null; server-only resolved to its installed empty.js). No probe files were written. Initial probe failures from server-only loading, unsupported friendlyFire:'all', and out-of-bounds damage amount were corrected; the final crash witness below uses accepted native values and passes validateMatureSkillDefinition.

## Strengths

- The handler/service authorize before execution and validate the submitted Resonance draft. References resolve by current server identity, reject disabled/current canonical Ability records, and do not accept client-supplied reference definitions.
- Historical capability is explicitly selected; the old no-reference rejection remains. Canonical Manual, modifier, Automatic, Ongoing and Basic routing is unchanged in the inspected diff.
- The loop uses the actual native Resonance adapter and evaluates the augmented native effects, rather than quoting an unaugmented Skill and claiming full Resonance simulation. AP remains spent between commands; MP and cooldown legality remain on the native evaluation path.
- No resource refill, forced hit, turn advance or placement rewrite was added. The fixture and RNG are fresh per request. Native armed/activated/expired events are individually allowlisted with exact draft identity/version, and private state/effect origins are not returned.
- Stat bridge reattachment prefers the actual returned bridge, preserving newly spawned Summon profiles. Added tests cover deterministic repeatability, input immutability, actual payoff changes, misses, current versions, disabled/canonical rejection, and authorization.

## Important findings

### I1 — Defeating a setup-created Summon crashes the entire preview response

**Locations:** `apps/web/src/server/master/combat-content-preview.ts:1310–1316` and `:1447–1449`.

The resource projection iterates every combatant in the pre-command state, then assumes each still exists in the post-command state. Native `executePv1fMatureSkill` calls `removeDefeatedCombatSummons`, which removes defeated Summons from both the battle and the stat bridge. A Summon created by the setup and defeated by the trigger is therefore absent when `historicalSampleResources(state, unit.id)` dereferences `unit.hp`. The command itself resolves, but the preview throws `TypeError: Cannot read properties of undefined (reading 'hp')` instead of returning the actual sample outcome. This is material functionality failure for supported native references, not a request for multi-turn Summon simulation.

**Confirmed witness, using actual native content and helper:**

```ts
const setup = structuredClone(resolveMatureSkillVersion('wildwarden.renewing-herbs')!)
const trigger = structuredClone(resolveMatureSkillVersion('vanguard.forceful-strike')!)
trigger.target = {
  kind: 'self', teamPolicy: 'self',
  shape: { kind: 'circle', radius: 2 },
  minimumRange: 0, maximumRange: 0,
  requiresLineOfSight: false, maximumElevationDifference: 0,
  friendlyFire: 'all-except-actor',
}
trigger.effects = Array.from({ length: 4 }, () => ({
  type: 'damage', recipient: 'affected-units', amount: 20, durationTurns: 0,
}))
// validateMatureSkillDefinition(trigger) => []
previewHistoricalResonanceCombatContentDefinition(
  resolveResonanceForPair('lifebinder', 'vanguard', 1)!,
  trigger,
  { setup, seed: 1 },
)
// Throws in historicalSampleResources while projecting the second command.
```

The setup is builtin version6, costs45 AP and spawns a36-HP Verdant Stalker at `{x:3,y:1}`; the trigger retains native45 AP, so both fit the100-AP fixture. The trigger selection is `{kind:'self'}` and its area excludes the actor. A setup need not match the Resonance to be sampled; the existing lane deliberately supports honest mismatches. This witness uses no invalid amount, forced hit, turn advance or synthetic battle state.

**Fix:** Make the public resource projection tolerate lifecycle additions/removals. Either intentionally project the stable fixture participants required by the bounded contract, or use a before/after identity union with explicit existence/removal semantics. Never dereference a missing native combatant. Add the regression with a native Summon setup and valid lethal area trigger; retain exact bridge validation and ensure the response preserves the completed command's actual owner/target outcome.

### I2 — Ground-fire sample reports one selection and executes a different native command

**Location:** `apps/web/src/server/master/combat-content-preview.ts:1395` (contrast fixture construction `:1380–1387` and response targeting `:1499–1504`).

Fixture construction sets the derived `groundFire` flag, but per-step selection passes the raw Skill into `previewSelection`. For native geometry-v2 enemy ground line/circle/all fire, that helper requires `groundFire:true` to put `ground:true` on direction/activate selection. The flag is lost, so the actual command is direct Enemy fire while the returned top-level selection describes Ground fire.

**Confirmed builtin witness:**

```ts
const result = previewHistoricalResonanceCombatContentDefinition(
  resolveResonanceForPair('farstrider', 'lifebinder')!,
  resolveMatureSkillVersion('cinderweaver.flame-burst')!,
  { seed: 1 },
)
// result.legal === true
// result.targeting.selection === { kind: 'activate', ground: true }
// result.historicalSample.steps[0].selection === { kind: 'activate' }
```

The mismatch is meaningful: existing native elemental tests explicitly distinguish direct Enemy and Ground commits; Ground controls persistent area creation and Airborne immunity. A reasonable editor cannot rely on a sample whose advertised targeting and executed native operation differ. This is independent of whether the chosen Skill matches the sample Resonance; reference mismatch is expressly supported.

**Fix:** Derive ground-fire geometry for each reference Skill when constructing its actual step selection, matching the intended native fixture selection. Ensure top-level targeting is consistent with the trigger command actually selected. Add a builtin flame-burst regression asserting the executed step retains `ground:true`; preserve native target constraints/armed-state handling and avoid manufacturing a primary unit for Ground.

## Other assessed boundaries

- AP insufficiency is checked before commit, and native MP/cooldown issues are copied rather than bypassed. Native legality is evaluated on the same appended effects the adapter executes.
- Setup mismatch, expiry, rearming and attack miss semantics flow from the native adapter. The added mismatch test checks expiration, though it does not assert the same-action rearm event; static tracing confirms the adapter processes both.
- First-step illegality stops the loop; absent active turn before a subsequent command produces an explicit unavailable step. Fixed geometry can legitimately reject a setup that cannot reach the trigger-oriented fixture; no adaptive repositioning was introduced.
- Returned results contain explicit resource scalars, selected targets, public identities, costs and allowlisted Resonance fields. No accuracy coefficients, raw battle/state objects, captures or origin arrays are exposed by the new projection.
- Newly spawned Summons are omitted from the spawning step's before-based resource list. The brief requires owner/target resource outcomes, so richer Summon presentation is not separately graded as a new issue; removal crashing that same projection is I1.

## Declined to judge — individual behaviors and reasons

1. Editor reference selectors and rendered historical outcome display: explicitly deferred backend-first slice; no UI files changed.
2. Multi-turn setup/trigger sequences, AP regeneration and cooldown expiry over turns: explicitly excluded same-turn fixture contract; no turn progression authorized here.
3. Simulating canonical Skill Ability roots by appending historical effects: explicitly unsupported; this slice correctly rejects them instead of discarding Ability.
4. Arbitrary player/equipment/build history and equipped Resonance interactions: the accepted capability is a fresh local fixture, not a captured live battle.
5. Future Ground-area ticks and other delayed effects after this sample's turn: outside same-turn execution; I2 still judges correct selection of the command now.
6. Full Summon AI, future Summon turns, lifetime expiry and rich summon result rendering: not part of bounded owner/target scalar output; same-turn Summon execution/bridge/removal correctness was inspected and I1 applies.
7. Hosted authorization/RLS/session behavior and real database publication races: no hosted operations in scope; local handler/service authorization and current resolver use were inspected.
8. Roster balance, content changes, AI redesign and migration/schema behavior: unchanged by this diff and excluded by the brief.
9. Browser/mobile/keyboard/accessibility and human gameplay acceptance: no UI change or browser acceptance claimed in this backend slice.
10. Deployment, production readiness receipts and final release acceptance: no publication/deployment requested or exercised; parent full quality still pending.
11. Re-adjudication of the inherited16 Minors: explicitly deferred by the review package; none silently promoted or counted as new.

## Verification limits and recommendation

The review traced MP, cooldown, setup rearming, target-unavailable and terminal-state paths but did not independently execute every listed edge. The new regression file does not directly cover all of them. Parent should use the authorized single Critical/Important repair wave for I1/I2 with focused failing→passing witnesses, plus required affected checks. Do not start another review pass or claim broader UI/live-battle completion from this bounded backend review.

**Final assessment: 0C / 2I / 0newM; ready after the two Important fixes and their required validation.**
