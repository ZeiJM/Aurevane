from pathlib import Path
import json,re,hashlib,tarfile,subprocess,datetime,sys
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery');receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
r=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);s=Path(r['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',s)
expected=int((w/'historical-preview-test-count.txt').read_text());source=(w/'historical-preview-tested-source.txt').read_text().strip()
assert r['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert datetime.datetime.fromisoformat(r['started_utc'])>=datetime.datetime.fromisoformat(subprocess.check_output(['git','show','-s','--format=%cI',source],text=True).strip())
assert 'ℹ pass 7' in s and 'ℹ fail 0' in s
complete='2 successful, 2 total' in s.rsplit('$ turbo run build',1)[-1]
if '--partial-evidence' not in sys.argv: assert complete
logs=[];tag='historical-preview'+('-repair-initial' if '--partial-evidence' in sys.argv else '-initial' if '--initial' in sys.argv else '')
with tarfile.open(w/(tag+'-turbo-logs.tar.gz'),'w:gz') as archive:
 for folder in [Path('apps'),Path('packages')]:
  for p in sorted(folder.glob('*/.turbo/turbo-*.log')):
   b=p.read_bytes();logs.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});archive.add(p,arcname=str(p))
d={'source':source,'receipt':r,'counts':counts,'rootBuildTailComplete':complete,'logs':logs}
(w/(tag+'-fullcheck-audit.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='logs'}))
