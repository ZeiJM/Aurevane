import { readFileSync,writeFileSync } from 'node:fs'
import {it,expect,vi} from 'vitest'
import * as before from './historical-preview-legacy-baseline-module'
import * as after from '@/server/master/combat-content-preview'
vi.mock('server-only',()=>({}))
const w='/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery'
it('preserves every proposed Manual action quote exactly',()=>{
 const records=JSON.parse(readFileSync('/workspace/scratch/680b26e4eb86/aurevane/docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json','utf8')).records
 const old=[],current=[]
 for(const row of records){
  const definition=row.kind==='essence'?{...row.after.skill,ability:row.after.ability}:row.after
  for(const group of definition.ability.behaviors.filter((g:any)=>g.activation==='manual'&&g.mode==='action')){
   const run=(module:typeof before)=>{try{return {id:row.id,behaviorId:group.id,result:(row.kind==='resonance'?module.previewResonanceCombatContentDefinition:row.kind==='basic'?module.previewBasicCombatContentDefinition:module.previewCombatContentDefinition)(definition,{behaviorId:group.id})}}catch(e){return {id:row.id,behaviorId:group.id,error:e instanceof Error?{name:e.name,message:e.message}:String(e)}}}
   const previous=run(before),next=run(after);expect(next,row.id+':'+group.id).toEqual(previous);old.push(previous);current.push(next)
  }
 }
 expect(current).toHaveLength(284)
 writeFileSync(w+'/historical-preview-actions-baseline.json',JSON.stringify(old,null,2)+'\n')
 writeFileSync(w+'/historical-preview-actions-observation.json',JSON.stringify(current,null,2)+'\n')
})
