import { source } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-behavior.test-utils.ts'
import { captureCombatAbilitySource } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-behavior-capture.ts'
import { percentageDotEncounter } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-percentage-dots.test-utils.ts'
import { preparePv1fTurnEconomy, PV1F_COMBAT_CONTENT, readPv1fActionEconomy } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/pv1f-action-economy.ts'
import { reconcileCombatAbilitySources, primeCombatControlledAbility, combatAbilityCommandContext, refreezeCapturedCombatAbilityState } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-behavior-runtime.ts'
import { prepareCombatAbilityCommand, commitCombatAbilityCommand } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-ability-command.ts'
import { validateCombatAbilityState } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-ability-state.ts'
import { defaultBasicSkills } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-basic-actions.ts'

function fixture(rootOverride = {}, extras = [], policy = undefined) {
  const root = captureCombatAbilitySource(source({ effects: [{id:'hit', timing:'controlled', payload:{type:'damage',recipient:'primary-unit',amount:10}}], ...rootOverride }))
  const modifier = captureCombatAbilitySource({...source({id:'bonus', mode:'modifier', targeting:null, costs:[{resource:'ap',amount:7}], cooldown:{key:'bonus',ownerTurns:2}, effects:[{id:'extra',timing:'instant',payload:{type:'damage',recipient:'primary-unit',amount:3}}]},'modifier'), abilityId:'test.modifier'})
  const base = preparePv1fTurnEconomy(percentageDotEncounter())
  const state = reconcileCombatAbilitySources({...base, ...(policy ? {effectTimingPolicy:policy} : {})}, [root, modifier, ...extras])
  const refs = [{sourceInstanceId:'modifier',behaviorId:'bonus'}]
  const prime = next => primeCombatControlledAbility({state:next,actorId:'actor',sourceInstanceId:root.sourceInstanceId,behaviorId:'strike',manualModifiers:refs}).state
  const command = next => ({state:next,actorId:'actor',root:{kind:'canonical',source:root},manualModifiers:refs,selection:{kind:'unit',combatantId:'enemy'},content:PV1F_COMBAT_CONTENT,context:combatAbilityCommandContext(next,root)})
  return {root, modifier, state, refs, prime, command}
}

it('independent default Controlled timing and explicit modifier timing retain capture and aggregate release', () => {
  const f = fixture({effects:[{id:'hit',payload:{type:'damage',recipient:'primary-unit',amount:10}}]}, [], {version:12,modes:{damage:'controlled'}})
  const primed = f.prime(f.state)
  expect(primed.tactical).toEqual(f.state.tactical)
  expect(validateCombatAbilityState(primed)).toEqual([])
  const released = commitCombatAbilityCommand(f.command(primed))
  expect(readPv1fActionEconomy(released.state,'actor').current).toBe(82)
  expect(released.state.abilityRuntime.controlled.primes).toEqual([])
  expect(released.state.capturedAbilitySources.find(row => row.sourceInstanceId === 'source-a').definition.behaviors[0].effects[0].timing).toBeUndefined()
})

it('independent native Basic Attack binds its captured Controlled root and explicit modifier', () => {
  const f = fixture()
  const template = defaultBasicSkills().find(row => row.id === 'unarmed.basic')
  const basic = {...template, ability:{schemaVersion:1,behaviors:template.ability.behaviors.map(row => ({...row,effects:row.effects.map(effect => ({...effect,timing:'controlled'}))}))}}
  const root = captureCombatAbilitySource({schemaVersion:1,sourceInstanceId:'native-basic',ownerCombatantId:'actor',abilityId:basic.id,contentVersion:basic.contentVersion,sourceKind:'basic',tags:basic.tags,definition:basic.ability,basic})
  const state = reconcileCombatAbilitySources(f.state,[root,f.modifier])
  const primed = primeCombatControlledAbility({state,actorId:'actor',sourceInstanceId:root.sourceInstanceId,behaviorId:'use',manualModifiers:f.refs}).state
  const command = {...f.command(primed),root:{kind:'canonical',source:root}}
  const prepared = prepareCombatAbilityCommand(command)
  expect(prepared.evaluation.legal).toBe(true)
  expect(prepared.action.nativeBasicAttackCommand).toBe(true)
  expect(prepared.action.effects).toHaveLength(2)
  const released = commitCombatAbilityCommand(command)
  expect(readPv1fActionEconomy(released.state,'actor').current).toBe(63)
  expect(released.state.abilityRuntime.controlled.primes).toEqual([])
})

it('independent paid interruption retains root plus attachment costs and never restores the bundle', () => {
  const counter = captureCombatAbilitySource({...source({id:'counter',activation:'automatic',costs:[],activationLimits:['once-per-action'],automaticTarget:{subject:'triggering'},requirements:{kind:'event',eventType:'combat_action_used',phase:'before'},effects:[{id:'kill',payload:{type:'damage',recipient:'primary-unit',amount:20}}]},'counter'),ownerCombatantId:'enemy',abilityId:'counter'})
  const f = fixture({},[counter])
  const state = {...f.state,tactical:{...f.state.tactical,battle:{...f.state.tactical.battle,combatants:f.state.tactical.battle.combatants.map(unit=>unit.id==='actor'?{...unit,hp:2}:unit)}}}
  const primed = f.prime(state)
  expect(primed.abilityRuntime.usage).toEqual([])
  const released = commitCombatAbilityCommand(f.command(primed))
  expect(released.events).toContainEqual(expect.objectContaining({event:'combat_action_interrupted',reason:'actor-unavailable'}))
  expect(readPv1fActionEconomy(released.state,'actor').current).toBe(82)
  expect(released.state.abilityRuntime.controlled.primes).toEqual([])
  expect(released.state.abilityRuntime.controlled.used[0].manualModifiers).toHaveLength(1)
  expect(released.events).toContainEqual(expect.objectContaining({event:'skill_cooldown_started',cooldownKey:'bonus'}))
  expect(released.state.tactical.battle.combatants.find(unit=>unit.id==='enemy').hp).toBe(1000)
})

it('independent malformed persisted metadata reports issues without throwing', () => {
  const f = fixture()
  const primed = f.prime(f.state)
  for (const collection of ['used','primes']) for (const value of [null,1,'a',{},[null],[1],[[]],[{}],[{sourceInstanceId:'modifier',behaviorId:'bonus',abilityId:'test.modifier',contentVersion:'1'}]]) {
    const saved = JSON.parse(JSON.stringify(primed))
    saved.abilityRuntime.controlled[collection][0].manualModifiers = value
    expect(()=>validateCombatAbilityState(saved)).not.toThrow()
    expect(validateCombatAbilityState(saved).length).toBeGreaterThan(0)
  }
})

it('independent restore of inactive attachment cancels prime and retains used history', () => {
  const f = fixture()
  const saved = JSON.parse(JSON.stringify(f.prime(f.state)))
  saved.abilityRuntime.activeSourceIds = ['source-a']
  const restored = refreezeCapturedCombatAbilityState(saved)
  expect(restored.abilityRuntime.controlled.primes).toEqual([])
  expect(restored.abilityRuntime.controlled.used[0].manualModifiers).toHaveLength(1)
  expect(validateCombatAbilityState(restored)).toEqual([])
})

it.each([2,3].flatMap(geometryVersion=>['line','circle','all'].map(kind=>({geometryVersion,kind}))))('structural area admission must reject a primary-unit modifier: $geometryVersion/$kind', ({geometryVersion,kind})=>{
  const shape = kind === 'line' ? {kind,length:3} : kind === 'circle' ? {kind,radius:2} : {kind}
  const maximumRange = kind === 'line' ? 3 : kind === 'circle' ? 2 : 0
  const f = fixture({targeting:{geometryVersion,kind:'unit',teamPolicy:'enemy',friendlyFire:'enemies-only',...(geometryVersion===3?{categories:['enemy']}:{}),shape,minimumRange:0,maximumRange,requiresLineOfSight:false,maximumElevationDifference:null,maximumSelections:1},effects:[{id:'area-hit',timing:'controlled',payload:{type:'damage',recipient:'affected-units',amount:10}}]})
  const selection = kind === 'line' ? {kind:'direction',direction:'east'} : {kind:'activate'}
  const barePrime = primeCombatControlledAbility({state:f.state,actorId:'actor',sourceInstanceId:f.root.sourceInstanceId,behaviorId:'strike'}).state
  expect(prepareCombatAbilityCommand({...f.command(barePrime),manualModifiers:undefined,selection}).evaluation.legal).toBe(true)
  const blocked = f.prime(f.state)
  expect(validateCombatAbilityState(blocked)).toEqual([])
  expect(()=>prepareCombatAbilityCommand({...f.command(blocked),selection})).toThrow('modifier-root-incompatible')
  expect(()=>f.prime(f.state)).toThrow('modifier-root-incompatible')
})

it('structural Single Ground-only category must reject a primary-unit modifier',()=>{
  const f = fixture({targeting:{geometryVersion:3,kind:'unit',teamPolicy:'enemy',friendlyFire:'enemies-only',categories:['ground'],shape:{kind:'single'},minimumRange:0,maximumRange:4,requiresLineOfSight:false,maximumElevationDifference:null,maximumSelections:1},effects:[{id:'ground-hit',timing:'controlled',payload:{type:'damage',recipient:'affected-units',amount:10}}]})
  const selection = {kind:'tile',position:{x:2,y:1}}
  const barePrime = primeCombatControlledAbility({state:f.state,actorId:'actor',sourceInstanceId:f.root.sourceInstanceId,behaviorId:'strike'}).state
  expect(prepareCombatAbilityCommand({...f.command(barePrime),manualModifiers:undefined,selection}).evaluation.legal).toBe(true)
  const blocked = f.prime(f.state)
  expect(()=>prepareCombatAbilityCommand({...f.command(blocked),selection})).toThrow('modifier-root-incompatible')
  expect(()=>f.prime(f.state)).toThrow('modifier-root-incompatible')
})
