export default { test: { globals: true, include: ['/tmp/aurevane-controlled-review/review.test.ts'], pool: 'forks', maxWorkers: 1 } }
