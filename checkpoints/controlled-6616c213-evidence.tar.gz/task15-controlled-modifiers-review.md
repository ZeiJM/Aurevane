# Task15 Controlled modifier bundle prerequisite — independent review

## Scope and identity

- BASE: `02628b541e3aaf3d7a1bf1d8d9508abdf2d34cd3`.
- Reviewed all ten files in `task15-controlled-modifiers-review.diff`, including the two added files. Frozen diff SHA256: `fc45dd635144b77e290701284c629854b792bf430bba8fcbe5ffebc84739b241`. A fresh diff of the same ten working-tree files against BASE produced the identical hash before the final geometry reproductions. At report finalization the author had begun remediation and the working diff hash had changed; this report's verdict applies only to the frozen `fc45dd…` source, with no second review of subsequent edits.
- Authority: repository and battle-scoped `AGENTS.md`; requesting-code-review's actual `code-reviewer.md`; Task15 brief and latest progress ledger; manual-modifier command design sections 1/4/6/7/8; recovery design/plan's capture, Controlled and downstream boundaries; applicable combat, engineering and concurrent-workflow guidance.
- This is a read-only product review of one bounded prerequisite. The only checkout write is this requested review report. No helper agents, duplicate broad suite, content publication, hosted write or release operation.

## Strengths

- `combat-manual-modifier-references.ts:8-78` extracts the previous structural checks and code-unit sorting without changing the supported paid-composition compatibility contract. The remaining paid path still evaluates each explicit modifier's Requirements and participant/resource/clock limits, and appends Manual blocks before optional Automatic blocks. Resolving the complete structural list before checking Requirements changes only which invalid-reference error may be reported first; it introduces no settlement or effect-order change.
- `combat-controlled.ts:201-230,280-303` resolves exact owned active Manual modifier references at free prime, pins ability/version alongside source/behavior identity, and requires the same normalized captured set at release. Definitions stay in the immutable encounter capture inventory, whose existing reconciliation rejects same-source replacement. Prime performs no target resolution, payment, modifier usage/cooldown reservation or paid before-action traversal. Structural primary-recipient feasibility has the Important defect below.
- `combat-controlled.ts:74-111,323-517` removes the whole live prime when an attachment source disappears while preserving the once-per-battle admission history. Optional historical absence remains empty. Restore validates metadata shape, identity, owner, version, mode, compatibility, uniqueness/order and prime/history agreement; malformed tested JSON reports issues without throwing. Restore reconciliation removes inactive-source primes.
- `combat-ability-command.ts:427-434` checks the pinned set before ordinary preparation. The existing authoritative release path still prepares afresh, consumes the prime before paid before-use reactions, and retains all accepted costs/clocks when the root is interrupted after payment. Native Basic binding and current/default Controlled root timing continue through that same path.
- `battle-session-service.ts:222-239,582-612` forwards prime references through the shared service and normalizes attachment order for replay. Historical no-attachment prime/cancel/action fingerprints retain exact bytes. The actual `/api/battles/[battleSessionId]/commit` route reaches the same handler/service, including PvP. Owner projections return identities only; existing controlled-owner filtering and recursive public projection retain the privacy boundary.
- The Zod split accepts identity-only lists on prime and rejects attachment fields on cancellation. Added tests cover real service reload, normalized replay, changed release rejection without payment, actual preview and aggregate release.

## Issues

### Critical

None found.

### Important

**I1 — Free prime accepts an attachment whose primary recipient can never exist, spending the ability's once-per-battle admission.**

- Location: `packages/game-core/src/combat/combat-controlled.ts:206-210` and `:504-508`; the shared compatibility helper at `combat-manual-modifier-references.ts:70-71` trusts the supplied `hasPrimaryRecipient` fact.
- Both new prime admission and persisted-metadata validation pass `hasPrimaryRecipient: true` unconditionally. Current geometry2/3 Line, Circle and All actions use direction/activation and never explicitly select a unit: `actions-legacy.ts:2992-2993,3093-3135` resolves them with `primaryCombatantId: null` and `selectedCombatantIds: []`. Paid composition correctly rejects an attachment containing a `primary-unit` effect against that geometry. Geometry3 Single with raw `kind: 'unit'` but `categories: ['ground']` has the same structural impossibility: its legal tile selection supplies no selected unit.
- Concrete reproduction: capture a valid Manual Attack with unit/enemy targeting, geometry3 Circle radius2, range0–2, one selection, and Controlled Damage to `affected-units`. Its ordinary `{kind:'activate'}` release is legal after a bare prime. Add one owned active Manual modifier with Instant Damage to `primary-unit`. Free prime accepts and writes the bundle to both `primes` and `used`; restore validation reports no issues. Releasing with `{kind:'activate'}` and the exact references throws `modifier-root-incompatible`; omitting the attachment throws `controlled-modifier-bundle-mismatch`. Cancellation retains `used`, so the player cannot repair the bundle and prime that ability again during the battle.
- Independent RED proof: `/tmp/aurevane-controlled-review/review.test.ts` contains six parameterized expected-rejection cases for geometry2/3 × Line/Circle/All and one Single Ground-only case. Each first proves the bare root can release, then proves the captured bundle is accepted/restores but cannot release; all seven fail the final assertion that structurally impossible prime admission should throw. The five other independent boundary tests still pass. An initial geometry2 test-fixture category error was corrected before this final reproduction; all seven final failures are the admission assertion.
- Fix: derive structural explicit-unit feasibility from the effective/canonical target contract (including shape, geometry and unit categories) rather than assuming it. Apply the same fact to prime admission and persisted validation. Reject only the incompatible primary-required bundle before changing the admission history; retain supported `affected-units`/actor modifiers on area roots and the existing legacy/native targeting semantics. Add the seven negative cases plus positive area attachment coverage.

### Minor

None introduced by this frozen milestone found. Existing Ground/controls display findings remain on their original ledger.

## Verification

- Inspected the complete frozen diff and the surrounding admission, capture/reconciliation, preparation/commit, validation, owner projection, service/replay and actual route paths. `git diff --check BASE` passed.
- Ran five additional independent boundary tests from `/tmp/aurevane-controlled-review` without editing product/tests in the checkout: default-Controlled root with explicit Instant modifier; captured native Basic Controlled Attack with modifier; paid actor-defeat interruption retaining aggregate attachment costs/cooldown and consumed prime; malformed persisted metadata matrix in both inventories; restore with an inactive attachment retaining used history. All five passed.
- A subsequent geometry-feasibility audit reproduced I1 with seven focused RED cases on the same frozen source, as detailed above. The final independent run is five passed/seven failed; the failures are the seven expected prime rejections. The reviewer made no product-source changes; author remediation after these reproductions is outside this frozen-source verdict.
- Compared the actual old/new fingerprint helper source against four historical no-attachment prime/cancel/action inputs, including differing object-key insertion order. All four resulting request fingerprints matched BASE exactly.
- Inspected the supplied final frozen-source quality receipt `evidence/20261016T032213515722Z.log`: format, lint, types, all package test tasks and build succeeded; 7,023 Vitest tests plus seven Node checks. The author reports exit 0 and the 03:22:13–03:24:36Z execution window. Type receipt `evidence/20261016T032146595847Z.log` also records all eight type tasks succeeding. I did not rerun the full gate. The existing Vite native-config advisory is unchanged.

## Declined to judge

- Player modifier picker, selection persistence/clearing, combined interactive forecast/readiness, and native keyboard/touch accessibility: explicitly outside this prerequisite; no implemented or accepted player flow is claimed.
- Full AI bundle-choice strategy and whole-roster playable/counterplay/balance completeness: downstream Task15 work, not delivered by structural prime admission.
- Expanding globally inherited Controlled timing to modifier/Automatic/Ongoing groups: existing `applyAbilityTimingDefaults`/definition gates already reject unsupported combinations before this diff. The tested supported case is a Controlled root with explicitly legal modifier packet timing; this review does not authorize independent modifier release or broaden timing capability.
- Prior Ground subset wording and controls display/selection semantics findings: unchanged, already open in their own milestone reviews and final display audit.
- Actual protected browser/editor flows, physical desktop/mobile layout, roster publication/history backfill and deployed gameplay acceptance: no relevant UI/content/hosted changes in this diff and no such acceptance evidence claimed.
- Hosted concurrent PvP delivery/CAS/restart/load behavior: shared route/service/repository authority was traced, but no hosted operation was authorized or performed; existing release and multiplayer acceptance gates remain open.

## Recommendations

Fix I1 with focused RED→GREEN coverage before proceeding. Retain the above follow-on gates and the existing supported timing boundary when consuming the new pinned-reference DTO.

## Assessment

**Ready to merge/checkpoint: With fixes — 0 Critical, 1 Important, 0 new Minor.** The captured identities, exact-set release, payment/interruption, source-removal/history, replay and owner-only handoff are sound in the reviewed cases, but I1 allows an unreleasable bundle to consume a once-per-battle ability. Correct that structural admission/restore defect before treating this prerequisite as complete. This verdict does not complete Task15, accept the future picker/full AI flow, activate a roster or authorize release.
