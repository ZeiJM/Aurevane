# Combined review — frozen source 7b6f813e03c4b946836c69a006a3354dc8ea8a0f

Reviewer: /root/live_conditional_strength_combined_review; fresh gpt-6-astra High, fork none. Read-only review of all three changed files, review package, brief, Owner §10, Task15 and native/projector/shared-reader code. No tests, services, network, browser/native execution, mutations or subagents.

## Strengths

Active native application semantics are correct: Ward combines its common Burn condition; Taunt combines only a common recorded source; legacy uses root potency/source once. Source IDs remain internal; unknown versions unavailable; Covert precedes readers. Ward bypass qualification is truthful and does not claim all Pierce bypasses protection. Existing unconditional/recovery helpers are unchanged. Revised negative assertion rejects an unqualified row and allows a qualified conditional row.

## Issues

Critical: none. Important: one. New Minor: none.

I1: Grouped pending Taunts lose source identity before the helper evaluates it. Changed source battle-effect-strength-information.ts:28–35,105–117; contributing combat-effect-timing.ts:249–280, battle-effect-summary.ts:105–133, battle-combatant-effects.tsx:76,105 and battle-combatant-card.tsx:108–115. Pending apply-status projection retains sourceCombatantId but no applicationModifiers. aggregateBattleStatusStacks keys source only for source-scoped Mark; matching pending Taunts from two casters merge into two stacks with the first root source. Fallback treats that as a common source and advertises “Outgoing damage on activation against targets other than the source: 56.25%.” Native activation retains both sources: 75% versus either source, 56.25% versus a third target. Legacy grouping retains first source whereas sequential activation selects latest source, so even its75% row has unsupported source binding. Actual compact-card inspection provides misleading target-dependent preparation guidance.

Reproduction: four-combatant actual encounter, challenged next-round; actor casts on enemy, end actor/enemy/other turns, ally casts same Taunt in same round. Project spectator statuses, aggregate actual live grouping, report/SSR, then activate and compare native targets. Existing pending tests have one cast and mixed-source tests inspect active rows; neither intersects pending/source grouping. Suggested correction: preserve pending source distinctions or complete captured application/source sets; do not reconstruct lost applications from first source. Add native casts → projection → actual grouping → report/SSR → activation coverage.

## Declined to judge

1. Mounted mouse interaction.
2. Mounted touch interaction.
3. Mounted keyboard navigation and focus restoration.
4. Assistive-technology output.
5. Long-report physical overflow.
6. Small-screen clipping and geometry.
7. 200% zoom geometry.
8. Popup/button CSS sizing.
9. Inspection-backdrop dismissal behavior.
10. Unused noncompact EffectModifiers trigger summaries.
11. Source-specific forecasts or caster naming.
12. Other conditional modifier families.
13. Whole-action readiness.
14. Legacy whole-attack global min/max.
15. Ordinary incoming-summary arithmetic.
16. Extreme native arithmetic capacity policy.
17. Full malformed persisted-state validation.
18. Full malformed pending-payload validation.
19. Summon serialization/validation.
20. Live expiry/revocation enforcement.
21. Alternate selected-character enforcement.
22. Direct RPC/CAS bypass resistance.
23. No-input/free-priming bounds.
24. Duplicate payment behavior.
25. Extra-turn behavior.
26. Interrupted Move reached-origin legality.
27. Concurrent publication.
28. Concurrent build and claim.
29. Concurrent recovery and settlement.
30. Manual/public authored-content completeness.
31. Historical Chronicle/modal redesign.
32. Rewind witness origin.
33. Supporting Shot version pin.
34. Ongoing-pair dynamic identity pin.
35. Repeated bounded AI discovery.
36. Admission double-prefix provenance.
37. Ranged negative direct-commit witness.
38. Independent defense-positive HP reconciliation.
39. Exact Arsenal historical values.
40. Singular status-clock grammar.
41. Burn ordinary tick-boundary wording.
42. Master inline reference-button sizing.
43. Cross-status direct-input immutability witness.
44. Legacy duplicate component keys.
45. Complete original combat/editor/control integration.
46. Full roster natural combat cycles.
47. Whole-roster balance and twelve-round pacing.
48. Full Task15 acceptance.
49. Full Task16 acceptance.
50. Current Owner-hosted content acceptance.
51. Atlas motion acceptance.
52. Human gameplay acceptance.
53. Publication/activation/migration readiness.
54. Merge/deployment/release readiness.
55. Independent reviewer test-total verification.

Assessment: Ready for the bounded checkpoint with fixes. One Important in real shared consumer path; no Critical/new Minor. No independent test rerun.

