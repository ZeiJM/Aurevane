# Parent review rulings

I1 accepted as Important: the live compact-card path can present a false source-bound conditional rate before activation. Repair the grouping authority, retaining source IDs for challenged rows exactly as existing source-scoped Mark retains them. Do not synthesize application data. Reason: each pending source must retain its condition through projection → grouping → reader; actual native activation differs by target. Cost: different pending casters occupy separate existing rows; this avoids inventing a merged target forecast and does not display raw source IDs. Current/legacy and same-source preservation must pass actual native tests.

ONE Critical/Important repair wave only; no new reviewer or rereview. No new Minor. Thirteen inherited Minors remain deferred.

1. **Mounted mouse interaction** — Ruling/reason: Keep native gate open; no browser execution was permitted. Cost if wrong: Click/dismiss behavior remains physically unaccepted.

2. **Mounted touch interaction** — Ruling/reason: Keep device gate open; no touch/browser execution was permitted. Cost if wrong: Touch behavior remains physically unaccepted.

3. **Mounted keyboard navigation and focus restoration** — Ruling/reason: SSR/source tracing cannot establish mounted physical behavior. Cost if wrong: Keyboard/focus restoration remains unaccepted.

4. **Assistive-technology output** — Ruling/reason: No AT execution; plain accessible text coverage is narrower. Cost if wrong: Actual spoken output remains unaccepted.

5. **Long-report physical overflow** — Ruling/reason: SSR has no layout measurements. Cost if wrong: Long reports still need mounted overflow checks.

6. **Small-screen clipping and geometry** — Ruling/reason: No viewport execution. Cost if wrong: Small-screen layout remains unaccepted.

7. **200% zoom geometry** — Ruling/reason: No physical zoom execution. Cost if wrong: Zoom layout remains unaccepted.

8. **Popup/button CSS sizing** — Ruling/reason: CSS unchanged; no physical inspection. Cost if wrong: Sizing remains unaccepted.

9. **Inspection-backdrop dismissal behavior** — Ruling/reason: Interaction owner unchanged; this cohort changes values/grouping. Cost if wrong: Backdrop dismissal still needs native acceptance.

10. **Unused noncompact EffectModifiers trigger summaries** — Ruling/reason: Actual cards hardcode compact; no production caller was found. Cost if wrong: Retained unused branch gains no combined summary.

11. **Source-specific forecasts or caster naming** — Ruling/reason: Conditional facts use private source equality; naming needs its own privacy-aware contract. Cost if wrong: No full source-named target forecast is supplied.

12. **Other conditional modifier families** — Ruling/reason: Known Ward/Taunt scope is bounded; other conditions require their own real context. Cost if wrong: Other conditional readers remain unfinished.

13. **Whole-action readiness** — Ruling/reason: Effect helper does not own command legality or eligibility. Cost if wrong: Whole-action readiness remains unfinished.

14. **Legacy whole-attack global min/max** — Ruling/reason: Isolated effect factors cannot represent the whole attack budget. Cost if wrong: Combined attack forecast remains separate.

15. **Ordinary incoming-summary arithmetic** — Ruling/reason: Separate implementation unchanged; do not mix unrelated arithmetic repair. Cost if wrong: Existing incoming-summary behavior remains.

16. **Extreme native arithmetic capacity policy** — Ruling/reason: Preserve truthful bounded unavailable fallback; no numeric-policy redesign. Cost if wrong: Extreme nominal rates may be unavailable.

17. **Full malformed persisted-state validation** — Ruling/reason: Relevant capture constraints traced; no comprehensive parser audit. Cost if wrong: Malformed-state audit remains open.

18. **Full malformed pending-payload validation** — Ruling/reason: Projection traced; no comprehensive pending-schema audit. Cost if wrong: Malformed pending-state audit remains open.

19. **Summon serialization/validation** — Ruling/reason: Unchanged and unrelated to Ward/Taunt. Cost if wrong: Summon validation remains outside this checkpoint.

20. **Live expiry/revocation enforcement** — Ruling/reason: Authority unchanged; no hosted execution. Cost if wrong: Live authority acceptance remains open.

21. **Alternate selected-character enforcement** — Ruling/reason: Authority unchanged. Cost if wrong: Selected-character enforcement acceptance remains open.

22. **Direct RPC/CAS bypass resistance** — Ruling/reason: No hosted/RPC checks authorized here. Cost if wrong: Hosted bypass-resistance acceptance remains open.

23. **No-input/free-priming bounds** — Ruling/reason: Native command execution unchanged. Cost if wrong: Priming gameplay acceptance remains open.

24. **Duplicate payment behavior** — Ruling/reason: Payment authority unchanged. Cost if wrong: Payment acceptance remains open.

25. **Extra-turn behavior** — Ruling/reason: Turn authority unchanged. Cost if wrong: Extra-turn acceptance remains open.

26. **Interrupted Move reached-origin legality** — Ruling/reason: Movement execution unchanged; preserve original required integration. Cost if wrong: Movement acceptance remains open.

27. **Concurrent publication** — Ruling/reason: Transactions unchanged; no publication performed. Cost if wrong: Publication race acceptance remains open.

28. **Concurrent build and claim** — Ruling/reason: Transactions unchanged. Cost if wrong: Build/claim race acceptance remains open.

29. **Concurrent recovery and settlement** — Ruling/reason: Worker/settlement unchanged. Cost if wrong: Settlement race acceptance remains open.

30. **Manual/public authored-content completeness** — Ruling/reason: Separate content acceptance; not inferred from effect readers. Cost if wrong: Manual/public content remains unfinished.

31. **Historical Chronicle/modal redesign** — Ruling/reason: Historical reader owner unchanged. Cost if wrong: Chronicle integration remains unfinished.

32. **Rewind witness origin** — Ruling/reason: Keep inherited Minor deferred; unrelated fixture. Cost if wrong: Witness still starts at origin.

33. **Supporting Shot version pin** — Ruling/reason: Keep inherited Minor deferred; unrelated capture coverage. Cost if wrong: Explicit version witness remains absent.

34. **Ongoing-pair dynamic identity pin** — Ruling/reason: Keep inherited Minor deferred; unrelated identity witness. Cost if wrong: Dynamic identity witness remains incomplete.

35. **Repeated bounded AI discovery** — Ruling/reason: Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

36. **Admission double-prefix provenance** — Ruling/reason: Keep inherited Minor deferred; wording unchanged. Cost if wrong: Duplicate-prefix wording remains.

37. **Ranged negative direct-commit witness** — Ruling/reason: Keep inherited Minor deferred; native preparation/commit unchanged. Cost if wrong: Negative witness remains preparation-only.

38. **Independent defense-positive HP reconciliation** — Ruling/reason: Keep inherited Minor deferred; event witness unchanged. Cost if wrong: Events lack independent HP reconciliation.

39. **Exact Arsenal historical values** — Ruling/reason: Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact historical values/labels remain incompletely pinned.

40. **Singular status-clock grammar** — Ruling/reason: Keep inherited Minor deferred; no incidental editorial repair. Cost if wrong: Grammar defect remains.

41. **Burn ordinary tick-boundary wording** — Ruling/reason: Keep inherited Minor deferred; ordinary Burn unchanged. Cost if wrong: Boundary wording remains imprecise.

42. **Master inline reference-button sizing** — Ruling/reason: Keep inherited Minor deferred; different surface. Cost if wrong: Master geometry remains unaccepted.

43. **Cross-status direct-input immutability witness** — Ruling/reason: Keep inherited Minor deferred; separate cohort. Cost if wrong: That witness remains weaker.

44. **Legacy duplicate component keys** — Ruling/reason: Keep inherited Minor deferred; no demonstrated mounted failure; source separation fixes the reviewed Taunt loss only. Cost if wrong: Legacy expiry/replacement state reuse still needs mounted acceptance.

45. **Complete original combat/editor/control integration** — Ruling/reason: This bounded reader cohort cannot establish full integration. Cost if wrong: Original pre-release work remains unfinished.

46. **Full roster natural combat cycles** — Ruling/reason: Representative native fixtures are not exhaustive cycles. Cost if wrong: Full natural cycles remain unaccepted.

47. **Whole-roster balance and twelve-round pacing** — Ruling/reason: No balance evaluation in a reader cohort. Cost if wrong: Balance/pacing remains unaccepted.

48. **Full Task15 acceptance** — Ruling/reason: Bounded implementation is part of the larger task. Cost if wrong: Task15 remains unfinished.

49. **Full Task16 acceptance** — Ruling/reason: Final integrated gate not performed. Cost if wrong: Task16 remains unfinished.

50. **Current Owner-hosted content acceptance** — Ruling/reason: No hosted access or changes. Cost if wrong: Current Owner edits remain to reconcile.

51. **Atlas motion acceptance** — Ruling/reason: No animation/runtime inspection; existing .830568 versus <.75 gap remains. Cost if wrong: Atlas motion remains unaccepted.

52. **Human gameplay acceptance** — Ruling/reason: Source/fixtures cannot establish human acceptance. Cost if wrong: Human acceptance remains open.

53. **Publication/activation/migration readiness** — Ruling/reason: No operational review/authorization in this checkpoint. Cost if wrong: No publication, activation or hosted migration is authorized.

54. **Merge/deployment/release readiness** — Ruling/reason: Keep final integration/release gates open. Cost if wrong: Combat overhaul remains unreleased.

55. **Independent reviewer test-total verification** — Ruling/reason: Reviewer was prohibited from executing tests; parent must verify receipts directly. Cost if wrong: Totals depend on parent-run evidence, not independent rerun.

