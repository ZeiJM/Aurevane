from pathlib import Path
import json, hashlib

w = Path(__file__).resolve().parent
root = w.parents[2]
a = json.loads((w / 'live-conditional-strength-reader-observation.json').read_text())
b = json.loads((w / 'live-recovery-rate-reader-observation.json').read_text())
assert len(a['records']) == len(b['records']) == 294
assert a['records'] == b['records']
assert a['source'] == (w / 'live-conditional-strength-tested-source.txt').read_text().strip()
assert hashlib.sha256((root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json').read_bytes()).hexdigest() == 'b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for p, digest in json.loads((w / 'ranged-ai-analysis.json').read_text())['sourceHashes'].items():
    assert hashlib.sha256((root / p).read_bytes()).hexdigest() == digest, p
result = {
    'source': a['source'],
    'rawSha256': hashlib.sha256((w / 'live-conditional-strength-reader-observation.json').read_bytes()).hexdigest(),
    'records': len(a['records']),
    'groups': sum(len(r['groups']) for r in a['records']),
    'effects': sum(len(g['effects']) for r in a['records'] for g in r['groups']),
    'allReportsAndHtmlExactlyUnchanged': True,
    'manifestAndSixAiSourceHashesUnchanged': True,
    'scope': 'Static named Skill readers only. Live-effect controlled callbacks and SSR are separately tested; native keyboard, AT and geometry acceptance remain open.'
}
(w / 'live-conditional-strength-reader-analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
