from pathlib import Path
import json,re,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='live-conditional-strength'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
log=Path(gate['log']).read_text();expected=int((w/(prefix+'-test-count.txt')).read_text())
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
source=(w/(prefix+'-tested-source.txt')).read_text().strip()
reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip()
assert reviewed=='7b6f813e03c4b946836c69a006a3354dc8ea8a0f'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==source
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
observed=json.loads((w/(prefix+'-reader-analysis.json')).read_text())
assert observed['source']==source and observed['records']==294 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged']
review=(w/(prefix+'-review-outcome.md')).read_text();rulings=(w/(prefix+'-review-rulings.md')).read_text()
assert len(re.findall(r'^\d+\. \*\*',rulings,re.M))==55
report=f'''# Conditional Burn Ward and source-aware Taunt — verified development checkpoint

Shared compact-card inspection now describes Burn Ward's combined incoming-damage factor only **against burning opponents**, and Taunt's outgoing factor only **against targets other than the source**. Pending rows explicitly say **on activation**. The report retains the condition qualification and “Other damage modifiers still apply.” Burn Ward also retains its secondary rule: damage that bypasses incoming protection is unaffected. This does not claim every current Pierce action bypasses protection.

Ward combines recorded applications under its common Burn condition. Two default 20% reductions show 64% under current application stacking and 80% under historical whole-row rules; default then 30% shows56% or 70%. Native damage is unchanged: without Burn the conditional kernel is 100%; with Burn the exact displayed factors apply, and actual 100-damage enemy attacks cause 64 or 80 HP damage under the respective rules.

Taunt combines current applications only when every application records the same known source. Two default 25% reductions show 56.25% current or 75% historical; default then 20% shows60% or 80%. Current mixed sources show no invented combined rate; the explanation says combined damage depends on which source is attacked and retains the recorded per-application descriptions. Historical rules apply the root potency/latest native source once. Source identity is used internally for equality and is never printed as a raw caster ID. This is an isolated conditional effect fact, not a selected-target forecast, command-readiness claim or final HP prediction.

The combined review exposed one real shared-path defect: public pending Taunt rows have a root source but no applicationModifiers; the existing card grouper merged two sources and retained the first. That made a false common-source factor possible. The ONE Important repair preserves Taunt source distinctions in the shared grouping key, as the existing source-scoped Mark path already does. Separate pending casters now retain separate 75% rows; same-source pending casts still combine. No application set is reconstructed from lost data. On actual activation current sources yield 75% against either caster and 56.25% against a third target. Historical activation uses the latest caster, yielding 75% against the first and 100% against the latest.

## Scope and live consumers

Actual BattleCombatantCard consumers hardcode compact, across the shared playable PvE/PvP cockpit and spectator surface. Compact icons open the shared BattleEffectPopover/BattleEffectInformation report, which inherits these facts on both breakpoints. Source tracing found no production caller of the retained noncompact EffectModifiers branch; that unused branch is unchanged. Its individual-delta design is not a reason to add dead-path UI. If a future Master/other consumer mounts it, revisit its readouts then.

Four source/test files changed from BASE92cdee2eb60a68db728666c956c8aa00f521934b; this report is a fifth, docs-only file. No native operator, policy, DTO, schema, validation, AI, manifest, command, control, CSS, artwork or geometry change. Grouping separates Taunt source conditions without exposing new public data. Unknown ID/version rules remain unavailable; positive Ward remains hidden from a spectator under actual Covert. Input state remains unchanged by reading.

## Verification and review

- Initially reviewed source: {reviewed}. Final tested repaired source: {source}. Final report is a docs-only descendant.
- Initial RED192519385233:16 valid missing conditional-row/qualification failures, three unknown/Covert guards passing. Native checks passed before reader failures. The old negative guard now rejects an exact unqualified label, preserving its intent while allowing explicit conditional labels. Existing 30 unconditional cases are retained.
- Initial 83 cases GREEN192601771810. Two actual native protection-bypass cases then failed for the missing Ward secondary-rule note in RED192643076992 before that note was added. Initial focused995/87files, native conditional 722/3 files, webtypes and zero-warning lint passed.
- Important repair RED193316620357: two valid distinct-source grouping failures;23 cases already passed. GREEN193335309415:25/25. Four added cases run real pending casts, public spectator projection, actual live grouping, shared report/SSR, then actual native round activation and target comparisons; same-source current/historical aggregation also remains correct.
- Repaired focused **999tests/87files GREEN193349867191Z-e3d63ebd**; webtypes193349872727Z-6a8b9ada and zero-warning scopedlint193349862354Z-9b5c2c53 GREEN. **25 new cases overall** from the previous8608-case baseline.
- Final exact-source root: **{expected:,}Vitest plus seven Node checks**, formatting, lint, all workspace typechecks and both builds GREEN. Receipt {Path(gate['log']).stem}, {gate['started_utc']} → {gate['completed_utc']}. Package counts: {', '.join(a+' '+b for a,b in counts)}. Complete root build tail/package-log hash audit preserved.
- Initial reviewed-source root192842001155 exited0 with8629+7; its saved combined stdout omitted the final build-summary lines, and initial root/diagnostic timestamp collision interleaved their logs. Initial audit/package logs and raw data are preserved. Ignored evidence runner now adds a UUID suffix to prevent filename collisions. Repaired production source required the fresh final root above; the initial incomplete stdout is not used as final proof.
- All 294 named Skill reports and HTML strings remain exactly unchanged from the preceding recovery-rate checkpoint:294 records, 297 groups, 604 effects, observation SHA256 {observed['rawSha256']}. Repaired-source diagnostic193501475530Z-3007cba7 GREEN. Manifest and six AI/native source hashes remain unchanged. No fresh289-case gameplay matrix is claimed for this presentation-only work.

{review}

Actual native casts/turns/kernel/commands, public spectator projection, shared grouping/report and SSR are exercised. Only the server-only import marker is mocked. Source parity and SSR do not establish mounted DOM, native mouse/touch/keyboard, AT, focus restoration, physical overflow/clipping or 200% zoom acceptance. No new browser installation/tunnel attempt was made.

## Remaining release work

The modular foundation already live, proposed Skill rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled, full controls/editors/readers/previews and native acceptance remain pre-release requirements. Whole-action readiness, public Manual rich references, historical Chronicle fallback and complete editor previews remain open. Other conditional/non-damage values require actual context and must not infer target/source/facing from an isolated status.

Full Task 15/16, natural roster cycles, twelve-round pacing/balance, current Owner edits, hosted authority/CAS, Atlas motion (.830568 versus<.75), human acceptance and final release gates remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat. No publication, activation, hosted migration, merge or deployment is performed. The deployment lock is retained. High remains sufficient for routine integration.

## Deferred Minors

Thirteen inherited items remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing-pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal historical values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status input-immutability witness; legacy duplicate component keys. No new Minor was found and no incidental repair was made.

## Initial implementation decisions

1. Leave unused noncompact trigger summaries unchanged. Reason: all actual cards use compact icons/shared popups. Cost: that retained branch has no new combined readouts if mounted later.
2. Combine Ward under one Burn condition and Taunt only under one known source condition. Reason: one conditional aggregate requires every included application to qualify together. Cost: mixed-source Taunt retains per-application facts without a single aggregate.
3. Compare public recorded source identity internally without naming the caster. Reason: mechanics need equality while source naming requires a separate privacy-aware presentation contract. Cost: no full source-named target forecast.
4. Preserve Taunt source distinctions in grouping. Reason: pending rows have no captured application set to reconstruct. Cost: separate pending casters occupy separate existing rows, and future legacy duplicate-key mounted acceptance remains open.

## Every parent set-aside ruling

{rulings}
'''
(root/'docs/verification/2026-10-16-live-effect-conditional-strength-readers.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Final conditional live-strength checkpoint\n'+report+'\n')
print('Wrote guarded conditional-strength report and ledger.')

