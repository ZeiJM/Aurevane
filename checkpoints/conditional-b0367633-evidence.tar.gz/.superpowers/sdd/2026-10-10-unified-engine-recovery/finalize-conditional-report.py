from pathlib import Path
import json,re
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
s=Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',s)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8384,counts
assert 'ℹ pass 7' in s and 'ℹ fail 0' in s
head=(w/'conditional-tested-source.txt').read_text().strip()
report=f"""# Conditional and Pierce prose — verified checkpoint

This bounded Task15 cohort removes generated condition prefixes from generated explanations. All29actual typed effect conditions and their exact full Effects rows remain unchanged:25status-presence and4resource-state, including Essence Aether Nova’s owner MP≥75% condition. The initial three numeric candidates were non-damage Resonance effects, not the full numeric-condition inventory. Group-level Requirements, recipient, timing, order, maintenance and limits remain separate and unchanged. Full report consumers retain conditions before explanations. Exact aligned authored explanations remain escaped text, including any intentional numeric wording.

Four actual canonical Pierce effects retain exact damage magnitude and equipment-Armor bypass percentage in the structured magnitude. Generated prose explains that the displayed bypass applies only to equipment Armor and offers no advantage without equipment Armor. The specialized Basic Attack branch retains stronger-Power scaling, rounding and tie rules, with the same plain equipment boundary. Legacy Mature piercing:true, native execution, schemas, manifest, all six planner/fixture hashes and values are unchanged. No new289matrix is claimed for presentation-only changes; native equipment-Armor integration/full-cycle acceptance stays separate.

Preflight160416646119:9validRED/1authoredGREEN. Ten new portable cases cover all3actual non-damage conditional Resonance effects, all4actual Pierce effects, nested effect/global Requirements separation, escaped authored explanations and captured33.33% Basic Pierce with Mystic scaling. Covering160602521960 passes35tests across6actual files, including native Basic projection and exact captured reports. A nonexistent requested techniques-manual.test.ts is not counted; actual current-manual.test.ts runs in the full root. Two existing Basic projection assertions check exact condition in typedfields/Effects and exact bypasspercentage in magnitude, retaining stronger-Power/immutability/authority checks.

Frozen source `{head}` passes the complete root check, receipt `{Path(gate['log']).stem}`, exit0:8,384Vitest plus7Node checks, formatting, lint, all8package typechecks and both builds. Actual window {gate['started_utc']}–{gate['completed_utc']}. Documentation follows without source changes. Full-root output/package evidence is preserved in the checkpoint; no unobserved pass is inferred.

Fresh diagnostic160709732791 renders all294actual records/297groups/604effects through shared readers. Independent comparison proves every structured report field/row/effect/condition/recipient/timing/limit/maintenance exactly unchanged from the prior frozen checkpoint. All29non-Pierce generated conditions are removed by exact prefix only;4Pierce explanations change independently. Thus33explanations change,571others remain exact;369total changed/235unchanged from original editorial observation. Raw SHA256`0144a44a91bb54836140aed7d138bedff71d3f156c227537eb109e7b06fe8709`. Remaining171numeric explanations are all directDamage/Pierce; this is an inventory, not complete editorial/native acceptance. Authored text is never stripped or normalized.

One fresh combined review0Critical/0Important/0newMinor; parent accepts. No C/I wave or rereview. Fifty-six individually considered/declined behaviors each have a separate parent reason/cost in the checkpoint ledger/rulings. Ten inherited Minors remain deferred, including ordinary Burn tick-boundary clarity; none fixed incidentally. Reviewer inspected all29actual requirement-bearing effects and relevant current/captured/legacy/authored report consumers. The actual manifest has no effect-level prime/nested condition; unchanged generic formatting and the custom nested regression remain narrower evidence than native execution.

Complete orange inline references/link interaction, original combat Targeting/Move/editable five Basics/Controlled/native controls, full editors/previews/popups, distinct complete cycles/balance, fresh Owner edits, hosted authority/CAS, Atlas motion and human acceptance remain open before release. Broader Master panels follow combat. High remains sufficient. No publication, activation, hosted write, migration application, merge or deployment.
"""
(root/'docs/verification/2026-10-16-conditional-pierce-reader-prose.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n\n## Final conditional/Pierce checkpoint verification\n'+report+'\n')
print(json.dumps({'tested':head,'receipt':gate,'counts':counts}))
