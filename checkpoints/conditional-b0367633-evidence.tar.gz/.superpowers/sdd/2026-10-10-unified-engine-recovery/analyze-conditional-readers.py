from pathlib import Path
import json,hashlib,re,collections
w=Path(__file__).resolve().parent
def flat(name):
 d=json.loads((w/name).read_text());out={}
 for r in d['records']:
  for g,p in zip(r['groups'],r['reports'],strict=True):
   for i,(e,s) in enumerate(zip(g['effects'],p['effectDescriptions'],strict=True)):
    k=(r['id'],g['id'],e['id']);assert k not in out;out[k]={'description':s,'type':e['type'],'recipient':e['recipient'],'condition':p['effects'][i]['condition']}
 return d,out
now,n=flat('conditional-reader-observation.json');previous,old=flat('periodic-reader-observation.json');_,orig=flat('editorial-readers-observation.json')
assert n.keys()==old.keys()==orig.keys()
for r,p in zip(now['records'],previous['records'],strict=True):
 assert r['id']==p['id'] and r['groups']==p['groups']
 for after,before in zip(r['reports'],p['reports'],strict=True):
  assert set(after)==set(before)
  for key in after:
   if key!='effectDescriptions':assert after[key]==before[key],(r['id'],key)
changed=[k for k in n if n[k]['description']!=old[k]['description']];total=[k for k in n if n[k]['description']!=orig[k]['description']]
conditions=[k for k in old if old[k]['condition'] is not None]
assert len(n)==604 and len(now['records'])==294 and len(changed)==33 and len(conditions)==29
for k in n:
 prefix=f"If {old[k]['condition']}: " if old[k]['condition'] else ''
 prior=old[k]['description'];assert prior.startswith(prefix),k
 if n[k]['type']=='pierce':
  assert 'only to equipment Armor' in n[k]['description'] and 'Without equipment Armor' in n[k]['description']
  assert not re.search(r'Ignores \d',n[k]['description'])
 else:assert n[k]['description']==prior[len(prefix):],k
numeric=[{'record':k[0],'group':k[1],'effect':k[2],**v} for k,v in n.items() if re.search(r'\d',v['description'])]
assert not [x for x in numeric if x['type'] not in ('damage','pierce')]
result={'source':now['source'],'rawSha256':hashlib.sha256((w/'conditional-reader-observation.json').read_bytes()).hexdigest(),'records':294,'groups':sum(len(r['groups']) for r in now['records']),'effects':604,'changedFromPeriodic':len(changed),'unchangedFromPeriodic':604-len(changed),'conditionalEffects':len(conditions),'allStructuredReportsExactlyUnchanged':True,'allGeneratedConditionPrefixesRemovedExactly':True,'changedByType':dict(collections.Counter(n[k]['type'] for k in changed)),'changedFromOriginal':len(total),'unchangedFromOriginal':604-len(total),'withDigits':len(numeric),'nonDirectDamageWithDigits':0,'scope':'Static default context exact shared reports; numeric inventory is not complete semantic/editorial/native acceptance. All rows/effect presentation/conditions/limits/maintenance byte-for-byte unchanged from prior. All29condition prefixes removed exactly. Authored prose never stripped; source tests retain authored numbers. Damage numeric explanations intentionally retained.'}
(w/'conditional-reader-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
(w/'conditional-reader-changes.json').write_text(json.dumps([{'record':k[0],'group':k[1],'effect':k[2],'before':old[k]['description'],**n[k]} for k in changed],indent=2)+'\n')
assert result['source']==(w/'conditional-tested-source.txt').read_text().strip()
root=w.parents[2]
assert hashlib.sha256((root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json').read_bytes()).hexdigest()=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for p,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest,p
print(json.dumps(result))
