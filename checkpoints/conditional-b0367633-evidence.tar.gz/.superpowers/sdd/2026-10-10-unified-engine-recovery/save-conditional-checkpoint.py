import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'conditional-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'conditional-tested-source.txt').read_text().strip();base='0783819c60a47ba09d2317d9550cc5ca2e5e2221'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=set(git('diff','--name-only',base,head).splitlines())
assert paths=={'apps/web/src/components/character/ability-detail-presentation.ts','apps/web/src/components/character/conditional-pierce-reader.test.tsx','apps/web/src/server/battle/battle-basic-action-projection.test.ts','docs/verification/2026-10-16-conditional-pierce-reader-prose.md'},paths
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8384,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
reviewed='d47e412015caf3d7dbda0546fad471bbffab0bcc'
assert reviewed==tested
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'conditional-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['changedFromPeriodic']==33 and observed['conditionalEffects']==29 and observed['changedFromOriginal']==369 and observed['allStructuredReportsExactlyUnchanged'] and observed['allGeneratedConditionPrefixesRemovedExactly'] and observed['rawSha256']==sha(w/'conditional-reader-observation.json')
comparison=json.loads((w/'secondary-matrix-analysis.json').read_text());assert comparison['records']==289 and comparison['commands']==8219 and comparison['allCompleteRowsIdentical'] and comparison['rawSha256']==sha(w/'secondary-restored-289.jsonl')
bundle=w/('conditional-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'conditional-bundle-verify.log').write_text(v.stdout)
evidence=w/('conditional-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-conditional-pierce-reader-brief.md', 'conditional-combined-review-package.md', 'conditional-review-rulings.md', 'task15-conditional-reader-review.md', 'conditional-tested-source.txt', 'conditional-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-conditional-checkpoint.py', 'finalize-conditional-report.py', 'conditional-readers-diagnostic.test.tsx', 'vitest-conditional-reader.config.ts', 'conditional-reader-observation.json', 'conditional-reader-analysis.json', 'analyze-conditional-readers.py', 'conditional-reader-changes.json', 'conditional-fullcheck-audit.json', 'conditional-turbo-logs.tar.gz', 'secondary-matrix-analysis.json', 'ranged-ai-analysis.json', 'conditional-pierce-reader-candidate.test.tsx', 'vitest-conditional-pierce-preflight.config.ts', 'periodic-reader-observation.json']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T160400':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'9a561f940ec0b0556f77d24ef2dfe83926af5f8d','previousArchiveTree':'94805617502e8d503a95459c7c5ed9682cfbbf56','fullCheckReceipt':gate,'tests':{'vitest':8384,'node':7},'priorMatrixReference':comparison,'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':'Conditional/Pierce generated prose: all29conditions retained exactly in typedfields/Effects rows, generatedprefix removed only from explanations; all4Pierce exactmagnitude/bypasspercent retained with equipment-only/noequipment noadvantage plainprose. All294staticreports604effects;33new369totalexplanationchanges;allstructuredreportsexactprior,571othersidentical. 10newcases,9validRED1authoredGREEN,35covering. Frozen8384Vitest+7Node; native/schema/manifest/AI/fixtures unchanged, no fresh289claimed. Onecombinedreview parent verdict recorded separately;10priorMinors deferred. Originalcombat/native/editorial/orangereferences/fullcycles/balance/Ownerhosted/Atlas/human/release andbroaderMaster remainopen. No hostedwrite/publication/activation/migration/merge/deploy.'}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k not in ('matrix','readerAudit')}))
