# Parent rulings — conditional/Pierce combined review

Fresh reviewer /root/conditional_pierce_reader_review, gpt-6-astra High, fork none. Read-only0783819c..d47e4120; no suites/mutations/browser/delegation. Parent accepts0Critical/0Important/0newMinor. No C/I wave or rereview. Ten prior Minors remain deferred; none fixed incidentally.

1. Final: Ruling: Native equipment-Armor integration — explicit contribution helper supports wording; no native integration claim. Cost if wrong: unresolved equipment execution could block release.
2. Final: Ruling: Legacy Mature piercing:true execution — separate execution and description paths unchanged. Cost if wrong: historic Pierce could regress if later unified carelessly.
3. Final: Ruling: Every historical metadata combination — inspected fallbacks/capture projection cover bounded contexts. Cost if wrong: an untested old capture could display incorrect semantics.
4. Final: Ruling: Complete orange reference appearance — no styling changed; next bounded reader work. Cost if wrong: inconsistent references remain until completed.
5. Final: Ruling: Orange hover/touch/link interaction — no native browser exercise; original gate remains. Cost if wrong: references could be inaccessible on an untested device.
6. Final: Ruling: Targeting/controller completion — no targeting or controller change; original integration stays open. Cost if wrong: a selection/range/control defect could block combat release.
7. Final: Ruling: Attached Move traversal/interruption — execution unchanged; native path not accepted here. Cost if wrong: an interrupted traversal could violate legal movement.
8. Final: Ruling: Attacks from reached origin — no native interruption/origin acceptance. Cost if wrong: an attack could incorrectly use an unreached tile.
9. Final: Ruling: Editable Move completion — reader correctness does not complete editor/execution acceptance. Cost if wrong: saved Move edits might fail in battle.
10. Final: Ruling: Editable Basic Attack completion — custom projection proves presentation only. Cost if wrong: saved attack edits might diverge during execution.
11. Final: Ruling: Editable Guard completion — no full authoring/runtime workflow exercised. Cost if wrong: saved Guard semantics might diverge.
12. Final: Ruling: Editable HP Recovery completion — captured condition projection is narrower than full workflow. Cost if wrong: HP recovery edits might execute incorrectly.
13. Final: Ruling: Editable MP Recovery completion — no full authoring/runtime acceptance. Cost if wrong: MP recovery edits might execute incorrectly.
14. Final: Ruling: Controlled prime/release/cancel completion — explanation retained; native workflow gate remains. Cost if wrong: prime/release cancellation could violate allowance/payment.
15. Final: Ruling: Full Master editor coverage — relevant adapters inspected, all mounted editors still need acceptance. Cost if wrong: a mounted editor could mis-save or hide a field.
16. Final: Ruling: Every preview/popup — shared report paths checked; all mounted surfaces remain open. Cost if wrong: a surface could hide or mislabel mechanics.
17. Final: Ruling: Long-name geometry — source/SSR cannot prove native layout. Cost if wrong: long text could obscure controls.
18. Final: Ruling: Mobile/touch geometry — no device exercise. Cost if wrong: mobile controls or text could become unusable.
19. Final: Ruling: Native keyboard/focus/dismissal — no physical input exercise. Cost if wrong: keyboard users might lose control/focus.
20. Final: Ruling: 200% zoom — no physical zoom acceptance. Cost if wrong: enlarged controls or prose might clip.
21. Final: Ruling: Stale-browser expiry/revocation — authority paths unchanged; require actual gate. Cost if wrong: stale privileges could remain effective.
22. Final: Ruling: Alternate selected-character authority — binding paths unchanged; independent gate stays open. Cost if wrong: another character could receive unauthorized actions.
23. Final: Ruling: Direct RPC expiry — protected RPC not exercised. Cost if wrong: expired access might bypass a UI-only check.
24. Final: Ruling: Direct RPC revocation — protected RPC not exercised. Cost if wrong: revoked access might remain effective.
25. Final: Ruling: Direct RPC CAS — no concurrency exercise. Cost if wrong: a stale direct write could overwrite newer state.
26. Final: Ruling: Malformed nested definitions — parser unchanged; valid reader tests are not rejection tests. Cost if wrong: invalid definitions could escape validation.
27. Final: Ruling: Malformed captured definitions — capture validation untouched. Cost if wrong: corrupt history could execute or leak fields.
28. Final: Ruling: Malformed pending work — pending validation untouched. Cost if wrong: invalid pending packets could execute.
29. Final: Ruling: Malformed summon data — summon validation untouched. Cost if wrong: invalid summon payloads could execute.
30. Final: Ruling: Complete transport/privacy acceptance — shared public report purity is narrower than every API/RSC/live envelope. Cost if wrong: another envelope could leak private fields.
31. Final: Ruling: No-input/timeout behavior — scheduler/terminal paths unchanged and unexercised here. Cost if wrong: idle turns could terminate or reward incorrectly.
32. Final: Ruling: Free priming bounds — no native prime-budget exercise. Cost if wrong: unbounded priming could become advantageous.
33. Final: Ruling: Repeated-event bounds — event budget unchanged; independent acceptance required. Cost if wrong: repeated events could trigger unbounded output.
34. Final: Ruling: Duplicate payment prevention — no complete payment-path acceptance. Cost if wrong: a release could pay more than once or skip payment.
35. Final: Ruling: Extra-turn prevention — turn economy unchanged; independent acceptance required. Cost if wrong: reactions could create unintended extra turns.
36. Final: Ruling: Concurrent publication — no hosted race/rollback exercise. Cost if wrong: publication could race into an incoherent version.
37. Final: Ruling: Concurrent build writes — no build race exercise. Cost if wrong: simultaneous build writes could lose updates.
38. Final: Ruling: Concurrent claims — claim/idempotency authority untouched. Cost if wrong: repeated claims could duplicate rewards.
39. Final: Ruling: Concurrent recovery — no late-worker recovery exercise. Cost if wrong: recovery could conflict with fresh state.
40. Final: Ruling: Concurrent settlement — no settlement race exercise. Cost if wrong: a battle could settle repeatedly or inconsistently.
41. Final: Ruling: Distinct complete combat cycles — legible requirements do not establish executable setup/payoff cycles. Cost if wrong: a roster cycle could fail or dominate despite readable text.
42. Final: Ruling: AI strategy — planner unchanged and no new strategy acceptance claimed. Cost if wrong: AI may still choose weak legal actions.
43. Final: Ruling: Natural combat pacing — no natural balance experiment in this cohort. Cost if wrong: combat could remain too long or one-sided.
44. Final: Ruling: Twelve-round balance — original benchmark acceptance remains open. Cost if wrong: a nominal test could hide poor intended pacing.
45. Final: Ruling: Fresh Owner edits — main unchanged on refreshed read; release-time content reconciliation still required. Cost if wrong: later Owner changes could be overwritten or omitted.
46. Final: Ruling: Atlas motion — no motion change or acceptance; known .830568 threshold miss stays open. Cost if wrong: motion may remain above the agreed limit.
47. Final: Ruling: Human gameplay acceptance — requires actual Owner gameplay evidence. Cost if wrong: software checks could miss poor play experience.
48. Final: Ruling: Broader Master panels — scheduled after combat package as instructed. Cost if wrong: unrelated Master workflows remain unfinished.
49. Final: Ruling: Exact frozen full root — parent owns actual gate and will read output before acceptance. Cost if wrong: an unobserved failure could invalidate the checkpoint.
50. Final: Ruling: All294 diagnostic — parent executed160709732791 and independently compared all report fields; static scope retained. Cost if wrong: SSR could miss mounted/native or contextual defects.
51. Final: Ruling: Publication — not authorized by this checkpoint; none performed. Cost if wrong: premature roster publication could expose unfinished mechanics.
52. Final: Ruling: Activation — not authorized by this checkpoint; none performed. Cost if wrong: unfinished definitions could become active.
53. Final: Ruling: Hosted writes — none necessary for local presentation work. Cost if wrong: remote state could change without accepted native gates.
54. Final: Ruling: Migration application — no migration necessary or applied. Cost if wrong: hosted authority/schema could change prematurely.
55. Final: Ruling: Merge — no merge authorized or performed. Cost if wrong: unaccepted combat integration could enter main.
56. Final: Ruling: Deployment/release — no release authorized; lock unchanged. Cost if wrong: users could receive unfinished combat behavior.

Deferred minors (existing10; no new findings):

- Final: minor (deferred): Rewind origin witness; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): SupportingShot version pin; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Ongoing pair identity pin; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Repeated bounded AI discovery; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Admission provenance prefix; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Ranged negative direct-commit witness; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Defense event/HP reconciliation; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Arsenal full-label/exact-history-value hardening; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Singular elemental-duration grammar; inherited, unchanged and not fixed in this bounded cohort.
- Final: minor (deferred): Ordinary Burn tick-boundary clarity; inherited, unchanged and not fixed in this bounded cohort.
