import subprocess, pathlib, hashlib, json, tarfile, base64, sys

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'effects-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = '6f246f7b76e5bca52c309c2fb2d8ae772215c073'
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in receipts if '20261016T060117688565Z.log' in r['log'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
assert '4039 passed (4039)' in log and '3429 passed (3429)' in log
bundle = workspace / ('executable-effects-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^eec45d645fa6f8faf51174cc8564e7d040f24ca7'], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'effects-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('executable-effects-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T0*.log')):
        if file.name >= '20261016T054400':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-executable-effects-review.md', 'task15-executable-effects-review.diff', 'effects-bundle-verify.log', 'save-effects-checkpoint.py', 'task15-status-requirement-preflight.md', 'task15-effects-I1-negative-control.patch']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'tests': {'vitest': 7714, 'node': 7}, 'prerequisite': 'eec45d645fa6f8faf51174cc8564e7d040f24ca7', 'previousArchiveCommit': 'c578c31c6132a647dc605896e489810b9db57d3b', 'previousArchiveTree': 'd5551ecf8636b83c8ff9d759ad42a2061dbf8e15', 'manifestSha256': 'bdceab2a7547845d15f20654c1dc758a97d6c104d2dad76c906364e4504cdd9f', 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': 'Bounded executable19effect-ID test milestone only; no runtime or manifest changes. Two Minor test-hardening items deferred: distinct prime witness and support-root version pin. Native UI/Atlas/all-tag executable evidence/whole-roster realAI-Level100/current Owner edits/hosted CAS remain OPEN; no hosted write, activation, merge or deployment.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
