# Combined executable-effect review

Reviewer /root/executable_effects_review, gpt-6-astra High, read-only; exact eec45d645fa6f8faf51174cc8564e7d040f24ca7..d8562a2fccae128d1f8a96aafcc74d73ab0e566d.
Verdict: bounded merge with fixes;0Critical/2Important/2Minor. No runtime defect, extraction regression or manifest drift. Reviewer did not duplicate parent suites.

Strengths: exact actual19-ID registry equality and primary versions; all old41test bodies/assertions preserved; real capture/prepare/commit/turns/JSON+stat validation; actual DoTprofiles/bases/ticks; real occupied Push/summon; selected Ground mapping/nativeautomaticaccuracy; honest futurePierce/currentDefense boundary and release limits.

ImportantI1: damage-bonus asserts event amounts and payment but not recipientHP (test:479–484), allowing boosted event with ordinary applied damage. Add actual974/971enemyHP assertions.
ImportantI2: generic negative guards can pass for unrelated reasons (test:53–56,93–100,485–493/report:11,29). Move path endpoint outside attack range; modifier replay45APversus55required plus active rootcooldown. Isolate bounds with expected issue code, excessive legal route ending inrange, sufficientresources and a different available compatible root while modifier remains oncooldown.

MinorM1: new Rewind witness prime equals turnorigin, though existing dedicated Controlled tests cover distinct prime. Deferred test hardening.
MinorM2: supporting AimedShot reportedversion5 is not separately pinned; only19primarywitnessversions pinned. Deferred test hardening.

Declined items all individually ruled with reason/cost in committed report:24statuses+2system/history;8Requirements;4activations;class/fourSkill/paircycles;294individualrecords;Level1/100PvE/PvP/twelve-roundbalance;realAI;everyDoTtick/decay/interact;everydownstreamstatusmechanic;summonabilities/AI;futureequipmentArmor;wholecatalogueGround/pub/timing;Owneredits/publication/migration/hostedCAS;derivedTags/prose/orange/readers;nativebrowser/editor/picker/keys/touch/layout/accessibility/Atlas;deploy/smoke/release;independentreplayofparentreceipts;unchangedbroaderbranch.

Parent: accept bothImportanttest-evidence findings; one scoped test-only fix pass with negativecontrol/failedprecondition receipts, no production change or rereview. Keep Minors deferred per selected workflow. ParentTask15/16 remain open.
