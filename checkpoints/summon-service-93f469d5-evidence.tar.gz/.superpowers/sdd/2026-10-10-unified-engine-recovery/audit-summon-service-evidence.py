from pathlib import Path
import json,subprocess,hashlib
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery');p=w/'summon-service-cycles-frozen.jsonl';rows=[json.loads(s) for s in p.read_text().splitlines()]
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
kinds=['persisted-expiry','paid-timeout-and-stale-clock','persisted-player-defeat','idle-owner-timeout']
assert len(rows)==16 and {(x['kind'],x['level'],x['context']) for x in rows}=={(k,l,c) for k in kinds for l in [1,100] for c in ['pve','pvp']}
units=lambda s:{u['id']:u for u in s['tactical']['battle']['combatants']}
ap=lambda u:next(r['current'] for r in u['temporaryResources'] if r['key']=='pv1f.action-economy')
summary=[]
for x in rows:
 assert x['seed']==1
 initial=x['initial'];commits=x['commits'];final=x['final'];first=commits[0];spawn=first['nextSnapshot'];child=spawn['effectState']['summons'][0];owner=child['ownerCombatantId'];cid=child['combatantId']
 assert child['sourceSkillVersion']==7 and child['profile']['maxHp']==36 and child['profile']['maxMp']==12 and child['profile']['lifetimeTurns']==5 and child['turnsCompleted']==0
 assert units(spawn)[owner]['mp']==units(initial)[owner]['mp']-6 and ap(units(spawn)[owner])==ap(units(initial)[owner])-50
 assert next(r['current'] for r in units(spawn)[owner]['temporaryResources'] if r['key']=='p3.skill-cooldown.wildwarden.renewing-herbs')==5
 assert x['version']==len(commits)+1 and final==commits[-1]['nextSnapshot']
 allEvents=[e for c in commits for e in c['events']]
 assert sum(e['event']=='summon_spawned' for e in allEvents)==1
 previous=initial;childTurns=0;timeout=[]
 for i,c in enumerate(commits):
  assert c['expectedBattleVersion']==i+1
  after=c['nextSnapshot'];assert after['capturedAbilitySources']==initial['capturedAbilitySources'] and after['buildAuthority']==initial['buildAuthority']
  assert c['privacyJournal']['schemaVersion']==1
  beforeTurn=previous['tactical']['battle']['currentTurn'];afterTurn=after['tactical']['battle']['currentTurn']
  if beforeTurn and beforeTurn['combatantId']==cid and (not afterTurn or afterTurn['combatantId']!=cid):childTurns+=1
  for e in c['events']:
   if e['event'] in ['pvp_turn_timed_out','ai_turn_timed_out']:
    assert e['combatantId']==owner
    beforeChild=previous['effectState']['summons'][0]
    assert after['effectState']['summons'][0]==beforeChild
    assert after['tactical']['battle']['turnNumber']==previous['tactical']['battle']['turnNumber']+1
    timeout.append(e)
  previous=after
 if x['kind']=='persisted-expiry':
  assert childTurns==5 and sum(e['event']=='summon_expired' for e in allEvents)==1 and not any(e['event']=='summon_defeated' for e in allEvents)
  assert any(e['event']=='summon_ai_decision' for e in allEvents) and any(e['event']=='summon_ability_used' for e in allEvents)
 if x['kind']=='persisted-player-defeat':
  assert sum(e['event']=='summon_defeated' for e in allEvents)==1 and not any(e['event']=='summon_expired' for e in allEvents)
  assert any(e['event']=='damage_applied' and e['targetCombatantId']==cid and e['hpAfter']==0 for e in allEvents)
 if x['kind'] in ['persisted-expiry','persisted-player-defeat']:
  assert not final['effectState']['summons'] and cid not in units(final) and cid not in final['tactical']['battle']['initiativeOrder']
  for group in [final['tactical']['placements'],final['statBridge']['combatants'],final['turnTriggerState']['combatants']]:assert not any(r['combatantId']==cid for r in group)
  assert not timeout
 if x['kind']=='paid-timeout-and-stale-clock':
  assert len(commits)==2 and len(timeout)==1 and timeout[0]['hadActivity'] and timeout[0]['consecutiveMisses']==0 and childTurns==0
  assert not any(e['event'].endswith('lowered_guard_applied') for e in allEvents)
 if x['kind']=='idle-owner-timeout':
  assert len(timeout)==1 and not timeout[0]['hadActivity'] and timeout[0]['consecutiveMisses']==1 and childTurns==0
  pending=[e for e in final['pendingEffects'] if e['effect'].get('statusId')=='lowered-guard']
  assert len(pending)==1 and pending[0]['recipientIds']==[owner]
  assert pending[0]['activationRound']==commits[-2]['nextSnapshot']['tactical']['battle']['round']+1
 assert final['tactical']['battle']['lifecycle']=='active' and units(final)[owner]['hp']>0
 summary.append({'kind':x['kind'],'level':x['level'],'context':x['context'],'commits':len(commits),'childTurnsCompleted':childTurns,'timeouts':timeout,'lifecycle':final['tactical']['battle']['lifecycle']})
base='083faeae23562f0dc91a9bb3a84de2ab5b62741f';source=(w/'summon-service-tested-source.txt').read_text().strip()
assert git('diff','--name-only',base,source).splitlines()==['apps/web/src/server/battle/roster-legal-summon-services.test.ts']
manifest=Path('docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json');assert sha(manifest)=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
hashes=json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes']
for name,d in hashes.items():assert sha(Path(name))==d
result={'source':source,'base':base,'traceRows':len(rows),'traceBytes':p.stat().st_size,'traceSha256':sha(p),'summary':summary,'runtimeContentHelpersAndPriorFixturesUnchanged':True,'protectedHashesUnchanged':hashes,'rosterManifestSha256':sha(manifest),'deploymentLockBlob':git('rev-parse','HEAD:apps/web/vercel.json'),'externalClockAndRepositoryTransportSimulated':True,'hostedSqlOrPhysicalCasVerified':False}
assert result['deploymentLockBlob']=='b8a4e0e3c57b95a8da49c05d1fe5f60ba2181b5f'
(w/'summon-service-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['summary','protectedHashesUnchanged']}))
