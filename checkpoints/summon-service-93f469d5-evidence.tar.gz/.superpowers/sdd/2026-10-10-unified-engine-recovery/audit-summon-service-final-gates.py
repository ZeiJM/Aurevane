from pathlib import Path
import json,subprocess,re,hashlib,datetime,tarfile
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery');rs=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
source=(w/'summon-service-tested-source.txt').read_text().strip();stamp=datetime.datetime.fromisoformat(subprocess.check_output(['git','show','-s','--format=%cI',source],text=True).strip())
def receipt(fragment):
 r=next(r for r in rs if fragment in r['log']);assert r['exit_code']==0 and datetime.datetime.fromisoformat(r['started_utc'])>=stamp;return r,Path(r['log']).read_text()
primary,p=receipt('20261017T105111302587Z-70c0645f');final,f=receipt('20261017T105241490488Z-058a9610');build,b=receipt('20261017T105352135386Z-e48b1e7e')
assert primary['argv']==final['argv']==['pnpm','--reporter=append-only','check'] and build['argv']==['pnpm','--reporter=append-only','build']
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',p);assert len(counts)==7 and sum(int(n) for _,n in counts)==9062
assert 'ℹ pass 7' in p and 'ℹ fail 0' in p and '$ turbo run build' in p
assert '$ turbo run build' in b and '2 successful, 2 total' in b and '@aurevane/worker:build:' in b and '@aurevane/web:build:' in b
artifacts=[]
for name in ['BUILD_ID','build-manifest.json','routes-manifest.json','required-server-files.json','prerender-manifest.json','server/app-paths-manifest.json']:
 path=Path('apps/web/.next')/name;data=path.read_bytes();assert data
 if name.endswith('.json'):json.loads(data)
 artifacts.append({'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mtimeUtc':datetime.datetime.fromtimestamp(path.stat().st_mtime,datetime.timezone.utc).isoformat()})
logs=[]
with tarfile.open(w/'summon-service-turbo-logs.tar.gz','w:gz') as a:
 for base in [Path('apps'),Path('packages')]:
  for path in sorted(base.glob('*/.turbo/turbo-*.log')):
   data=path.read_bytes();logs.append({'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});a.add(path,arcname=str(path))
result={'source':source,'receipt':final,'primarySuccessfulReceipt':primary,'buildReceipt':build,'counts':counts,'countsSource':'first successful unchanged-source root gate','rootCounts':re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',f),'rootBuildTailComplete':False,'multiArtifactEvidenceComplete':True,'literalTwoBuildSummaryFromDedicatedBuild':True,'noThirdWholeGateReplay':True,'artifacts':artifacts,'logs':logs,'limitation':'Both successful root stdout files truncate; first retains all test/Node counts and build marker, second only start. Dedicated cached build retains literal 2-success tail; raw logs and package archives are retained.'}
(w/'summon-service-fullcheck-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['logs','artifacts']}))
