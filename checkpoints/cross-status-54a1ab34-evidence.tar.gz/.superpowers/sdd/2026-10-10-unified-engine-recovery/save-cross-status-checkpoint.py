import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'cross-status-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'cross-status-tested-source.txt').read_text().strip();reviewed=(w/'cross-status-reviewed-source.txt').read_text().strip();base='5d4dd27125a69d76dff0d2f0c522fb10b106eaf3'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert set(paths)=={'apps/web/src/components/character/canonical-effect-explanation.ts','apps/web/src/components/character/canonical-status-explanation.ts','apps/web/src/components/character/linked-cross-status-references.test.tsx','docs/verification/2026-10-16-cross-status-reader-references.md'},paths
assert tested==reviewed
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8449,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'cross-status-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['plainDescriptionsChanged']==0 and observed['addedReferenceNodes']==65 and observed['effectPacketsWithNewReferenceMetadata']==42 and observed['allPriorStructuredFieldsAndExistingReferenceMetadataExactlyUnchanged'] and observed['allStaticVisibleReaderTextExactlyUnchanged'] and observed['eachNewReferenceExactlyMatchesTypedInventoryRecordGroupEffectAndExpectedOccurrences'] and observed['rawSha256']==sha(w/'cross-status-reader-observation.json')
bundle=w/('cross-status-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'cross-status-bundle-verify.log').write_text(v.stdout)
evidence=w/('cross-status-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','task15-cross-status-next-brief.md','requirements-next-cross-status-inventory.json','cross-status-combined-review-package.md','cross-status-review-rulings.md','task15-cross-status-reader-review.md','cross-status-tested-source.txt','cross-status-reviewed-source.txt','cross-status-bundle-verify.log','verification.jsonl','run.py','save-cross-status-checkpoint.py','cross-status-readers-diagnostic.test.tsx','vitest-cross-status-reader.config.ts','cross-status-reader-observation.json','cross-status-reader-analysis.json','analyze-cross-status-readers.py','cross-status-reference-observation.json','cross-status-fullcheck-audit.json','cross-status-turbo-logs.tar.gz','requirements-reader-observation.json','ranged-ai-analysis.json','finalize-cross-status-report.py','audit-cross-status-fullcheck.py','task15-live-effect-integration-next-notes.md','cross-status-checkpoint-summary.txt']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T172300':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'0b81f2d0ac53f6d508e3a0f467192250a4cc7a6d','previousArchiveTree':'5c0b1706bc735b86709c0b20567d5202695da154','fullCheckReceipt':gate,'tests':{'vitest':8449,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/'cross-status-checkpoint-summary.txt').read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
