# Parent rulings for the single cross-status review

Reviewer0C/0I/1newMinor; parentacceptsgrades. NoCIfixwaveor rereview. NewtestinputimmutabilityMinorjoins11inherited, total12deferred.

1. Ruling: Native interaction — Keep open: unchanged shared interaction code and controlled callbacks do not establish browser hover, focus, touch or dismissal acceptance. Cost if wrong: An interaction defect can remain until native acceptance.

2. Ruling: Long-text/mobile/200% zoom geometry — Keep open: static SSR does not measure physical geometry; layout source is unchanged. Cost if wrong: Clipping or obstruction may require later work.

3. Ruling: Master inline reference-button sizing — Inherited Minor remains deferred; no measured obstruction supports promotion. Cost if wrong: Enlarged inline spacing can remain.

4. Ruling: Singular elemental clock grammar — Inherited Minor remains deferred; no clock source changed. Cost if wrong: One-duration grammar stays awkward.

5. Ruling: Burn ordinary tick-boundary wording — Inherited Minor remains deferred; adding links does not resolve that application-neutral wording. Cost if wrong: The exact ordinary tick boundary remains less discoverable.

6. Ruling: Unsupported Reveal/Revealed/Cleanse/Dispel and other terms — Stand scoped: only five existing identities are newly referenced; plain unsupported terms are not advertised as linked. Cost if wrong: Separate explicit identity/help integration is still needed.

7. Ruling: Noncanonical historical prose — Keep open: existing noncanonical branches remain plain and are not inferred from words. Cost if wrong: Older sentences may lack linked terms.

8. Ruling: Plain native Basic and summon wording — Keep open: this bounded canonical template addition does not certify every native fallback. Cost if wrong: Those readers still need separate review.

9. Ruling: Public Manual rich references — Keep open: an existing plain-summary reader is not converted by metadata alone. Cost if wrong: Manual readers still lack complete linked behavior.

10. Ruling: Live-instance stacks/magnitude/lifetime/readiness — Keep open: generic references cannot identify a specific active application. Read-only next notes prioritize actual-instance reader integration. Cost if wrong: Specific combined values and remaining lifetimes remain acceptance work.

11. Ruling: Third-level references inside compact help — Stand: leaf bodies stay plain to preserve finite nesting and usable dismissal. Cost if wrong: A reader cannot follow another link inside the leaf.

12. Ruling: Prototype-name behavior in other core callers — Stand scoped: the canonical web dictionary now rejects inherited entries; no broader core-hardening claim. Cost if wrong: Other callers may retain inherited fallthrough.

13. Ruling: Malformed nested/captured/pending/summon authority — Stand scoped: source adds optional public strings/tag nodes, without replacing validation/capture/serialization. Cost if wrong: Broader malformed-data acceptance remains open.

14. Ruling: Private-accuracy enforcement — Stand scoped: no private state or accuracy is added to nodes; existing viewer projection remains authority. Cost if wrong: Full privacy acceptance is not re-audited by this presentation change.

15. Ruling: Expiry/revocation and selected-character/direct-RPC authorization — Stand scoped: no capability or protected operation changes. Cost if wrong: Task8/16 hosted authorization acceptance remains open.

16. Ruling: No-input/free-prime/duplicate-payment/events/interrupted Move execution — Stand scoped: timing text is verified, execution source is unchanged; root regressions are distinct from final gameplay acceptance. Cost if wrong: Full timeout/payment/interruption scenarios remain release gates.

17. Ruling: Concurrent publication/build/claim/recovery/settlement — Stand scoped: no lifecycle, transaction or worker change. Cost if wrong: Hosted concurrency acceptance remains separate.

18. Ruling: Full roster cycles/AI/natural pacing/twelve-round balance — Stand scoped: six source-hash guards and root regressions protect presentation-only work; no new289 is claimed. Cost if wrong: Natural pacing and distinct/full cycles/balance remain open.

19. Ruling: Hosted Owner reconciliation/Atlas motion/human/release — Keep open: no hosted write, migration, publication, activation, merge or deploy is included. Cost if wrong: The combat update remains unreleased.

20. Ruling: Exact-head root suite/all294 completion — Parent owns verification: all294 already passes172516171916 with65nodes/42packets/252othermarkup unchanged; exact-source full8449+7 still must complete before final claim. Cost if wrong: Static evidence alone cannot certify all checks.

