from pathlib import Path
import json,hashlib,re,collections,copy
w=Path(__file__).resolve().parent;root=w.parents[2]
a=json.loads((w/'cross-status-reader-observation.json').read_text());b=json.loads((w/'requirements-reader-observation.json').read_text())
assert len(a['records'])==len(b['records'])==294
inventory=json.loads((w/'requirements-next-cross-status-inventory.json').read_text())['effects']
expected={}
for item in inventory:
 tags=item['existingSupportedCrossTags'];expected[(item['record'],item['group'],item['effect'])]=['covert','covert'] if item['payload']['type']=='sensory' else tags
nodes=[];changed=[];groups=effects=0;seen=set()
for now,old in zip(a['records'],b['records'],strict=True):
 assert now['id']==old['id'] and now['groups']==old['groups']
 normalized=copy.deepcopy(now['reports'])
 for i,(group,report,prior) in enumerate(zip(now['groups'],now['reports'],old['reports'],strict=True)):
  for j,(effect,presentation,priorEffect) in enumerate(zip(group['effects'],report['effects'],prior['effects'],strict=True)):
   key=(now['id'],group['id'],effect['id'])
   if key not in expected:continue
   seen.add(key)
   assert 'explanationParts' not in priorEffect,key
   parts=presentation['explanationParts']
   assert ''.join(p if isinstance(p,str) else p['label'] for p in parts)==report['effectDescriptions'][j],key
   refs=[p for p in parts if not isinstance(p,str)]
   assert [p['tag'] for p in refs]==expected[key],key
   for part in refs:
    assert set(part)=={'tag','label','explanation'} and all(isinstance(x,str) and x for x in part.values()),(key,part)
    nodes.append({'record':key[0],'group':key[1],'effect':key[2],**part})
   del normalized[i]['effects'][j]['explanationParts']
 assert normalized==old['reports'],now['id']
 assert len(now['html'])==len(old['html'])
 for n,o in zip(now['html'],old['html'],strict=True):assert re.sub(r'<[^>]*>','',n)==re.sub(r'<[^>]*>','',o),now['id']
 if now['html']!=old['html']:changed.append(now['id'])
 groups+=len(now['groups']);effects+=sum(len(g['effects']) for g in now['groups'])
assert groups==297 and effects==604 and seen==set(expected)
assert len(nodes)==65 and len(changed)==42 and set(changed)=={x['record'] for x in inventory}
result={'source':a['source'],'rawSha256':hashlib.sha256((w/'cross-status-reader-observation.json').read_bytes()).hexdigest(),'records':294,'groups':groups,'effects':effects,'plainDescriptionsChanged':0,'allPriorStructuredFieldsAndExistingReferenceMetadataExactlyUnchanged':True,'allStaticVisibleReaderTextExactlyUnchanged':True,'recordsWithNewReferenceMarkup':changed,'allOtherRecordMarkupExactlyUnchanged':294-len(changed),'addedReferenceNodes':len(nodes),'effectPacketsWithNewReferenceMetadata':len(seen),'referenceNodeCounts':dict(collections.Counter(n['tag'] for n in nodes)),'eachNewReferenceExactlyMatchesTypedInventoryRecordGroupEffectAndExpectedOccurrences':True,'scope':'Default-context static named-reader SSR, exact report/text comparison and typed effect binding only; no native interaction/layout/full editorial acceptance.'}
assert result['source']==(w/'cross-status-tested-source.txt').read_text().strip()
assert hashlib.sha256((root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json').read_bytes()).hexdigest()=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for p,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest,p
(w/'cross-status-reader-analysis.json').write_text(json.dumps(result,indent=2)+'\n');(w/'cross-status-reference-observation.json').write_text(json.dumps(nodes,indent=2)+'\n')
print(json.dumps(result))
