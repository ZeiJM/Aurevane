from pathlib import Path
import json,re,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8449
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
source=(w/'cross-status-tested-source.txt').read_text().strip();reviewed=(w/'cross-status-reviewed-source.txt').read_text().strip();assert source==reviewed
observed=json.loads((w/'cross-status-reader-analysis.json').read_text());assert observed['source']==source
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
rulings=(w/'cross-status-review-rulings.md').read_text().split('\n\n',2)[2]
report=f'''# Generated cross-status references — verified development checkpoint

This bounded Task15 change adds **65 explicit references in 42 effect packets across 42 proposed records**: Rooted 25, Covert 6, Burn 14, Poison 10 and Bleed 10. Displacement links Rooted; Reveal links both actual Covert mentions; Suppress links Burn/Poison/Bleed; Burn Ward links Burn. Known typed payload branches author the reference templates. There is no keyword replacement or new reference identity.

Existing English, recipients, values, meaningful conditions and timing remain unchanged. Plain descriptions and typed parts come from one template source. The canonical status description table now supports plain strings and typed templates, with an own-property guard so a status named `constructor` cannot become a JavaScript function description. This guard applies to this web dictionary, without claiming broader core fallback hardening.

The existing report → resolver → text view → shared popover path carries the metadata through full definitions, shared readers, manual modifiers and native Basic information. Existing captured policy context, selected-group binding, authored overrides and stale escaped-text fallback remain intact. Delayed and Controlled appendages retain their exact text. Generic referenced explanations stay plain leaf bodies, preserving finite help depth and avoiding invented active-application magnitudes or durations. No client interaction, CSS, geometry, popup system, combat runtime, schema, manifest, AI or native fixture change is included.

## Verification

- TDD `172325770225`: nine valid failures (eight missing-reference assertions and the inherited prototype-entry fallthrough) plus two existing guards GREEN; no import failure. Corrected implementation passes 47 tests in three files `172401710626`, then 377 focused tests in 42 files `172409509035`. Web typecheck GREEN `172409509008`. Eleven new cases.
- One fresh read-only combined review inspected all three changed files and actual consumers/capture helpers: **0 Critical, 0 Important, 1 new Minor**. Parent accepts those grades. No C/I repair wave and no rereview. The new Minor is a test weakness: the direct report call parses a second definition, so one immutability assertion does not observe that direct input. No runtime mutation or reader defect was demonstrated. It joins eleven inherited deferred Minors; total twelve.
- Reviewed and tested source `{source}` passes **8,449 Vitest plus seven Node checks**, all eight workspace typechecks, lint, formatting and both builds. Complete direct root receipt `{Path(gate['log']).stem}`: {gate['started_utc']} → {gate['completed_utc']}. No root stdout truncation or cached root replay.
- Diagnostic `172516171916` observes all 294 records, 297 groups and 604 effects. Every prior structured field, plain description, static visible reader string and existing reference field is exact. Only the 42 intended packets gain explanation metadata; all 65 nodes match exact inventory record/group/effect/occurrence expectations. Forty-two records gain markup; the other 252 are byte-identical. Raw observation SHA256 `{observed['rawSha256']}`. This is default-context static named-reader evidence, not native interaction or full editorial acceptance.
- Accepted manifest and six AI/native fixture source hashes remain unchanged. No new 289-case matrix is claimed for presentation-only work; prior complete gameplay evidence remains a separate reference.

## Release scope and next work

The live modular foundation, proposed Skill rebalance and original unfinished combat integration remain distinct. Original Targeting/Move/five editable Basics/Controlled integration, complete controls/editors/readers/previews and native acceptance must finish before combat release. Full distinct roster cycles, natural pacing and twelve-round balance, Owner current edits, hosted SQL/CAS, Atlas motion, human and release gates remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat. This checkpoint publishes, activates, applies migrations, merges and deploys nothing. High remains sufficient for routine integration.

Next is actual active-effect reader integration, with captured stacks, current combined strength, remaining lifetime and readiness. Read-only notes trace the shared `BattleCombatantEffects`/`describeBattleEffect` path and the separately mounted legacy `BattleStatusEffectAssist`; its actual trigger coverage and captured facts must be traced before a fix is designed. Existing native popovers are not accepted merely because a legacy assist exists. No next-cohort source edits are included here. Public Manual rich references, other generated/noncanonical prose, remaining elemental/removal references and complete native acceptance remain unfinished. No repeated browser install or tunnel attempt was made.

The provisional combat/rebalance testing-release estimate remains 16–30 active working hours, roughly 2–4 full working days, subject to final integration/acceptance findings; this is not a calendar launch promise.

## Deferred minors

All eleven inherited Minors remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI route/target discovery; admission double-prefix provenance; ranged negative preparation direct-commit witness; independent HP reconciliation in defense-positive events; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button minimum height/font sizing. New twelfth Minor: one cross-status immutability assertion compares a different parsed definition from the direct report-generation input. No incidental Minor fix is included.

## Rulings I made

Implementation rulings:

- Only supported identities in actual payload branches gain links. Reason: words and capitalization do not establish semantic identity. Cost if wrong: a newly supported term needs separate explicit identity/help work.
- Both Covert occurrences link; Reveal/Revealed remain plain. Reason: the inventory's 62 semantic candidates represent 65 actual textual occurrences, and unsupported identities must not be invented. Cost if wrong: other terms remain plain until supported.
- The mixed plain/rich status dictionary requires an own key. Reason: Object prototype functions are not descriptions. Cost if wrong: untouched core fallbacks may retain their inherited prototype issues.
- Generic compact help remains a plain leaf. Reason: nesting depth and touch dismissal must stay usable. Cost if wrong: readers cannot follow third-level references.

Every reviewer set-aside behavior receives a separate parent disposition with reason and cost below.

{rulings}
'''
(root/'docs/verification/2026-10-16-cross-status-reader-references.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Final generated cross-status checkpoint verification\n'+report+'\n')
print(json.dumps({'source':source,'reviewed':reviewed,'vitest':8449,'node':7,'rootReceipt':gate,'nodes':65,'packets':42,'parentRulings':20,'deferredMinors':12}))
