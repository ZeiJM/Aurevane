import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'defense-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'defense-tested-source.txt').read_text().strip();base='034a56fb4fcb3c21996a7e2615a8ddc5dc1176b9'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
assert set(git('diff','--name-only',base,head).splitlines())=={'apps/web/src/server/battle/roster-legal-defense-payoff-cycles.test.ts','docs/verification/2026-10-16-defense-payoff-cycles.md'}
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()];gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8242
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
natural=json.loads((w/'defense-payoff-natural-analysis.json').read_text());assert natural['cases']==8 and natural['rawSha256']==sha(w/'defense-payoff-natural.jsonl')
bundle=w/('defense-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'defense-bundle-verify.log').write_text(v.stdout)
evidence=w/('defense-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','task15-defense-cycle-next-brief.md','task15-defense-cycle-review.md','defense-payoff-natural.jsonl','defense-payoff-natural-analysis.json','defense-payoff-natural-diagnostic.test.ts','roster-legal-defense-payoff-cycles.draft.ts','defense-tested-source.txt','defense-bundle-verify.log','verification.jsonl','run.py','save-defense-checkpoint.py']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T132600':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'prerequisite':base,'previousArchiveCommit':'d04f84e64d0ecc9be8f9b38f4ca3e8f66d8fb8af','previousArchiveTree':'a7650c68e4313d2c9c4c40e462e3f1abb1c2da9b','fullCheckReceipt':gate,'tests':{'vitest':8242,'node':7},'bundle':info(bundle),'evidence':info(evidence),'acceptance':'12 actual learned defensive setup/payoff/counter witnesses.8 observational natural runs:both Level100 kits activeafter40.0C0I1newMinor;7deferred. Test-only production/manifest/defaultfixture unchanged from prior0cf. No duplicate289 replay. Targeting/Move/Basics/Controlled/editor/readers/previews/native acceptance and fullTask15/16/balance/hosted/Atlas/human/release OPEN. No activation/publication/migration/merge/deploy.'}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
