from pathlib import Path
import json,hashlib,subprocess
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery');p=w/'earned-rewind-actual-cycles-frozen.jsonl'
rows=[json.loads(s) for s in p.read_text().splitlines()]
kinds={'same-turn-return':20,'wounded-later-return':40,'occupied-then-vacated-anchor':60,'held-then-returned':60,'cancelled-without-return':60}
assert len(rows)==20 and {(r['kind'],r['level'],r['context']) for r in rows}=={(k,l,c) for k in kinds for l in [1,100] for c in ['pve','pvp']}
def unit(s,id):return next(r for r in s['tactical']['battle']['combatants'] if r['id']==id)
def pos(s,id):return next(r['position'] for r in s['tactical']['placements'] if r['combatantId']==id)
def ap(s,id):return next(r['current'] for r in unit(s,id)['temporaryResources'] if r['key']=='pv1f.action-economy')
observations=[]
for row in rows:
 stages=row['stages'];initial=stages[0]['state'];actor=initial['tactical']['battle']['currentTurn']['combatantId'];prime=stages[2]['state'];departure=stages[3]['state'];last=stages[-1];final=last['state']
 assert pos(initial,actor)=={'x':0,'y':1} and pos(prime,actor)=={'x':1,'y':1} and pos(departure,actor)=={'x':2,'y':1}
 assert prime['abilityRuntime']['controlled']['primes'][0]['returnAnchor']=={'x':1,'y':1}
 assert prime['tactical']==stages[1]['state']['tactical'] and stages[2]['events']==[]
 source=[s for s in initial['capturedAbilitySources'] if s['ownerCombatantId']==actor and s['abilityId']=='chronist.rewind-step'];assert len(source)==1 and source[0]['contentVersion']==6
 assert ap(final,actor)==kinds[row['kind']]
 assert len(final['abilityRuntime']['controlled']['primes'])==0 and len(final['abilityRuntime']['controlled']['used'])==1
 assert final['tactical']['battle']['lifecycle']=='active'
 if row['kind']=='cancelled-without-return':
  assert pos(final,actor)=={'x':2,'y':1} and last['events']==[] and final['tactical']==departure['tactical']
 else:
  assert pos(final,actor)=={'x':1,'y':1}
  events=last['events'];payments=[e for e in events if e['event']=='ap_spent' and e['combatantId']==actor];mana=[e for e in events if e['event']=='mp_spent' and e['combatantId']==actor]
  assert len(payments)==1 and payments[0]['amount']==40 and payments[0]['remaining']==kinds[row['kind']]
  assert len(mana)==1 and mana[0]['amount']==4 and mana[0]['remaining']==unit(final,actor)['mp']
  returns=[e for e in events if e['event']=='combatant_rewound'];assert len(returns)==1 and returns[0]['combatantId']==actor and returns[0]['to']=={'x':1,'y':1} and returns[0]['actionId']=='chronist.rewind-step'
  assert unit(final,actor)['mp']==unit(initial,actor)['mp']-4
 hit=next((s for s in stages if s['label']=='actual-opposing-basic'),None)
 if hit:
  damage=[e for e in hit['events'] if e['event']=='damage_applied' and e['targetCombatantId']==actor];assert len(damage)==1 and damage[0]['amount']>0
  assert damage[0]['hpAfter']==unit(final,actor)['hp'] and damage[0]['hpBefore']-damage[0]['hpAfter']==damage[0]['amount']
 blocked=next((s for s in stages if s['label']=='blocked-unpaid-release'),None)
 if blocked:
  enemy=next(u['id'] for u in blocked['state']['tactical']['battle']['combatants'] if u['id']!=actor)
  assert pos(blocked['state'],enemy)=={'x':1,'y':1} and ap(blocked['state'],actor)==80
  assert blocked['state']['abilityRuntime']['controlled']['primes'][0]['returnAnchor']=={'x':1,'y':1}
 observations.append({'kind':row['kind'],'level':row['level'],'context':row['context'],'seed':row['seed'],'sourceId':source[0]['sourceInstanceId'],'contentVersion':6,'hpBefore':unit(initial,actor)['hp'],'hpAfter':unit(final,actor)['hp'],'mpBefore':unit(initial,actor)['mp'],'mpAfter':unit(final,actor)['mp'],'apAfter':ap(final,actor),'positionAfter':pos(final,actor),'movementRemainingAfter':final['tactical']['battle']['currentTurn']['movementRemaining']})
result={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'records':20,'traceBytes':p.stat().st_size,'traceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'fullEventReplay':False,'allSourcePositionPaymentAndWoundedHpAuditsPassed':True,'observations':observations}
(w/'earned-rewind-observations.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='observations'}))
