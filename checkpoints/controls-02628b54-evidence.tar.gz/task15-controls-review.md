# Task15 active special / noncast controls review

Reviewed the complete frozen milestone diff over `ecdfad4325fa72b00a21049158fd898901939cbf`, plus the untracked `battle-ability-controls.test.ts`, and relevant shared controller, reader, cooldown, targeting, runtime construction, source-resolution and keyboard callers. Scope is the ten product/test files described in `task15-controls-review.diff`; this is not an inherited-branch or whole-Task15 acceptance review.

Authority consulted: root and battle `AGENTS.md`, continuation and next-controls preflights, latest progress ledger, engineering/concurrent-work standards and the accepted recovery/roster contracts. No product edits, external writes, helpers or duplicate test suites were run. `git diff --check` passes. The implementer's focused 74-test/type/lint receipts were treated as reported evidence, not independently rerun evidence. Browser acceptance and the running full check are not claimed here.

## Critical

None found.

## Important

### I1 — Noncast information hotkeys are disabled outside the local turn

**Location:** `apps/web/src/components/battle/battle-experience.tsx:2095`, with the newly added information branches at `2122–2129` and `2139–2152`.

**Scenario:** Equip an Automatic/Ongoing/modifier-only Skill, let the opponent own the turn, and press that slot's configured key. `planningDisabled` is true because `localTurn` is false (`719–724`), so the handler returns before clicking its information trigger. The same problem affects noncast special information, and terminal battles. The normal pointer information button remains available, but native Tab/Shift+Tab cycling is deliberately prevented, so the advertised slot binding does not provide keyboard access in these ordinary reading states.

**Required correction:** Resolve read-only noncast Skill/special information shortcuts before the command-only planning/execution gate, while retaining the existing text-entry/modal/repeat/modifier-key guards. Commands must still remain disabled. Add a focused controller/shortcut regression for an opponent-owned turn and completed battle, asserting information opens without preview/commit.

This is a failure of the explicitly accepted keyboard-access requirement, not an authority bypass.

## Minor

### M1 — An unavailable canonical Manual Resonance is falsely labelled Passive

**Location:** `apps/web/src/components/battle/battle-selected-skills.tsx:309–313`.

**Scenario:** A canonical Resonance definition contains a Manual Action but has no active actor-owned Manual reference (removed/inactive source or only another owner's capture). `battleCapturedSpecialAction` correctly returns undefined and no action is offered, but `resonanceMode.canCast` is true, so the caption falls through to `Resonance · Passive`. Its full reader still describes the Manual Action. Label this canonical unavailable state truthfully; keep the historical absent-definition Passive label and actual Automatic/Ongoing/Modifier labels. The descriptor/hotkey fails closed, so this does not allow an invalid cast.

### M2 — Newly active Resonance footprints lose attack/recovery semantics

**Location:** `apps/web/src/components/battle/battle-captured-action-cost.ts:76–89`, consumed by `battle-experience.tsx:756`, `1771–1786` and `2728–2750`.

**Scenario:** Arm an active healing Resonance such as the accepted `resonance.cinderweaver-lifebinder.linked-sequence`, or a damaging active Resonance. The synthetic presentation always has empty tags and no definition. Consequently `battleActionUsesRecoverySelection` and `damagingSelection` both return false, and its legal non-ground footprint gets `data-buff-path` rather than the established healing/attack indication. The accepted mixed-command Aetherist/Edgedancer pair also retains its first group's utility category when its attack group is selected. Captured target geometry and actual server outcomes remain correct; the visual targeting meaning does not follow the selected command. Carry safe selected-group semantics through the shared adapter instead of inferring them from empty native envelopes.

## Declined judgments and preserved behavior

- No reproducible source/actor/version or stale-command authority bypass was found. Owner filtering precedes client resolution; server projection includes only active captured sources; `capturedBattleActionSource` verifies the actual actor, source kind, captured content version and exact Resonance pair-derived source identity. Versioned commit, turn/lifecycle, focus, repeat and pending guards remain in the real shared path.
- No extra Skill slot or artwork-size/layout change was introduced. Resonance uses the same existing special action markup/CSS contract as Essence; desktop/mobile visual acceptance still requires the separately pending actual browser check.
- Multi-command resolution remains explicit and fails closed until a behavior is selected; selected behavior, captured geometry, costs and Controlled metadata propagate into preview/commit intents. Shared captured cooldown lookup remains authoritative. No recommendation was made to silently select the first Manual behavior.
- Historical absent-canonical-definition fallback is preserved. Present canonical definitions with no Manual capture now fail closed in the resolver; Automatic/Ongoing/modifier-only entries are excluded from cast lists and their hotkeys do not manufacture native action descriptors.
- Controlled self-targeting, area targeting, free prime and ordinary release route through existing shared intent/commit machinery. No new queue or local payment/authority implementation was introduced. This read-only review does not establish browser/touch/zoom or full-roster acceptance.
- Explicit Manual modifier selection, event-conditioned Master previews, broad final prose/readability work, publication and release remain outside this bounded milestone. Their incompleteness is not reported as a new defect in these ten files.

## Assessment

Address I1 before accepting this bounded controls milestone. M1 and M2 are concrete presentation corrections; none of the findings requires changing the combat kernel or loosening server authority. Full-check and actual responsive keyboard/touch browser evidence remain required by the existing acceptance plan.
