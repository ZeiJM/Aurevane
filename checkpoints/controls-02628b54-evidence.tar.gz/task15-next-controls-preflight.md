# Next specified Task15 consumer milestone — source map only

Ground support is a separate checkpoint. Do not count the notes below as completed controls or combined release acceptance.

## Active Resonance

- BattleSelectedSkills has exclusive Essence/Resonance artwork already; preserve its square dimensions/columns. Resonance currently uses nonbutton span and literal Passive. Reuse actionCost/ControlledReady/SkillCooldown for an owner-captured Manual Resonance, keeping ResonanceParameters for its full information reader. Historical/noncast Resonances remain information-only.
- BattleExperience only includes runtime.essence in attack options/cooldown list/actionDescriptor/selected special fallback/essence hotkey. The shared special hotkey must select the actual owner-captured active Resonance, prime/release through current authority, or open information for noncast history.
- Safe manualActionTargets already projects owner, action/group ID, costs, cooldown, report, geometry, Move and Controlled. Add safe typed classification if needed for menu routing, not prose parsing or parallel execution. Multiple groups remain explicit choices with shared native cooldown; no ambiguous fallback cast.
- A single helper deriving a safe active special presentation from runtime plus actor-owned captured references can keep card/menu/descriptor/hotkey from drifting. Never manufacture a caster endpoint from Resonance passive prose or trust a different controlled actor's capture.

## Automatic/Ongoing/modifier-only Skills

- Runtime four cards still show cast controls/fallback native costs for every equipped Skill. Derive truthful noncast state from the captured canonical public definition, retaining historical fallback only when immutable metadata is actually absent.
- Keep information access and existing artwork; label Automatic/Ongoing/Modifier honestly and do not add action slots.
- Exclude these from selectable cast lists and reject hotkey/descriptor fallback; a hidden or disabled button alone does not establish controller parity. Native server authority continues to reject malformed intents.

## Explicit modifiers

- Snapshot manualModifierAvailability exists and is owner-filtered; references use sourceInstanceId+behaviorId and server binding retains root/source/owner/version authority.
- Player selection must be explicit, reflected in every preview and commit and cleared on relevant stale source/battle/actor/root/group changes. Use canonical composition and costs, no extra action queue.

Required before live: actual desktop/mobile/keyboard/touch/200% integration, all related authoring/previews/reader flows and complete roster balance/AI. Final reader audit still owes concise plain-language descriptions, no duplicate non-damage values or timing, matching orange labels/values and the reviewed Ground subset note.
