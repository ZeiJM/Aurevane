import datetime
import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='public-manual-mechanics';payload=w/(prefix+'-backup-payload.json')
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip();base='62aaebb264bfec2e130868aad6a2fdd1f6b3427a'
report='docs/verification/2026-10-16-public-manual-mechanics.md'
assert git('diff','--name-only',tested,head).splitlines()==[report]
paths=set(git('diff','--name-only',base,head).splitlines());assert paths=={report,'apps/web/src/components/public-information/manual-article.module.css','apps/web/src/content/manual-mechanic-text.ts','apps/web/src/content/public-information.ts','apps/web/src/content/techniques-manual.ts','apps/web/src/components/public-information/manual-article.tsx','apps/web/src/components/public-information/manual-mechanic-text.tsx','apps/web/e2e/fixtures/public-manual-mechanics.test.tsx','apps/web/src/app/manual/[slug]/page.test.tsx'},paths
assert reviewed=='1ead4e9351b28bd57159eeb9acfe736a225566aa' and len(tested)==40
subprocess.run(['git','merge-base','--is-ancestor',reviewed,tested],check=True)
expected=int((w/(prefix+'-test-count.txt')).read_text());receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert datetime.datetime.fromisoformat(gate['started_utc']) >= datetime.datetime.fromisoformat(git('show','-s','--format=%cI',tested))
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/(prefix+'-reader-analysis.json')).read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged'] and observed['rawSha256']==sha(w/(prefix+'-reader-observation.json'))
plain=json.loads((w/(prefix+'-plain-analysis.json')).read_text());assert plain['source']==tested and plain['allPlainArticleDataExactlyUnchanged'] and plain['rawSha256']==sha(w/(prefix+'-plain-observation.json'))
contrast=json.loads((w/(prefix+'-contrast-observation.json')).read_text());assert all(row['minContrast']>=4.5 for row in contrast['rows'])
rendered=json.loads((w/(prefix+'-render-observation.json')).read_text());assert len(rendered)==2 and all(row['visibleTextExactlyPreserved'] and row['compactEffects']>0 for row in rendered)
assert next(row for row in rendered if row['id']=='builtin')['references']==0
assert next(row for row in rendered if row['id']=='proposed')['references']>0
bundle=w/(prefix+'-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/(prefix+'-bundle-verify.log')).write_text(v.stdout)
evidence=w/(prefix+'-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','task15-public-manual-mechanics-brief.md',prefix+'-combined-review-package.md','task15-public-manual-mechanics-combined-review.md',prefix+'-review-outcome.md',prefix+'-review-rulings.md',prefix+'-implementation-notes.md',prefix+'-tested-source.txt',prefix+'-reviewed-source.txt',prefix+'-bundle-verify.log','verification.jsonl','run.py','save-'+prefix+'-checkpoint.py',prefix+'-readers-diagnostic.test.tsx','vitest-'+prefix+'-reader.config.ts',prefix+'-reader-observation.json',prefix+'-reader-analysis.json','analyze-'+prefix+'-readers.py',prefix+'-fullcheck-audit.json',prefix+'-turbo-logs.tar.gz','controlled-command-availability-reader-observation.json','ranged-ai-analysis.json','finalize-'+prefix+'-report.py','audit-'+prefix+'-fullcheck.py','task15-'+prefix+'-next-notes.md',prefix+'-test-count.txt',prefix+'-checkpoint-summary.txt']
names += [prefix+'-contrast-diagnostic.mjs',prefix+'-contrast-observation.json',prefix+'-render-observation.json',prefix+'-plain-baseline.json',prefix+'-plain-observation.json',prefix+'-plain-analysis.json',prefix+'-plain-diagnostic.test.tsx','vitest-'+prefix+'-plain.config.ts','analyze-'+prefix+'-plain.py']
for n in [prefix+'-initial-fullcheck-audit.json',prefix+'-initial-turbo-logs.tar.gz',prefix+'-repair-notes.md']:
 if (w/n).exists():names.append(n)
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T201200':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'cc887a44c5f16c556062e8995bce4156c2e254b1','previousArchiveTree':'71a467bd294e874a22cf7bda2512ea49ce33aa9e','fullCheckReceipt':gate,'tests':{'vitest':expected,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/(prefix+'-checkpoint-summary.txt')).read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
