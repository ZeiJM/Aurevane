# Public Manual mechanics implementation notes

BASE62aaebb264bfec2e130868aad6a2fdd1f6b3427a → reviewed1ead4e9351b28bd57159eeb9acfe736a225566aa → final tested4b05948226468f4b53a97042e1d4e0b211ed219f. Seven initial source/test files plus one scoped CSS correction. Sixteen new root cases (8668→8684); ignored diagnostics do not increase root counts.

Actual coherent public catalogue route already exists. Additive bulletParts annotates authoritative strings; pure shape/whole-text guard falls back to original escaped text for missing/stale/unsupported metadata. Shared MechanicTextView and CompactEffectSummary preserve typed requirements/conditions/effect labels/magnitudes/durations/details/groups/limits/maintenance. Canonical target kind owns self omission, not native Move's displayed Empty Ground. No prose inference or gameplay math.

Fixture corrections: missing required Fire companion correctly rejected; add supported self-removal, not a rule change. Native Skill names derive ID, so escaping uses actual Basic-name input. Actual Frozen Ground report provides typed Fire/Ground references; no invented links from ordinary Fire prose. Valid initialRED201808 five missing markup/reference failures; Move self-recipient and coercible malformed timingRED202050785034; strict timing/canonical target fix16GREEN202106740835. Route test now asserts visible text plus real markup because spans split raw HTML; privacy/catalogue guards remain.

Focused391/44GREEN202207234834 and postrepair202826122263. Types202122638652/scopedlint202207231933 GREEN. Reviewed-source full202314170422 GREEN8684+7, complete build tail preserved. Source changed for I1, requiring fresh final root; not a missing-receipt replay.

Review0C1I1newM; I1 contrastRED202810589220; first candidate202819028546 remained below4.5:1; finalGREEN202826122264 minima4.7317orange/4.6595teal. Actual source PostCSS endpoint/overlay calculation, not mounted measurement. Samegold/orange labels/magnitudes/refs; duration/timingdarkteal; currentColor focus retained. M1 deferred, fourteen total. No rereview.

Actual builtin/proposed136Skills+5Basics full article plain JSON exact preproduct baselineSHA1bd2b9ef74551bc2e0b36322958180630454aeb056e9b5af1755f9f749b3203c. ActualManualArticle rich/plainSSR visibletext exact both fullcatalogues202937069049. All294 namedSkillreports/HTML/sixAIhashes/manifest unchanged. No fresh289gameplay matrix claimed.

NativelegacySkillbullets/statusdictionary/staticarticleprose remainplain. No concreteChroniclegap found; do not rebuild pinned chain. No hooks/effects/listeners/fetch/dependencies/privatefields/execution/art/control/schema/persistence changes. CSSexception limitedtoManualcontrast.

No publication/activation/hostedmigration/merge/deploy;deploymentlock retained. FullTask15/16/native/AT/geometry/editors/previews/currentOwneredits/fullcycles/naturalbalance/hostedSQLCAS/Atlas/human/releaseOPEN. Highsufficient.

