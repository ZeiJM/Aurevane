import datetime
from pathlib import Path
import json,re,subprocess,hashlib
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='public-manual-mechanics'
def git(*a): return subprocess.check_output(['git',*a],text=True).strip()
source=(w/(prefix+'-tested-source.txt')).read_text().strip()
reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip()
assert git('rev-parse','HEAD')==source=='4b05948226468f4b53a97042e1d4e0b211ed219f'
assert reviewed=='1ead4e9351b28bd57159eeb9acfe736a225566aa' and not git('status','--porcelain')
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
log=Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert datetime.datetime.fromisoformat(gate['started_utc']) >= datetime.datetime.fromisoformat(git('show','-s','--format=%cI',source))
expected=int((w/(prefix+'-test-count.txt')).read_text())
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected==8684,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log and '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
analysis=json.loads((w/(prefix+'-reader-analysis.json')).read_text())
plain=json.loads((w/(prefix+'-plain-analysis.json')).read_text())
rendered=json.loads((w/(prefix+'-render-observation.json')).read_text())
contrast=json.loads((w/(prefix+'-contrast-observation.json')).read_text())
assert analysis['source']==source and analysis['records']==294 and analysis['allReportsAndHtmlExactlyUnchanged'] and analysis['manifestAndSixAiSourceHashesUnchanged']
assert plain['source']==source and plain['allPlainArticleDataExactlyUnchanged'] and plain['rawSha256']==plain['baselineSha256']
assert len(rendered)==2 and all(row['visibleTextExactlyPreserved'] for row in rendered)
assert all(row['minContrast']>=4.5 for row in contrast['rows'])
rulings=(w/(prefix+'-review-rulings.md')).read_text().removeprefix('# Parent decisions\n\n').replace('## Every declined behavior', '### Every declined behavior')
assert rulings.count('Cost if wrong:')>=50
outcome=(w/(prefix+'-review-outcome.md')).read_text()
report=f'''# Public Manual mechanics — verified development checkpoint

Canonical Skill and Basic summaries in the public Manual now retain the shared typed mechanic presentation. Requirements, effect conditions and explicitly authored reference terms use the existing explanation controls. Effect names, values, durations and timing use the existing compact renderer. The exact original bullet remains authoritative: missing, stale or unsupported annotations fall back to that escaped text.

The route already reads one coherent current catalogue and applies the public projection. This checkpoint completes the presentation seam between its report generator and ManualArticle; it does not change publication or catalogue authority. Repeated action groups, conditions, recipients, limits, maintenance and native Basic traversal pricing keep their previous wording. Canonical targeting determines self omission; the displayed “Empty Ground” label does not infer a recipient.

Native legacy Skill bullets, the status dictionary table and static article prose remain plain. No arbitrary word linking is introduced. No concrete current-source Chronicle gap was found, so that existing pinned context was not rebuilt.

## Reviewed source and correction

BASE62aaebb264bfec2e130868aad6a2fdd1f6b3427a → reviewed {reviewed} → final tested {source}. Seven initial source/test files plus one Manual CSS correction; this report is a docs-only descendant.

The fresh combined review found no Critical issue, one Important issue and one new Minor. The Important issue was a real integration regression: shared pale gold and teal labels lost contrast on the Manual's parchment surface. ONE repair wave adds scoped dark orange and teal colors for these markers. Names and magnitudes retain the same color. Existing reference underlines and focus-visible currentColor outlines remain; shared dark readers are unchanged. The original no-CSS ruling has this bounded exception.

The source contrast calculation reproduced the defect in RED202810589220Z-e1fc1089. The first candidate202819028546Z-94e4326d remained below4.5:1 at the darkest overlay. Final GREEN202826122264Z-73f31ff6 calculates minimum contrast4.7317:1 for orange and4.6595:1 for teal across source gradient endpoints and overlay combinations. This is source-derived numerical evidence, not a mounted-browser measurement or native/AT/geometry acceptance.

M1 remains deferred: the unknown-reference fixture also has mismatching visible text, so it does not isolate matching-text rejection. Production validation correctly rejects unknown nodes. Thirteen inherited Minors plus this new coverage weakness remain deferred, fourteen total. No incidental Minor repair and no rereview.

## Verification

- Sixteen new native-definition → actual report builder → actual ManualArticle/shared SSR cases use no mocks. They cover typed requirements/conditions, actual proposed Frozen Ground references, separate Manual/Ongoing groups, compact values, all five Basics, traversal prices, input immutability, escaping and missing/stale/unsupported metadata.
- Initial valid RED201808960527Z-5588879b reproduced five missing reference/markup failures with ten guards already passing. Actual Move self-recipient rendering and coercible malformed timing produced two valid failures in RED202050785034Z-2ccc0da6; all sixteen passed202106740835Z-ec4f9806.
- Fixture corrections preserved native legality: Fire required its supported companion; actual Skill titles derive identity so escaping uses a real Basic name; typed Ground references come from the real proposed Frozen Ground report rather than inferred Fire prose. Route assertions now compare visible text where spans split raw HTML, while retaining actual shared markup and privacy/coherent-read guards.
- Focused **391 tests /44 files GREEN**, both initial202207234834Z-0511f4c4 and repaired202826122263Z-38a7503b. Initial web types202122638652Z-1be24831 and zero-warning scoped lint202207231933Z-a197755f GREEN; final root repeats these gates.
- Final exact-source root **{expected:,} Vitest plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN. Receipt {Path(gate['log']).stem}, {gate['started_utc']} → {gate['completed_utc']}. Package counts: {', '.join(a+' '+b for a,b in counts)}. Complete root build tail and package-log hash audit are preserved.
- Reviewed-source initial root202314170422Z-74743f23 also passed8684+7 with complete build tail. The first repaired-source attempt202842928832Z-d891069d was interrupted during lint and has no completed receipt; its partial log is retained. The fresh completed final receipt above is the claimed evidence.
- Full plain article data exactly match the preproduct baseline for both builtins and proposals: **136 regular Skills plus five Basics each**. SHA256 {plain['rawSha256']}.
- Actual complete rich-versus-plain ManualArticle SSR also retains exactly the same visible text for both catalogues, receipt202937069049Z-81382d86. Builtins keep their136 legacy Skill rows plain and render five compact Basics; proposals render249 compact effects and43 explicit reference controls. Rendering counts do not certify opening or operating a control.
- All **294 named Skill reports and HTML** remain exactly unchanged from the previous reader checkpoint (297 groups,604 effects). Observation SHA256 {analysis['rawSha256']}. The proposal manifest and six AI/native hashes are unchanged. No fresh289-case gameplay matrix is claimed.

## Evidence boundaries and launch work

This slice adds no hooks, effects, event listeners, service reads, dependencies, private authoring fields, execution math, schema, persistence, control binding or artwork changes. The only CSS change is the scoped readability correction. The existing parentless shared popover fallback is reused.

SSR and source calculations are not mounted interaction, physical keyboard/touch, screen-reader, focus, mobile geometry, zoom or browser performance acceptance. Existing browser limitations remain; no repeated installation or tunnel attempt was made.

The modular foundation is already live. Proposed rebalance and the original unfinished combat integration remain separate. Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance remain pre-release requirements. Full Task15/16, whole-action current-intent readiness, full equipped natural cycles, twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion and human/release acceptance remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is performed. Git auto-deployment lock remains in place. High remains sufficient for routine integration. The earlier16–30active-working-hour estimate remains provisional and is not a calendar promise.

## Parent review decisions

{rulings}
'''
for a,b in [('BASE62','BASE 62'),('and4.6595','and 4.6595'),(' /44',' / 44'),('groups,604','groups, 604'),('Task15/16','Task 15/16'),('below4.5','below 4.5'),('contrast4.','contrast 4.'),('proposals render249','proposals render 249'),('and43','and 43'),('their136','their 136'),('earlier16–30active-working-hour','earlier 16–30 active-working-hour'),('fresh289','fresh 289'),('passed8684','passed 8684')]:
 report=report.replace(a,b)
(root/'docs/verification/2026-10-16-public-manual-mechanics.md').write_text(report)
with (w/'progress.md').open('a') as f: f.write('\n## Public Manual mechanics final checkpoint\n'+report+'\n')
print('Guarded final Manual report and ledger written.')

