# Public Manual mechanics — fresh combined review

Reviewer /root/public_manual_mechanics_review; frozen BASE 62aaebb264bfec2e130868aad6a2fdd1f6b3427a → HEAD 1ead4e9351b28bd57159eeb9acfe736a225566aa. All seven source/test files and the actual route/guard chain reviewed. Working tree remained clean. No tests, services, browser, native tooling, network, mutations or subagents.

Strengths: actual coherent catalogue route reaches the new shared renderers; authoritative plain bullets and exact-text guards remain; conditions/recipients/groups/limits/maintenance/Basic traversal costs remain connected; no execution, dependency, private field or arbitrary prose-link change; fixture uses native parsing, generation and SSR without mocks.

Critical: none.

Important I1 — New mechanic colors are unreadable on the Manual ink surface. manual-mechanic-text.tsx:20–23 reuses compact shared pale #e4bd67 and #70d7ce; Manual final parchment composition is manual-article.module.css:351–357 with body overlay:166–167. Source-derived contrast approximately1.38–1.85:1. Existing light consumers darken shared markers. Apply a narrowly scoped ink treatment retaining focus indication and dark-reader behavior. This is source/cascade evidence, not a mounted measurement.

Minor M1 — Unknown-reference fixture does not isolate matching-text rejection (fixture:192–200). Unknown label Burn differs from authoritative Burn <literal> &, so mismatch alone rejects it. Production validation is correct. A future matching-text unknown-tag case with valid metadata alongside it should establish whole-bullet fallback.

Inherited13Minors carried, not regraded.

## Individually considered and declined

1. **Native legacy Skill linking:** Its unchanged plain path is deliberately outside this typed canonical catalogue cohort. Legacy Skill bullets remain plain.

2. **Status dictionary linking:** This table has no typed transport in the approved cohort. Dictionary rows retain plain rendering.

3. **Static article prose linking:** Typed provenance is absent; automatic word matching could invent a reference. Static prose remains plain.

4. **Replacing compact disclosures with full cards:** The approved catalogue retains compact summaries. Full parameter-card interactions remain separate.

5. **Chronicle changes:** No concrete current-source gap was found here. Historical reader acceptance remains separate.

6. **Reworking current catalogue publication:** The actual route already reads one coherent snapshot. Existing catalogue authority is reused.

7. **Fallback to builtins after catalogue failure:** Silently resurrecting stale content would violate catalogue authority. Catalogue errors keep their existing failure path.

8. **Disabled content resurrection:** Existing public filtering and route guards remain in place. No additional disabled-content behavior is certified.

9. **Additional private-data projection:** The recursive public projection precedes generation and metadata contains presentation fields. Future private fields still require projection review.

10. **Executable getters, proxies or prototypes:** This server-generated JSON presentation boundary adds no external runtime metadata ingestion. Arbitrary executable objects are not certified as inputs.

11. **Unknown nested reference nodes:** The guard checks supported nested identities; production behavior is correct. The matching-text regression weakness is deferred as M1.

12. **Stale nested label text:** The shared renderer retains its exact-label fallback. Stale annotations lose their link instead of rewriting words.

13. **Absent explanation strings:** The existing renderer returns a plain label rather than inventing dictionary content. Missing explanations are unavailable.

14. **Malformed timing coercion:** Strict string validation and the isolated matching-text fixture reject it. Unsupported timing metadata falls back to plain text.

15. **Recipient inference from Empty Ground text:** Canonical targeting kind owns self omission. Display wording does not determine recipients.

16. **Conditional Fire and Ground claims:** Only actual typed report references are transported. Ordinary prose is not automatically linked.

17. **Repeated group merging:** Groups retain their numbering, boundaries and own values. No collapsed or combined execution is introduced.

18. **Cost and attached-Move changes:** This presentation change leaves native costs and wording intact. Existing included-cost and native walking rules retain authority.

19. **Parentless nested popovers:** The existing shared fallback supports a root reader without a parent. Mounted ownership acceptance remains open.

20. **Outside-click consumption:** The shared dismissal behavior is intentionally reused. This cohort does not certify new dismissal semantics.

21. **Opened explanation escaping evidence:** Closed SSR does not include the explanation; JSX already renders it as text. The new SSR test is not proof of an opened explanation.

22. **Mounted keyboard, touch and focus:** Source and SSR cannot establish physical interaction. Mounted/native interaction acceptance remains open.

23. **Screen-reader acceptance:** SSR attributes do not establish assistive-technology behavior. AT acceptance remains open.

24. **Long names, mobile geometry and 200% zoom:** The existing layout is retained without mounted measurement. Actual layout acceptance remains open.

25. **Catalogue-scale browser performance:** Generation remains linear and adds no per-reference network calls. Hydration and browser performance remain unmeasured.

26. **Expiry, revocation, alternate character and RPC authority:** The underlying authority paths are unchanged. Dedicated final authority acceptance remains required.

27. **Captured, pending and summon execution:** Engine and persistence paths are unchanged. No new execution certification is claimed.

28. **No-input, priming, repeated events and interrupted Move:** The cohort changes presentation only. Broader native execution acceptance remains required.

29. **Concurrent publication, claim, recovery and settlement:** Transaction paths are unchanged. Concurrency acceptance remains open.

30. **AI, manifest, full equipped cycles and balance:** Hash-preserving presentation checks are narrower than gameplay acceptance. Natural cycles and balance remain open.

31. **Hosted, Atlas, human and release acceptance:** These were neither performed nor implied. Launch readiness remains open.

Verdict with fixes:0Critical,1Important,1newMinor. Typed transport/exact fallback sound for bounded scope; I1 required. FullTask15/16/native/AT/geometry/release remain open. Reported executor test counts were not independently certified; full gate was running during review.

