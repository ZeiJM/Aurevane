# Parent decisions

I1 accepted Important: actual public learning text loses contrast on parchment. ONE repair wave applies Manual-scoped marker colors as a bounded exception to the no-CSS ruling. Dark-reader styles, label/value equality and currentColor focus outline remain. Cost if wrong: numerical source evidence does not replace native/AT/geometry acceptance.

M1 deferred Minor: production rejects unknown tags correctly; the matching-text fixture is weaker than intended. Reason: a coverage weakness without observed reader failure. Cost if wrong: isolated matching-text unknown-tag rejection lacks a direct regression witness. Thirteen inherited plus one new Minor = fourteen deferred. No incidental Minor repair; no rereview.

## Every declined behavior

1. **Native legacy Skill linking** — Ruling/reason: Its unchanged plain path is deliberately outside this typed canonical catalogue cohort. Cost if wrong: Legacy Skill bullets remain plain.

2. **Status dictionary linking** — Ruling/reason: This table has no typed transport in the approved cohort. Cost if wrong: Dictionary rows retain plain rendering.

3. **Static article prose linking** — Ruling/reason: Typed provenance is absent; automatic word matching could invent a reference. Cost if wrong: Static prose remains plain.

4. **Replacing compact disclosures with full cards** — Ruling/reason: The approved catalogue retains compact summaries. Cost if wrong: Full parameter-card interactions remain separate.

5. **Chronicle changes** — Ruling/reason: No concrete current-source gap was found here. Cost if wrong: Historical reader acceptance remains separate.

6. **Reworking current catalogue publication** — Ruling/reason: The actual route already reads one coherent snapshot. Cost if wrong: Existing catalogue authority is reused.

7. **Fallback to builtins after catalogue failure** — Ruling/reason: Silently resurrecting stale content would violate catalogue authority. Cost if wrong: Catalogue errors keep their existing failure path.

8. **Disabled content resurrection** — Ruling/reason: Existing public filtering and route guards remain in place. Cost if wrong: No additional disabled-content behavior is certified.

9. **Additional private-data projection** — Ruling/reason: The recursive public projection precedes generation and metadata contains presentation fields. Cost if wrong: Future private fields still require projection review.

10. **Executable getters, proxies or prototypes** — Ruling/reason: This server-generated JSON presentation boundary adds no external runtime metadata ingestion. Cost if wrong: Arbitrary executable objects are not certified as inputs.

11. **Unknown nested reference nodes** — Ruling/reason: The guard checks supported nested identities; production behavior is correct. Cost if wrong: The matching-text regression weakness is deferred as M1.

12. **Stale nested label text** — Ruling/reason: The shared renderer retains its exact-label fallback. Cost if wrong: Stale annotations lose their link instead of rewriting words.

13. **Absent explanation strings** — Ruling/reason: The existing renderer returns a plain label rather than inventing dictionary content. Cost if wrong: Missing explanations are unavailable.

14. **Malformed timing coercion** — Ruling/reason: Strict string validation and the isolated matching-text fixture reject it. Cost if wrong: Unsupported timing metadata falls back to plain text.

15. **Recipient inference from Empty Ground text** — Ruling/reason: Canonical targeting kind owns self omission. Cost if wrong: Display wording does not determine recipients.

16. **Conditional Fire claims** — Ruling/reason: Only actual typed report references are transported. Cost if wrong: Ordinary prose is not automatically linked.

17. **Ground condition claims** — Ruling/reason: Only actual typed report references are transported. Cost if wrong: Ordinary prose is not automatically linked.

18. **Repeated group merging** — Ruling/reason: Groups retain their numbering, boundaries and own values. Cost if wrong: No collapsed or combined execution is introduced.

19. **Overall Skill cost** — Ruling/reason: This presentation change leaves native costs and wording intact. Cost if wrong: Existing included-cost and native walking rules retain authority.

20. **Attached Move included cost** — Ruling/reason: This presentation change leaves native costs and wording intact. Cost if wrong: Existing included-cost and native walking rules retain authority.

21. **Native Basic walking cost** — Ruling/reason: This presentation change leaves native costs and wording intact. Cost if wrong: Existing included-cost and native walking rules retain authority.

22. **Parentless nested popovers** — Ruling/reason: The existing shared fallback supports a root reader without a parent. Cost if wrong: Mounted ownership acceptance remains open.

23. **Outside-click consumption** — Ruling/reason: The shared dismissal behavior is intentionally reused. Cost if wrong: This cohort does not certify new dismissal semantics.

24. **Opened explanation escaping evidence** — Ruling/reason: Closed SSR does not include the explanation; JSX already renders it as text. Cost if wrong: The new SSR test is not proof of an opened explanation.

25. **Mounted keyboard** — Ruling/reason: Source and SSR cannot establish physical interaction. Cost if wrong: Mounted/native interaction acceptance remains open.

26. **Mounted touch** — Ruling/reason: Source and SSR cannot establish physical interaction. Cost if wrong: Mounted/native interaction acceptance remains open.

27. **Mounted focus** — Ruling/reason: Source and SSR cannot establish physical interaction. Cost if wrong: Mounted/native interaction acceptance remains open.

28. **Screen-reader acceptance** — Ruling/reason: SSR attributes do not establish assistive-technology behavior. Cost if wrong: AT acceptance remains open.

29. **Long-name wrapping** — Ruling/reason: The existing layout is retained without mounted measurement. Cost if wrong: Actual layout acceptance remains open.

30. **Mobile geometry** — Ruling/reason: The existing layout is retained without mounted measurement. Cost if wrong: Actual layout acceptance remains open.

31. **200% zoom** — Ruling/reason: The existing layout is retained without mounted measurement. Cost if wrong: Actual layout acceptance remains open.

32. **Catalogue-scale browser performance** — Ruling/reason: Generation remains linear and adds no per-reference network calls. Cost if wrong: Hydration and browser performance remain unmeasured.

33. **Live expiry** — Ruling/reason: The underlying authority paths are unchanged. Cost if wrong: Dedicated final authority acceptance remains required.

34. **Live revocation** — Ruling/reason: The underlying authority paths are unchanged. Cost if wrong: Dedicated final authority acceptance remains required.

35. **Alternate selected character** — Ruling/reason: The underlying authority paths are unchanged. Cost if wrong: Dedicated final authority acceptance remains required.

36. **Direct RPC authority** — Ruling/reason: The underlying authority paths are unchanged. Cost if wrong: Dedicated final authority acceptance remains required.

37. **Captured execution** — Ruling/reason: Engine and persistence paths are unchanged. Cost if wrong: No new execution certification is claimed.

38. **Pending execution** — Ruling/reason: Engine and persistence paths are unchanged. Cost if wrong: No new execution certification is claimed.

39. **Summon execution** — Ruling/reason: Engine and persistence paths are unchanged. Cost if wrong: No new execution certification is claimed.

40. **No-input execution** — Ruling/reason: The cohort changes presentation only. Cost if wrong: Broader native execution acceptance remains required.

41. **Free priming** — Ruling/reason: The cohort changes presentation only. Cost if wrong: Broader native execution acceptance remains required.

42. **Repeated execution events** — Ruling/reason: The cohort changes presentation only. Cost if wrong: Broader native execution acceptance remains required.

43. **Interrupted Move** — Ruling/reason: The cohort changes presentation only. Cost if wrong: Broader native execution acceptance remains required.

44. **Concurrent publication** — Ruling/reason: Transaction paths are unchanged. Cost if wrong: Concurrency acceptance remains open.

45. **Concurrent claim** — Ruling/reason: Transaction paths are unchanged. Cost if wrong: Concurrency acceptance remains open.

46. **Concurrent recovery** — Ruling/reason: Transaction paths are unchanged. Cost if wrong: Concurrency acceptance remains open.

47. **Concurrent settlement** — Ruling/reason: Transaction paths are unchanged. Cost if wrong: Concurrency acceptance remains open.

48. **AI behavior** — Ruling/reason: Hash-preserving presentation checks are narrower than gameplay acceptance. Cost if wrong: Natural cycles and balance remain open.

49. **Rebalance manifest** — Ruling/reason: Hash-preserving presentation checks are narrower than gameplay acceptance. Cost if wrong: Natural cycles and balance remain open.

50. **Full equipped cycles** — Ruling/reason: Hash-preserving presentation checks are narrower than gameplay acceptance. Cost if wrong: Natural cycles and balance remain open.

51. **Natural twelve-round balance** — Ruling/reason: Hash-preserving presentation checks are narrower than gameplay acceptance. Cost if wrong: Natural cycles and balance remain open.

52. **Hosted acceptance** — Ruling/reason: These were neither performed nor implied. Cost if wrong: Launch readiness remains open.

53. **Atlas motion** — Ruling/reason: These were neither performed nor implied. Cost if wrong: Launch readiness remains open.

54. **Human acceptance** — Ruling/reason: These were neither performed nor implied. Cost if wrong: Launch readiness remains open.

55. **Release readiness** — Ruling/reason: These were neither performed nor implied. Cost if wrong: Launch readiness remains open.

