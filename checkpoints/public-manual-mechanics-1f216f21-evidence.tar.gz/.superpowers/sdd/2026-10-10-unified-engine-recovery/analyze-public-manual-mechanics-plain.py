from pathlib import Path
import json,hashlib
w=Path(__file__).resolve().parent
baseline=json.loads((w/'public-manual-mechanics-plain-baseline.json').read_text());observed=json.loads((w/'public-manual-mechanics-plain-observation.json').read_text())
assert baseline==observed and len(observed)==2
assert all(row['skills']==136 and row['basics']==5 for row in observed)
d={'source':(w/'public-manual-mechanics-tested-source.txt').read_text().strip(),'catalogues':[{k:row[k] for k in ['id','skills','basics']} for row in observed],'allPlainArticleDataExactlyUnchanged':True,'rawSha256':hashlib.sha256((w/'public-manual-mechanics-plain-observation.json').read_bytes()).hexdigest(),'baselineSha256':hashlib.sha256((w/'public-manual-mechanics-plain-baseline.json').read_bytes()).hexdigest()}
(w/'public-manual-mechanics-plain-analysis.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
