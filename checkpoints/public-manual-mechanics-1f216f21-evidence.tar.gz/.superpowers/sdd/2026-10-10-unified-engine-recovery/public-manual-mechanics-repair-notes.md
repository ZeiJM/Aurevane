# Parent review outcome

Accepted I1 as Important: real public learning text loses contrast on its actual parchment surface. ONE bounded repair wave adds only Manual-scoped marker colors; global shared dark-reader colors and focus-visible outline remain unchanged. The initial no-CSS ruling receives this necessary local exception. No rereview.

M1 remains Minor and deferred: production guards correctly reject unknown nodes, and a stronger matching-text regression is a test coverage improvement. No observed player-facing behavior failure. Thirteen inherited Minors plus M1 = fourteen deferred Minors.

Source contrast diagnostic RED202810589220Z-e1fc1089 reproduced all six low-contrast marker cases. First candidate202819028546Z-94e4326d was still below4.5:1 at the darkest overlay; darker orange #3b2100 and teal #042e27 GREEN202826122264Z-73f31ff6 at minimum4.7317 and4.6595. This is numerical source-derived endpoint/overlay contrast, not mounted-browser/AT/geometry acceptance. Effect label and magnitude remain the same orange; reference underline and inherited currentColor focus outline remain.

Repaired focused391tests/44files GREEN202826122263Z-38a7503b. Reviewed1ead4e9351b28bd57159eeb9acfe736a225566aa → repaired/final-tested4b05948226468f4b53a97042e1d4e0b211ed219f. Eight total source/test files (seven initial plus one scoped CSS correction). Sixteen new root-suite cases remain; ignored diagnostics do not increase the root count.

