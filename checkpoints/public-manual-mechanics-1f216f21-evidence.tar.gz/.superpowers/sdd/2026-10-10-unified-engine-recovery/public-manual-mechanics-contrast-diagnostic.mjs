// Source cascade/contrast diagnostic; not a mounted browser or AT acceptance test.
import fs from 'node:fs'
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
const require = createRequire(process.cwd() + '/node_modules/.pnpm/node_modules/')
const postcss = require('postcss')
const w = new URL('.', import.meta.url)
const article = postcss.parse(fs.readFileSync('apps/web/src/components/public-information/manual-article.module.css', 'utf8'))
const shared = postcss.parse(fs.readFileSync('apps/web/src/components/character/compact-skill-effect-summary.module.css', 'utf8'))
function declaration(root, selector, property) {
 let result
 root.walkRules(rule => {
  if (rule.parent.type !== 'root' || !rule.selectors.includes(selector)) return
  rule.walkDecls(property, decl => { result = decl.value })
 })
 assert(result, selector + ' ' + property)
 return result
}
const rgb = hex => hex.match(/[a-f\d]{2}/gi).map(n => parseInt(n,16))
const endpoints = declaration(article,'.article','background').match(/#[a-f\d]{6}/gi).map(rgb)
const overlays = [...declaration(article,'.body','background').matchAll(/rgba\(([\d.,\s]+)\)/g)].map(m=>m[1].split(',').map(Number))
const blend = (bg,fg) => bg.map((n,i) => n*(1-fg[3])+fg[i]*fg[3])
const backgrounds = endpoints.flatMap(bg => {
 const shaded = blend(bg, overlays.at(-1))
 return [bg, shaded, blend(shaded, overlays[0])]
})
const lum = c => c.map(n=>n/255).map(n=>n<=.04045?n/12.92:((n+.055)/1.055)**2.4).reduce((s,n,i)=>s+n*[.2126,.7152,.0722][i],0)
const contrast = (a,b) => (Math.max(lum(a),lum(b))+.05)/(Math.min(lum(a),lum(b))+.05)
const cases = [
 ['label','data-compact-effect-label'], ['magnitude','data-compact-effect-magnitude'],
 ['timing','data-compact-effect-duration'], ['timing','data-compact-effect-timing'],
 ['magnitude','data-compact-effect-detail'], ['reference','data-combat-tag-reference-trigger'],
]
const rows = cases.map(([className, marker]) => {
 const fallback = declaration(shared,'.'+className,'color')
 let color = fallback
 let best = 0
 article.walkRules(rule => {
  if(rule.parent.type!=='root') return
  for(const selector of rule.selectors) {
   // This diagnostic intentionally evaluates only the introduced .article marker selectors.
   if(selector !== '.article ['+marker+']') continue
   rule.walkDecls('color', d=>{if(best<=2){color=d.value;best=2}})
  }
 })
 return { marker, color, darkReaderColor:fallback, contrast:backgrounds.map(bg=>contrast(rgb(color), bg)), minContrast:Math.min(...backgrounds.map(bg=>contrast(rgb(color),bg))) }
})
const result = {scope:'Source CSS cascade and numerical endpoint/overlay contrast only; not mounted, geometry, native input or AT acceptance.', rows}
fs.writeFileSync(new URL('public-manual-mechanics-contrast-observation.json',w), JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify(result))
assert(rows.every(row=>row.minContrast>=4.5),'Mechanic labels, values and reference triggers need at least 4.5:1 across parchment endpoint and overlay combinations')
assert.equal(rows[0].color, rows[1].color, 'Effect names and magnitudes retain the same color')
assert.equal(declaration(shared,'.reference:focus-visible','outline'),'2px solid currentColor')

