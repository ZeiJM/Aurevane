import { readFileSync, writeFileSync } from 'node:fs'
import { expect, it } from 'vitest'
import { renderToStaticMarkup } from 'react-dom/server'
import { ManualArticle } from '@/components/public-information/manual-article'
import { createTechniquesManualArticle } from '@/content/techniques-manual'
import { latestEnabledMatureSkills, type MatureSkillDefinition } from '@aurevane/game-core/combat/mature-skills'
import { defaultBasicSkills, type BasicSkillDefinition } from '@aurevane/game-core/combat/combat-basic-actions'
import { defaultCombatEffectTimingPolicy } from '@aurevane/game-core/combat/combat-effect-timing'
import { projectPublicCombat } from '@aurevane/game-core/combat/public-combat-presentation'
const w = '/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery'
it('records exact plain Manual articles for builtin and proposed regular/Basic definitions', () => {
 const manifest = JSON.parse(readFileSync('/workspace/scratch/680b26e4eb86/aurevane/docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json', 'utf8')).records
 const catalogues = [
 { id: 'builtin', skills: latestEnabledMatureSkills(), basics: defaultBasicSkills() },
 { id: 'proposed', skills: manifest.filter((r: {kind: string}) => r.kind === 'skill').map((r: {after: MatureSkillDefinition}) => projectPublicCombat(r.after)),
 basics: manifest.filter((r: {kind: string}) => r.kind === 'basic').map((r: {after: BasicSkillDefinition}) => projectPublicCombat(r.after)) },
 ]
 const rendered = []
 const articles = catalogues.map(catalogue => {
 expect(catalogue.skills).toHaveLength(136); expect(catalogue.basics).toHaveLength(5)
 const before = JSON.stringify(catalogue)
 const article = createTechniquesManualArticle({...catalogue, timingPolicy: defaultCombatEffectTimingPolicy()})
 expect(JSON.stringify(catalogue)).toBe(before)
 const plain = JSON.parse(JSON.stringify(article), (key, value) => key === 'bulletParts' ? undefined : value)
 const baseline = JSON.parse(readFileSync(w + '/public-manual-mechanics-plain-baseline.json', 'utf8')).find((row: {id:string}) => row.id === catalogue.id).article
 const richHtml = renderToStaticMarkup(<ManualArticle {...article} />)
 const plainHtml = renderToStaticMarkup(<ManualArticle {...baseline} />)
 expect(richHtml.replace(/<[^>]*>/g, '')).toBe(plainHtml.replace(/<[^>]*>/g, ''))
 rendered.push({id: catalogue.id, visibleTextExactlyPreserved: true, references: (richHtml.match(/data-combat-tag-reference=/g) ?? []).length, compactEffects: (richHtml.match(/data-compact-skill-effect=/g) ?? []).length, richHtmlBytes: Buffer.byteLength(richHtml), plainHtmlBytes: Buffer.byteLength(plainHtml)})
 return { id: catalogue.id, skills: catalogue.skills.length, basics: catalogue.basics.length, article: plain }
 })
 writeFileSync(w + '/public-manual-mechanics-render-observation.json', JSON.stringify(rendered, null, 2) + '\n')
 writeFileSync(w + '/public-manual-mechanics-plain-observation.json', JSON.stringify(articles, null, 2) + '\n')
})

