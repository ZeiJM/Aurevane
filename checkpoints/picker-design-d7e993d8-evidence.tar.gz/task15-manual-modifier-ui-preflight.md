# Manual modifier UI continuation preflight

This is source mapping, not implemented or approved new UX. Core Controlled bundle prerequisite is under fresh independent review. Preserve the frozen source and final fullcheck evidence before further edits.

## Existing binding and target paths

BattleIntent.action already carries exact Manual refs. New prime schema accepts them; core pins normalized source/ability/version/behavior against immutable encounter captures, release matches set. Owner Manual action DTO Controlled availability returns pinned refs only for a nonempty primed bundle. Historical absence means empty. Never silently inject a changed set.

UI picker must bind deliberate selection to owner/battle/version/root/group and clear cancellation/root/group/version/turn loss/terminal state. Keep deliberate unavailable same-context selections visible/rejected rather than filtering them out. All selected target/movement/range previews and commit must carry identical refs; pending quotes/range keys must invalidate immediately on changes. Server stays legality/payment authority.

BattlePreviewSkill currently lacks manualModifiers. movedBattleSkillIntent wraps all ordinary/directional/initial paths and is a useful shared attachment boundary. battleRangePreviewIntents line/circle branches and experience next/previous direction candidates bypass that wrapper and need identical metadata. useBattleRangePreviews destructures descriptor fields and memoizes request keys; include refs/deps there. requestBattlePreview and isCurrentBattlePreview already use whole intent JSON. clearPlanning clears quotes/path/pending targets but does not own modifier draft yet. Action descriptor must prefer exact persisted Controlled bundle on primed release, and disable changing that set.

## Availability / reader / costs

Safe owner manualModifierAvailability currently has source/behavior name (raw behaviorID), cost/clock/blocked status and requiresAction. Add safe abilityId/contentVersion/report at the server projection if needed to map actual equipped public names and explain effects/requirements; never parse opaque source ID or expose private captures. It is owner-only across controlled units; filter exact actor in UI. Root compatibility is Attack, unit target, no persistent Ground; shared new core helper owns supported payload/primary-recipient restrictions. Authoritative aggregate preview/commit still determines target-specific Requirements, budgets and final payment. Show combined AP/MP/HP and participating clocks in appropriate ordinary command information, preserving the Owner's removal of inline cost/Range forecast chips.

## Actual keyboard / prime integration seam

Existing battle policy prevents all plain Tab cycling, even within readers. New checkboxes need a real arrow/Space interaction and initial focus, not just a focusable locator. Existing Skill1-4/Essence hotkeys open noncast information. BattleInfoPopover focuses its dialog on open and lacks a child initial-focus contract. Cast Skill hotkeys currently arm/execute, so a mixed action+modifier needs a usable keyboard picker path too. A new default chord must preserve all custom controls and migration contracts; do not silently take an existing custom chord.

armAction immediately primes an unprimed single Controlled group when its artwork/hotkey is activated. Choosing attachments after that would violate immutable bundle capture. A complete UX must permit choosing the set before the free prime while preserving once-per-battle prime, artwork dimensions, no extra Release button and ready-only glow. Decide/review this flow together with keyboard access rather than bolt a picker after priming. The approved spec states the requirement but does not prescribe this UI transition. This is the next architecture/interaction design seam, not permission to implement an independent persistent modifier queue.

## Available browser harness and limits

Existing scripts/battle-canonical-targeting-browser-regression.mjs mounts production BattleExperience with real canonical kernel behind local fixture responses; entry is e2e/fixtures/battle-ally-inspection-harness.jsx. It covers PvE/PvP desktop/mobile and 200percent targeting scenarios, plus Move/Controlled modes. It does not prove hosted/account/Master publication. Playwright API is installed but expected Chromium /root/.cache/ms-playwright/chromium-1234/chrome-linux64/chrome is missing; no executable found in ordinary /opt,/usr or cache paths. Do not claim an actual browser run until a valid executable/supported browser route is available. Authenticated suites also require local Supabase credentials. Existing inherited Atlas browser failure remains unresolved and release-blocking.


## Next Extra High pass and pause boundary

Before implementing the picker, settle one coherent interaction contract covering: choosing a root/group and explicit modifiers before a single-group Controlled action auto-primes; keyboard entry/arrow/Space behavior under the existing no-Tab policy, including mixed action+modifier sources; retaining all custom chord meanings if a new command binding is selected; draft clearing versus visible same-command blocked selections; and consuming the authoritative primed set after the prime's new battle version clears local drafts. No extra Release button, artwork/slot expansion or persistent modifier queue. A chosen empty prime must remain empty rather than falling back to a later local draft.

Also decide the safe combined resource/cooldown reader contract. Current public action forecast exposes AP and MP but no complete AP/MP/HP costs array. Existing canonical prepare owns aggregate costs, including optional Automatic contributions; do not label a client sum as authoritative or expose private participants/captures/accuracy. All target/range/movement constructors and their memo keys must consume identical exact refs. Existing handoff says actual source/owner/version authority is already available, so avoid another execution path.

The approved spec fixes semantics but does not resolve these interacting UI transitions; the next step is an interaction/architecture design pass. Root will finish verification, commit and exact remote recovery backup of the current bounded prerequisite, then genuinely pause and ask Owner to switch from High to Extra High under the persistent effort agreement. Do not begin the design/implementation before explicit switch confirmation. Routine High implementation resumes after the design checkpoint and a real return-to-High pause as agreed. All Task15/16/combat-first and broader Master/world scope remains active.
