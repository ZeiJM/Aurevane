### Task 15: Apply all accepted new roster versions and required real extensions

**Files:** Actual roster/version pipeline/resolver/seed-publication preparation, any reviewed bounded kernel/schema/editor/reader/AI extension, full roster tests and before/after manifest.

**Interfaces:** Consume exact accepted14 manifest. Produce complete new immutable roster definitions and reviewed publication/backfill procedure preserving current Owner edits/history/relationship selections/earned facts. Implement all selected new mechanics before their definitions may publish.

- [ ] RED each selected new mechanic's finite/counterplay/capture/history/no-input cases, whole actual roster parser/handler coverage and stable source/eligibility/version comparisons. Add a registry-driven completeness check that fails for any implemented gameplay tag lacking a playable roster case, and authoritative outcome tests for the documented tag cases; mere presence in JSON or a description is insufficient. Retain individual representative PvE/PvP and real AI cases for each distinct cycle.
- [ ] Implement exact14 definitions and complete any extension through parser→handler→capture→editor→public reader→AI. Append versions; never mutate old snapshots or restore obsolete hidden formulas/retired statuses. Recalculate actual budgets and interaction cases rather than assuming labels prove uniqueness/balance.
- [ ] Run covering complete roster and new-extension tests, actual editor/service/AI/serialization/browser cases and affected checks. Expected: all records supported and each promised mechanic executable/legible; no unsupported placeholder or infinite/free dominance case.
- [ ] Commit complete applied manifest/evidence, independent gate and durable checkpoint. Carry all exact changed records and test instructions to16/release.

