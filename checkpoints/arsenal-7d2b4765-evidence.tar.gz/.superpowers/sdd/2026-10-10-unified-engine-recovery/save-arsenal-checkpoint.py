import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'arsenal-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'arsenal-tested-source.txt').read_text().strip();base='8229c4a94780da096559802a71c4d1ee283ac315'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert set(paths)=={'apps/web/src/components/character/character-arsenal-shell.tsx','apps/web/src/components/character/arsenal-canonical-essence-preview.test.tsx','docs/verification/2026-10-16-arsenal-essence-reader.md'},paths
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()];gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8272
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'editorial-readers-analysis.json').read_text());assert observed['records']==294 and observed['counts']['effects']==604 and observed['rawSha256']==sha(w/'editorial-readers-observation.json')
bundle=w/('arsenal-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'arsenal-bundle-verify.log').write_text(v.stdout)
evidence=w/('arsenal-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','task15-roster-consumer-next-brief.md','task15-arsenal-essence-review.md','arsenal-tested-source.txt','arsenal-bundle-verify.log','verification.jsonl','run.py','save-arsenal-checkpoint.py','task15-roster-consumer-next-brief.md','task15-editorial-audit-inventory.json','editorial-readers-diagnostic.test.tsx','vitest-editorial.config.ts','editorial-readers-observation.json','editorial-readers-analysis.json','editorial-effect-fallback-examples.json','editorial-payload-display-audit.json']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T140900':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'prerequisite':base,'previousArchiveCommit':'cb6da1ab71309b8a79c125d09a21fa3f236f5039','previousArchiveTree':'6d1002c9aff011bb468f1ae8afecb66f1874e459','fullCheckReceipt':gate,'tests':{'vitest':8272,'node':7},'bundle':info(bundle),'evidence':info(evidence),'acceptance':'Actual Arsenal canonical Essence reader corrected via existing exact-version adapter. All17 current and public plus pinned history18tests;0C0I1newMinor,total8deferred. Frozen8272Vitest+7Node fullcheck. Manifest/AI/executor/pricing/defaultfixture unchanged; no duplicate289. Original combat integration/readers/prose/native and full balance/Owner/hosted/Atlas/human/release OPEN. No publication/activation/migration/merge/deploy.'}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
