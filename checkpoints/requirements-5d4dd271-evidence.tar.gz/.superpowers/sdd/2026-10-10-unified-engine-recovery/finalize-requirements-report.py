from pathlib import Path
import json,re,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8438
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
source=(w/'requirements-tested-source.txt').read_text().strip();reviewed=(w/'requirements-reviewed-source.txt').read_text().strip();observed=json.loads((w/'requirements-reader-analysis.json').read_text());assert observed['source']==source
assert set(subprocess.check_output(['git','diff','--name-only',reviewed,source],text=True).splitlines())=={'apps/web/src/components/character/mechanic-tag-explanation.ts','apps/web/src/components/character/linked-requirement-references.test.tsx'}
rulings=(w/'requirements-review-rulings.md').read_text().split('\n\n',2)[2]
report=f'''# Typed prerequisite and condition references — verified development checkpoint

This bounded Task15 change links 82 actual status-presence references: 57 global prerequisites and 25 individual effect conditions, across 69 proposed records and 17 status IDs. References come directly from typed requirement nodes. Subjects, presence/absence, nested all/any grouping, resource thresholds, event/action/prime predicates and individual effect binding retain their exact existing text. Unknown status IDs and raw ability IDs stay plain; action tags are not inferred as status references.

Optional public `requirementParts` and `conditionParts` contain only strings or tag/label/explanation nodes. Shared characteristic rows, AbilityParameters, full-definition and manual modifier readers consume them. Native Basic cockpit composition preserves selected-group filtering, multiple-group prefixes and mixed old/new captured reports. Native Move Requirements remain N/A. Authored effect-description overrides do not remove independent prerequisite/condition links. Stale reference metadata falls back to the exact escaped captured string. A shared web status-name guard also prevents an unknown `constructor` identity from becoming JavaScript function text; other core callers are outside this fix.

Generic help reuses canonical/native descriptions and captured elemental options, without manufacturing an active application's potency, stacks or lifetime. Containing-Skill elemental damage does not add an overlap condition to generic help. Burn, Poison and Bleed presence does not identify a fixed or percentage application; the help therefore explains their role and leaves exact application facts to inspection. Current Initiative and Storm consumption rules remain available. For legacy Drenched and Conductive, the public context cannot distinguish oldest fixed-bonus history from later per-application history: generic help describes the common Storm and removal/consumption rules without promising either a percentage or a stacking model.

The existing shared one-primary/one-leaf popover and keyboard navigation are reused. Custom bindings, disabled battle Tab/ShiftTab, picker controls and artwork geometry are unchanged. No additional popup system, runtime, schema, manifest, AI or fixture change is included. Desktop/mobile PvE, PvP and spectators share the same presentation authorities. Static rendering and controlled callback tests are narrower than native interaction and physical layout acceptance; those remain open.

## Verification

- Initial TDD `170606595884`: 22 valid missing-feature failures and two existing guards passed. The first implementation exposed a wrong expected Drenched phrase and the pre-existing prototype-name fallback; both are recorded without claiming that failed run passed.
- Native cockpit consumer was removed before its own boundary test: three valid failures `170730760985`, then shared consumer integration passed. Focused checks reached 378 tests in 43 files; web typecheck passed `170846035237`. Earlier type failures were test-only optional indexing and an invalid target fixture, corrected before freezing.
- Initial reviewed source `{reviewed}` passed the full root gate `170921209851`: 8,436 Vitest plus seven Node checks, all types/lint/format and both builds, complete output. Its all294 observation and hashed package logs are preserved separately.
- One fresh combined review inspected all nine changed files and actual consumers: reviewer found 0 Critical, 0 Important and 0 new actionable Minor. Parent promoted the oldest-legacy-Storm ambiguity to Important by its possible effect on the reader, rather than requiring a demonstrated proposed-record capture. ONE fix wave: two valid failures `171332600788` → 380 focused tests in 43 files GREEN `171350452955`. Only the resolver and its regression file differ from reviewed source. No rereview.
- Final tested source `{source}` passes **8,438 Vitest plus seven Node checks**, all eight workspace typechecks, lint, formatting and both builds. Complete direct root receipt `{Path(gate['log']).stem}`: {gate['started_utc']} → {gate['completed_utc']}. No root stdout truncation or cached root replay.
- Final diagnostic observes all 294 records, 297 groups and 604 effects. Every prior structured field, plain description and static visible reader string is unchanged. All 82 added references exactly match typed inventory record/group/scope/effect/status; 69 records have added markup and the other 225 are byte-identical. Raw observation SHA256 `{observed['rawSha256']}`. This is default-context static reader evidence, not a browser or full editorial acceptance claim.
- Accepted roster manifest and six AI/native fixture source hashes are unchanged. No new 289-case matrix is claimed for this presentation-only change; prior complete matrix evidence remains a separate reference.

## Remaining release gates

The live modular foundation, proposed Skill rebalance and original unfinished combat integration remain distinct. Targeting/Move/five editable Basics/Controlled integration, complete controls/editors/readers/previews and native acceptance still precede combat release. Full distinct roster cycles, natural pacing and twelve-round balance, Owner current edits, hosted SQL/CAS, Atlas motion, human acceptance and release gates remain open. Broader unrelated Master/Staff/Players/Events/Music/world work follows combat. Nothing in this checkpoint publishes, activates, applies migrations, merges or deploys. High remains sufficient for routine integration.

Rich Public Manual references, other generated/noncanonical prose, primary tag-label help and complete live-instance stacks/magnitude/duration/readiness remain unfinished. Native browser remains unavailable; no repeated browser install or tunnel was attempted. Next read-only inventory identifies 42 generated cross-status effect packets (25 displacement, three sensory, 14 status), across 42 records; its 62 semantic tag candidates are not a promise of exact textual occurrence count. No implementation of that next cohort is included.

## Deferred minors

All eleven inherited Minors remain deferred: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI route/target discovery; admission double-prefix provenance; ranged negative preparation direct-commit witness; independent HP reconciliation in defense-positive events; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick boundary wording; Master inline reference-button minimum height/font sizing. No incidental Minor fix is included.

## Rulings I made

Additional implementation rulings:

- Only actual supported status-presence identities link; unknown IDs and raw prime/action words remain plain. Reason: semantic identity comes from the typed tree. Cost if wrong: a new supported status needs explicit mapping.
- Presence help does not choose fixed versus percentage DoT or assign live values. Reason: both application forms coexist. Cost if wrong: the user needs application inspection for exact triggers.
- Elemental help excludes the containing Skill's overlap context. Reason: presence is not an effect application. Cost if wrong: a separate policy-specific generic helper is required.
- The prototype-name fix is scoped to the shared web string boundary. Reason: truthful unknown labels do not require changing combat execution. Cost if wrong: other core callers retain the inherited fallback issue.

Every reviewer set-aside behavior has a separate parent reason/cost disposition below. Eleven inherited findings remain deferred Minors; they are listed individually to avoid dropping one inside the reviewer's grouped carry-forward.

{rulings}
'''
(root/'docs/verification/2026-10-16-linked-requirement-references.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Final prerequisite/condition checkpoint verification\n'+report+'\n')
print(json.dumps({'source':source,'reviewed':reviewed,'vitest':8438,'node':7,'rootReceipt':gate,'observedReferenceNodes':observed['addedReferenceNodes'],'parentRulings':28,'inheritedMinors':11}))
