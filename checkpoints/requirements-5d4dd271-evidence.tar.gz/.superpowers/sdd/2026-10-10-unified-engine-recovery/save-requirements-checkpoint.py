import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'requirements-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'requirements-tested-source.txt').read_text().strip();reviewed=(w/'requirements-reviewed-source.txt').read_text().strip();base='60b9c4a2398c915d8b5492fa3ec803feeed96e40'
assert set(git('diff','--name-only',reviewed,tested).splitlines())=={'apps/web/src/components/character/mechanic-tag-explanation.ts','apps/web/src/components/character/linked-requirement-references.test.tsx'}
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
allowed={'apps/web/src/components/character/linked-requirement-references.test.tsx','apps/web/src/components/battle/battle-skill-command-references.test.tsx','apps/web/src/components/character/mechanic-text.ts','apps/web/src/components/character/mechanic-tag-explanation.ts','apps/web/src/components/character/ability-detail-presentation.ts','apps/web/src/components/character/ability-parameters.tsx','apps/web/src/components/character/skill-characteristic-rows.tsx','apps/web/src/components/battle/battle-skill-command.tsx','apps/web/src/lib/battle/combat-interaction-presentation.ts','docs/verification/2026-10-16-linked-requirement-references.md'}
assert set(paths)==allowed,paths
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8438,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'requirements-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['plainDescriptionsChanged']==0 and observed['addedReferenceNodes']==82 and observed['allPriorStructuredReportsExactlyUnchanged'] and observed['allStaticVisibleReaderTextExactlyUnchanged'] and observed['eachReferenceExactlyMatchesTypedInventoryRecordGroupScopeEffectAndStatus'] and observed['rawSha256']==sha(w/'requirements-reader-observation.json')
bundle=w/('requirements-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'requirements-bundle-verify.log').write_text(v.stdout)
evidence=w/('requirements-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','task15-linked-requirement-next-brief.md','linked-next-requirement-inventory.json','requirements-combined-review-package.md','requirements-review-rulings.md','task15-requirements-reader-review.md','requirements-tested-source.txt','requirements-reviewed-source.txt','requirements-bundle-verify.log','verification.jsonl','run.py','save-requirements-checkpoint.py','requirements-readers-diagnostic.test.tsx','vitest-requirements-reader.config.ts','requirements-reader-observation.json','requirements-reader-analysis.json','analyze-requirements-readers.py','requirements-reference-observation.json','requirements-fullcheck-audit.json','requirements-turbo-logs.tar.gz','linked-reader-observation.json','ranged-ai-analysis.json','finalize-requirements-report.py','audit-requirements-fullcheck.py','requirements-next-cross-status-inventory.json','task15-cross-status-next-brief.md','requirements-checkpoint-summary.txt','requirements-pre-fix-reader-observation.json','requirements-pre-fix-reader-analysis.json','requirements-pre-fix-reference-observation.json','requirements-pre-fix-fullcheck-audit.json','requirements-pre-fix-turbo-logs.tar.gz']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T170600':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'825625c88e682b1e69c106f20e1f504c1ee1e120','previousArchiveTree':'f8bbdf56774413ccaa0a53ccdc9af81a1b655809','fullCheckReceipt':gate,'tests':{'vitest':8438,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/'requirements-checkpoint-summary.txt').read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
