import { readFileSync, writeFileSync } from 'node:fs'
import { renderToStaticMarkup } from 'react-dom/server'
import { expect, it } from 'vitest'
import { parseAbilityDefinition } from '@aurevane/game-core/combat/combat-definition'
import { essenceCombatSkill, type EssenceDefinition } from '@aurevane/game-core/combat/essence'
import type { MatureSkillDefinition } from '@aurevane/game-core/combat/mature-skills'
import type { AnyResonanceDefinition } from '@aurevane/game-core/combat/resonance'
import { abilityBehaviorInformation } from '@/components/character/ability-detail-presentation'
import { AbilityDefinitionParameters } from '@/components/character/ability-definition-parameters'
import { SkillDetails } from '@/components/character/skill-details'
import { SkillParameters } from '@/components/character/skill-parameters'
import { ResonanceParameters } from '@/components/character/resonance-parameters'
const root = '/workspace/scratch/680b26e4eb86/aurevane'
const w = root + '/.superpowers/sdd/2026-10-10-unified-engine-recovery'
it('observes every actual proposed canonical report and named shared reader without changing source', () => {
  const rows = JSON.parse(readFileSync(root + '/docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json', 'utf8')).records
  expect(rows).toHaveLength(294)
  const evidence = rows.map((row: { kind: string; id: string; after: Record<string, unknown> }) => {
    const before = JSON.stringify(row.after)
    const definition = parseAbilityDefinition(row.after.ability)
    const reports = definition.behaviors.map((group) => abilityBehaviorInformation(group))
    for (const report of reports) expect(report.rows).toHaveLength(10)
    const skill = row.kind === 'essence' ? essenceCombatSkill(row.after as unknown as EssenceDefinition) : row.after as unknown as MatureSkillDefinition
    const readers = row.kind === 'resonance'
      ? [<ResonanceParameters key="resonance" definition={row.after as unknown as AnyResonanceDefinition} />]
      : row.kind === 'basic'
        ? [<AbilityDefinitionParameters key="basic" definition={definition} />]
        : [<SkillDetails key="details" skill={skill} expanded />, <SkillParameters key="parameters" skill={skill} />]
    const html = readers.map((node) => renderToStaticMarkup(node))
    expect(html.every((s) => s.includes('data-ability-definition-parameters="true"'))).toBe(true)
    expect(JSON.stringify(row.after)).toBe(before)
    return { kind: row.kind, id: row.id, groups: definition.behaviors.map((g) => ({ id: g.id, effects: g.effects.map((e) => ({ id: e.id, type: e.payload.type, recipient: e.payload.recipient })) })), reports, html }
  })
  writeFileSync(w + '/requirements-reader-observation.json', JSON.stringify({ source: readFileSync(w + '/requirements-tested-source.txt', 'utf8').trim(), context: 'default shared reader context, static rendering only; not mounted/native acceptance', records: evidence }, null, 2) + '\n')
})
