from pathlib import Path
import json,hashlib,re,collections
w=Path(__file__).resolve().parent;root=w.parents[2]
a=json.loads((w/'requirements-reader-observation.json').read_text());b=json.loads((w/'linked-reader-observation.json').read_text())
assert len(a['records'])==len(b['records'])==294
fields={'requirementParts','conditionParts'}
nodes=[];changed=[];groups=effects=0
inventory=json.loads((w/'linked-next-requirement-inventory.json').read_text())
expected=collections.Counter((r['record'],r['group'],r['scope'],r['effect'], 'rooted' if r['requirement']['statusId']=='root' else r['requirement']['statusId']) for r in inventory['references'])
def base(value):
 if isinstance(value,dict):return {k:base(v) for k,v in value.items() if k not in fields}
 if isinstance(value,list):return [base(v) for v in value]
 return value
def references(parts,record,group,scope,effect,text):
 if parts is None:return
 assert ''.join(p if isinstance(p,str) else p['label'] for p in parts)==text,(record,scope,effect)
 for part in parts:
  if isinstance(part,str):continue
  assert set(part)=={'tag','label','explanation'} and all(isinstance(x,str) and x for x in part.values()),(record,part)
  nodes.append({'record':record,'group':group,'scope':scope,'effect':effect,**part})
for now,old in zip(a['records'],b['records'],strict=True):
 assert now['id']==old['id'] and now['groups']==old['groups']
 assert base(now['reports'])==old['reports'],now['id']
 assert len(now['html'])==len(old['html'])
 for n,o in zip(now['html'],old['html'],strict=True):assert re.sub(r'<[^>]*>','',n)==re.sub(r'<[^>]*>','',o),now['id']
 if now['html']!=old['html']:changed.append(now['id'])
 for group,report in zip(now['groups'],now['reports'],strict=True):
  requirements=next(value for label,value in report['rows'] if label=='Requirements')
  references(report.get('requirementParts'),now['id'],group['id'],'group',None,requirements)
  for effect,presentation in zip(group['effects'],report['effects'],strict=True):references(presentation.get('conditionParts'),now['id'],group['id'],'effect',effect['id'],presentation['condition'])
 groups+=len(now['groups']);effects+=sum(len(g['effects']) for g in now['groups'])
assert groups==297 and effects==604
actual=collections.Counter((r['record'],r['group'],r['scope'],r['effect'],r['tag']) for r in nodes)
assert actual==expected,(actual-expected,expected-actual)
assert set(changed)=={r['record'] for r in inventory['references']}
result={'source':a['source'],'rawSha256':hashlib.sha256((w/'requirements-reader-observation.json').read_bytes()).hexdigest(),'records':294,'groups':groups,'effects':effects,'plainDescriptionsChanged':0,'allPriorStructuredReportsExactlyUnchanged':True,'allStaticVisibleReaderTextExactlyUnchanged':True,'recordsWithNewReferenceMarkup':changed,'allOtherRecordMarkupExactlyUnchanged':294-len(changed),'addedReferenceNodes':len(nodes),'globalRequirementNodes':sum(n['scope']=='group' for n in nodes),'effectConditionNodes':sum(n['scope']=='effect' for n in nodes),'referenceIds':sorted({n['tag'] for n in nodes}),'eachReferenceExactlyMatchesTypedInventoryRecordGroupScopeEffectAndStatus':True,'scope':'Default-context static named-reader SSR and exact plain contract comparison only. New optional reference fields extend reports; no native hover/focus/touch/zoom/layout or full editorial acceptance implied.'}
assert result['source']==(w/'requirements-tested-source.txt').read_text().strip()
assert hashlib.sha256((root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json').read_bytes()).hexdigest()=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for p,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest,p
(w/'requirements-reader-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
(w/'requirements-reference-observation.json').write_text(json.dumps(nodes,indent=2)+'\n')
print(json.dumps(result))
