# Parent rulings for the single prerequisite/condition review

Reviewer0C/0I/0newMinor; parentpromotesoldestlegacyStormtoImportant. OneRED→GREENwave, no rereview. EleveninheritedMinorsunchanged/deferred.

1. Ruling: Native hover/keyboard/touch/dismissal/focus restoration — Keep open: source and controlled callback tests establish integration only; no native browser is available. Cost if wrong: A physical interaction defect can remain until native acceptance.

2. Ruling: Mobile/long-text geometry/200% zoom — Keep open: static rendering is not a physical viewport measurement. Cost if wrong: Obstruction or clipping may require later layout work.

3. Ruling: Master inline button sizing — Inherited Minor remains deferred; no measured functional obstruction supports promotion. Cost if wrong: Inline spacing can remain enlarged.

4. Ruling: Rewind prime witness begins at origin — Inherited Minor deferred; no Rewind test or runtime changed. Cost if wrong: Origin-return coverage remains weaker.

5. Ruling: Supporting Shot version pin — Inherited Minor deferred; no capture fixture changed. Cost if wrong: Version drift may escape that fixture.

6. Ruling: Ongoing pair dynamic ID pin — Inherited Minor deferred; no pairing/capture changed. Cost if wrong: The fixture does not pin exact identity.

7. Ruling: Repeated bounded AI route/target discovery — Inherited Minor deferred; no AI route or target code changed. Cost if wrong: Repeated bounded work remains.

8. Ruling: Admission double-prefix provenance — Inherited Minor deferred; no admission labels changed. Cost if wrong: Provenance wording can be redundant.

9. Ruling: Ranged negative preparation direct commit — Inherited Minor deferred; no ranged execution changed. Cost if wrong: The negative witness is narrower than direct-commit acceptance.

10. Ruling: Defense event independent HP reconciliation — Inherited Minor deferred; no defense payoff changed. Cost if wrong: The positive witness does not separately reconcile HP.

11. Ruling: Arsenal labels/history exact values — Inherited Minor deferred; no Arsenal/history source changed. Cost if wrong: Some reader assertions remain label-focused.

12. Ruling: Singular status clock grammar — Inherited Minor deferred; no status clock changed. Cost if wrong: One-duration grammar remains awkward.

13. Ruling: Burn ordinary tick boundary wording — Inherited Minor deferred; no Burn periodic rule changed. Cost if wrong: The ordinary tick boundary remains less discoverable.

14. Ruling: Public Manual rich references — Keep open: plain Manual summaries are not accepted as rich-reference completion. Cost if wrong: Readers do not yet get the full linked-term behavior there.

15. Ruling: Noncanonical legacy prose — Keep open: typed canonical prerequisite references do not imply arbitrary prose conversion. Cost if wrong: Some older sentences remain plain.

16. Ruling: Live-instance popup completeness — Keep open: generic presence links do not replace actual-instance stack/magnitude/readiness display. Cost if wrong: Specific active-effect facts still need full reader acceptance.

17. Ruling: Generic presence stacks/potency/lifetime/periodic triggers — Stand: a presence predicate does not identify a particular fixed or percentage application, so generic help avoids fabricating those facts. Cost if wrong: Users must inspect the active application for its exact values.

18. Ruling: Oldest legacy Storm fixed-vs-stacking context — PROMOTE TO IMPORTANT: new help could claim per-application scaling while the available legacyElemental context also admits fixed20% history. No need to prove one proposed record already has that capture to keep the public explanation truthful. ONE C/I wave makes generic legacy Wet/Conductive help describe common rules without promising a percentage or stacking model. Cost if wrong: Less detailed legacy help until a context can distinguish those historical policies.

19. Ruling: Prototype fallthrough in other core callers — Stand scoped: web display now returns a string or the original ID; broader core hardening is separate and no combat executor changed. Cost if wrong: Other core callers may retain the inherited prototype-name bug.

20. Ruling: Malformed nested captures — Stand scoped: typed validated requirement trees and optional safe presentation nodes remain the boundary; no new parser or hydration authority was added. Cost if wrong: Malformed authority coverage is not freshly re-audited here.

21. Ruling: Pending effects and summon authority — Stand scoped: no pending/summon schema/runtime changed. Cost if wrong: Their broader acceptance remains open.

22. Ruling: Expiry and revocation — Stand scoped: no capabilities or protected operation changed. Cost if wrong: Task8/16 live freshness acceptance remains open.

23. Ruling: Selected-character/direct-RPC authorization — Stand scoped: rendering strings grants no authority; no authorization path changed. Cost if wrong: Hosted authorization acceptance remains open.

24. Ruling: No-input damage/payment/repeated events/interrupted Move — Stand scoped: no execution source changed; root regression suite is distinct from final gameplay acceptance. Cost if wrong: Full timeout/payment/interruption scenarios remain release gates.

25. Ruling: Concurrent publication/build/claim/recovery/settlement — Stand scoped: no transaction, worker or lifecycle source changed. Cost if wrong: Hosted concurrency acceptance remains a separate gate.

26. Ruling: Full roster cycles/AI/balance — Stand scoped: source hashes and existing regression gates protect presentation-only work; no fresh289 is claimed. Cost if wrong: Natural pacing, distinct/full cycles and twelve-round balance remain open.

27. Ruling: Hosted/Atlas/human/publication/release — Keep open: no hosted write or deployment is authorized for this checkpoint. Cost if wrong: The combat release is not live or accepted.

28. Ruling: Exact-head full suite/all294 audit — Parent owns verification: initial frozen67f65723 passes8436+7 at170921209851 and all294 at170922430596. After the ONE fix wave, repeat both on its frozen source before any final success claim. Cost if wrong: Cannot use pre-fix evidence to certify post-fix source.

