import subprocess, pathlib, hashlib, json, tarfile, base64, sys, re

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'ranged-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = (workspace / 'ranged-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
counts = re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed', log)
assert len(counts) == 7 and sum(int(n) for _, n in counts) >= 8181
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
diagnostic_receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--filter', '@aurevane/web', 'exec', 'vitest', 'run', 'src/server/battle/roster-budget-diagnostic.test.ts'])
assert diagnostic_receipt['exit_code'] == 0
assert 'Tests  14 passed (14)' in pathlib.Path(diagnostic_receipt['log']).read_text()
matrix = [json.loads(line) for line in (workspace / 'ranged-budget-diagnostic.jsonl').read_text().splitlines()]
assert len(matrix) == 14 and all(r['lifecycle'] == 'completed' for r in matrix)
source = json.loads((workspace / 'ranged-budget-source.json').read_text())
for key, file in [('driverSha256',workspace/'ranged-budget-diagnostic-driver.test.ts'), ('helperSha256',root/'apps/web/src/server/battle/roster-legal-duel.test-utils.ts'), ('rangedTestsSha256',root/'apps/web/src/server/battle/roster-legal-ranged-cycle.test.ts'), ('jsonlSha256',workspace/'ranged-budget-diagnostic.jsonl')]:
    assert hashlib.sha256(file.read_bytes()).hexdigest() == source[key], key

prerequisite = '1461fa3de939e5fb4770d5ab507b8c9561256a05'
bundle = workspace / ('ranged-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + prerequisite], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'ranged-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('ranged-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T*.log')):
        if file.name >= '20261016T105800':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-ranged-review.md', 'task15-ranged-review.diff', 'task15-ranged-cycle-brief.md', 'ranged-budget-diagnostic-driver.test.ts', 'ranged-budget-source.json', 'ranged-budget-diagnostic.jsonl', 'ranged-budget-analysis.json', 'ranged-tested-source.txt', 'ranged-bundle-verify.log', 'save-ranged-checkpoint.py', 'task15-extra-high-handoff.md', 'ranged-independent-evidence-audit.txt']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

manifest = root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == 'b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'naturalDiagnosticReceipt': diagnostic_receipt, 'naturalDiagnosticCases': len(matrix), 'tests': {'vitest': sum(int(n) for _, n in counts), 'node': 7}, 'prerequisite': prerequisite, 'previousArchiveCommit': '948cbbc30edf9eedbde7a8f961495aaa92c83167', 'previousArchiveTree': 'ce79be77f044565558b95eef18fdc940a9c71f45', 'manifestSha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': '21actualrangedcyclesLevel1/100PvE/PvP plus14naturalPvPbudgetdiagnostics; genuinefourSkillbuilds/current-pinnedauthority/realcommands. Optionalfixtureboardonly,defaultcompatibilityguard. No productionbehavior/AI/prices/formulas/definitions/UI/hostedwrites/activation/merge/deploy. Task15/16andreleaseOPEN; pauseforOwnerExtraHighstrategy-balancejudgment. Exactlimits/rulings/prior5Minors inreport.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
