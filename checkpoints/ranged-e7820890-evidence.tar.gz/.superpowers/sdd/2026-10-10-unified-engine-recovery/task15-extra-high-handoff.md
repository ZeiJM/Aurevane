# Extra High judgment handoff — Task15 remains open

Frozen ranged source: 8657f3c46473f0c5455947d270ce8d69763e2cb6; base1461fa3d.
Owner reserved creative/architectural strategy/balance decisions for an actual Extra High setting. Finish verification and exact backup, then actually pause; no silent model switch or strategy choices on High.

Concrete evidence: 21 real outcome cases and14 natural diagnostic matches. See docs/verification/2026-10-16-ranged-role-and-budget-evidence.md. Level100 final rounds11–29,median13; minimum finalMP81.25%; three sampled low-mana pair roots not chosen. One seed/flatboard/PvP mirrors, no per-command resource snapshots: do not infer intermediate threshold eligibility, optimality or defects from absence. Level1finalrounds5–9median6. Current prices/formulas/AI/accepted definitions unchanged.

Next judgment after Owner switch: assess the intended approximately12round legalLevel100 benchmark against protection/sustain role differences and29roundmirror; decide which wider asymmetric/ally/terrain/seeds/PvE and percommand resource opportunity samples must precede any AI/cost/threshold proposal. Preserve fourSkill/earned eligibility/attachedMove/control-set/capture contracts. Do not reprice merely because MP remains at final. Use existing actual engine/roster authority; no parallel formulas.

Reproduce exact diagnostic only in an isolated checkout of frozen source: copy retained ranged-budget-diagnostic-driver.test.ts to apps/web/src/server/battle/roster-budget-diagnostic.test.ts; its evidence path is absolute, so redirect that single path to a fresh JSONL and preserve original driver hash. Run pnpm --filter @aurevane/web exec vitest run src/server/battle/roster-budget-diagnostic.test.ts. Remove temporary tracked-test placement after collection. No reproduction needed merely to resume; accepted14 receipt/raw/hash are archived.

Task15/16 full distinct cycles, natural balance, currentOwneredits/timing/hostedCAS, nativebrowser/readers/orange/derivedTags/editor/Atlas/human/release gates remain open. No hostedwrite/publication/activation/merge/deploy. Preserve both ignored workspaces and evidence. Prior five Minors unchanged. One combined reviewer per bounded milestone; no helper implementers or per-record review; one C/I RED→GREEN fix pass, Minor defer, no rereview.
