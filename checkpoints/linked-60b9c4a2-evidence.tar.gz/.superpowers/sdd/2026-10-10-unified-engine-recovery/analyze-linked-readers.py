from pathlib import Path
import json,hashlib,re,collections
w=Path(__file__).resolve().parent;root=w.parents[2]
a=json.loads((w/'linked-reader-observation.json').read_text());b=json.loads((w/'conditional-reader-observation.json').read_text())
assert len(a['records'])==len(b['records'])==294
nodes=[];changed=[];effects=0;groups=0
allowed={'frozen-ground','steam','airborne','rooted','slow','fire'}
def base(value):
 if isinstance(value,dict):return {k:base(v) for k,v in value.items() if k not in ('explanationParts','labelParts')}
 if isinstance(value,list):return [base(v) for v in value]
 return value
def refs(value,record):
 if isinstance(value,dict):
  for key,v in value.items():
   if key in ('explanationParts','labelParts'):
    assert isinstance(v,list)
    for part in v:
     if isinstance(part,str):continue
     assert set(part)=={'tag','label','explanation'} and part['tag'] in allowed and all(isinstance(x,str) for x in part.values()),(record,part)
     nodes.append({'record':record,'field':key,**part})
   else:refs(v,record)
 elif isinstance(value,list):
  for v in value:refs(v,record)
for now,old in zip(a['records'],b['records'],strict=True):
 assert now['id']==old['id'] and now['groups']==old['groups']
 assert base(now['reports'])==old['reports'],now['id']
 assert len(now['html'])==len(old['html'])
 for n,o in zip(now['html'],old['html'],strict=True):assert re.sub(r'<[^>]*>','',n)==re.sub(r'<[^>]*>','',o),now['id']
 if now['html']!=old['html']:changed.append(now['id'])
 refs(now['reports'],now['id']);groups+=len(now['groups']);effects+=sum(len(g['effects']) for g in now['groups'])
assert effects==604 and groups==297
assert set(changed)=={'ironfist.breakfall','frostweaver.chilling-mist','resonance.bastion-edgedancer.linked-sequence'}
assert len(nodes)==11 and set(x['tag'] for x in nodes)==allowed
result={'source':a['source'],'rawSha256':hashlib.sha256((w/'linked-reader-observation.json').read_bytes()).hexdigest(),'records':294,'groups':groups,'effects':effects,'plainDescriptionsChanged':0,'allNormalizedStructuredReportsExactlyUnchanged':True,'allStaticVisibleReaderTextExactlyUnchanged':True,'recordsWithNewReferenceMarkup':changed,'allOtherRecordMarkupExactlyUnchanged':291,'referenceNodes':len(nodes),'referenceIds':sorted(allowed),'scope':'Default-context static named-reader SSR and exactplaincontract comparison only. Optional semantic nodes intentionally extend3reports. No nativehover/focus/touch/zoom/layout or fulltag/editorial acceptance implied.'}
assert result['source']==(w/'linked-tested-source.txt').read_text().strip()
assert hashlib.sha256((root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json').read_bytes()).hexdigest()=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for p,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest,p
(w/'linked-reader-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
(w/'linked-reference-observation.json').write_text(json.dumps(nodes,indent=2)+'\n')
print(json.dumps(result))
