import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'linked-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'linked-tested-source.txt').read_text().strip();base='b036763303a1e34b43f60188ab3b55b591637c54'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==22 and all(p.startswith(('apps/web/src/components/character/','apps/web/src/components/battle/')) or p=='docs/verification/2026-10-16-linked-ground-airborne-references.md' for p in paths),paths
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8409,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
reviewed='aed2fb535a5561f48efdeddd67c73f20977e3e1f'
assert set(git('diff','--name-only',reviewed,tested).splitlines())=={'apps/web/src/components/battle/battle-info-popover.tsx','apps/web/src/components/battle/battle-info-reference-navigation.test.tsx','apps/web/src/components/character/mechanic-text-view.tsx','apps/web/src/components/character/linked-tag-references.test.tsx'}
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'linked-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['plainDescriptionsChanged']==0 and observed['referenceNodes']==11 and observed['allNormalizedStructuredReportsExactlyUnchanged'] and observed['allStaticVisibleReaderTextExactlyUnchanged'] and observed['rawSha256']==sha(w/'linked-reader-observation.json')
comparison=json.loads((w/'secondary-matrix-analysis.json').read_text());assert comparison['records']==289 and comparison['commands']==8219 and comparison['allCompleteRowsIdentical'] and comparison['rawSha256']==sha(w/'secondary-restored-289.jsonl')
bundle=w/('linked-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'linked-bundle-verify.log').write_text(v.stdout)
evidence=w/('linked-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-linked-tag-reference-brief.md', 'task15-linked-foundation-brief.md', 'linked-combined-review-package.md', 'linked-review-rulings.md', 'task15-linked-reader-review.md', 'linked-tested-source.txt', 'linked-reviewed-source.txt', 'linked-pre-review-reader-observation.json', 'linked-pre-review-reader-analysis.json', 'linked-pre-review-reference-observation.json', 'linked-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-linked-checkpoint.py', 'finalize-linked-report.py', 'linked-readers-diagnostic.test.tsx', 'vitest-linked-reader.config.ts', 'linked-reader-observation.json', 'linked-reader-analysis.json', 'analyze-linked-readers.py', 'linked-reference-observation.json', 'linked-next-requirement-inventory.json', 'task15-linked-requirement-next-brief.md', 'linked-fullcheck-audit.json', 'linked-turbo-logs.tar.gz', 'secondary-matrix-analysis.json', 'ranged-ai-analysis.json', 'conditional-reader-observation.json']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T163100':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'4f2f5f72cdacaca82573624674df857251cc499f','previousArchiveTree':'15b6b1d8450cfd07ddd1774851babbc7b42373c1','fullCheckReceipt':gate,'tests':{'vitest':8409,'node':7},'priorMatrixReference':comparison,'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':'Typed Ground/Airborne reference foundation:6explicitIDs,3actualcanonicaleffects+Steamfactlabel,11safe publicnodes; no keywordinference. Existing plainstrings/normalizedfields/staticvisibletext all294exactprior,291otherrecordmarkupunchanged. Capturednativegenerichelp/authoredoverride/stalemetadata/unknownID/finiteplaintexthelp preserve truth. Sharedpopupoptin1primary+1leaf withcapturedlayer/hoverfocus/cleanup/sibling/globalhandoff/reentrancy; oldglobaldismissmeaning retained. Initial11validRED6GREEN->344covering/41files incl16newcases; reviewerKeyboardImportantfixedonewave9validRED+1modifierRED->372covering/43files;25newcases; frozen8409Vitest+7Node. Onecombinedreview0C1I1newMinor; keyboardImportantfixedTDDonewave; MasterSizingMinordeferred,11totalMinors;65individualparentrulings;no rereview. Otherterms/legacy/conditions/Manual/authoredtypededitor/livepopups andnativehover/focus/touch/mobilezoomacceptance remainOPEN; no allorangecompletion. Native/schema/manifest/AI/fixtures unchanged;no new289claimed. Originalcombat/fullcycles/balance/Ownerhosted/Atlas/human/release andbroaderMaster remainopen. No hostedwrite/publication/activation/migration/merge/deploy.'}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k not in ('matrix','readerAudit')}))
