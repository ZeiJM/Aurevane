# Parent rulings — linked Ground/Airborne foundation

Reviewer /root/linked_ground_airborne_reference_review, gpt-6-astra High, fork none; read-onlyb0367633..aed2fb53, no suites/services/browser/mutations/delegation/rereview. Parent accepts0Critical/1Important/1newMinor. Keyboard reachability Important enters ONE C/I RED→GREEN wave; Master inline sizing accepted as Minor and deferred (possible tall lines, no established functional obstruction or measured dimensions). Total11Minors; no incidental sizing change.

1. Final: Ruling: Complete orange treatment across every tag — six explicit identities are the bounded foundation. Cost if wrong: other references remain inconsistent until later cohorts.
2. Final: Ruling: Noncanonical/legacy prose links — existing plain fallback generation remains outside this foundation. Cost if wrong: older readers can lack interactive linked terms.
3. Final: Ruling: Condition links — typed condition linking remains next work. Cost if wrong: prerequisite names remain plain text.
4. Final: Ruling: Manual rich links — Manual string consumer unchanged. Cost if wrong: public Manual terms remain noninteractive.
5. Final: Ruling: Authored typed-reference insertion — authored plain explanations are preserved; insertion workflow remains open. Cost if wrong: editors cannot yet deliberately insert typed links.
6. Final: Ruling: Live-instance potency/stacks/expiry — generic help has no instance source and makes no instance claim. Cost if wrong: active-effect popups still require separate complete acceptance.
7. Final: Ruling: Every historical policy combination — relevant old Ground/Fire/Airborne branches tested; not exhaustive. Cost if wrong: an untested historical combination could display wrong help.
8. Final: Ruling: Malformed runtime reference arrays — internally generated typed metadata introduces no external deserializer. Cost if wrong: a future persisted/untrusted reference boundary would need validation.
9. Final: Ruling: Malformed nested definitions — parser unchanged; no rejection-path acceptance here. Cost if wrong: invalid authored structures could escape independent validation.
10. Final: Ruling: Malformed captured definitions — capture validation unchanged. Cost if wrong: corrupt historical definitions could be misread or execute incorrectly.
11. Final: Ruling: Malformed pending work — pending execution unchanged. Cost if wrong: invalid pending packets could survive an unrelated boundary.
12. Final: Ruling: Malformed summon data — summon validation unchanged. Cost if wrong: invalid summon payloads could survive an unrelated boundary.
13. Final: Ruling: Complete transport/privacy — new nodes contain only tag/label/explanation but other envelopes remain unaccepted. Cost if wrong: another transport surface could leak private fields.
14. Final: Ruling: Physical hover traversal — source and ownership tests are narrower than real pointer geometry. Cost if wrong: pointer gaps could dismiss or strand a popup.
15. Final: Ruling: Physical touch dismissal — click ownership inspected; real touch sequencing remains open. Cost if wrong: touch users might struggle to dismiss or switch terms.
16. Final: Ruling: Native focus restoration — appropriate targets retained; no real browser focus acceptance. Cost if wrong: physical focus could be lost or reopen unexpectedly.
17. Final: Ruling: Full keyboard/AT acceptance — reported reachability Important enters one fix wave; native AT/device exercise remains open. Cost if wrong: real keyboard or screen-reader behavior might differ from handler checks.
18. Final: Ruling: Long-name geometry — no physical layout measurements. Cost if wrong: long labels could overflow or obscure controls.
19. Final: Ruling: Mobile viewport geometry — shared code applies to mobile but no device acceptance. Cost if wrong: mobile terms or panels could clip.
20. Final: Ruling: 200% zoom — source/SSR cannot establish enlarged layout. Cost if wrong: zoomed controls or text could become inaccessible.
21. Final: Ruling: Exact Master inline heights — new sizing Minor deferred; no used-height measurement. Cost if wrong: Master inline reference rows may be taller than intended.
22. Final: Ruling: Outer-modal backdrop dismissal — existing close-all modal boundary preserved. Cost if wrong: a modal backdrop can close the broader reader instead of only the leaf.
23. Final: Ruling: Arbitrary open-callback recursion — actual callbacks only close/resume their own hierarchy; broader callback API unchanged. Cost if wrong: a future exotic caller could violate ownership expectations.
24. Final: Ruling: Complete Master editor coverage — relevant shared report adapters inspected only. Cost if wrong: other mounted editors may still mis-save or misdisplay fields.
25. Final: Ruling: Every mounted preview/popup — shared paths traced; full mounted audit remains open. Cost if wrong: a separate surface can miss reference or parameter changes.
26. Final: Ruling: Targeting/controller completion — execution unchanged; original gate remains. Cost if wrong: selection or range defects could block combat release.
27. Final: Ruling: Attached Move traversal/interruption — no movement execution change. Cost if wrong: interrupted movement could violate path or payment rules.
28. Final: Ruling: Attacks from reached origins — native movement/attack acceptance remains separate. Cost if wrong: an attack could use an unreached origin.
29. Final: Ruling: Editable Basic Move completion — no complete editor-to-native workflow exercised. Cost if wrong: saved Move edits may diverge during battle.
30. Final: Ruling: Editable Basic Attack completion — projection/readers are narrower than full workflow. Cost if wrong: saved attack edits may execute differently.
31. Final: Ruling: Editable Guard completion — no complete editor/runtime exercise. Cost if wrong: saved Guard effects may diverge.
32. Final: Ruling: Editable HP Recovery completion — no complete editor/runtime exercise. Cost if wrong: saved HP recovery may execute incorrectly.
33. Final: Ruling: Editable MP Recovery completion — no complete editor/runtime exercise. Cost if wrong: saved MP recovery may execute incorrectly.
34. Final: Ruling: Controlled prime/release/cancel completion — wrapper text remains exact; native gate still required. Cost if wrong: release/cancel could violate allowance or payment.
35. Final: Ruling: Stale-browser expiry/revocation — authority unchanged; independent gate remains. Cost if wrong: stale privileges might remain effective.
36. Final: Ruling: Alternate selected-character authority — selection/binding unchanged. Cost if wrong: operations could affect an unauthorized character.
37. Final: Ruling: Direct RPC expiry — protected RPC not exercised. Cost if wrong: expired direct access might bypass UI-only checks.
38. Final: Ruling: Direct RPC revocation — protected RPC not exercised. Cost if wrong: revoked direct access might remain effective.
39. Final: Ruling: Direct RPC CAS — no concurrency exercise. Cost if wrong: stale direct writes could overwrite newer state.
40. Final: Ruling: No-input/timeout behavior — scheduler/terminal paths unchanged. Cost if wrong: idle handling could settle or reward incorrectly.
41. Final: Ruling: Free priming bounds — no native budget exercise. Cost if wrong: repeated priming could create unintended advantage.
42. Final: Ruling: Repeated-event bounds — event execution unchanged. Cost if wrong: reactions could produce unbounded output.
43. Final: Ruling: Duplicate payment prevention — no complete payment-path exercise. Cost if wrong: release could pay repeatedly or skip costs.
44. Final: Ruling: Extra-turn prevention — turn economy unchanged. Cost if wrong: reactions could create unintended extra turns.
45. Final: Ruling: Concurrent publication — no hosted race/rollback exercise. Cost if wrong: versions could publish inconsistently.
46. Final: Ruling: Concurrent build writes — no write-concurrency exercise. Cost if wrong: simultaneous edits could lose changes.
47. Final: Ruling: Concurrent claims — claim/idempotency paths unchanged. Cost if wrong: repeated claims could duplicate grants/rewards.
48. Final: Ruling: Concurrent recovery — no late-worker exercise. Cost if wrong: recovery could conflict with fresh state.
49. Final: Ruling: Concurrent settlement — no settlement race exercise. Cost if wrong: a battle could settle repeatedly or inconsistently.
50. Final: Ruling: Distinct complete combat cycles — links do not prove playable setup/payoff cycles. Cost if wrong: a roster cycle could fail or dominate despite legible descriptions.
51. Final: Ruling: AI strategy — planner/fixtures unchanged. Cost if wrong: legal AI decisions may remain strategically weak.
52. Final: Ruling: Natural pacing — no balance experiment in this presentation cohort. Cost if wrong: combat could be too long or one-sided.
53. Final: Ruling: Twelve-round balance — original benchmark gate remains open. Cost if wrong: intended pacing could remain unbalanced.
54. Final: Ruling: Fresh Owner content — release-time reconciliation remains required. Cost if wrong: later Owner edits could be overwritten or missed.
55. Final: Ruling: Atlas motion — no motion change or acceptance; known threshold miss stays open. Cost if wrong: motion could remain above the agreed limit.
56. Final: Ruling: Human gameplay acceptance — requires actual Owner play evidence. Cost if wrong: software checks could miss a poor gameplay experience.
57. Final: Ruling: Broader Master panels — scheduled after combat as instructed. Cost if wrong: unrelated Master workflows remain unfinished.
58. Final: Ruling: Frozen full root — parent read actual8400+7 initial gate; post-fix source must pass its own full gate. Cost if wrong: unobserved post-fix failures could invalidate the checkpoint.
59. Final: Ruling: All294 mounted behavior — parent static audit proves exact text/normalized fields only. Cost if wrong: mounted interaction/layout can differ from SSR.
60. Final: Ruling: Publication — none authorized or performed by this cohort. Cost if wrong: unfinished definitions could reach players.
61. Final: Ruling: Activation — none authorized or performed. Cost if wrong: unfinished mechanics could become active.
62. Final: Ruling: Hosted writes — none needed for local reader changes. Cost if wrong: remote state could change before acceptance.
63. Final: Ruling: Migration application — no migration in this cohort or applied. Cost if wrong: hosted schema/authority could change prematurely.
64. Final: Ruling: Merge — not authorized or performed. Cost if wrong: unaccepted work could reach main.
65. Final: Ruling: Deployment/release — original gates remain open; lock retained. Cost if wrong: players could receive unfinished combat behavior.

Final: minor (deferred): Master button min-height/font cascade can enlarge inline reference rows; exact geometry unmeasured. New11thMinor, preserved for later Owner-prioritized work. Ten inheritedMinors remain individually unchanged: Rewindoriginwitness; SupportingShotversionpin; Ongoingpairidentitypin; repeatedboundedAIdiscovery; admissionprovenanceprefix; rangednegativedirectcommit; defenseevent/HPreconciliation; Arsenalfull-label/exacthistoryvaluehardening; singulardurationgrammar; ordinaryBurntickboundaryclarity.
