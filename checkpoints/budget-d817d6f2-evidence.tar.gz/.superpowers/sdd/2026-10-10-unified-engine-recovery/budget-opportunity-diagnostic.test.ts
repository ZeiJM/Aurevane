// One-off observational probe. Original AI is called unchanged and its exact decision returned.
import { appendFileSync } from 'node:fs'
import { describe, expect, it, vi } from 'vitest'
import * as ai from '@aurevane/game-core/combat/recruit-ai-build'
import { prepareCombatAbilityCommand } from '@aurevane/game-core/combat/combat-ability-command'
import { combatAbilityCommandContext } from '@aurevane/game-core/combat/combat-behavior-runtime'
import { canonicalAbilityTargetSpec, enumerateCombatTargetSelections } from '@aurevane/game-core/combat/combat-targeting-shapes'
import { evaluateAbilityRequirements } from '@aurevane/game-core/combat/combat-requirements'
import { applyAbilityTimingDefaults } from '@aurevane/game-core/combat/combat-definition'
import { PV1F_COMBAT_CONTENT, readPv1fActionEconomy } from '@aurevane/game-core/combat/pv1f-action-economy'
import { createLegalRosterDuel, legalRosterCycleKits, playLegalRosterDuel } from './roster-legal-duel.test-utils'
vi.mock('server-only',()=>({}))
const selected=legalRosterCycleKits.filter(k=>['resonance.aetherist-bastion.','resonance.aetherist-edgedancer.','resonance.chronist-runeblade.'].some(p=>k.name.startsWith(p)))
const cases=selected.flatMap(kit=>[
 {name:`baseline:${kit.name}`,kit,seed:1,context:'pvp' as const},
 {name:`seed17:${kit.name}`,kit,seed:17,context:'pvp' as const},
 {name:`pve:${kit.name}`,kit,seed:1,context:'pve' as const},
])
const asymmetry=[
 {name:'pressure:aetherist-bastion-primary-bastion-vs-pure-aetherist',kit:selected.find(k=>k.primary==='bastion')!,opponentKit:legalRosterCycleKits.find(k=>k.primary==='aetherist'&&!k.secondary)!,seed:1,context:'pvp' as const},
 {name:'drain:chronist-runeblade-primary-runeblade-vs-pure-runeblade',kit:selected.find(k=>k.primary==='runeblade')!,opponentKit:legalRosterCycleKits.find(k=>k.primary==='runeblade'&&!k.secondary)!,seed:1,context:'pvp' as const},
]
const evidence=process.env.AUREVANE_BUDGET_OPPORTUNITY_EVIDENCE!
if(!evidence)throw Error('Fresh evidence path required')
const original=ai.chooseBuildAwareRecruitAiDecision
let observations: unknown[]=[]
const spy=vi.spyOn(ai,'chooseBuildAwareRecruitAiDecision').mockImplementation(input=>{
 const before=JSON.stringify(input.state)
 const decision=original(input)
 const s=input.state, actorId=s.tactical.battle.currentTurn!.combatantId
 const unit=s.tactical.battle.combatants.find(u=>u.id===actorId)!
 const owner={resources:{mp:unit.mp,hp:unit.hp,ap:readPv1fActionEconomy(s,actorId).remaining},maximumResources:{mp:unit.maxMp,hp:unit.maxHp,ap:100}}
 const position=s.tactical.placements.find(p=>p.combatantId===actorId)!.position
 const opportunities=(s.capturedAbilitySources??[]).filter(source=>source.ownerCombatantId===actorId&&source.abilityId.startsWith('resonance.')).flatMap(source=>source.definition.behaviors.filter(b=>b.activation==='manual'&&b.mode==='action').map(authored=>{
  const b=applyAbilityTimingDefaults(authored,s.effectTimingPolicy)
  const requirement=evaluateAbilityRequirements(b.requirements,{owner})
  let legal=0,maximumProjectedUtility:number|null=null
  const issues=new Set<string>()
  const move=b.effects.find(e=>e.payload.type==='move')
  const paths=move?[{x:position.x,y:position.y-1},{x:position.x+1,y:position.y},{x:position.x,y:position.y+1},{x:position.x-1,y:position.y}].map(p=>[position,p]):[undefined]
  for(const selection of enumerateCombatTargetSelections(s,actorId,canonicalAbilityTargetSpec(b.targeting!))){
   for(const movementPath of paths){
    try{
     const q=prepareCombatAbilityCommand({state:s,actorId,root:{kind:'canonical',source,behaviorId:b.id},selection,movementPath,content:PV1F_COMBAT_CONTENT,context:combatAbilityCommandContext(s,source)})
     if(q.evaluation.legal){legal++;const u=ai.projectedCombatEffectUtility(q.evaluation,s,q.action.effects);maximumProjectedUtility=Math.max(maximumProjectedUtility??-Infinity,u)}
     else for(const issue of q.evaluation.issues)issues.add(issue.code)
    }catch(error){issues.add(String(error))}
   }
  }
  return {abilityId:source.abilityId,version:source.contentVersion,behaviorId:b.id,requirement,legalQuotes:legal,maximumProjectedUtility,issues:[...issues],chosen:decision.intent.kind==='action'&&decision.intent.actionId===source.abilityId&&decision.intent.behaviorId===b.id}
 }))
 expect(JSON.stringify(input.state)).toBe(before)
 observations.push({round:s.tactical.battle.round,actorId,resources:owner.resources,maxHp:unit.maxHp,maxMp:unit.maxMp,position,opportunities,decision})
 return decision
})
describe('natural reserve eligibility and chosen-action observations, not balance acceptance',()=>{
 it.each([...cases,...asymmetry])('$name',async(sample)=>{
  observations=[]
  const duel=await createLegalRosterDuel({kit:sample.kit,opponentKit:'opponentKit'in sample?sample.opponentKit:undefined,level:100,context:sample.context,seed:sample.seed,board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]}})
  const result=playLegalRosterDuel(duel,{maximumRounds:40})
  expect(spy).toHaveBeenCalled()
  expect(observations).toHaveLength(result.commands.length)
  expect(result.errors).toEqual([])
  expect(result.state.tactical.battle.lifecycle==='completed'||result.state.tactical.battle.round>40).toBe(true)
  appendFileSync(evidence,JSON.stringify({name:sample.name,kit:sample.kit.name,opponentKit:'opponentKit'in sample?sample.opponentKit.name:sample.kit.name,level:100,seed:sample.seed,context:sample.context,maximumRounds:40,round:result.state.tactical.battle.round,lifecycle:result.state.tactical.battle.lifecycle,final:result.state.tactical.battle.combatants.map(u=>({id:u.id,hp:u.hp,maxHp:u.maxHp,mp:u.mp,maxMp:u.maxMp})),commands:result.commands,observations})+'\n')
 },180_000)
})
