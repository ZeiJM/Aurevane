import subprocess,pathlib,hashlib,json,tarfile,base64,sys,re
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'budget-backup-payload.json'
if len(sys.argv)>1:
 data=json.loads(payload.read_text());key,index=sys.argv[1],int(sys.argv[2]);content=base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode();print(json.dumps({'chunk':content[index*12000:(index+1)*12000]}));sys.exit()
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
assert not git('status','--porcelain'),'requires clean final source'
head=git('rev-parse','HEAD');tested=(w/'budget-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
rs=list(map(json.loads,(w/'verification.jsonl').read_text().splitlines()));gate=next(r for r in reversed(rs) if r['argv']==['pnpm','--reporter=append-only','check']);assert gate['exit_code']==0
log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log);assert len(counts)==7 and sum(int(n) for _,n in counts)==8197
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
analysis=json.loads((w/'budget-pacing-analysis.json').read_text())
for name,sha in analysis['sha256'].items():assert hashlib.sha256((w/name).read_bytes()).hexdigest()==sha,name
raw=['budget-opportunity-natural.jsonl','pure-pacing-natural.jsonl','pure-counter-pacing-natural.jsonl','selected-counter-pacing-natural.jsonl','stall-receipts-natural.jsonl']
rows=[json.loads(s) for name in raw for s in (w/name).read_text().splitlines()];assert len(rows)==51 and sum(r['lifecycle']=='completed' for r in rows)==42 and sum(r['lifecycle']=='active' for r in rows)==9
prereq='e7820890256733b51edc00e98895efebe0d3d6fc'
bundle=w/('budget-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+prereq],check=True)
check=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'budget-bundle-verify.log').write_text(check.stdout)
evidence=w/('budget-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','verification.jsonl','run.py','task15-budget-review.md','task15-budget-review.diff','budget-tested-source.txt','budget-bundle-verify.log','budget-pacing-analysis.json','budget-pacing-analysis-summary.txt','budget-pacing-source.json','analyze-budget-pacing.py','finalize-budget-pacing-analysis.py','save-budget-checkpoint.py','ranged-budget-diagnostic.jsonl','ranged-budget-source.json','task15-budget-next-brief.md']+raw+[p.name for p in w.glob('*-diagnostic*.test.ts')]
with tarfile.open(evidence,'w:gz') as archive:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T113000':archive.add(p,arcname=str(p.relative_to(root)))
 for name in sorted(set(names)):
  p=w/name
  if p.exists():archive.add(p,arcname=str(p.relative_to(root)))
def info(p):
 data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'blobSha':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'chunks':(len(base64.b64encode(data))+11999)//12000}
manifest=root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json';sha=hashlib.sha256(manifest.read_bytes()).hexdigest();assert sha=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
meta={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'fullCheckReceipt':gate,'tests':{'vitest':8197,'node':7},'prerequisite':prereq,'previousArchiveCommit':'d21131a10595d0b4d60d9a937f53761677a4afb0','previousArchiveTree':'90bff87df0948aae1faa3c5e18d36d311183ff15','manifestSha256':sha,'diagnosticExecutions':51,'completedExecutions':42,'active40RoundExecutions':9,'bundle':info(bundle),'evidence':info(evidence),'acceptance':'16actualAetherinPoiserelease/closingcountercasesbothPrimaryLevels1/100PvE/PvP;20actualresourceopportunitytraces;17purekitnaturalsincludepriorAetherist;12pressure/countercomparisons;3exactHP-eventreceiptcalibrations. Pacingrough12roundsNOTACCEPTED:3puremirrorsactiveafter40. No productAI/mechanics/prices/formulas/definitions/UI/hostedwrite/activation/merge/deploy. Source/driverlimitations and6priorMinors explicit. Task15/16allcycles/balance/nativeUI/Owneredits/hostedCAS/human/releaseOPEN. See report for judgment/rulings/gates.'}
payload.write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
