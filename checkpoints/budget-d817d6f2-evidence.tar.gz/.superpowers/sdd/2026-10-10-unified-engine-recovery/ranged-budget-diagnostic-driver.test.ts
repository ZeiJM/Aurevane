// One-off bounded evidence collection; retained with the checkpoint evidence.
import { appendFileSync } from 'node:fs'
import { describe, expect, it, vi } from 'vitest'
import { createLegalRosterDuel, legalRosterCycleKits, playLegalRosterDuel } from './roster-legal-duel.test-utils'

vi.mock('server-only',()=>({}))
const selected=legalRosterCycleKits.filter((kit)=>
  kit.name==='aetherist:approved-entry-kit'||
  ['resonance.aetherist-bastion.','resonance.aetherist-edgedancer.','resonance.chronist-runeblade.'].some((prefix)=>kit.name.startsWith(prefix)))
const cases=selected.flatMap((kit)=>([1,100]as const).map((level)=>({name:`${kit.name}:level:${level}`,kit,level})))
const evidence='/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/ranged-budget-diagnostic.jsonl'
describe('stated-seed natural resource/pacing diagnostic, not balance acceptance',()=>{
 it.each(cases)('$name records genuine completion or an active32round horizon',async({kit,level})=>{
  const duel=await createLegalRosterDuel({kit,level,context:'pvp',seed:1,
    board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]}})
  const initial=duel.state.tactical.battle.combatants.map((u)=>({id:u.id,hp:u.hp,maxHp:u.maxHp,mp:u.mp,maxMp:u.maxMp}))
  const result=playLegalRosterDuel(duel,{maximumRounds:32})
  expect(result.errors).toEqual([])
  expect(result.state.tactical.battle.lifecycle==='completed'||result.state.tactical.battle.round>32).toBe(true)
  appendFileSync(evidence,JSON.stringify({kit:kit.name,primary:kit.primary,secondary:kit.secondary,level,context:'pvp',seed:1,maximumRounds:32,
   board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]},initial,
   final:result.state.tactical.battle.combatants.map((u)=>({id:u.id,hp:u.hp,maxHp:u.maxHp,mp:u.mp,maxMp:u.maxMp})),
   actualRound:result.state.tactical.battle.round,lifecycle:result.state.tactical.battle.lifecycle,
   commands:result.commands,sourceVersions:duel.participants.map((p)=>({actorId:p.actorId,sources:p.sources.map((s)=>({id:s.abilityId,contentVersion:s.contentVersion}))}))})+'\n')
 },120_000)
})
