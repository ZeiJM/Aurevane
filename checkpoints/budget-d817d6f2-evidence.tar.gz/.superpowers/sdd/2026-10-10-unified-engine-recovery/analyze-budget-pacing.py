from pathlib import Path
import json,hashlib,statistics,collections,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
traces=[json.loads(s) for s in (w/'budget-opportunity-natural.jsonl').read_text().splitlines()]
old=[json.loads(s) for s in (w/'ranged-budget-diagnostic.jsonl').read_text().splitlines()]
assert len(traces)==20 and len({r['name'] for r in traces})==20
summary=[]
for r in traces:
 assert len(r['commands'])==len(r['observations'])
 if r['name'].startswith('baseline:'):
  o=next(o for o in old if o['kit']==r['kit'] and o['level']==100)
  assert r['commands']==o['commands'] and r['round']==o['actualRound'] and r['final']==o['final']
 groups={}
 for d,c in zip(r['observations'],r['commands']):
  assert d['round']==c['round'] and d['actorId']==c['actorId']
  for o in d['opportunities']:
   key=o['abilityId']+':'+o['behaviorId'];a=groups.setdefault(key,dict(observations=0,requirementTrue=0,legalOpportunity=0,chosen=0,issues=collections.Counter()))
   a['observations']+=1;a['requirementTrue']+=o['requirement'];a['legalOpportunity']+=o['legalQuotes']>0;a['chosen']+=o['chosen'];a['issues'].update(o['issues'])
 minimum=min([d['resources']['mp']/d['maxMp'] for d in r['observations']]+[u['mp']/u['maxMp'] for u in r['final']])
 summary.append(dict(name=r['name'],kit=r['kit'],context=r['context'],seed=r['seed'],round=r['round'],lifecycle=r['lifecycle'],commands=len(r['commands']),minimumObservedMpBasisPoints=int(minimum*10000),groups=groups))
p=w/'pure-pacing-natural.jsonl'
pure=[json.loads(s) for s in p.read_text().splitlines()] if p.exists() else []
if len(pure)==16:
 assert len({r['kit'] for r in pure})==16
 aeth=next(r for r in old if r['level']==100 and r['kit']=='aetherist:approved-entry-kit')
 pure_summary=[dict(kit=r['kit'],round=r['round'],lifecycle=r['lifecycle'],commands=len(r['commands']),basicAttackCommands=sum(c['abilityId']=='basic.attack.unarmed.basic' for c in r['commands']),attackOrActionCommands=sum(c['kind']=='action' for c in r['commands'])) for r in pure]
 pure_summary.append(dict(kit=aeth['kit'],round=aeth['actualRound'],lifecycle=aeth['lifecycle'],commands=len(aeth['commands']),basicAttackCommands=sum(c['abilityId']=='basic.attack.unarmed.basic' for c in aeth['commands']),attackOrActionCommands=sum(c['kind']=='action' for c in aeth['commands']),provenance='prior unchanged source14diagnostic'))
 completed=[r['round'] for r in pure_summary if r['lifecycle']=='completed']
 aggregate=dict(kits=17,completed=len(completed),activeAt40=sum(r['lifecycle']=='active' for r in pure_summary),completedMin=min(completed),completedMedian=statistics.median(completed),completedMax=max(completed))
else:pure_summary=[];aggregate={'pending':len(pure),'expectedNew':16}
paths=['budget-opportunity-diagnostic.test.ts','pure-pacing-diagnostic.test.ts','budget-opportunity-natural.jsonl','pure-pacing-natural.jsonl']
hashes={str(p):hashlib.sha256((w/p).read_bytes()).hexdigest() for p in paths if (w/p).exists()}
result=dict(sourceHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),tracedCases=20,allTracedCompleted=all(r['lifecycle']=='completed' for r in traces),baseline6ExactReplay=True,traces=summary,pure=pure_summary,pureAggregate=aggregate,sha256=hashes,limitations=['Trace observer reads nonexistent AP remaining field: AP omitted, MP/HP observations remain exact; no per-step AP claim. Authoritative legal quote evaluates original state AP. Selected pair requirements use ownerMP only.','One flatboard, single-opponent roles, seed1/17 only; broad balance/optimality/human acceptance not established.','Mirror horizon40 is diagnostic, never a forced victory; completed-only summaries exclude active samples explicitly.'])
(w/'budget-pacing-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'traced':20,'allTracedCompleted':result['allTracedCompleted'],'baseline6ExactReplay':True,'traces':[{k:r[k] for k in ['name','round','minimumObservedMpBasisPoints']} for r in summary],'pure':pure_summary,'pureAggregate':aggregate},indent=2))
