// Observational wrappers call original shared transitions, then return the exact object unchanged.
import { appendFileSync } from 'node:fs'
import { describe, expect, it, vi } from 'vitest'
import * as ai from '@aurevane/game-core/combat/recruit-ai-build'
import * as pv from '@aurevane/game-core/combat/pv1f-action-economy'
import { createLegalRosterDuel, legalRosterCycleKits, playLegalRosterDuel } from './roster-legal-duel.test-utils'
vi.mock('server-only',()=>({}))
const evidence=process.env.AUREVANE_STALL_RECEIPTS_EVIDENCE!
if(!evidence)throw Error('Fresh evidence path required')
let transitions:unknown[]=[]
function resources(state:Parameters<typeof pv.finishPv1fTurn>[0]){
 return state.tactical.battle.combatants.map(u=>({id:u.id,hp:u.hp,maxHp:u.maxHp,mp:u.mp,maxMp:u.maxMp,ap:pv.readPv1fActionEconomy(state,u.id)!.current,statuses:state.statuses.filter(s=>s.combatantId===u.id)}))
}
const originalAction=ai.executeBuildAwareRecruitAiAction,originalMove=pv.executePv1fMovement,originalEnd=pv.finishPv1fTurn
vi.spyOn(ai,'executeBuildAwareRecruitAiAction').mockImplementation((...args)=>{
 const before=resources(args[0]),out=originalAction(...args)
 transitions.push({kind:'action',abilityId:args[1],actorId:args[0].tactical.battle.currentTurn!.combatantId,round:args[0].tactical.battle.round,before,after:resources(out.state),events:out.events})
 return out
})
vi.spyOn(pv,'executePv1fMovement').mockImplementation((...args)=>{
 const before=resources(args[0]),out=originalMove(...args)
 transitions.push({kind:'move',actorId:args[0].tactical.battle.currentTurn!.combatantId,round:args[0].tactical.battle.round,before,after:resources(out.state),events:out.events})
 return out
})
vi.spyOn(pv,'finishPv1fTurn').mockImplementation((...args)=>{
 const before=resources(args[0]),out=originalEnd(...args)
 transitions.push({kind:'end',actorId:args[0].tactical.battle.currentTurn!.combatantId,round:args[0].tactical.battle.round,before,after:resources(out.state),events:out.events})
 return out
})
const kits=legalRosterCycleKits.filter(k=>!k.secondary&&['bastion','wildwarden','dawnshield'].includes(k.primary))
describe('exact actual receipts behind active40round pure mirrors',()=>{
 it.each(kits)('$name',async(kit)=>{
  transitions=[]
  const duel=await createLegalRosterDuel({kit,level:100,context:'pvp',seed:1,board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]}})
  const result=playLegalRosterDuel(duel,{maximumRounds:40})
  expect(transitions).toHaveLength(result.commands.length)
  expect(result.errors).toEqual([])
  appendFileSync(evidence,JSON.stringify({kit:kit.name,seed:1,context:'pvp',level:100,maximumRounds:40,round:result.state.tactical.battle.round,lifecycle:result.state.tactical.battle.lifecycle,commands:result.commands,final:resources(result.state),transitions})+'\n')
 },180_000)
})
