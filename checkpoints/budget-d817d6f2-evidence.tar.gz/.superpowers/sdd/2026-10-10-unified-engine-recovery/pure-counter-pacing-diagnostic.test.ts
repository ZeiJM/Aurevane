// One-off asymmetric follow-up to three active40round mirrors; original engine/AI only.
import { appendFileSync } from 'node:fs'
import { describe, expect, it, vi } from 'vitest'
import { createLegalRosterDuel, legalRosterCycleKits, playLegalRosterDuel } from './roster-legal-duel.test-utils'
vi.mock('server-only',()=>({}))
const evidence=process.env.AUREVANE_COUNTER_PACING_EVIDENCE!
if(!evidence)throw Error('Fresh evidence path required')
const pure=legalRosterCycleKits.filter(k=>!k.secondary)
const cases=['bastion','wildwarden','dawnshield'].flatMap(id=>['vanguard','cinderweaver'].map(enemy=>({name:`${id}:vs:${enemy}`,kit:pure.find(k=>k.primary===id)!,opponentKit:pure.find(k=>k.primary===enemy)!})))
describe('actual asymmetric counter-role natural pacing, not global balance acceptance',()=>{
 it.each(cases)('$name',async({name,kit,opponentKit})=>{
  const duel=await createLegalRosterDuel({kit,opponentKit,level:100,context:'pvp',seed:1,board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]}})
  const result=playLegalRosterDuel(duel,{maximumRounds:40})
  expect(result.errors).toEqual([])
  expect(result.state.tactical.battle.lifecycle==='completed'||result.state.tactical.battle.round>40).toBe(true)
  appendFileSync(evidence,JSON.stringify({name,kit:kit.name,opponentKit:opponentKit.name,level:100,seed:1,context:'pvp',maximumRounds:40,round:result.state.tactical.battle.round,lifecycle:result.state.tactical.battle.lifecycle,final:result.state.tactical.battle.combatants.map(u=>({id:u.id,hp:u.hp,maxHp:u.maxHp,mp:u.mp,maxMp:u.maxMp})),commands:result.commands,sourceVersions:duel.participants.map(p=>({actorId:p.actorId,sources:p.sources.map(s=>({id:s.abilityId,version:s.contentVersion}))}))})+'\n')
 },180_000)
})
