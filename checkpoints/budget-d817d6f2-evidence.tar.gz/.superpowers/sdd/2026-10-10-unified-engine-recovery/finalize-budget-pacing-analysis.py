from pathlib import Path
from collections import Counter,defaultdict
import json,hashlib
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery')
a=json.loads((w/'budget-pacing-analysis.json').read_text())
pure=list(map(json.loads,(w/'pure-pacing-natural.jsonl').read_text().splitlines()))
for filename,key in [('pure-counter-pacing-natural.jsonl','ordinaryPressure'),('selected-counter-pacing-natural.jsonl','selectedCounter')]:
 rows=list(map(json.loads,(w/filename).read_text().splitlines()));assert len(rows)==6
 a[key]=[dict(name=r['name'],round=r['round'],lifecycle=r['lifecycle'],committedGuardBreak=sum(c['abilityId']=='vanguard.guard-break' for c in r['commands']),committedVitalSever=sum(c['abilityId']=='lifebinder.vital-sever' for c in r['commands'])) for r in rows]
receipts=list(map(json.loads,(w/'stall-receipts-natural.jsonl').read_text().splitlines()));assert len(receipts)==3
a['stallReceipts']=[]
for r in receipts:
 old=next(o for o in pure if o['kit']==r['kit']);assert r['commands']==old['commands']
 assert [{k:u[k] for k in ['id','hp','maxHp','mp','maxMp']} for u in r['final']]==old['final']
 assert len(r['transitions'])==len(r['commands'])
 totals=Counter();by=defaultdict(Counter)
 for t in r['transitions']:
  hpBefore=sum(u['hp'] for u in t['before']);hpAfter=sum(u['hp'] for u in t['after']);net=0
  for e in t['events']:
   kind=e['event']
   if kind in ['damage_applied','healing_applied','barrier_absorbed']:
    n=e['hpBefore']-e['hpAfter'] if kind=='damage_applied' else e['hpAfter']-e['hpBefore'] if kind=='healing_applied' else e['amount']
    totals[kind]+=n;by[e.get('actionId','')][kind]+=n
    net+=n if kind=='healing_applied' else -n if kind=='damage_applied' else 0
  assert hpAfter-hpBefore==net,(r['kit'],t['round'],hpAfter-hpBefore,net)
 assert 1000+totals['healing_applied']-totals['damage_applied']==sum(u['hp'] for u in r['final'])
 a['stallReceipts'].append(dict(kit=r['kit'],round=r['round'],lifecycle=r['lifecycle'],exactReplay=True,totals=totals,byAction=by))
records=json.loads(Path('docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json').read_text())['records']
ids=['resonance.aetherist-bastion.linked-sequence','resonance.aetherist-edgedancer.linked-sequence','resonance.chronist-runeblade.linked-sequence']
for r in records:
 if r['id'] in ids:
  for b in r['after']['ability']['behaviors']:
   n=b['requirements'];assert n['kind']=='resource-state' and n['subject']=='owner' and n['resource']=='mp'
a['selectedRequirementContextsValidated']='All traced selected pair nodes are ownerMP resource-state; omitted AP does not alter their Requirement result.'
a['limitations'].append('Stall-receipt resource snapshots contain AP/HP/MP and full actual events; optional status snapshot field is omitted (observer used nonexistent combatant.statuses). No full status-history claim. Event-origin/cost/outcome data remain exact;3 full command/final-resource replays and every-transition HP event reconciliation pass.')
for p in w.glob('*-diagnostic*.test.ts'):a['sha256'][p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
for filename in ['pure-counter-pacing-natural.jsonl','selected-counter-pacing-natural.jsonl','stall-receipts-natural.jsonl']:a['sha256'][filename]=hashlib.sha256((w/filename).read_bytes()).hexdigest()
a['counts']={'successfulDiagnosticRuns':51,'completed':42,'activeAt40':9,'note':'includes6baselineand3stallreplays;not51distinctscenariosnorbalanceacceptance;pure17table reusespriorAetheristresult'}
(w/'budget-pacing-analysis.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'pure':a['pureAggregate'],'counts':a['counts'],'stall':a['stallReceipts']},indent=2))
