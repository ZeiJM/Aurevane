import subprocess, pathlib, hashlib, json, tarfile, base64, sys

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'legal-build-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = (workspace / 'legal-build-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
assert '4097 passed (4097)' in log and '3743 passed (3743)' in log
prerequisite = '0354e2c3f849e0c0bd6ccb1f089df1519222bf31'
bundle = workspace / ('legal-build-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + prerequisite], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'legal-build-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('legal-build-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T0*.log')):
        if file.name >= '20261016T093200':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-legal-build-review.md', 'task15-legal-build-review.diff', 'task15-distinct-cycle-preflight.md', 'task15-legal-cycle-preflight.md', 'legal-build-tested-source.txt', 'legal-build-bundle-verify.log', 'save-legal-build-checkpoint.py']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

manifest = root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'tests': {'vitest': 8086, 'node': 7}, 'prerequisite': prerequisite, 'previousArchiveCommit': 'da547b4e89ead1bed8249c5ed29531eb360fdd37', 'previousArchiveTree': 'ac36a9d5a8d33c481fe8c12a6f1c3bb290e95b25', 'manifestSha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': 'Bounded legal save/load/current-pinned publication/capture and actual first AI command:306coveragebuilds x2levels x2authoritycontexts=1224combinations;312new tests. Test-only, no production/manifest change. Review0Critical/0Important/1Minor provenance fixture label deferred;prior4 carried. Seeded earned facts not actual progression awards. Pure halves coverage not new strategies. Three nativeGround paths remain native. Task15/16 distinctcycles/multiturnAI/balance/pacing/Groundcanonical/readers/browser/Owneredits-hostedCAS/Atlas remainOPEN. No hosted write, activation, merge or deployment. See committed verification report for exact boundaries and full gate counts.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
