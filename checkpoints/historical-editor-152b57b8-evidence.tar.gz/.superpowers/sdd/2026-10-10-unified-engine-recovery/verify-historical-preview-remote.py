from pathlib import Path
import subprocess,json,hashlib,tempfile
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';meta=json.loads((w/'historical-preview-backup-payload.json').read_text());archive='3aef6d8b45cc865e3d7eb4256c662eeaf1983acb'
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
assert git('rev-parse','origin/agent/overhaul-source-backup-20261016')==archive
assert git('show','-s','--format=%P',archive)==meta['parentArchive']
remote=w/'historical-preview-remote-bytes';remote.mkdir(exist_ok=True);proof=[]
for key in ['bundle','evidence','metadata','latest']:
 item=meta[key];data=subprocess.check_output(['git','show',archive+':'+item['path']]);p=remote/Path(item['path']).name;p.write_bytes(data)
 assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
 line=git('ls-tree',archive,'--',item['path']).split();assert line[:3]==['100644','blob',item['blobSha']]
 proof.append({'path':item['path'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'blobSha':line[2],'mode':line[0],'type':line[1]})
restored=Path(tempfile.mkdtemp(prefix='historical-preview-restored-',dir=w));subprocess.run(['git','init','--bare',str(restored)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
subprocess.run(['git','-C',str(restored),'fetch','--depth=1',str(root),meta['prerequisite']],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
assert subprocess.run(['git','-C',str(restored),'cat-file','-e',meta['source']+'^{commit}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE).returncode!=0
bundle=remote/Path(meta['bundle']['path']).name
for op in ['verify','unbundle']:
 r=subprocess.run(['git','-C',str(restored),'bundle',op,str(bundle)],check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(w/('historical-preview-remote-bundle-'+op+'.log')).write_text(r.stdout)
assert subprocess.check_output(['git','-C',str(restored),'rev-parse',meta['source']+'^{tree}'],text=True).strip()==meta['tree']
refs=git('ls-remote','origin','refs/heads/main','refs/heads/agent/overhaul-source-backup-20261016');assert archive+'\trefs/heads/agent/overhaul-source-backup-20261016' in refs and meta['mainUnchanged']+'\trefs/heads/main' in refs
p={'source':meta['source'],'sourceTree':meta['tree'],'testedSource':meta['testedSource'],'archive':archive,'archiveTree':git('rev-parse',archive+'^{tree}'),'archiveParent':meta['parentArchive'],'allFourRemoteBytesAndModesVerified':True,'entries':proof,'incrementalRestore':{'prerequisite':meta['prerequisite'],'destination':str(restored),'sourceTipAbsentBeforeUnbundle':True,'restoredSourceTipAndTreeVerified':True,'coldOlderArchiveChainRestoration':False},'freshLsRemoteMatches':True,'mainUnchanged':meta['mainUnchanged'],'binaryConnectorLimitation':'GitHub fetch/fetch_blob refuse binary UTF-8; verified remote Git objects through authenticated fetch/show instead.'}
(w/'historical-preview-remote-proof.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(p))
