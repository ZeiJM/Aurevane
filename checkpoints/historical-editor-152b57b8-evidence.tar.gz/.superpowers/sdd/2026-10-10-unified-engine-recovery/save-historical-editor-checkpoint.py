from pathlib import Path
import subprocess,json,hashlib,tarfile,base64,re,datetime
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';prefix='historical-editor'
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/(prefix+'-tested-source.txt')).read_text().strip();reviewed=(w/(prefix+'-reviewed-source.txt')).read_text().strip();base='06d489988cd8571d40c81dd58525457ac6319d75'
report='docs/verification/2026-10-16-historical-resonance-editor.md'
assert git('diff','--name-only',tested,head).splitlines()==[report]
assert set(git('diff','--name-only',base,head).splitlines())=={report,
 *['apps/web/src/components/master/combat-content/'+n for n in ['combat-content-review-panel.tsx','combat-content-workflow.ts','resonance-content-editor.tsx','resonance-preview-interaction.test.tsx','historical-resonance-sample.tsx','historical-resonance-sample.module.css']],
 'apps/web/src/server/master/master-resonance-preview.test.tsx'}
subprocess.run(['git','merge-base','--is-ancestor',reviewed,tested],check=True)
audit=json.loads((w/(prefix+'-fullcheck-audit.json')).read_text());gate=audit['receipt'];s=Path(gate['log']).read_text();expected=int((w/(prefix+'-test-count.txt')).read_text())
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',s)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==expected
assert datetime.datetime.fromisoformat(gate['started_utc'])>=datetime.datetime.fromisoformat(git('show','-s','--format=%cI',tested))
assert 'ℹ pass 7' in s and 'ℹ fail 0' in s and audit['source']==tested
assert '$ turbo run build' in s and '2 successful, 2 total' in s.rsplit('$ turbo run build',1)[-1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest
assert sha(w/(prefix+'-legacy-observation.json'))=='49050e22e414dd9ada6e16f69e809170c09b8b0dab2f57b915dd44bf337b3127'
assert sha(w/(prefix+'-actions-observation.json'))=='8b513e1284d6275fd410f405aead301ecf589748e12c8e9e68068295d1a43cfc'
preserve=json.loads((w/(prefix+'-preservation.json')).read_text());assert preserve['source']==tested and preserve['allReportsAndHtmlExactlyUnchanged'] and preserve['records']==294
stem=prefix+'-'+head[:8];bundle=w/(stem+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(w/(prefix+'-bundle-verify.log')).write_text(v.stdout)
evidence=w/(stem+'-evidence.tar.gz')
names=[p for p in w.glob('*historical*') if p.is_file() and p.suffix not in ['.gz','.bundle'] and p.name not in [prefix+'-backup-payload.json']]
names += [w/'progress.md',w/'verification.jsonl',w/'run.py',w/'ranged-ai-analysis.json',w/'modifier-preview-reader-observation.json']
with tarfile.open(evidence,'w:gz') as a:
 for p in names:a.add(p,arcname=str(p.relative_to(root)))
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T234552':a.add(p,arcname=str(p.relative_to(root)))
 for suffix in ['-turbo-logs.tar.gz','-initial-turbo-logs.tar.gz','-repair-initial-turbo-logs.tar.gz']:
  if (w/(prefix+suffix)).exists(): a.add(w/(prefix+suffix),arcname=str((w/(prefix+suffix)).relative_to(root)))
def item(p,remote):
 b=p.read_bytes();return {'local':str(p),'path':remote,'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
d={'source':head,'tree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedSource':reviewed,'prerequisite':base,'parentArchive':'3aef6d8b45cc865e3d7eb4256c662eeaf1983acb','parentTree':'507a2ee57bd58ce8ff61906337754a6feeaddca0','mainUnchanged':'29506e293e81abef1b0b8a46099618ab3ae3f0ae','fullCheckReceipt':gate,'tests':{'vitest':expected,'node':7},'preservation':preserve,'acceptance':(w/(prefix+'-checkpoint-summary.txt')).read_text().strip(),'bundle':item(bundle,'checkpoints/'+stem+'.bundle'),'evidence':item(evidence,'checkpoints/'+stem+'-evidence.tar.gz')}
meta=w/(stem+'.json');meta.write_text(json.dumps(d,indent=2)+'\n');latest=w/(prefix+'-LATEST.txt');latest.write_text('Aurevane historical Resonance backend preview checkpoint\nSource '+head+'\nTested '+tested+'\nMetadata checkpoints/'+stem+'.json\n'+d['acceptance']+'\n')
d['metadata']=item(meta,'checkpoints/'+stem+'.json');d['latest']=item(latest,'LATEST.txt');(w/(prefix+'-backup-payload.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k not in ['preservation','acceptance']}))
