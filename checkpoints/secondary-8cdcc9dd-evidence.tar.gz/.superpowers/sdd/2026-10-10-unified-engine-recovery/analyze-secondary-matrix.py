from pathlib import Path
import hashlib,json,collections
w=Path(__file__).resolve().parent
raw=w/'secondary-restored-289.jsonl';gold=w/'ranged-ai-final-matrix.jsonl'
assert hashlib.sha256(gold.read_bytes()).hexdigest()=='d60cb8110a8ad3f74342c52fbaf368c2c52aa04c6e44f22d0fd1dfcdd6cba280'
rows=[json.loads(s) for s in raw.read_text().splitlines()]
prior=[json.loads(s) for s in gold.read_text().splitlines()]
assert len(rows)==len(prior)==289
bykit={r['kit']:r for r in rows};baseline={r['kit']:r for r in prior}
assert len(bykit)==289 and bykit.keys()==baseline.keys()
assert sum(r['secondary'] is None for r in rows)==17
assert sum(r['secondary'] is not None for r in rows)==272
assert all(r['maximumRounds']==4 and r['actualRound']==5 and r['lifecycle']=='active' for r in rows)
for r in rows:
 assert r['commands']==baseline[r['kit']]['commands'],r['kit']
 assert r==baseline[r['kit']],r['kit']
 sources={actor['actorId']:actor['sources'] for actor in r['sourceVersions']}
 for c in r['combatants']:
  assert c['id'] in sources and 0<=c['hp']<=c['maxHp'] and 0<=c['mp']<=c['maxMp']
 for c in r['commands']:
  assert c['actorId'] in sources and 1<=c['round']<=4
  if c['kind']=='face':
   assert c['abilityId']=='face'
  else:
   ability={'basic.attack.unarmed.basic':'unarmed.basic','move':'basic.move'}.get(c['abilityId'],c['abilityId'])
   assert ability in {s['abilityId'] for s in sources[c['actorId']]},(r['kit'],c)
 for actor,saved in sources.items():
  for s in saved:
   assert actor in s['sourceInstanceId'] and s['contentVersion']>=1
unchanged={}
for rel,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():
 actual=hashlib.sha256((w.parents[2]/rel).read_bytes()).hexdigest()
 assert actual==digest,rel
 unchanged[rel]=actual
out={'source':(w/'secondary-tested-source.txt').read_text().strip(),'rawSha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'goldSha256':hashlib.sha256(gold.read_bytes()).hexdigest(),'records':289,'pure':17,'orderedMixed':272,'commands':sum(len(r['commands']) for r in rows),'allCommandArraysIdentical':True,'allCompleteRowsIdentical':True,'allFourRoundsPlayed':True,'allActiveAtRoundFive':True,'resourcesVersionsOwnershipVerified':True,'sourceHashes':unchanged,'scope':'Same fixed four-round Level100 PvP roster benchmark and seed as gold. This verifies unchanged constant outcomes; not natural pacing, twelve-round balance, human acceptance or release.'}
(w/'secondary-matrix-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='sourceHashes'}))
