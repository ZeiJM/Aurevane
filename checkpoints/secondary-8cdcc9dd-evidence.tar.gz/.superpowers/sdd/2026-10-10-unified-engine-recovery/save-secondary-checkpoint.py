import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'secondary-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'secondary-tested-source.txt').read_text().strip();base='5e047d597cda9eabb1e1cc60d1586c49af422477'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==12 and all(p.startswith(('apps/web/src/components/character/','packages/game-core/')) or p=='docs/verification/2026-10-16-secondary-status-reader-facts.md' for p in paths),paths
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8347,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
matrix=next(r for r in reversed(receipts) if r['argv']==['pnpm','--filter','@aurevane/web','exec','vitest','run','src/server/battle/roster-legal-duel-matrix.test.ts'])
assert matrix['exit_code']==0 and matrix['started_utc']>='2026-10-16T15:24:00'
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'secondary-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['changedFromStandardStatus']==17 and observed['changedFromOriginal']==341 and observed['rawSha256']==sha(w/'secondary-reader-observation.json')
comparison=json.loads((w/'secondary-matrix-analysis.json').read_text());assert comparison['source']==tested and comparison['records']==289 and comparison['commands']==8219 and comparison['allCompleteRowsIdentical'] and comparison['rawSha256']==sha(w/'secondary-restored-289.jsonl')
bundle=w/('secondary-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'secondary-bundle-verify.log').write_text(v.stdout)
evidence=w/('secondary-'+head[:8]+'-evidence.tar.gz')
names=['progress.md','task-15-brief.md','task15-secondary-status-brief.md','task15-secondary-status-next-brief.md','secondary-review-rulings.md','task15-secondary-status-review.md','secondary-tested-source.txt','secondary-bundle-verify.log','verification.jsonl','run.py','save-secondary-checkpoint.py','finalize-secondary-report.py','secondary-readers-diagnostic.test.tsx','vitest-secondary-reader.config.ts','secondary-reader-observation.json','secondary-reader-analysis.json','analyze-secondary-readers.py','secondary-remaining-numeric-candidates.json','secondary-history-inventory.test.ts','vitest-secondary-history.config.ts','secondary-historical-reader-inventory.json','secondary-status-289.jsonl','secondary-restored-289.jsonl','secondary-matrix-analysis.json','analyze-secondary-matrix.py','workspace-recovery-20261016.json','airborne-entry-probe.test.ts','task15-dot-ground-reader-preflight.md','dot-ground-reader-preflight.test.tsx','edited-status-potency-preflight.test.tsx','vitest-edited-status-preflight.config.ts','vitest-dot-ground-preflight.config.ts','secondary-fullcheck-audit.json','secondary-turbo-logs.tar.gz']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T145700':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'prerequisite':base,'previousArchiveCommit':'c28844e3e8abe0a31d72b7fed0a19f615b6d315c','previousArchiveTree':'658d64a8d3389189c24f20951c57e7bb028dcdd9','fullCheckReceipt':gate,'matrixReceipt':matrix,'tests':{'vitest':8347,'node':7},'matrix':comparison,'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':'Seventeen secondary status effects retain structured native/captured values and plain prose. Review0C1I fixed Blindside expiry through nine valid RED then22/22GREEN;772 covering. Frozen restored source8347Vitest+7Node verified. All294 shared-reader SSR;17new/341total prose changes. Fresh289 builds8219commands and complete rows exactly identical to prior gold; no AI or mechanics/balance change. Automated maintenance recovery from verified Git backups and three exact reviewer-retained files; new source identity does not claim420b exact restoration. Nine prior Minors deferred;58 individual declined-scope rulings plus reproduced inherited edited-status Important retained for next pass before release. Original combat/native/editorial/fullcycles/balance/Ownerhosted/Atlas/human/release and broader Master remain open. No publication/activation/migration/merge/deploy.'}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k not in ('matrix','readerAudit')}))
