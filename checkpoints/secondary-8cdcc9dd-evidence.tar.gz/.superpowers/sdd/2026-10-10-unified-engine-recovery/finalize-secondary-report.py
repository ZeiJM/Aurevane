from pathlib import Path
import json,re,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
tested=(w/'secondary-tested-source.txt').read_text().strip()
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
assert gate['exit_code']==0
text=Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',text)
assert len(counts)==7 and sum(int(n) for _,n in counts)==8347 and 'ℹ pass 7' in text
matrix=json.loads((w/'secondary-matrix-analysis.json').read_text())
assert matrix['source']==tested and matrix['records']==289 and matrix['allCompleteRowsIdentical']
reader=json.loads((w/'secondary-reader-analysis.json').read_text())
p=root/'docs/verification/2026-10-16-secondary-status-reader-facts.md'
s="""# Secondary status reader facts — bounded checkpoint verified

Seventeen current effects now keep secondary values in structured public facts before shortening prose: Airborne2, Blindside5, Haste4 and Drenched6. Historical policy flags, exact captured multipliers/potencies, input immutability and public projection remain preserved. Four temporary current-equals-raw protections are replaced with actual pinned noncanonical historical SkillDetails witnesses (Breakfallv5, Backstabv5, Hastev4, WaterLancev7), including their complete actual preview explanation and version.

Airborne shares native Jump3/Attack Target Elevation3, retaining Basic Attack limits, Ground immunity and movement restrictions. Blindside shares front100% and exact captured side/rear multipliers. Haste shares the actual10AP movement floor. Drenched shares the unchanged ten-application Initiative ceiling/divisor, independently of captured Storm potency. Existing values/arithmetic, accepted definitions, prices, AI and historical execution are unchanged. The elemental clock extraction preserves the earlier deferred singular grammar Minor.

The original bounded review found0Critical/1Important/0newMinor. Parent accepts and fixes the missing Blindside expiry boundary in one RED→GREEN wave: instant/Controlled counts recipient turn ends from activation, including the recipient’s current turn; supported Normal/Delayed wrappers retain their full-round clock. Native scheduling is unchanged. Nine previous Minors remain deferred. A separately reproduced inherited issue remains for the next reader/editor integration pass before release: a real Guard→Airborne edit retains unused potency metadata and displays15% despite native Airborne ignoring it. Current seventeen proposed payloads lack this metadata. This is a known follow-up, not a claim of universal reader/editor acceptance.

Automated workspace maintenance removed source, Git metadata and dependencies during original420b2423 verification. The original full check and288-row replay were interrupted and are not accepted. Recovery cloned verified archivec28844e3 and imported26 preserved source bundles through5e047d59, restoring2,951 missing files without overwriting existing files. The reviewer returned exact retained copies of the two new helpers and13-case test; remaining small edits were restored from the recorded diff/contract. New tested sourcefc170382 is independently verified below and is not claimed byte-identical to420b2423. Frozen-lock dependency restoration passed supply-chain checks.

Original Targeting/Move/editable five Basics/Controlled/native controls, all editor-preview-popup surfaces, distinct legal cycles, natural pacing/twelve-round balance, fresh Owner edits, hosted authority/CAS, Atlas and human acceptance remain open. Broader Master panels remain after the combat package. No publication, activation, hosted migration, merge or deployment.
"""
s+='''\n## Final exact-source evidence

'''+f'''Frozen restored source `{tested}` passes the complete project gate: **8,347 Vitest plus seven Node checks** (4,136core,3,965web,246other), formatting, lint, eight typechecks and two builds. Original completed root run152433565570 (15:24:33–15:30:39UTC) had truncated root stdout; preserved package logs reconcile all counts. One cached exact-source root replay153107936970 (15:31:07–15:31:44UTC) produces the complete direct summary. No source change or further broad repeats. Final covering772/9GREEN152433574453 includes22 secondary cases (13 restored plus9 expiry regressions). The nine expiry cases fail on the restored reviewed reader at152256034081, then pass in the final covering suite; the preceding unsupported-duration fixture attempt is retained as an error, not claimed regression evidence.

All294 static shared-reader observation152450947555 passes:297groups604effects,17new secondary explanations,341changed263unchanged from the original, and inputimmutability/ten-row contracts retained. RawSHA256 `{reader['rawSha256']}`.182numeric explanations, eleven excluding directDamage/Pierce plus four separate Pierce equipment-Armor candidates; these counts are inventories, not complete style/semantic acceptance.

Fresh explicit289 matrix passes on the same source:17pure+272orderedmixed Level100PvP builds, seed12345, four rounds played and all remain active at round5. All**8,219commands**, every commandarray, complete final resources, sourceversions, ownership and entire recorded rows match the prior verified0cf9f9c3 gold exactly. RawSHA256 `{matrix['rawSha256']}`, previous gold `{matrix['goldSha256']}`. Planner, six AI/fixture source hashes and accepted manifest are unchanged. This proves the constant extraction preserves the fixed benchmark, not broader strategic quality, natural pacing, complete distinct cycles or twelve-round roster balance.

The next Burn/Poison/Ground preflight is outside the routine suite: three valid RED cases153026555857 demonstrate missing structured secondary facts, with no next production change made during this frozen verification. It remains planned work and is not part of the completed gate.

## Parent review rulings and deferred Minors

'''+(w/'secondary-review-rulings.md').read_text()
p.write_text(s)
with (w/'progress.md').open('a') as f:f.write(f'\nSecondary boundedcheckpoint final: tested{tested} complete8347Vitest+7Node cachedroot153107936970;772covering;all294SSR17new/341originalchanged;explicit289/8219commands/complete rows identicalgold{matrix["goldSha256"]}. Review0C1IexpiryfixedsingleREDGREENwave,0newMinor,9priorMinorsdefer.59individualparentrulings(58declines+inheritedmetadatafollowup)retained. Next3REDoutsideSRCpreflight, no newproductionedits. NoallTask15/releaseacceptance. Finaldocs-onlycommit+exactbackupnext.\n')
print('Final report and ledger prepared after actual gates; source unchanged.')
