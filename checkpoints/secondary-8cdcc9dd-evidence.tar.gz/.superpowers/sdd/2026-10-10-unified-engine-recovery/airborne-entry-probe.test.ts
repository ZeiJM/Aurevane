import { airborneDescription, AIRBORNE_JUMP } from '/workspace/scratch/680b26e4eb86/aurevane/packages/game-core/src/combat/combat-airborne'
import { expect, it } from 'vitest'

it('loads the public Airborne module before the rest of combat authority', () => {
  expect(AIRBORNE_JUMP).toBe(3)
  expect(airborneDescription()).toContain('Your Jump is 3')
  expect(airborneDescription(true)).not.toContain('Ground-targeted Skills')
})
