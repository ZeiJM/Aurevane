import { writeFileSync } from 'node:fs'
import { expect, it } from 'vitest'
import { latestEnabledMatureSkills } from '@aurevane/game-core/combat/mature-skills'
it('locates actual older noncanonical secondary-status readers',()=>{
 const skills=latestEnabledMatureSkills()
 const records=Object.fromEntries(['airborne','blindside','haste','wet'].map(statusId=>[statusId,skills.filter(s=>!s.ability&&s.effects.some(e=>e.type==='apply-status'&&e.statusId===statusId)).map(s=>({id:s.id,contentVersion:s.contentVersion,effects:s.effects.filter(e=>e.type==='apply-status'&&e.statusId===statusId)}))]))
 expect(Object.values(records).every(rows=>rows.length>0)).toBe(true)
 writeFileSync('/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/secondary-historical-reader-inventory.json',JSON.stringify(records,null,2)+'\n')
})
