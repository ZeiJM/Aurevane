import { readFileSync } from 'node:fs'
import { renderToStaticMarkup } from 'react-dom/server'
import { expect, it } from 'vitest'
import { parseAbilityDefinition } from '@aurevane/game-core/combat/combat-definition'
import { projectPublicCombat } from '@aurevane/game-core/combat/public-combat-presentation'
import { abilityBehaviorInformation } from '@/components/character/ability-detail-presentation'
import { AbilityDefinitionParameters } from '@/components/character/ability-definition-parameters'
const root = '/workspace/scratch/680b26e4eb86/aurevane'
const rows = JSON.parse(readFileSync(root + '/docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json', 'utf8')).records
// Fails if the actual shared reader leaves these secondary rules only in prose.
// This preflight remains outside the routine suite until the next bounded cohort.
it.each(['burn', 'poison', 'create-terrain'])(
  'keeps every actual %s secondary rule structured in the public reader',
  (type) => {
    let count = 0
    for (const row of rows) {
      const definition = parseAbilityDefinition(row.after.ability)
      const before = JSON.stringify(definition)
      for (const group of definition.behaviors) {
        const report = abilityBehaviorInformation(group)
        for (const [index, effect] of group.effects.entries()) {
          if (effect.payload.type !== type) continue
          count++
          const facts = type === 'burn'
            ? [
                { label: 'Backlash', value: '10% own hostile HP damage' },
                { label: 'Backlash allowance', value: 'Once per turn' },
              ]
            : type === 'poison'
              ? [
                  { label: 'Refresh', value: 'Every 5 traversed tiles' },
                  { label: 'Refresh duration', value: 'Captured full duration' },
                  { label: 'Extra damage on refresh', value: 'None' },
                ]
              : [
                  { label: 'Movement surcharge', value: '+10 AP per entered tile' },
                  { label: 'Affected units', value: 'Caster’s enemies' },
                ]
          expect(report.effects[index]!.parts.details).toEqual(expect.arrayContaining(facts))
          if (type === 'create-terrain')
            expect(report.effects[index]!.parts.duration).toBe('2 global round boundaries')
          const html = renderToStaticMarkup(<AbilityDefinitionParameters definition={projectPublicCombat({ schemaVersion: 1, behaviors: [group] })} />)
          for (const { label, value } of facts) expect(html).toContain(`[${label}: ${value}]`)
        }
      }
      expect(JSON.stringify(definition)).toBe(before)
    }
    expect(count).toBe({ burn: 7, poison: 2, 'create-terrain': 1 }[type])
  },
)
