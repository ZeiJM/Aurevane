# Secondary reader combined-review rulings

Original bounded review5e047d59..420b2423:0Critical/1Important/0newMinor. Parent accepts Important, Blindside expiry. Exact two helpers/13-case test recovered from retained reviewer source; restored sourcefc170382 is independently reverified, not claimed byte-identical420b. No rereview. One C/I correction wave: supported duration1 fixtures nine RED152256034081; final covering772/9 GREEN152433574453. Native unchanged. Nine prior Minors remain deferred.

Final: Ruling: Stale-browser revocation — No authority-path execution; retain authority gate — Cost if wrong: A revoked browser may remain unverified.

Final: Ruling: Alternate selected-character binding — No selected-character authorization exercise — Cost if wrong: Wrong-character authority may remain unverified.

Final: Ruling: Direct RPC expiry — No protected RPC call — Cost if wrong: A direct-call expiry defect may remain.

Final: Ruling: Direct RPC CAS — No concurrency-authority exercise — Cost if wrong: A concurrency defect may remain.

Final: Ruling: Malformed nested definitions — Valid readers do not replace parser rejection tests — Cost if wrong: Malformed definitions may remain unverified.

Final: Ruling: Malformed captures — No new capture rejection evidence — Cost if wrong: Invalid captures may remain unverified.

Final: Ruling: Malformed pending packets — No pending-data rejection evidence — Cost if wrong: Invalid pending data may remain unverified.

Final: Ruling: Malformed summons — No summon validation exercise — Cost if wrong: Malformed summons may remain unverified.

Final: Ruling: Recursive private-accuracy confidentiality — Selected public SSR is narrower than all transports — Cost if wrong: Another transport could expose private data.

Final: Ruling: Every immutable historical consumer — Four pinned witnesses are narrower — Cost if wrong: Another historical consumer may remain wrong.

Final: Ruling: No-input/timeout execution — No scheduler exercise — Cost if wrong: Timeout behavior may remain unverified.

Final: Ruling: Free priming bounds — Instructions are not execution evidence — Cost if wrong: A prime allowance defect may remain.

Final: Ruling: Repeated-event bounds — No event-budget exercise — Cost if wrong: An event loop may remain unverified.

Final: Ruling: Duplicate payment — No complete payment-path acceptance — Cost if wrong: Duplicate payment may remain unverified.

Final: Ruling: Extra-turn prevention — No turn-economy exercise — Cost if wrong: An extra-turn path may remain unverified.

Final: Ruling: Interrupted Move — No reached-origin execution witness — Cost if wrong: An origin defect may remain unverified.

Final: Ruling: Concurrent publication — No publication race or rollback exercise — Cost if wrong: Publication races may remain.

Final: Ruling: Concurrent build writes — No build-write race — Cost if wrong: Concurrent build incoherence may remain.

Final: Ruling: Concurrent claims — No idempotency race — Cost if wrong: Duplicate claims may remain.

Final: Ruling: Concurrent recovery — No late-worker recovery exercise — Cost if wrong: Recovery races may remain.

Final: Ruling: Concurrent settlement — No settlement race — Cost if wrong: Settlement races may remain.

Final: Ruling: Hosted locks/retry/no-contest — No hosted database acceptance — Cost if wrong: Database-only integrity defects may remain.

Final: Ruling: Long-name layout — SSR does not establish geometry — Cost if wrong: Long names may overflow.

Final: Ruling: Missing metadata across every reader — Selected historical cases are narrower — Cost if wrong: Other fallbacks may remain misleading.

Final: Ruling: Native keyboard/focus — No physical focus/dismissal exercise — Cost if wrong: Keyboard usability may remain inadequate.

Final: Ruling: Touch/mobile — No native device interaction — Cost if wrong: Touch controls may remain inaccessible.

Final: Ruling: 200% zoom — No actual zoom geometry — Cost if wrong: Zoom layout may remain inadequate.

Final: Ruling: Contrast/overflow — No physical visual acceptance — Cost if wrong: Visual accessibility may remain inadequate.

Final: Ruling: Native Targeting — Keep original combat integration gate — Cost if wrong: Targeting may remain unfinished.

Final: Ruling: Native Move controls — Keep original movement interaction gate — Cost if wrong: Movement gestures may remain unfinished.

Final: Ruling: Editable five Basics — No complete native edited-Basic acceptance — Cost if wrong: An edited Basic may remain misrepresented.

Final: Ruling: Controlled prime/release/cancel — Retained instructions do not close native acceptance — Cost if wrong: A native release/cancel path may remain wrong.

Final: Ruling: Rewind anchors/history — No complete Rewind interaction proof — Cost if wrong: Anchor/history paths may remain unverified.

Final: Ruling: Every editor/preview/popup — Shared adapters are narrower than all mounted surfaces — Cost if wrong: Another consumer may remain stale.

Final: Ruling: Burn backlash presentation — Separate next secondary-fact cohort — Cost if wrong: Backlash may remain repetitive or incomplete.

Final: Ruling: Poison movement-refresh presentation — Separate next secondary-fact cohort — Cost if wrong: Movement refresh may remain poorly presented.

Final: Ruling: Frozen Ground presentation — Separate next secondary-fact cohort — Cost if wrong: Ground facts may remain repetitive or incomplete.

Final: Ruling: All294 prose quality — Static observation supplements semantic review — Cost if wrong: Other explanations may remain incomplete.

Final: Ruling: Orange references/links — No complete appearance/interaction audit — Cost if wrong: References may remain visually inconsistent.

Final: Ruling: Active lifetime through expiry — Reader review is not elemental expiry execution — Cost if wrong: An expiry defect may remain unverified.

Final: Ruling: Learned-build admission — No complete admission exercise — Cost if wrong: A legal build may remain ineffective.

Final: Ruling: Canonical Requirements — Packet/reader evidence is narrower — Cost if wrong: Prerequisite opportunities may remain unverified.

Final: Ruling: Full distinct legal cycles — Readable facts do not establish gameplay cycles — Cost if wrong: A setup/payoff cycle may remain ineffective.

Final: Ruling: Fresh explicit289 build replay — Require actual final restored-source output; interrupted288 is not accepted — Cost if wrong: Roster regressions could be missed.

Final: Ruling: Exact command-array comparison — Require all289 arrays against prior gold — Cost if wrong: A native outcome change could be missed.

Final: Ruling: AI strategic quality — Deterministic replay is narrower than strategic quality — Cost if wrong: AI planning weakness may remain.

Final: Ruling: Natural pacing — No new balance experiment — Cost if wrong: Sustain stalls may remain.

Final: Ruling: Twelve-round balance — Keep original full benchmark — Cost if wrong: Broader pacing may remain outside target.

Final: Ruling: Current Owner edits — Require fresh release-time reconciliation — Cost if wrong: Publication could overwrite newer edits.

Final: Ruling: Atlas — Keep existing motion bound and acceptance gate — Cost if wrong: Motion acceptance remains unresolved.

Final: Ruling: Human gameplay — Require actual human acceptance — Cost if wrong: Gameplay feel may remain unmet.

Final: Ruling: Frozen full-root check — Require actual completed restored-source receipt — Cost if wrong: Unchecked regressions could be accepted.

Final: Ruling: Publication — None authorized here — Cost if wrong: Premature publication could bypass gates.

Final: Ruling: Activation — None performed — Cost if wrong: Premature activation could bypass gates.

Final: Ruling: Migration application — None performed — Cost if wrong: Hosted data could change before acceptance.

Final: Ruling: Merge — None performed — Cost if wrong: Unaccepted work could enter main.

Final: Ruling: Deployment — None performed — Cost if wrong: Unaccepted work could be released.

Final: Ruling: Broader Master panels — Retain after combat package — Cost if wrong: Broader panel work remains unfinished until that stage.

Final: Ruling: inherited unused non-potency percentage metadata — The reviewer did not establish normal authoring exposure. Parent later traced SkillEffectEditor and reproduced a real Guard→Airborne status-ID edit at153707157289: unused1500basispoints survives, canonical parser accepts it, native Airborne ignores it and the reader incorrectly displays15%. Parent grades this an inherited Important for the next reader/editor integration pass before publication; current seventeen records lack it, so it is not a newly introduced cohort regression. Preserve the completed single expiry fix wave and record this separate reproduced next-pass failure — Cost if deferred through release: a legitimate edited status can advertise an irrelevant percentage.

Deferred Minors, unchanged: Rewind origin witness; Supporting Shot version pin; Ongoing pair identity pin; repeated bounded AI discovery; admission provenance prefix; ranged negative direct-commit witness; defense event/HP reconciliation; Arsenal complete label/exact historical-value hardening; singular elemental duration grammar.
