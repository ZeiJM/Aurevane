from pathlib import Path
import json,hashlib,re,collections
w=Path(__file__).resolve().parent

def flatten(name):
 data=json.loads((w/name).read_text());out={}
 for row in data['records']:
  for group,report in zip(row['groups'],row['reports'],strict=True):
   for e,desc in zip(group['effects'],report['effectDescriptions'],strict=True):
    key=(row['id'],group['id'],e['id']);assert key not in out
    out[key]={'description':desc,'type':e['type'],'recipient':e['recipient']}
 return data,out
now,entries=flatten('secondary-reader-observation.json')
original,old=flatten('editorial-readers-observation.json')
prior,previous=flatten('status-reader-observation.json')
assert entries.keys()==old.keys()==previous.keys()
new=[k for k,v in entries.items() if v['description']!=previous[k]['description']]
changed=[k for k,v in entries.items() if v['description']!=old[k]['description']]
numeric=[{'record':k[0],'group':k[1],'effect':k[2],**v} for k,v in entries.items() if re.search(r'\d',v['description'])]
assert len(now['records'])==294 and len(entries)==604 and len(new)==17 and len(changed)==341
result={'source':now['source'],'rawSha256':hashlib.sha256((w/'secondary-reader-observation.json').read_bytes()).hexdigest(),'records':294,'groups':sum(len(r['groups']) for r in now['records']),'effects':604,'changedFromOriginal':len(changed),'unchangedFromOriginal':604-len(changed),'changedFromStandardStatus':len(new),'changedFromStandardByType':dict(collections.Counter(entries[k]['type'] for k in new)),'withDigits':len(numeric),'nonDirectDamageWithDigits':sum(x['type'] not in ('damage','pierce') for x in numeric),'pierceArmorNumericCandidates':sum(x['type']=='pierce' for x in numeric),'nonDamagePayloadWithDigits':sum(x['type']!='damage' for x in numeric),'scope':'Static shared readers. Numeric candidates are not proven semantic/style failures. No native, complete editorial or release acceptance.'}
(w/'secondary-reader-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
(w/'secondary-remaining-numeric-candidates.json').write_text(json.dumps([x for x in numeric if x['type'] not in ('damage','pierce')],indent=2)+'\n')
print(json.dumps(result))
for x in numeric:
 if x['type'] not in ('damage','pierce'):print(x['record'],x['type'],x['description'][:240])
