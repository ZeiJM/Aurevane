import { readFileSync } from 'node:fs'
import { isValidElement, type ReactNode, type ReactElement } from 'react'
import { expect, it } from 'vitest'
import { parseAbilityDefinition } from '@aurevane/game-core/combat/combat-definition'
import type { CombatEffectDefinition } from '@aurevane/game-core/combat/actions'
import { SkillEffectEditor } from '@/components/master/combat-content/skill-effect-editor'
import { abilityBehaviorInformation } from '@/components/character/ability-detail-presentation'
const root = '/workspace/scratch/680b26e4eb86/aurevane'
const base = JSON.parse(readFileSync(root + '/docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json', 'utf8')).records.find((r: {id: string}) => r.id === 'vanguard.brace').after.ability.behaviors[0]
function findStatusInput(node: ReactNode): ReactElement<{ 'aria-label': string; onChange: (event: { currentTarget: {value: string} }) => void }> | null {
  if (Array.isArray(node)) {
    for (const child of node) { const result = findStatusInput(child); if (result) return result }
  }
  if (!isValidElement<{ 'aria-label'?: string; children?: ReactNode }>(node)) return null
  if (node.props['aria-label'] === 'Status ID') return node as ReturnType<typeof findStatusInput>
  return findStatusInput(node.props.children)
}
it('does not invent potency percentages after a real Master status-ID edit', () => {
  for (const statusId of ['airborne', 'root', 'covert', 'invisible', 'frozen']) {
    const original: CombatEffectDefinition = { type: 'apply-status', recipient: 'actor', statusId: 'guarded', durationTurns: 2, stacks: 1, potencyBasisPoints: 1500 }
    const before = JSON.stringify(original)
    let edited: CombatEffectDefinition | undefined
    const input = findStatusInput(SkillEffectEditor({ value: original, onChange: value => { edited = value } }))
    expect(input).not.toBeNull()
    input!.props.onChange({ currentTarget: { value: statusId } })
    expect(edited).toMatchObject({ statusId, potencyBasisPoints: 1500 })
    const definition = parseAbilityDefinition({ schemaVersion: 1, behaviors: [{ ...base, effects: [{ id: 'edited', payload: edited, timing: 'instant' }] }] })
    expect(abilityBehaviorInformation(definition.behaviors[0]!).effects[0]!.parts.magnitude).toBeNull()
    expect(JSON.stringify(original)).toBe(before)
  }
})
