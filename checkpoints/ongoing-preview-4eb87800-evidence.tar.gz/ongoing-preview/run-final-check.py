import datetime,json,os,pathlib,signal,subprocess
w=pathlib.Path.cwd()/'.superpowers/sdd/2026-10-16-ongoing-preview'
log=w/'final-check.log';receipt=w/'final-check.json'
argv=['corepack','pnpm@11.17.0','--reporter=append-only','check']
env={**os.environ,'TURBO_TELEMETRY_DISABLED':'1','NEXT_TELEMETRY_DISABLED':'1','DO_NOT_TRACK':'1'}
record={'argv':argv,'cwd':str(pathlib.Path.cwd()),'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'log':str(log)}
with log.open('w') as out:
 p=subprocess.Popen(argv,stdout=out,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 try:record['exit_code']=p.wait(timeout=300)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM);record['exit_code']=p.wait();record['timeout']=True
record['completed']=datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
raise SystemExit(record['exit_code'])
