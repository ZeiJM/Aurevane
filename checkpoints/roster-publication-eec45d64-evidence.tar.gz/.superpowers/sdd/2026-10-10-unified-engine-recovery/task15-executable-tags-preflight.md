# Next bounded Task15 work: executable registry-to-roster coverage

Read-only preflight after publication-boundary source efb6fd33. No new acceptance claim.

Existing design coverage has19registry effect IDs,26runtime status classifications (24authored plus Lowered Guard system rule and Displaced historical-only),8Requirement kinds and4selected activation/mode combinations. roster-design-manifest.test.ts verifies registry equality and resolves typed witness paths; this proves selected definitions contain real payloads, not that each promised observable outcome executes. Do not relabel these tests as full executable coverage.

The separate roster-design-outcomes.test.ts executes genuine selected proposed mechanics through capture/prepare/commit/current stat bridge, including finite/no-input reactions, Move/cost, Controlled/cooldown and real recovery/removal. The older candidate-outcomes report explicitly covers41candidate records of294 atLevel1, not the final full-roster/AI/Level100 gate. It is not a current generated receipt for the amended complete manifest.

Next implementation should retain exact current manifest/hash and add a registry-driven executable case registry. Each entry must point to a legal obtainable final record/version/behavior, use actual native or canonical production preparation/commit (including selected Ground bridge), and assert its observable mechanical outcome plus a counter/finite or no-input boundary as appropriate. Registry equality must fail when a supported effect/status/Requirement has no executed case. A declaration, path, case ID or event-name-only check cannot satisfy outcome coverage. Generated/system/historical-only exceptions must remain explicit and tested under their actual system/restore rules, not stuffed into unrelated roster definitions.

Effects inventory: move,damage,pierce,healing,percentage-recovery,resource-change,apply-status,remove-status,return-to-turn-start,create-terrain,displace,poison,burn,bleed,barrier-change,copy-statuses,sensory,summon,damage-bonus.

First witnesses to trace for missing outcome groups: chronist.rewind-step(return-to-turn-start),frostweaver.chilling-mist(create-terrain; native selected Ground bridge),wildwarden.renewing-herbs(summon),farstrider.scouts-mark(sensory),farstrider.keen-focus(damage-bonus). Do not assume these are untested anywhere: search existing actual tests and reuse real fixtures/assertions where useful. The new completeness boundary must link final playable content to executed outcomes, not merely duplicate generic kernel tests.

Still separate: fresh hosted current-catalogue/Owner-edit reconciliation and whole-catalogue timing policy; actual class/pair four-Skill cycles/realAI/Level100 balance; native/browser/Atlas/consumer prose/color. These remain release gates even after a complete tag-outcome registry.
