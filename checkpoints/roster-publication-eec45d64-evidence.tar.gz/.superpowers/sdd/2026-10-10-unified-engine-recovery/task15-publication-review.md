# Single combined publication-boundary review

Reviewer: /root/roster_publication_boundary_review, gpt-6-astra, High, read-only.
Range:933e496cdb892119dfece6182c7771cb4268d370..41439a0f05eaeaba9cb61995b3ccff6061588509.
Result:0Critical/2Important/0Minor; ready with fixes for this bounded checkpoint only.

Strengths: bounded exact5metadata amendments at reviewed head; existing executor/capture with strict native+canonical validation; actual local publication/current+pinned resolver tests; genuine canonical restore/native/AI outcomes; honest hosted/browser/balance limits.

I1 authoring-service.ts:439: essenceCombatSkill calls assertUsableEssence and throws for disabled root or nested Skill outside validation exception handler. Reviewer reproduced actual RangeError. Separate mechanics selection from runtime usability; cover native/canonical disabled flags and invalid canonical root/partial Cleanse/identity/media/version/forbidden injection.

I2 gameplay-tags.ts:105: adding Covert to positive classifier changes historical absent-mode settlement because native projection/commit include Suppress based on Cleanse label (actions-legacy.ts:4449,5235). Real-engine base/head comparison removed Covert+Suppress versus only Covert. Preserve historical behavior through explicit compatibility distinction; cover captured/delayed old/new definitions.

Declined to judge, all carried open with per-item reason/cost in the committed report: earlier picker/broader branch; canonical derivedTags/editorial consumers; hosted SQL/CAS/current catalogue and Owner edits; native browser/accessibility/physical layout; complete tags/roster/AILevel100/twelve rounds; inherited Atlas motion; merge/deploy/activation/final acceptance.

Parent assessment: both Important findings valid. One scoped RED→GREEN fix pass, no reviewer rerun. Exact ten total packet-mode amendments (original5 narrow +5 explicit positive) and nine affected Resonance signatures are structurally verified. Native disabled nested Skill keeps its preexisting structured invalid result; runtime usability has not been globally weakened. Final whole-source gate follows fix commit.
