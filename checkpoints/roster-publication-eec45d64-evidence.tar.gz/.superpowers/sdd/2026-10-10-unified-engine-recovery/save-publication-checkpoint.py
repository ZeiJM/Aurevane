import subprocess, pathlib, hashlib, json, tarfile, base64, sys

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'publication-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = 'efb6fd33e73bd8efecd3dfab64bd32da771ce6ec'
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in receipts if '20261016T053707343541Z.log' in r['log'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
assert '4019 passed (4019)' in log and '3429 passed (3429)' in log
bundle = workspace / ('roster-publication-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^933e496cdb892119dfece6182c7771cb4268d370'], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'publication-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('roster-publication-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T05*.log')):
        if file.name >= '20261016T051400':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-publication-review.md', 'task15-publication-review.diff', 'publication-bundle-verify.log', 'save-publication-checkpoint.py', 'task15-executable-tags-preflight.md']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'tests': {'vitest': 7694, 'node': 7}, 'prerequisite': '933e496cdb892119dfece6182c7771cb4268d370', 'previousArchiveCommit': '0782bbb8c80a028d23a33251cb237063f3054e4c', 'previousArchiveTree': '958b09d354a25a3d6bb2dead3999748c17b4cd48', 'manifestSha256': 'bdceab2a7547845d15f20654c1dc758a97d6c104d2dad76c906364e4504cdd9f', 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': 'Bounded local publication milestone only. Native UI/Atlas/all-tag executable evidence/whole-roster realAI-Level100/current Owner edits/hosted CAS remain OPEN; no hosted write, activation, merge or deployment.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
