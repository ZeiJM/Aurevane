from pathlib import Path
import hashlib,json,subprocess,sys
w=Path('.superpowers/sdd/2026-10-10-unified-engine-recovery')
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
trace=w/'earned-summon-actual-cycles-frozen.jsonl'
rows=[json.loads(s) for s in trace.read_text().splitlines()]
kinds=['authored-child-actions','native-ai-support','finite-expiry','enemy-defeat:ai','enemy-defeat:canonical','enemy-defeat:native-player','occupied-spawn-and-repeat']
assert len(rows)==28 and {(x['kind'],x['level'],x['context']) for x in rows}=={(k,l,c) for k in kinds for l in [1,100] for c in ['pve','pvp']}
summary=[]
for x in rows:
 assert x['seed']==1
 stages=x['stages'];spawn=next(s for s in stages if s['label']=='spawn');state=spawn['state'];child=state['effectState']['summons'][0];cid=child['combatantId'];owner=child['ownerCombatantId']
 assert child['sourceSkillVersion']==7 and child['profile']['maxHp']==36 and child['profile']['maxMp']==12 and child['profile']['lifetimeTurns']==5
 units=lambda s:{u['id']:u for u in s['tactical']['battle']['combatants']}
 p=units(state)[owner]
 assert next(r['current'] for r in p['temporaryResources'] if r['key']=='p3.skill-cooldown.wildwarden.renewing-herbs')==5
 assert [(e['event'],e['amount']) for e in spawn['events'] if e['event'] in ['ap_spent','mp_spent']]==[('ap_spent',50),('mp_spent',6)]
 assert any(s['abilityId']=='wildwarden.renewing-herbs' and s['contentVersion']==7 for s in state['capturedAbilitySources'])
 events=[e for s in stages for e in s['events']]
 for i,s in enumerate(stages):
  for e in s['events']:
   if e['event']=='healing_applied':
    before=units(stages[i-1]['state'])[e['targetCombatantId']];after=units(s['state'])[e['targetCombatantId']]
    assert e['amount']==min(before['maxHp']-before['hp'],max(1,before['maxHp']*4//100)) and after['hp']==before['hp']+e['amount']
   if e['event']=='summon_ability_used':
    assert e['combatantId']==cid and s['state']['tactical']['battle']['currentTurn']['combatantId']==cid
    assert any(v['event']=='action_economy_spent' and v['amount']==45 and v['remaining']==55 for v in s['events'])
 actions=[(e['turnNumber'],e['actionId']) for e in events if e['event']=='summon_ability_used']
 assert len({t for t,_ in actions})==len(actions)
 last=stages[-1]['state']
 if x['kind']=='authored-child-actions':
  assert [a for _,a in actions]==['wildwarden.verdant-stalker.verdant-mend','wildwarden.verdant-stalker.thorn-rake']
  assert any(e['event']=='damage_applied' and e['sourceCombatantId']==cid and e['hpBefore']>e['hpAfter'] for e in events)
 if x['kind']=='native-ai-support':assert [a for _,a in actions]==['wildwarden.verdant-stalker.verdant-mend']
 if x['kind'].startswith('enemy-defeat') or x['kind']=='finite-expiry':
  reason='summon_expired' if x['kind']=='finite-expiry' else 'summon_defeated'
  assert sum(e['event']==reason for e in events)==1
  assert cid not in units(last) and not any(s['combatantId']==cid for s in last['effectState']['summons'])
  for group in [last['tactical']['placements'],last['statBridge']['combatants'],last['turnTriggerState']['combatants']]:assert not any(r['combatantId']==cid for r in group)
  assert last['tactical']['battle']['lifecycle']=='active' and units(last)[owner]['hp']>0
  assert next(p['position'] for p in last['tactical']['placements'] if p['combatantId']==owner)=={'x':1,'y':2}
  if reason=='summon_expired':assert sum(s['label']=='end:'+cid for s in stages)==5
 summary.append({'kind':x['kind'],'level':x['level'],'context':x['context'],'stages':len(stages),'summonActions':actions,'lifecycle':last['tactical']['battle']['lifecycle']})
manifest=Path('docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json');assert sha(manifest)=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
hashes=json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes']
for p,d in hashes.items():assert sha(Path(p))==d
base='d34ddeba83469f9295af699f661555c98037f36c';source=(w/'earned-summon-tested-source.txt').read_text().strip()
assert set(git('diff','--name-only',base,source).splitlines())=={'packages/game-core/src/combat/combat-ability-command.ts','apps/web/src/server/battle/roster-legal-summon-cycles.test.ts','packages/game-core/src/combat/pv1f-action-economy.ts','packages/game-core/src/combat/combat-summon-command-cleanup.test.ts'}
command='packages/game-core/src/combat/combat-ability-command.ts'
evidenceSource=(w/'earned-summon-matrix-source.txt').read_text().strip()
assert git('diff','--name-only',evidenceSource,source).splitlines()==['packages/game-core/src/combat/combat-summon-command-cleanup.test.ts']
assert git('diff','--numstat',evidenceSource,source).splitlines()==['1\t0\tpackages/game-core/src/combat/combat-summon-command-cleanup.test.ts']
result={'source':source,'traceSource':evidenceSource,'matrixSource':evidenceSource,'evidenceRuntimeMatchesTestedSource':True,'base':base,'traceRows':len(rows),'traceBytes':trace.stat().st_size,'traceSha256':sha(trace),'traceSummary':summary,'runtimeChangedPaths':[command,'packages/game-core/src/combat/pv1f-action-economy.ts'],'runtimeContentHelpersAndPriorFixturesUnchanged':False,'rosterManifestSha256':sha(manifest),'protectedHashesUnchanged':hashes,'commandOldSha256':hashlib.sha256(subprocess.check_output(['git','show',base+':'+command])).hexdigest(),'commandNewSha256':sha(Path(command)),'deploymentLockBlob':git('rev-parse','HEAD:apps/web/vercel.json')}
assert result['deploymentLockBlob']=='b8a4e0e3c57b95a8da49c05d1fe5f60ba2181b5f'
matrix=w/'earned-summon-matrix-frozen.jsonl'
if matrix.exists() and "--trace-only" not in sys.argv:
 m=[json.loads(s) for s in matrix.read_text().splitlines()];assert len(m)==289 and len({x['kit'] for x in m})==289
 assert all(x['maximumRounds']==4 and x['seed']==12345 and x['level']==100 and x['context']=='pvp' and x['commands'] and (x['actualRound']>4 or x['lifecycle']=='completed') for x in m)
 result['boundedMatrix']={'rows':len(m),'bytes':matrix.stat().st_size,'sha256':sha(matrix),'maximumRounds':4,'fullMatchBalance':False}
(w/('earned-summon-trace-audit.json' if '--trace-only' in sys.argv else 'earned-summon-preservation.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['traceSummary','protectedHashesUnchanged']}))
