import subprocess, pathlib, hashlib, json, tarfile, base64, sys, re

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'ground-roster-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = (workspace / 'ground-roster-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
counts = re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed', log)
assert len(counts) == 7 and sum(int(n) for _, n in counts) >= 8113
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
prerequisite = '7e7b1def59c81398d6698c8452da02e4e2f4cb3b'
bundle = workspace / ('ground-roster-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + prerequisite], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'ground-roster-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('ground-roster-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T*.log')):
        if file.name >= '20261016T100200':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-ground-materialization-review.md', 'task15-ground-materialization-review.diff', 'task15-next-cycle-build-preflight.md', 'audit-ground-materialization.py', 'ground-roster-tested-source.txt', 'ground-roster-bundle-verify.log', 'save-ground-roster-checkpoint.py']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

manifest = root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'tests': {'vitest': sum(int(n) for _, n in counts), 'node': 7}, 'prerequisite': prerequisite, 'previousArchiveCommit': '741ba9782298bc8621a6ddac85607f8a0d167baf', 'previousArchiveTree': '2194dcd660287f826a1906c3eea48020c259e66c', 'manifestSha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': 'Exact3selected Ground proposals materialized;preexistingafterfields/prices/targets/versions/payloads preserved,other291exact. Actualcapture/publication/editor/readers/sharedplayercontroller/AI/entryexpiry/source-removal/Airborne/Steam/terminal tested. Geometry2 Fire Ground intent fixed throughsharedpolicycapability;Geometry3authoredcategories/nativehistory retained. No hosted publication/activation/merge/deployment. Task15/16 distinctcycles/multiturnbalance/pacing/nativebrowser/fullreaders/Owneredits-hostedCAS/Atlas remainOPEN. See committed report for actual final gate/review/rulings and deferred minors.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
