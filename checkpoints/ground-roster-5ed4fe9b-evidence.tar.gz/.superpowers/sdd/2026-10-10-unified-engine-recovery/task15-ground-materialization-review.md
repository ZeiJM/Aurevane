# Combined Ground materialization review

Fresh reviewer: /root/ground_materialization_review, gpt-6-astra High, read-only.
Range: 7e7b1def59c81398d6698c8452da02e4e2f4cb3b..e9e0042d2107a3b9e4b19cb7751750b54d86808e.
Frozen tree: 53bd4dd3b73750284652128cc9d1ce0e614e0986.

Critical0 / Important0 / new Minor0. No correction requested. Prior five deferred Minors not reopened. No suites or mutations by reviewer.

Reviewer independently checked parsed manifest: exactly3 changed records,291others identical, all preexisting after fields preserved, new entry IDs/payloads equal the selected plans, manifest hash matches. Shared Fire predicate respects geometry2/policy boundary and preserves geometry3 categories; owner projection exposes only capability, controller uses captured authority, AI change applies only to persistent Ground groups. Actual captures replace synthetic reconstruction. Tests exercise capture/execution/local publication/components/editor callbacks, and report distinguishes browser/hosted acceptance. Explicit Instant Cleanse and actual9/11entry damage are honest.

## Individual reviewer exclusions and parent rulings

1. Final: Ruling: Final repository gate — Accept the actual frozen-source full check, exit0, with8113Vitest and7Node tests, formatting/lint/types/builds; the reviewer need not duplicate it — Cost if wrong: unrelated integration regression if the receipt or source attribution is wrong.

2. Final: Ruling: Native browser interaction — Keep keyboard/pointer/touch/mobile/zoom acceptance open; component and controller tests establish only their actual boundaries, and the known unavailable browser is not a basis for reinstall/tunnel loops — Cost if wrong: usable adapter behavior could still fail in real input flows.

3. Final: Ruling: Living Atlas/layout acceptance — Keep visual/layout/accessibility acceptance open; static rendering cannot prove the real dimensions or motion bound — Cost if wrong: clipping, accessibility or layout defects could remain.

4. Final: Ruling: Hosted publication/CAS — Keep hosted persistence and concurrency open; this checkpoint proves local service publication and version capture only — Cost if wrong: hosted CAS or persistence could differ.

5. Final: Ruling: Owner-edit reconciliation — Do not publish/backfill or overwrite current Owner content; reconcile edited catalogue before any later publication — Cost if wrong: current edits could be overwritten or rejected.

6. Final: Ruling: Hosted timing-policy reconciliation — Retain explicit captured Instant remove-status evidence and keep remote timing reconciliation open — Cost if wrong: actual cleanup timing could differ from the explicit fixture.

7. Final: Ruling: Every distinct class/pair cycle — Continue Task15 distinct-cycle work; these three Ground outcomes and previous suites are not a claim for every roster cycle — Cost if wrong: other authored combinations could be ineffective or unusable.

8. Final: Ruling: Natural Level1/100 PvE/PvP balance — Keep balance, dominance and pacing open; admission and bounded opportunities establish legality rather than budgets or match outcomes — Cost if wrong: imbalance or poor pacing could remain.

9. Final: Ruling: AI strategic optimality — Accept deterministic existing Ground intent for authored persistent groups as the bounded correctness fix; do not claim optimal Enemy-versus-Ground tactics — Cost if wrong: legal but inferior choices against Airborne or other counters.

10. Final: Ruling: All custom Fire compositions — Accept the shared geometry/policy capability predicate and actual unconditional proposed groups; arbitrary conditional/modifier/movement combinations remain part of broader authoring acceptance — Cost if wrong: additional capability-versus-execution edge cases could remain.

11. Final: Ruling: Full reader/editor audit — Accept tested current Skill readers and Ground callbacks; retain broad prose/orange/derivedTags and all authoring combinations as open gates — Cost if wrong: misleading or inconsistent surfaces elsewhere.

12. Final: Ruling: Every Ground lifecycle permutation — Accept covered entry/expiry/source-removal/JSON/terminal/Airborne/Steam outcomes; do not claim exhaustive overlap/policy/transition sequence coverage — Cost if wrong: uncommon interaction defects could remain.

13. Final: Ruling: Hosted long-running/restart/load behavior — Keep operational persistence and load acceptance open; JSON restoration and local finite clocks establish narrower contracts — Cost if wrong: production-only lifecycle failures.

14. Final: Ruling: Activation/release/human acceptance — Keep activation, migration, merge, deployment and human acceptance closed; no such action is part of this bounded checkpoint — Cost if wrong: premature release would bypass remaining gates.

