import json, subprocess, pathlib, hashlib
base='7e7b1def59c81398d6698c8452da02e4e2f4cb3b'
path='docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
old=json.loads(subprocess.check_output(['git','show',base+':'+path]))
new=json.loads(pathlib.Path(path).read_text())
assert old.keys()==new.keys()
assert {k:v for k,v in old.items() if k!='records'}=={k:v for k,v in new.items() if k!='records'}
changed=[]
for before,after in zip(old['records'],new['records'],strict=True):
 if before==after: continue
 assert before['id']==after['id']
 plan=before['provisionalCanonicalGroundGroup']; native=before['after']
 assert 'ability' not in native
 actual=after['after']['ability']; group=actual['behaviors'][0]
 assert actual['schemaVersion']==1 and len(actual['behaviors'])==1
 assert group['id']==plan['behaviorId'] and group['activation']=='manual' and group['mode']=='action'
 attack='attack' in native['tags']
 assert group['classification']==('attack' if attack else 'utility')
 assert group.get('attackFamily')==('mystic' if 'mystic' in native['tags'] else 'physical') if attack else 'attackFamily' not in group
 assert set(group)=={'id','activation','mode','classification','costs','cooldown','requirements','targeting','effects','groundArea','accuracy'} | ({'attackFamily'} if attack else set())
 assert group['groundArea']==plan['groundArea']
 assert group['effects']==[{'id':e['id'],'payload':e['payload']} for e in plan['effectIdMap']]
 assert group['costs']==[{'resource':'ap','amount':native['apCost']},{'resource':'mp','amount':native['mpCost']}]
 assert group['cooldown']==native['cooldown'] and group['requirements'] is None
 assert group['targeting']=={**native['target'],'maximumSelections':1}
 assert group['accuracy']==({'kind':'fixed','chanceBasisPoints':10000} if native['accuracyMode']=='automatic' else {'kind':'standard'})
 stripped=json.loads(json.dumps(after)); del stripped['after']['ability']
 stripped['provisionalCanonicalGroundGroup']['status']=before['provisionalCanonicalGroundGroup']['status']
 stripped['requiresSurfaceWork']=before['requiresSurfaceWork']
 assert stripped==before
 changed.append(after['id'])
assert sorted(changed)==sorted(['wildwarden.venom-shot','cinderweaver.flame-burst','frostweaver.chilling-mist'])
coverage='docs/superpowers/specs/2026-10-10-roster-rebalance-coverage.json'
a=json.loads(subprocess.check_output(['git','show',base+':'+coverage]));b=json.loads(pathlib.Path(coverage).read_text())
assert b['groundExtension']['status']=='materialized-local-not-active'
b['groundExtension']['status']=a['groundExtension']['status'];assert a==b
print(json.dumps({'changedRecords':changed,'otherRecordsExactlyPreserved':291,'existingAfterFieldsExactlyPreserved':True,'manifestSha256':hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest(),'coverageChange':'status only'}))
