import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'live-amount-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'live-amount-tested-source.txt').read_text().strip();reviewed=(w/'live-amount-reviewed-source.txt').read_text().strip();base='f9367ece1880896f09ebc20c1818fe7c41823c8b'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==7 and all(p.startswith('apps/web/') or p=='packages/game-core/src/combat/combat-effect-timing.ts' or p=='docs/verification/2026-10-16-live-effect-amount-readers.md' for p in paths),paths
assert reviewed=='fec7710a7fc3964b62186ce72085ff1b19beec19' and tested=='37455c988d89852125f08cdab0678977d8b6fe3b'
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text();counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8544,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'live-amount-reader-analysis.json').read_text());assert observed['source']==tested and observed['records']==294 and observed['effects']==604 and observed['allReportsAndHtmlExactlyUnchanged'] and observed['manifestAndSixAiSourceHashesUnchanged'] and observed['rawSha256']==sha(w/'live-amount-reader-observation.json')
bundle=w/('live-amount-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'live-amount-bundle-verify.log').write_text(v.stdout)
evidence=w/('live-amount-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-live-amount-reader-brief.md', 'live-amount-combined-review-package.md', 'task15-live-amount-combined-review.md', 'live-amount-review-rulings.md', 'live-amount-repair-notes.md', 'live-amount-repair-tests.txt', 'live-amount-tested-source.txt', 'live-amount-reviewed-source.txt', 'live-amount-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-live-amount-checkpoint.py', 'live-amount-readers-diagnostic.test.tsx', 'vitest-live-amount-reader.config.ts', 'live-amount-reader-observation.json', 'live-amount-reader-analysis.json', 'analyze-live-amount-readers.py', 'live-amount-fullcheck-audit.json', 'live-amount-initial-fullcheck-audit.json', 'live-amount-initial-turbo-logs.tar.gz', 'live-amount-turbo-logs.tar.gz', 'live-effect-reader-observation.json', 'ranged-ai-analysis.json', 'finalize-live-amount-report.py', 'audit-live-amount-fullcheck.py', 'task15-live-amount-next-notes.md', 'live-amount-checkpoint-summary.txt']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T181800':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'4533a1f6969a13ab76ec0fa9f7bf28fca14332e5','previousArchiveTree':'38fabd140b85eb6ea9010ce57f67dde4eabb040b','fullCheckReceipt':gate,'tests':{'vitest':8544,'node':7},'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':(w/'live-amount-checkpoint-summary.txt').read_text().strip()}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k!='readerAudit'}))
