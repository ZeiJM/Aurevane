from pathlib import Path
import json,re,subprocess
root=Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery'
receipts=[json.loads(x) for x in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check'])
log=Path(gate['log']).read_text(); counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8544,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
assert '2 successful, 2 total' in log.rsplit('$ turbo run build',1)[-1]
source=(w/'live-amount-tested-source.txt').read_text().strip();reviewed=(w/'live-amount-reviewed-source.txt').read_text().strip()
assert reviewed=='fec7710a7fc3964b62186ce72085ff1b19beec19' and source=='37455c988d89852125f08cdab0678977d8b6fe3b'
observed=json.loads((w/'live-amount-reader-analysis.json').read_text());assert observed['source']==source and observed['allReportsAndHtmlExactlyUnchanged']
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
rulings=(w/'live-amount-review-rulings.md').read_text().split('## Every declined behavior: parent ruling, reason and cost\n',1)[1]
report=f'''# Recovery and Barrier amount readers — verified development checkpoint

Live HP/MP recovery now shows the native recorded flat base or captured percentage amount, the original percentage and resource maximum, and the remaining application count. Percentage amounts retain the modifiers captured when used; later maximum-resource or status changes do not recalculate history. Flat amounts remain explicitly before applicable recovery modifiers. Both retain the missing-resource cap. Zero is a valid captured amount; unavailable historical captures remain unavailable.

Pending recovery retains its exact recipient-specific capture. Its first application occurs on activation; subsequent applications occur at affected-turn ends. Active schedules state one application per affected-turn end and preserve the skipped-current-turn qualification. Equal amount schedules with different remaining application counts remain separate; genuinely equal rows show total and per-stack strength with per-stack counts.

Barrier shows the pending grant request or each actual remaining native pool. Partial absorption changes the displayed individual pool rather than substituting the character's aggregate Barrier. Historical pending grants say up to the requested amount and retain their maximum-HP cap. Unlike remaining pools stay separate; equal pools show total and per-stack amounts.

The existing shared reader renders these values with its gold/orange summary component and equivalent accessible text. Compact/full/All and the five previously migrated legacy battle surfaces inherit the same facts. Unsupported versions do not borrow current rules. The optional ephemeral projection copies public numeric fields individually before the existing recipient/Covert privacy boundary; no persisted schema, native operator, timing-mode function, command, cost, AI, manifest, controls, art or geometry changes.

## Evidence and review

- BASE f9367ece1880896f09ebc20c1818fe7c41823c8b → initial frozen/reviewed `{reviewed}` → final tested `{source}`. Six production/test files, **35 new cases overall**:21 initial plus14 review repairs. Core changes are confined to additive presentation facts in combat-effect-timing.ts.
- Initial TDD182414565382:14 valid missing-fact failures, two fixture errors and one guard pass. The Covert fixture incorrectly used pending concealment; a partial-depletion fixture attempted illegal self damage. Corrected182507043887:18 valid RED, one remaining self-damage fixture error and two guard passes. Initial implementation182619886524:20 pass/one same fixture error. Corrected partial depletion uses actual actor end turn and native enemy attack; temporarily removing only the new Barrier aggregation key produces valid missing-separation RED182712985512. Restored hunk passes. No gameplay was changed to accommodate fixtures.
- Initial focused896/84 GREEN182800332756, core recovery/Barrier/timing69/3 GREEN182800338608, web types182800333707 GREEN. Initial wrong-root lint182800339417 ignored web files and is not clean evidence; corrected web182911224551 and core182911228279 are zero-warning GREEN. Initial complete full check183019306300 passes **8,530 Vitest plus seven Node checks**, both builds included; no stdout-loss replay needed.
- One fresh read-only combined review: **0 Critical, 2 Important, 0 new Minor**. Parent independently accepts I1 (different application counts merged) and I2 (ordinary/subsequent recovery cadence omitted). One joint repair wave adds14 actual native cases; all14 reproduce the missing grouping/cadence at183514594355 while21 existing cases pass. All35 GREEN183528282543. Final focused **910 tests/84 files GREEN183537280194**, web types183537273307 and zero-warning lint183537270966 GREEN. No rereview, implementer agents or incidental Minor repair.
- Final exact-source full check **8,544 Vitest plus seven Node checks**, formatting, lint, all workspace types and both builds GREEN: `{Path(gate['log']).stem}`, {gate['started_utc']} → {gate['completed_utc']}. Package counts: {', '.join(name+' '+n for name,n in counts)}. Complete root build tail and package-log hash audit preserved.
- Final all294 diagnostic183559984745:294 records,297 groups,604 effects. Every named Skill report and HTML string is exactly unchanged from the preceding captured live-effect checkpoint. Observation SHA256 `{observed['rawSha256']}`. Manifest and six AI/native source hashes unchanged. No new289-case gameplay-matrix claim for this presentation-only change.

The new tests execute native HP/MP capture, actual pending and active recovery, actor end turns, native enemy damage/Barrier absorption, and public server projection before invoking the real shared report and SSR body. They verify exact recipient captures, frozen amounts, flat bases, zero, caps, independent pools, grouping, application counts, ordinary/skip cadence, Covert and input immutability. SSR is not mounted DOM, native browser, assistive-technology or physical geometry acceptance. More separate same-status rows increase exposure to the inherited duplicate-key Minor; no mounted reconciliation failure was established here.

## Open work and release boundary

The modular foundation is already live. The proposed Skill rebalance and original unfinished combat integration remain separate. Original Targeting/Move/five editable Basics/Controlled, complete controls/editors/readers/previews and native acceptance must finish before combat release. Other live strength categories and whole-action readiness, historical Chronicle readers, public Manual references and remaining prose coverage remain open. Distinct/full roster cycles, natural pacing/twelve-round balance, current Owner edits, hosted SQL/CAS, Atlas motion and human acceptance remain open. Broader Master/Staff/Players/Events/Music/world work follows combat.

No publication, activation, hosted migration, merge or deployment is made by this checkpoint. High remains sufficient for routine integration. The provisional16–30 active working hours/roughly2–4 full working days remains an uncertain working estimate, not a calendar launch promise or mechanically reduced count.

## Deferred Minors

Thirteen retained: Rewind witness origin; Supporting Shot version pin; Ongoing pair dynamic identity pin; repeated bounded AI discovery; admission double-prefix provenance; ranged negative direct-commit witness; independent defense-positive HP reconciliation; exact Arsenal history values; singular status-clock grammar; Burn ordinary tick-boundary wording; Master inline reference-button sizing; cross-status direct-input immutability witness; legacy duplicate component keys. None is incidentally repaired.

## Initial implementation rulings

1. Use the existing core presentation projection for optional facts: the native instance is available before recipient/visibility filtering, avoiding an index join. Cost if wrong: broader consumers must tolerate additive ephemeral fields; full-root and fixture equality guard them.
2. Percentage recovery exposes frozen effective amounts; flat recovery exposes dynamic base amounts, matching native modifier handling. Cost if wrong: base text cannot promise future restoration.
3. Group equal facts with total/per-stack values and per-stack counts, separating unlike strength/counts/skip clocks. Cost if wrong: native long-list/key-expiry acceptance remains required.

## Every parent set-aside ruling

{rulings}
'''
(root/'docs/verification/2026-10-16-live-effect-amount-readers.md').write_text(report)
with (w/'progress.md').open('a') as f:f.write('\n## Final live amount checkpoint verification\n'+report+'\n')
print('Wrote final verified report and ledger.')
