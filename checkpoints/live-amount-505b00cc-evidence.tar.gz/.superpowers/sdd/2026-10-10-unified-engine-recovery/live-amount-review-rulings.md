# Parent review disposition

I1 and I2 accepted Important, one repair wave. No new Minor.

## Every declined behavior: parent ruling, reason and cost

1. Final: Ruling: Exact future HP/MP after caps — Keep recorded base/capture plus missing-resource qualification; future state is not available. Cost if wrong: Actual future restoration is not forecast.

2. Final: Ruling: Combined outgoing damage — Leave the unchanged damage reader for its own bounded cohort. Cost if wrong: Combined outgoing strength remains open.

3. Final: Ruling: Conditional damage — Do not invent absent attacker/recipient context. Cost if wrong: Conditional combined strength remains open.

4. Final: Ruling: Other non-damage strength — Leave separate native categories for subsequent integration. Cost if wrong: Those category readers remain incomplete.

5. Final: Ruling: Controlled readiness — Keep unchanged captured-action ownership. Cost if wrong: Controlled readiness still needs its own acceptance.

6. Final: Ruling: Manual modifiers and controls — Keep unchanged behavior and separate integration gate. Cost if wrong: No fresh control acceptance.

7. Final: Ruling: Historical Chronicle/modal redesign — Keep existing historical caller; current amount extension is additive. Cost if wrong: Historical readers remain unfinished.

8. Final: Ruling: Old fixed Storm magnitude — Retain inherited conservative unavailable handling. Cost if wrong: Old Storm does not gain an invented magnitude.

9. Final: Ruling: Native mouse — Leave acceptance open; browser is unavailable. Cost if wrong: Mouse behavior remains unverified.

10. Final: Ruling: Native touch — Leave acceptance open; browser is unavailable. Cost if wrong: Touch behavior remains unverified.

11. Final: Ruling: Native keyboard/focus — Source tracing is insufficient for mounted acceptance. Cost if wrong: Keyboard/focus still needs native verification.

12. Final: Ruling: Assistive technology — Keep shared accessible strings; no actual AT execution. Cost if wrong: AT acceptance remains open.

13. Final: Ruling: Long reports/small screens/200% zoom — Reuse existing layout and defer physical inspection. Cost if wrong: Clipping and overflow remain unverified.

14. Final: Ruling: Button CSS geometry — No geometry changes in this amount cohort. Cost if wrong: Physical sizing remains unverified.

15. Final: Ruling: Inspection backdrop dismissal — Retain existing outside-card behavior. Cost if wrong: Outside inspection still closes the whole inspection.

16. Final: Ruling: Broader malformed persisted/pending/summon validation — Retain existing parser authority; relevant captures traced. Cost if wrong: No whole-parser re-audit.

17. Final: Ruling: Expiry/revocation/character authority/CAS/direct RPC — Keep separate Task8/16 authority gate. Cost if wrong: Hosted security acceptance remains required.

18. Final: Ruling: No input/duplicate payment/interrupted Move/attack origin — Native execution unchanged. Cost if wrong: Fresh gameplay acceptance remains required.

19. Final: Ruling: Publication/build/claim/recovery/settlement concurrency — Transactions/workers unchanged. Cost if wrong: Hosted concurrency acceptance remains required.

20. Final: Ruling: Rewind witness origin — Keep inherited Minor deferred; unrelated witness. Cost if wrong: Witness still begins at origin.

21. Final: Ruling: Supporting Shot version pin — Keep inherited Minor deferred; unrelated capture test. Cost if wrong: Version-pin coverage remains incomplete.

22. Final: Ruling: Ongoing pair dynamic identity pin — Keep inherited Minor deferred; unrelated test. Cost if wrong: Identity witness remains weaker.

23. Final: Ruling: Repeated bounded AI discovery — Keep inherited Minor deferred; AI unchanged. Cost if wrong: Redundant bounded discovery remains.

24. Final: Ruling: Admission double-prefix provenance — Keep inherited Minor deferred; admission unchanged. Cost if wrong: Duplicate prefix wording remains.

25. Final: Ruling: Ranged negative preparation/direct-commit witness — Keep inherited Minor deferred; guarded native files unchanged. Cost if wrong: Negative witness remains preparation-only.

26. Final: Ruling: Defense-positive HP reconciliation — Keep inherited Minor deferred; execution unchanged. Cost if wrong: Events lack independent HP reconciliation.

27. Final: Ruling: Exact Arsenal history values — Keep inherited Minor deferred; history unchanged. Cost if wrong: Exact history label/value coverage incomplete.

28. Final: Ruling: Singular status-clock grammar — Keep inherited Minor deferred; unrelated editorial work. Cost if wrong: Grammar defect remains.

29. Final: Ruling: Burn ordinary tick-boundary wording — Keep inherited Minor deferred; distinct from recovery cadence. Cost if wrong: Burn boundary wording remains imprecise.

30. Final: Ruling: Master reference-button sizing — Keep inherited Minor deferred; different UI owner. Cost if wrong: Master inline geometry acceptance remains open.

31. Final: Ruling: Cross-status input immutability witness — Keep inherited Minor deferred; different test cohort. Cost if wrong: Its direct-input witness remains weaker.

32. Final: Ruling: Legacy duplicate component keys — Keep inherited Minor deferred: static collision but no demonstrated mounted failure; no incidental repair. Cost if wrong: More separate same-status rows may misassociate popup state at expiry/replacement.

33. Final: Ruling: Full roster balance/gameplay cycles — Keep separate complete-cycle/balance gate. Cost if wrong: Roster balance remains unaccepted.

34. Final: Ruling: Whole Task15/16 — Bounded readers cannot close original combat integration. Cost if wrong: Original combat integration remains unfinished.

35. Final: Ruling: Owner-hosted/Atlas/human acceptance — No hosted/native evidence establishes these. Cost if wrong: Acceptance gates remain open.

36. Final: Ruling: Merge/deploy/release readiness — No release authorized by this checkpoint. Cost if wrong: Combat update remains unreleased.
