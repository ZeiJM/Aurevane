# Fresh bounded combined review

Reviewer /root/periodic_ground_reader_review, gpt-6-astra High, fork none. Read-only8cdcc9dddaf192d8a512a36930362179814b61a4..7542b6cec83bf7f87e7fdbe5c51237af863ce0a9. No suites, mutations, services, browser, delegation or rereview.

Verdict0Critical/0Important/1newMinor: Burn’s regular tick timing remains unstated while Instant labels application; Poison supplies Tick fact. Native actions-legacy6013/combat-dots660 tick at affected-unit turn end. Parent accepts grade as inherited clarity debt without a falsely promised boundary; deferred, total10Minors. No fix wave.

Inspected native-preview/edit-handler path, native units/captured HealingDown scope, Burncapturedpercent/default/zero/multihit/miss/friendly/allowance, Poison independent maxima/carry/thresholds/PushPull/relocation/old trigger policies, Ground fixed native lifetime/team/sight/Steam policies, pure input/public shape and exact same-literal native extraction. No changed native operators/branches/values/AI/fixtures requiring another289matrix. Fullroot remains parent-owned; actualall294 observation is separate static evidence.

Each considered/declined behavior has a separate parent reason/cost in periodic-review-rulings.md and progress.md, including authorities/concurrency/native/layout/fullcycle/balance/release boundaries. No merge/release/Task15 completion approval.
