from pathlib import Path
import json,hashlib,re,collections
w=Path(__file__).resolve().parent

def flattened(name):
 data=json.loads((w/name).read_text());out={}
 for row in data['records']:
  for group,report in zip(row['groups'],row['reports'],strict=True):
   for e,desc in zip(group['effects'],report['effectDescriptions'],strict=True):
    key=(row['id'],group['id'],e['id']);assert key not in out
    out[key]={'description':desc,'type':e['type'],'recipient':e['recipient']}
 return data,out
now,entries=flattened('periodic-reader-observation.json');_,previous=flattened('secondary-reader-observation.json');_,original=flattened('editorial-readers-observation.json')
assert entries.keys()==previous.keys()==original.keys()
changed=[k for k,v in entries.items() if v['description']!=previous[k]['description']]
allchanged=[k for k,v in entries.items() if v['description']!=original[k]['description']]
assert len(now['records'])==294 and len(entries)==604 and len(changed)==10 and len(allchanged)==351
byType=dict(collections.Counter(entries[k]['type'] for k in changed));assert byType=={'poison':2,'burn':7,'create-terrain':1},byType
numeric=[{'record':k[0],'group':k[1],'effect':k[2],**v} for k,v in entries.items() if re.search(r'\d',v['description'])]
out={'source':now['source'],'rawSha256':hashlib.sha256((w/'periodic-reader-observation.json').read_bytes()).hexdigest(),'records':294,'groups':sum(len(r['groups']) for r in now['records']),'effects':604,'changedFromSecondary':10,'unchangedFromSecondary':594,'changedFromSecondaryByType':byType,'changedFromOriginal':351,'unchangedFromOriginal':253,'withDigits':len(numeric),'nonDirectDamageWithDigits':sum(x['type'] not in ('damage','pierce') for x in numeric),'pierceArmorNumericCandidates':sum(x['type']=='pierce' for x in numeric),'scope':'Default-context static shared readers only. Numeric counts are inventories, not complete editorial/native acceptance. Edited unused potency is covered independently through actual Master handler integration, not these unchanged current payloads.'}
(w/'periodic-reader-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
(w/'periodic-remaining-numeric-candidates.json').write_text(json.dumps([x for x in numeric if x['type']!='damage'],indent=2)+'\n')
print(json.dumps(out))
