# Periodic/Ground/edited-status combined review and parent rulings

Fresh gpt-6-astra High read-only review8cdcc9dd..7542b6ce:0Critical/0Important/1newMinor. Parent accepts the Minor grade: Burn regular tick boundary is unstated, but the displayed Instant describes valid application and no incorrect tick boundary is promised. This is inherited clarity debt, not a demonstrated native or false-timing regression. Defer as required; no C/I fix wave and no rereview. Total10Minors. Future complete editorial/native acceptance still includes clocks.

Final: minor (deferred): Burn regular ticks lack an explicit affected-turn-end fact; application Instant and percentage sequence/duration remain truthful. Native actions-legacy6013/combat-dots660 provide the actual clock.

Final: Ruling: Retained unused potency after status-ID editing — Preserve stored metadata; native preview now suppresses irrelevant magnitude — Cost if wrong: An unsupported retained value could remain misleading on another consumer.

Final: Ruling: Historical generic percentage formatting — Native units/direction improve accuracy; captured values unchanged — Cost if wrong: A legacy text-layout assumption may need adjustment.

Final: Ruling: Historical Wet/Conductive magnitude — Native legacy Storm bonus is fixed, independently of modern authored potency — Cost if wrong: Wrong history flag could show the wrong magnitude.

Final: Ruling: Haste/Slow retained potency — Native fixed AP overrides unused metadata — Cost if wrong: Another native-unit consumer could remain misleading.

Final: Ruling: Captured Healing Down scope — Already computed preview now receives existing policy flags; both scopes covered — Cost if wrong: Another consumer might omit its policy context.

Final: Ruling: Fixed native Basic formatting — Separate truthful native authority is unchanged — Cost if wrong: Separate Basic prose acceptance remains open.

Final: Ruling: Burn backlash versus tick percentage — Separate facts/captured1875basispoint witness retain distinct values — Cost if wrong: A magnitude mix-up could misstate backlash.

Final: Ruling: Burn multi-hit/miss/friendly/allowance — Prose matches existing aggregation and trigger claims — Cost if wrong: A missing edge could misstate trigger eligibility.

Final: Ruling: Burn reapplication/Copy allowance — Original restriction remains; native behavior unchanged — Cost if wrong: A misleading reset expectation could remain elsewhere.

Final: Ruling: Zero Burn backlash — Nullish default preserves zero — Cost if wrong: A future truthiness substitution could restore the default incorrectly.

Final: Ruling: Poison independent maxima — Prose matches independent percentage/original-duration selection — Cost if wrong: A reader could otherwise expect one winning application.

Final: Ruling: Poison carry/repeated thresholds — Modulo progress and captured full reset remain identical — Cost if wrong: A later movement-clock change could drift.

Final: Ruling: Poison Push/Pull/relocation — Existing traversal semantics retained; no authority change — Cost if wrong: A displacement path could remain unverified.

Final: Ruling: Legacy Burn trigger policy — Complete old explanation remains fallback — Cost if wrong: An uninspected historical consumer could differ.

Final: Ruling: Legacy Poison trigger policies — Both historical trigger/movement combinations preserve full fallback — Cost if wrong: Another captured policy mix may need acceptance.

Final: Ruling: Nonpercentage DoTs/Bleed — Helper returns null; existing presentation retained — Cost if wrong: Another untouched explanation may remain incomplete.

Final: Ruling: Ground authored versus native lifetime — Create-terrain produces Frozen Ground with fixed native lifetime; derive from overlay constants — Cost if wrong: A future versioned terrain rule would need new context.

Final: Ruling: Ground teams policy — Independent current enemy-only/legacy both-team flag retained — Cost if wrong: Wrong context could misstate who pays surcharge.

Final: Ruling: Steam lifetime policy — Modern remaining-life versus legacy configured-life matches authority — Cost if wrong: A wrong flag could misstate lifetime.

Final: Ruling: Ground versus Steam line of sight — No applies to Frozen Ground; prose explicitly identifies Steam blocking both teams — Cost if wrong: A reader could conflate overlay effects.

Final: Ruling: Definition mutation/public leakage — Pure reads/new presentation objects; public projection covered — Cost if wrong: An uninspected transport boundary could still leak.

Final: Ruling: Constant extraction/replay — Identical literals/operators/branches; actual native79/7/fullroot plus prior289gold, no duplicate matrix warranted — Cost if wrong: Unrecognized native change would require a fresh replay.

Final: Ruling: Conditional Requirements duplicates — Queued next; unchanged in this cohort — Cost if wrong: Conditions remain repetitively described.

Final: Ruling: Four Pierce equipment-Armor duplicates — Queued next; unchanged here — Cost if wrong: Bypass values remain repetitive.

Final: Ruling: Orange references/links — No complete appearance/interaction audit — Cost if wrong: References may remain inconsistent.

Final: Ruling: Stale-browser authority — No authority-path change/exercise — Cost if wrong: Revocation acceptance remains unverified.

Final: Ruling: Alternate selected-character authority — No binding-path change/exercise — Cost if wrong: Wrong-character authority remains unverified.

Final: Ruling: Direct RPC expiry — No protected RPC exercise — Cost if wrong: Direct-call expiry may remain unverified.

Final: Ruling: Direct RPC revocation — No protected RPC exercise — Cost if wrong: Direct-call revocation may remain unverified.

Final: Ruling: Direct RPC CAS — No protected concurrency exercise — Cost if wrong: CAS races may remain unverified.

Final: Ruling: Malformed nested data — No parser change; valid readers do not replace rejection evidence — Cost if wrong: Malformed definitions may remain unverified.

Final: Ruling: Malformed captures — No capture-validation change — Cost if wrong: Invalid captures may remain unverified.

Final: Ruling: Malformed pending data — No pending-packet validation change — Cost if wrong: Invalid pending packets may remain unverified.

Final: Ruling: Malformed summons — No summon parser/execution change — Cost if wrong: Malformed summons may remain unverified.

Final: Ruling: No-input/timeout — No scheduler change/exercise — Cost if wrong: Timeout outcomes may remain unverified.

Final: Ruling: Free priming — No native prime-budget exercise — Cost if wrong: Allowance bounds may remain unverified.

Final: Ruling: Repeated events — No native event-budget exercise — Cost if wrong: Unbounded reactions may remain unverified.

Final: Ruling: Interrupted Move/reached-origin attacks — No movement authority change/exercise — Cost if wrong: Origin or interruption defects may remain.

Final: Ruling: Duplicate payment — No complete payment-path acceptance — Cost if wrong: Duplicate costs may remain unverified.

Final: Ruling: Extra turns — No turn-economy acceptance — Cost if wrong: Extra-turn paths may remain unverified.

Final: Ruling: Concurrent publication — No hosted race/rollback exercise — Cost if wrong: Publication coherence may remain unverified.

Final: Ruling: Concurrent build writes — No build race exercise — Cost if wrong: Build coherence may remain unverified.

Final: Ruling: Concurrent claims — No claim/idempotency race — Cost if wrong: Duplicate claims may remain unverified.

Final: Ruling: Concurrent recovery — No late-worker recovery exercise — Cost if wrong: Recovery races may remain unverified.

Final: Ruling: Concurrent settlement — No settlement race exercise — Cost if wrong: Duplicate settlement may remain unverified.

Final: Ruling: Long names — SSR does not establish geometry — Cost if wrong: Names may overflow.

Final: Ruling: 200% zoom — No physical zoom geometry — Cost if wrong: Layout may remain inadequate.

Final: Ruling: Native keyboard/focus — No physical focus/dismissal exercise — Cost if wrong: Keyboard usability may remain inadequate.

Final: Ruling: Mobile/touch — No native device interaction — Cost if wrong: Touch behavior may remain inadequate.

Final: Ruling: Every editor/preview/popup — Shared-path coverage is narrower than all mounted consumers — Cost if wrong: Another surface may remain stale.

Final: Ruling: Missing historical metadata — Selected policy/history fixtures are narrower than every old reader — Cost if wrong: Another fallback may remain misleading.

Final: Ruling: Full legal cycles — Reader facts and literal equivalence are not complete learned cycles — Cost if wrong: A setup/payoff may remain ineffective.

Final: Ruling: AI strategy — Planner unchanged; no new strategic acceptance — Cost if wrong: Planning weaknesses may remain.

Final: Ruling: Natural pacing — No new natural balance experiment — Cost if wrong: Sustain stalls may remain.

Final: Ruling: Twelve-round balance — Original full-roster benchmark remains open — Cost if wrong: Global pacing may remain outside target.

Final: Ruling: Fresh Owner edits — Require current release-time reconciliation — Cost if wrong: Publication could overwrite newer edits.

Final: Ruling: Atlas — Original motion bound/acceptance remains open — Cost if wrong: Motion quality remains unresolved.

Final: Ruling: Human acceptance — Require actual Owner gameplay acceptance — Cost if wrong: Gameplay feel may remain unmet.

Final: Ruling: Broader Master panels — Remain after combat package — Cost if wrong: Broader panel work remains unfinished until its stage.

Final: Ruling: Nine prior Minors — No relevant resolution; individually retain previous9 deferred items — Cost if wrong: Existing test-hardening/grammar debt remains.

Final: Ruling: Frozen full-root result — Parent accepts only actual completed output — Cost if wrong: Unchecked regressions could otherwise be accepted.

Final: Ruling: All294 observation — Parent actual155223205194 passes with10changed594unchanged explanations — Cost if wrong: Static inventory does not prove native/full editorial acceptance.

Final: Ruling: Publication — None authorized/performed — Cost if wrong: Premature content could bypass gates.

Final: Ruling: Activation — None performed — Cost if wrong: Premature activation could bypass gates.

Final: Ruling: Migration application — None performed — Cost if wrong: Hosted state could change before acceptance.

Final: Ruling: Merge — None performed — Cost if wrong: Unaccepted work could enter main.

Final: Ruling: Deployment — None performed — Cost if wrong: Unaccepted work could be released.

Prior9Minors separately retained: (1)Rewind origin witness; (2)SupportingShot version pin; (3)Ongoing pair identity pin; (4)repeated bounded AI discovery; (5)admission provenance prefix; (6)ranged negative direct-commit witness; (7)defense event/HP reconciliation; (8)Arsenal full-label/exact-history-value hardening; (9)singular elemental-duration grammar. New(10)Burn tick-boundary clarity. None incidentally fixed.
