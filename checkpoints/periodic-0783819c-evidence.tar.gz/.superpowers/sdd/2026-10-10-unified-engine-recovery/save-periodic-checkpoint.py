import subprocess,pathlib,json,re,hashlib,tarfile,base64,sys
root=pathlib.Path.cwd();w=root/'.superpowers/sdd/2026-10-10-unified-engine-recovery';payload=w/'periodic-backup-payload.json'
if len(sys.argv)>1:
 d=json.loads(payload.read_text());b=base64.b64encode(pathlib.Path(d[sys.argv[1]]['path']).read_bytes()).decode();i=int(sys.argv[2]);print(json.dumps({'chunk':b[i*12000:(i+1)*12000]}));sys.exit()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(p),'blobSha':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'chunks':(len(base64.b64encode(b))+11999)//12000}
assert not git('status','--porcelain')
head=git('rev-parse','HEAD');tested=(w/'periodic-tested-source.txt').read_text().strip();base='8cdcc9dddaf192d8a512a36930362179814b61a4'
assert all(p.startswith('docs/') for p in git('diff','--name-only',tested,head).splitlines())
paths=git('diff','--name-only',base,head).splitlines()
assert len(paths)==13 and all(p.startswith(('apps/web/src/components/character/','packages/game-core/')) or p=='docs/verification/2026-10-16-periodic-ground-reader-facts.md' for p in paths),paths
receipts=[json.loads(s) for s in (w/'verification.jsonl').read_text().splitlines()]
gate=next(r for r in reversed(receipts) if r['argv']==['pnpm','--reporter=append-only','check']);log=pathlib.Path(gate['log']).read_text()
counts=re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed',log)
assert gate['exit_code']==0 and len(counts)==7 and sum(int(n) for _,n in counts)==8374,counts
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
reviewed='7542b6cec83bf7f87e7fdbe5c51237af863ce0a9'
assert set(git('diff','--name-only',reviewed,tested).splitlines()) == {'apps/web/src/components/character/character-v5-presentation-contract.test.ts','apps/web/src/components/character/resonance-parameters.test.tsx','apps/web/src/components/character/skill-effect-timing-context.test.tsx'}
assert sha(root/'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json')=='b86cfec056bbac582810e7da80f9bc687f02518892eb5d11275fc7b5ced19f05'
for name,digest in json.loads((w/'ranged-ai-analysis.json').read_text())['sourceHashes'].items():assert sha(root/name)==digest,name
observed=json.loads((w/'periodic-reader-analysis.json').read_text());assert observed['source']==reviewed and observed['records']==294 and observed['effects']==604 and observed['changedFromSecondary']==10 and observed['changedFromOriginal']==351 and observed['rawSha256']==sha(w/'periodic-reader-observation.json')
comparison=json.loads((w/'secondary-matrix-analysis.json').read_text());assert comparison['records']==289 and comparison['commands']==8219 and comparison['allCompleteRowsIdentical'] and comparison['rawSha256']==sha(w/'secondary-restored-289.jsonl')
bundle=w/('periodic-'+head[:8]+'.bundle');subprocess.run(['git','bundle','create',str(bundle),'HEAD','^'+base],check=True)
v=subprocess.run(['git','bundle','verify',str(bundle)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=True);(w/'periodic-bundle-verify.log').write_text(v.stdout)
evidence=w/('periodic-'+head[:8]+'-evidence.tar.gz')
names=['progress.md', 'task-15-brief.md', 'task15-periodic-reader-brief.md', 'periodic-review-rulings.md', 'task15-periodic-reader-review.md', 'periodic-tested-source.txt', 'periodic-bundle-verify.log', 'verification.jsonl', 'run.py', 'save-periodic-checkpoint.py', 'finalize-periodic-report.py', 'periodic-readers-diagnostic.test.tsx', 'vitest-periodic-reader.config.ts', 'periodic-reader-observation.json', 'periodic-reader-analysis.json', 'analyze-periodic-readers.py', 'periodic-remaining-numeric-candidates.json', 'periodic-fullcheck-audit.json', 'periodic-turbo-logs.tar.gz', 'task15-conditional-pierce-reader-brief.md', 'conditional-pierce-reader-candidate.test.tsx', 'vitest-conditional-pierce-preflight.config.ts', 'secondary-matrix-analysis.json', 'secondary-restored-289.jsonl', 'ranged-ai-analysis.json', 'task15-dot-ground-reader-preflight.md', 'dot-ground-reader-preflight.test.tsx', 'edited-status-potency-preflight.test.tsx', 'vitest-edited-status-preflight.config.ts', 'vitest-dot-ground-preflight.config.ts']
with tarfile.open(evidence,'w:gz') as a:
 for p in sorted((w/'evidence').glob('20261016T*.log')):
  if p.name>='20261016T154000':a.add(p,arcname=str(p.relative_to(root)))
 for n in names:a.add(w/n,arcname=str((w/n).relative_to(root)))
d={'sourceHead':head,'sourceTree':git('rev-parse','HEAD^{tree}'),'testedSource':tested,'reviewedProductionSource':reviewed,'prerequisite':base,'previousArchiveCommit':'00c81bb9ec28a98054ae0fff3975562d1c4343df','previousArchiveTree':'458d90ebfaf3a5b0e817ab9305c39084ad927cfc','fullCheckReceipt':gate,'tests':{'vitest':8374,'node':7},'priorMatrixReference':comparison,'readerAudit':observed,'bundle':info(bundle),'evidence':info(evidence),'acceptance':'Actual Master edited-status handler no longer invents unused potency percentages; compact native units/direction and captured HealingDown preserved. Burn/Poison/Ground structured secondary facts:10 actual effects,27new cases,806 covering plus79 native DoT tests. One combined review0C0I1newMinor: ordinary Burn tick boundary deferred,10totalMinors;67individual parent rulings. Three full-gate stale unit expectations fixed tests-only12GREEN; frozen8374Vitest+7Node verified. All294 static shared readers604effects,10new351totalprosechanges. Native literals1000bps/5tiles exported without changed values/operators/branches/formulas; no fresh289claimed, preceding289/8219exactgold remains reference. Accepted manifest and all6AI/fixture hashes unchanged. Original combat/native/editorial/fullcycles/balance/Ownerhosted/Atlas/human/release and broader Master remain open. No publication/activation/migration/merge/deploy.'}
payload.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items() if k not in ('matrix','readerAudit')}))
