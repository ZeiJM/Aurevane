export default {
  resolve: { alias: { '@': '/workspace/scratch/680b26e4eb86/aurevane/apps/web/src' } },
  test: { include: ['/workspace/scratch/680b26e4eb86/aurevane/.superpowers/sdd/2026-10-10-unified-engine-recovery/periodic-readers-diagnostic.test.tsx'] },
}
