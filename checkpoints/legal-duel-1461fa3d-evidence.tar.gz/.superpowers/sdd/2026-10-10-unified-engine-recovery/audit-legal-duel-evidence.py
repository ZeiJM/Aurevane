from pathlib import Path
import json, hashlib
from collections import Counter

root = Path.cwd()
w = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
proposals = json.loads((root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json').read_text())['records']
coverage = json.loads((root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-coverage.json').read_text())
by_id = {r['id']: r for r in proposals}
expected = {}
for row in coverage['classes']:
    extension = next(r for r in proposals if r['kind'] == 'essence' and r['after']['sourceDisciplineId'] == row['disciplineId'])
    expected[row['disciplineId'] + ':approved-entry-kit'] = {'skills': row['approachableLoadout'], 'extension': extension}
for row in proposals:
    if row['kind'] != 'resonance': continue
    for primary in row['after']['disciplinePair']:
        expected[row['id'] + ':primary:' + primary] = {'skills': [s['id'] for s in row['playIdentity']['earnedFourSkillKit']], 'extension': row}
file = w / 'legal-duel-final-matrix.jsonl'
rows = [json.loads(line) for line in file.read_text().splitlines()]
assert len(rows) == 289 and len({r['kit'] for r in rows}) == 289
assert set(r['kit'] for r in rows) == set(expected)
root_actions, selected_modifiers, primes = Counter(), Counter(), Counter()
all_equipped = set()
for row in rows:
    assert (row['level'], row['context'], row['seed'], row['maximumRounds']) == (100, 'pvp', 12345, 4)
    assert row['actualRound'] > 4 or row['lifecycle'] == 'completed'
    kit = expected[row['kit']]
    assert len(row['sourceVersions']) == 2
    owner_ids = {r['actorId'] for r in row['sourceVersions']}
    assert len(owner_ids) == 2
    captured = {}
    for owner in row['sourceVersions']:
        sources = owner['sources']
        assert len(sources) == 8
        assert len([s for s in sources if s['sourceKind'] == 'basic']) == 3
        assert sorted(s['abilityId'] for s in sources if s['sourceKind'] == 'discipline-skill') == sorted(kit['skills'])
        extensions = [s for s in sources if s['sourceKind'] in ['essence', 'resonance']]
        assert [(s['abilityId'], s['sourceKind']) for s in extensions] == [(kit['extension']['id'], kit['extension']['kind'])]
        for source in sources:
            assert json.loads(source['sourceInstanceId'])[1] == owner['actorId']
            if source['sourceKind'] != 'basic':
                assert source['contentVersion'] == by_id[source['abilityId']]['after']['contentVersion']
            captured[source['sourceInstanceId']] = source
        all_equipped.update(kit['skills'])
    for unit in row['combatants']:
        if unit['id'] in owner_ids: assert unit['maxHp'] == 500
        assert 0 <= unit['hp'] <= unit['maxHp'] and 0 <= unit['mp'] <= unit['maxMp']
    for command in row['commands']:
        if command['actorId'] in owner_ids and command['abilityId'] in by_id and by_id[command['abilityId']]['kind'] != 'basic':
            assert command['abilityId'] in kit['skills'] or command['abilityId'] == kit['extension']['id']
        if command['kind'] == 'action': root_actions[command['abilityId']] += 1
        elif command['kind'] == 'ability-prime': primes[command['abilityId']] += 1
        for modifier in command['manualModifiers']:
            source = captured[modifier['sourceInstanceId']]
            assert json.loads(source['sourceInstanceId'])[1] == command['actorId']
            selected_modifiers[source['abilityId']] += 1
manual_actions = [r for r in proposals if r['kind'] == 'resonance' and any(b['activation'] == 'manual' and b['mode'] == 'action' for b in r['after']['ability']['behaviors'])]
summary = {
    'testedSource': (w/'legal-duel-tested-source.txt').read_text().strip(),
    'matrixSha256': hashlib.sha256(file.read_bytes()).hexdigest(),
    'matrixBytes': file.stat().st_size,
    'cases': len(rows),
    'classes': sum(not r['secondary'] for r in rows),
    'pairPrimaryCombinations': sum(bool(r['secondary']) for r in rows),
    'commands': sum(len(r['commands']) for r in rows),
    'lifecycles': dict(Counter(r['lifecycle'] for r in rows)),
    'equippedSkillCount': len(all_equipped),
    'skillsOutsideTheseApprovedKits': sorted(r['id'] for r in proposals if r['kind'] == 'skill' and r['id'] not in all_equipped),
    'manualActionPairCount': len(manual_actions),
    'manualActionPairsWithChosenRoot': sorted(r['id'] for r in manual_actions if root_actions[r['id']]),
    'manualActionPairsWithoutChosenRoot': sorted(r['id'] for r in manual_actions if not root_actions[r['id']]),
    'actualRootActions': dict(sorted(root_actions.items())),
    'selectedManualModifiersNotIndependentEffectProof': dict(sorted(selected_modifiers.items())),
    'actualPrimesNotIndependentReleaseProof': dict(sorted(primes.items())),
    'scope': 'One stated seed, flat5x3 adjacent single-foe Level100PvP, four natural rounds. Root selections/selected modifiers/primes are observed planner intents committed by the engine; they do not independently prove every promised effect/automatic/ongoing payoff, counter, class role, full-match balance or twelve-round pacing. No absence of an action is labeled a balance defect.'
}
(w/'legal-duel-matrix-analysis.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({k: summary[k] for k in ['testedSource','matrixSha256','cases','classes','pairPrimaryCombinations','commands','lifecycles','equippedSkillCount','manualActionPairCount']}))
print(json.dumps({'manualActionPairsWithChosenRoot':len(summary['manualActionPairsWithChosenRoot']), 'manualActionPairsWithoutChosenRoot':len(summary['manualActionPairsWithoutChosenRoot']), 'notEquippedSkillCount':len(summary['skillsOutsideTheseApprovedKits'])}))
