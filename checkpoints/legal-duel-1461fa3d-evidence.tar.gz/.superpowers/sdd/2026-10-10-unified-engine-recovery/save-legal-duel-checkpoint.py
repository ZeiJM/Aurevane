import subprocess, pathlib, hashlib, json, tarfile, base64, sys, re

root = pathlib.Path.cwd()
workspace = root / '.superpowers/sdd/2026-10-10-unified-engine-recovery'
payload = workspace / 'legal-duel-backup-payload.json'
if len(sys.argv) > 1:
    data = json.loads(payload.read_text())
    key, index = sys.argv[1], int(sys.argv[2])
    content = base64.b64encode(pathlib.Path(data[key]['path']).read_bytes()).decode()
    print(json.dumps({'chunk': content[index * 12000:(index + 1) * 12000]}))
    sys.exit()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert not git('status', '--porcelain'), 'checkpoint requires clean source'
head = git('rev-parse', 'HEAD')
tested = (workspace / 'legal-duel-tested-source.txt').read_text().strip()
assert all(p.startswith('docs/') for p in git('diff', '--name-only', tested, head).splitlines())
receipts = [json.loads(line) for line in (workspace / 'verification.jsonl').read_text().splitlines()]
receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--reporter=append-only', 'check'])
assert receipt['exit_code'] == 0
log = pathlib.Path(receipt['log']).read_text()
counts = re.findall(r'@aurevane/([^:]+):test:.*Tests\s+(\d+) passed', log)
assert len(counts) == 7 and sum(int(n) for _, n in counts) >= 8160
assert 'ℹ pass 7' in log and 'ℹ fail 0' in log
matrix_receipt = next(r for r in reversed(receipts) if r['argv'] == ['pnpm', '--filter', '@aurevane/web', 'exec', 'vitest', 'run', 'src/server/battle/roster-legal-duel-matrix.test.ts'])
assert matrix_receipt['exit_code'] == 0
assert 'Tests  289 passed (289)' in pathlib.Path(matrix_receipt['log']).read_text()
matrix = [json.loads(line) for line in (workspace / 'legal-duel-final-matrix.jsonl').read_text().splitlines()]
assert len(matrix) == 289 and len({r['kit'] for r in matrix}) == 289
assert all(r['level'] == 100 and r['context'] == 'pvp' and r['maximumRounds'] == 4 for r in matrix)

prerequisite = '5ed4fe9bc2fb6bbb331344ac92edb22dd05ec445'
bundle = workspace / ('legal-duel-' + head[:8] + '.bundle')
subprocess.run(['git', 'bundle', 'create', str(bundle), 'HEAD', '^' + prerequisite], check=True)
verified = subprocess.run(['git', 'bundle', 'verify', str(bundle)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True)
(workspace / 'legal-duel-bundle-verify.log').write_text(verified.stdout)
evidence = workspace / ('legal-duel-' + head[:8] + '-evidence.tar.gz')
with tarfile.open(evidence, 'w:gz') as archive:
    for file in sorted((workspace / 'evidence').glob('20261016T*.log')):
        if file.name >= '20261016T102700':
            archive.add(file, arcname=str(file.relative_to(root)))
    for name in ['progress.md', 'task-15-brief.md', 'verification.jsonl', 'run.py', 'task15-legal-duel-review.md', 'task15-legal-duel-review.diff', 'task15-post-duel-cycle-preflight.md', 'task15-ranged-cycle-brief.md', 'task15-ranged-cycle-draft.test.ts', 'audit-legal-duel-evidence.py', 'finalize-legal-duel-report.py', 'legal-duel-final-matrix.jsonl', 'legal-duel-matrix-analysis.json', 'legal-duel-tested-source.txt', 'legal-duel-bundle-verify.log', 'save-legal-duel-checkpoint.py']:
        file = workspace / name
        if file.exists():
            archive.add(file, arcname=str(file.relative_to(root)))

def info(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'blobSha': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'chunks': (len(base64.b64encode(data)) + 11999) // 12000}

manifest = root / 'docs/superpowers/specs/2026-10-10-roster-rebalance-proposals.json'
meta = {'sourceHead': head, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'testedSource': tested, 'fullCheckReceipt': receipt, 'fullMatrixReceipt': matrix_receipt, 'fullMatrixCases': len(matrix), 'tests': {'vitest': sum(int(n) for _, n in counts), 'node': 7}, 'prerequisite': prerequisite, 'previousArchiveCommit': '5354316edf3c0f30fcf274f10c6be8c17b2a08af', 'previousArchiveTree': '190b5f9edb32ba70743210d73437e19e5794c9af', 'manifestSha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'bundle': info(bundle), 'evidence': info(evidence), 'acceptance': 'BothactuallegalfourSkillbuilds+exclusiveexactextension,current/pinnedauthority/captures/serverstartup,realAI/executor/JSON/resourcebounds;all289Level100PvPmirrors4naturalroundsorfactualterminal;routine25mirrors. ActualMercy10andVeiled8equippedchoicesbothPrimaryLevel1/100PvE/PvP, plus4duelcontracts includingpaidmiss/genuineterminal. Original312admissionassertionspreserved. No productionbehavior/definition/price/formula/UI/hostedwrite/activation/merge/deploy. Task15/16 allindividualdistinctcycles/fullmatchbalance/lowlevelmatrix/pacing/nativebrowser/fullreaders/Owneredits-hostedCAS/Atlas/humanreleaseOPEN. See report for exactreview/gates/rulings andprior5Minors.'}
payload.write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps(meta))
