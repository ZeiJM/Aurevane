// Planned next milestone test, not part of b586c2d4 and not executed yet.
import { describe, expect, it, vi } from 'vitest'
import { commitCombatAbilityCommand, prepareCombatAbilityCommand } from '@aurevane/game-core/combat/combat-ability-command'
import { combatAbilityCommandContext } from '@aurevane/game-core/combat/combat-behavior-runtime'
import { chooseBuildAwareRecruitAiDecision, executeBuildAwareRecruitAiAction } from '@aurevane/game-core/combat/recruit-ai-build'
import { executePv1fMovement, finishPv1fTurn, PV1F_COMBAT_CONTENT, readPv1fActionEconomy } from '@aurevane/game-core/combat/pv1f-action-economy'
import { reattachStatDrivenCombatBridge, validateStatDrivenCombatEncounterState, type StatDrivenCombatEncounterState } from '@aurevane/game-core/combat/stat-driven-combat'
import { createLegalRosterDuel, legalRosterCycleKits } from './roster-legal-duel.test-utils'

vi.mock('server-only', () => ({}))
const kit = legalRosterCycleKits.find((row) => row.primary === 'farstrider' && !row.secondary)!
const cases = ([1, 100] as const).flatMap((level) => (['pve','pvp'] as const).map((context) => ({ name: `${level}:${context}`, level, context })))
function restore(state: StatDrivenCombatEncounterState) {
  const next: StatDrivenCombatEncounterState = JSON.parse(JSON.stringify(state))
  expect(validateStatDrivenCombatEncounterState(next)).toEqual([])
  return next
}
function end(state: StatDrivenCombatEncounterState) {
  const actorId = state.tactical.battle.currentTurn!.combatantId
  return restore(finishPv1fTurn(state, state.tactical.placements.find((row) => row.combatantId === actorId)!.facing).state)
}
function shot(state: StatDrivenCombatEncounterState, actorId: string, enemyId: string) {
  const source = state.capturedAbilitySources!.find((row) => row.ownerCombatantId === actorId && row.abilityId === 'farstrider.aimed-shot')!
  return { state, actorId, root: {kind:'canonical' as const,source}, selection: {kind:'unit' as const,combatantId:enemyId}, content:PV1F_COMBAT_CONTENT, context:combatAbilityCommandContext(state,source) }
}
function fire(input: ReturnType<typeof shot>) {
  expect(prepareCombatAbilityCommand(input).evaluation.legal).toBe(true)
  const before = JSON.stringify(input.state)
  const out = commitCombatAbilityCommand(input)
  expect(JSON.stringify(input.state)).toBe(before)
  return {...out,state:restore(reattachStatDrivenCombatBridge(out.state,input.state.statBridge))}
}

describe('actual legal Farstrider ranged opportunity / paid closing / paid retreat cycle', () => {
  it.each(cases)('$name keeps actual minimum range, cooldown and native walking authority', async ({level,context}) => {
    const duel = await createLegalRosterDuel({kit,level,context,seed:1,board:{width:7,height:3,positions:[{x:1,y:1},{x:4,y:1}]}})
    const [actor,enemy] = duel.participants
    let state = restore(duel.state)
    while (state.tactical.battle.currentTurn!.combatantId !== actor!.actorId) state=end(state)
    const options = {committedSkills:actor!.definitions,canonicalSources:state.capturedAbilitySources!}
    const decision=chooseBuildAwareRecruitAiDecision({state,tieBreakSeed:1,skillOptions:options})
    const {intent}=decision
    expect(intent.kind).toBe('action')
    if(intent.kind!=='action')throw new Error('Expected an owned ranged command')
    const chosen=actor!.sources.find((source)=>source.abilityId===intent.actionId)
    expect(chosen?.definition.behaviors.some((b)=>b.classification==='attack' && b.targeting!.minimumRange>=2)).toBe(true)
    const planned=executeBuildAwareRecruitAiAction(state,intent.actionId,intent.target,options,intent)
    expect(validateStatDrivenCombatEncounterState(JSON.parse(JSON.stringify(planned.state)))).toEqual([])
    const opening=fire(shot(state,actor!.actorId,enemy!.actorId))
    expect(opening.events.some((e)=>e.event==='damage_applied'&&e.targetCombatantId===enemy!.actorId)).toBe(true)
    state=end(opening.state)
    for(let turns=0;turns<12;turns++){
      if(state.tactical.battle.currentTurn!.combatantId===actor!.actorId&&prepareCombatAbilityCommand(shot(state,actor!.actorId,enemy!.actorId)).evaluation.legal)break
      state=end(state)
    }
    expect(prepareCombatAbilityCommand(shot(state,actor!.actorId,enemy!.actorId)).evaluation.legal).toBe(true)
    state=end(state)
    expect(state.tactical.battle.currentTurn!.combatantId).toBe(enemy!.actorId)
    const closing=executePv1fMovement(state,[{x:4,y:1},{x:3,y:1},{x:2,y:1}])
    expect(readPv1fActionEconomy(closing.state,enemy!.actorId)!.current).toBe(60)
    state=end(restore(closing.state))
    const deniedBefore=JSON.stringify(state)
    const denied=prepareCombatAbilityCommand(shot(state,actor!.actorId,enemy!.actorId))
    expect(denied.evaluation.legal).toBe(false)
    expect(denied.evaluation.issues).toContainEqual(expect.objectContaining({code:'target-out-of-range'}))
    expect(JSON.stringify(state)).toBe(deniedBefore)
    const movementBefore=state.tactical.battle.currentTurn!.movementRemaining
    const retreat=executePv1fMovement(state,[{x:1,y:1},{x:0,y:1}])
    expect(readPv1fActionEconomy(retreat.state,actor!.actorId)!.current).toBe(80)
    expect(retreat.state.tactical.battle.currentTurn!.movementRemaining).toBe(movementBefore-1)
    const restoredRange=fire(shot(restore(retreat.state),actor!.actorId,enemy!.actorId))
    expect(readPv1fActionEconomy(restoredRange.state,actor!.actorId)!.current).toBe(35)
  })
})
