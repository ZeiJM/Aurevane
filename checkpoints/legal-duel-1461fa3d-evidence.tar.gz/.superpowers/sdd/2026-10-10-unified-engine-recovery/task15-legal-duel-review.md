# Combined legal duel replay review

Fresh reviewer /root/legal_duel_cycle_review, gpt-6-astra High, read-only.
Range5ed4fe9bc2fb6bbb331344ac92edb22dd05ec445..b586c2d4d363d2864185b92557c920018013ff5a; tree2baa20f39dcf2d093eb1a5c6f048eaf633aa6356. All7changedfilesread; no suites, changes or hosted operations.

Critical0 / Important0 / newMinor0. Parent agrees with grades. No C/I fix pass indicated and no rereview. Prior five Minors not reopened.

Independently confirmed original encounter/assertion suffix byte-identical and unchanged default identities. Both participants have independent identities/repositories, actual four-Skill save/load/current publication/pinned restoration/canonical extension capture. V5/provenance/current policies/real startup and nonreactivating JSON restore match entry points. Planner forwards actual Manual modifiers, Controlled operations and movement paths into existing executors; inputs immutable, restored states validated and resource bounds checked. Mercy earns wounded window through real attacks and requires connected positive outcomes plus actual HealingDown; paid miss has realRNG/cost/cooldown/noHPchange. Veiled uses ManaShield, pays70AP/net2MP, removesGuarded/grantsfiniteCovert/laterrejects. Horizon does not fabricate terminal; separateLevel1Vanguardrequiresgenuinedefeat/event/rejection. Routine25versusexplicit289/Turboenv boundary and localfictionalJSONL evidence accurately described. No claim of Task15/16/release completion.

## Individual parent rulings on reviewer exclusions

Final: Ruling: Final root check — Accept the frozen-source actual receipt104539928232, exit0,8160Vitest+7Node plusformat/lint/types/builds; reviewer does not duplicate the parent run — Cost if wrong: unrelated integration regression if the source/receipt attribution is wrong.

Final: Ruling: Final289mirror gate — Require the final-source explicit gate and its complete289-row evidence audit before checkpoint finalization; the earlier653.84-second capture-only baseline cannot substitute — Cost if wrong: a regression introduced by real startup activation or final trace changes could remain.

Final: Ruling: All153class and136pair cycles — Keep individual setup/payoff/counter acceptance open; two directed choices plus bounded mirrors do not establish all cycles, and these approved kits equip94of136Skills — Cost if wrong: missing or ineffective authored cycles could be overlooked.

Final: Ruling: Ranged/kiting/ally/formation/elevation roles — Name the flat5x3 adjacent single-foe limitation explicitly and retain role-friendly scenarios as open; observed FarstriderBasic-only and WildwardenBasic/FieldRemedy choices are not class weakness or balance conclusions — Cost if wrong: unjustified AI or price changes from an unsuitable opportunity.

Final: Ruling: Full-match balance and12round pacing — Keep completed-encounter distributions, more seeds/contexts, sustain and long-cycle dominance open; no forced completion or formula/price changes — Cost if wrong: unbalanced or slow/degenerate gameplay could ship.

Final: Ruling: Complete AI strategic quality — Accept actual planner/executor integration but retain comprehensive tactics/Modifier/Controlled utilization as open; baseline movement only reduces approach distance, so deliberate ranged spacing needs an explicit strategy judgment — Cost if wrong: legal but inferior choices could conceal intended class roles.

Final: Ruling: Complete counter/interruption/history matrix — Accept only the named cooldown/miss/HealingDown/concealment and genuine terminal contracts here; existing earlier mechanics suites remain evidence at their actual narrower boundaries — Cost if wrong: Barrier/lethal/source-removal/queued/idle-timeout or other legal-kit combinations could fail.

Final: Ruling: Progression and advanced prerequisites — Treat learned/mastered records as seeded fixture facts, retain actual acquisition/award/prerequisite acceptance separately, and preserve eligibility without new grants — Cost if wrong: unearned or inaccessible content could be mistaken for a normal progression route.

Final: Ruling: Native browser and editorial consumers — Keep actual browser/input and broad prose/orange/editor/reader acceptance open; no UI change is part of this test milestone and known browser unavailability does not justify repeating failed install/tunnel loops — Cost if wrong: inaccessible or misleading real input/readers could remain.

Final: Ruling: Hosted authority/persistence/CAS/operations — Keep SQL transactions/concurrent receipts/restart/load acceptance open; local in-memory services and JSON restore establish narrower contracts — Cost if wrong: hosted-only integrity or lifecycle failures could remain.

Final: Ruling: Current Owner edits and release compatibility — Perform the final main refresh and preserve current hosted Owner edits; no publication/reconciliation/backfill/merge/deploy is authorized by this evidence — Cost if wrong: stale publication could overwrite edits or bypass release reconciliation.

Final: Ruling: Human gameplay acceptance — Keep experiential uniqueness/enjoyment and human acceptance open; never infer it from deterministic replays — Cost if wrong: mechanically legal but unsatisfying play could be declared accepted.

## Prior deferred Minors

Final: minor (deferred): Rewind prime witness starts at its origin; separate Controlled anchor evidence exists.

Final: minor (deferred): Supporting Shot fixture does not pin its version.

Final: minor (deferred): Literal Ongoing pair fixture does not pin its dynamic pair ID.

Final: minor (deferred): AI repeats bounded route/target discovery across candidate modifier bundles; no demonstrated per-command timeout.

Final: minor (deferred): Original admission fixture passes a prefixed actor ID to the character factory, yielding double-prefixed provenance; numeric stats unchanged.

